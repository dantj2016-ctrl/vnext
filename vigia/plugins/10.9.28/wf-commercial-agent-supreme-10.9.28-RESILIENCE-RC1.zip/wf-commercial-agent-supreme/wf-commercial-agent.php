<?php
/**
 * Plugin Name: Website Factory — Commercial Agent
 * Description: Website Factory Commercial Agent: stable config-driven WhatsApp effect plane with transactional outbox, lifetime D0 idempotency, strict real spacing, per-lead media template capability, gated approved-template follow-up, owner/opt-out/payment fences, Kapso/Meta transport, InfinitePay verification and protected observability.
 * Version: 10.9.28-RESILIENCE-RC1
 * Author: Daniel Freire
 * Requires at least: 6.5
 * Requires PHP: 8.0
 */

if (!defined('ABSPATH')) exit;

define('WFCA_VERSION', '10.9.28-RESILIENCE-RC1');
define('WFCA_SCHEMA_VERSION', '10.4.0');
define('WFCA_DIR', plugin_dir_path(__FILE__));
define('WFCA_URL', plugin_dir_url(__FILE__));
define('WFCA_NS', 'website-factory/v1');

require_once WFCA_DIR . 'includes/class-wfca-util.php';
require_once WFCA_DIR . 'includes/class-wfca-db.php';
require_once WFCA_DIR . 'includes/class-wfca-airtable.php';
require_once WFCA_DIR . 'includes/class-wfca-ownership.php';
require_once WFCA_DIR . 'includes/class-wfca-kapso.php';
require_once WFCA_DIR . 'includes/class-wfca-transport.php';
require_once WFCA_DIR . 'includes/class-wfca-infinitepay.php';
require_once WFCA_DIR . 'includes/class-wfca-commercial-context.php';
require_once WFCA_DIR . 'includes/class-wfca-luna-brain-v2.php';
require_once WFCA_DIR . 'includes/class-wfca-openai.php';
require_once WFCA_DIR . 'includes/class-wfca-alerts.php';
require_once WFCA_DIR . 'includes/class-wfca-engine.php';
require_once WFCA_DIR . 'includes/class-wfca-rest.php';
require_once WFCA_DIR . 'includes/class-wfca-admin.php';

final class WFCA_Plugin {
    public static function init(): void {
        add_filter('cron_schedules', [__CLASS__, 'cron_schedules']);
        add_action('wfca_minute_tick', ['WFCA_Engine', 'tick']);
        add_action('wfca_process_inbound', ['WFCA_Engine', 'process_inbound'], 10, 1);
        add_action('wfca_verify_order', ['WFCA_Engine', 'verify_order'], 10, 1);
        add_action('wfca_deliver_alert', ['WFCA_Alerts', 'deliver_one'], 10, 1);
        add_action('rest_api_init', ['WFCA_REST', 'register']);
        add_action('admin_menu', ['WFCA_Admin', 'menu']);
        add_action('admin_init', ['WFCA_Admin', 'actions']);
        add_action('init', [__CLASS__, 'ensure_schedule']);
        add_action('init', ['WFCA_DB', 'maybe_upgrade']);
    }

    public static function activate(): void {
        WFCA_DB::install();
        if (get_option('wfca_local_mode', null) === null) {
            update_option('wfca_local_mode', 'SHADOW', false);
        }
        self::ensure_schedule();
        update_option('wfca_activated_version', WFCA_VERSION, false);
    }

    public static function deactivate(): void {
        $ts = wp_next_scheduled('wfca_minute_tick');
        while ($ts) {
            wp_unschedule_event($ts, 'wfca_minute_tick');
            $ts = wp_next_scheduled('wfca_minute_tick');
        }
    }

    public static function cron_schedules(array $schedules): array {
        $schedules['wfca_every_minute'] = [
            'interval' => 60,
            'display' => 'WFCA Every Minute',
        ];
        return $schedules;
    }

    public static function ensure_schedule(): void {
        if (!wp_next_scheduled('wfca_minute_tick')) {
            $due=time()+20;
            wp_schedule_event($due, 'wfca_every_minute', 'wfca_minute_tick');
            update_option('wfca_tick_due_at',gmdate('c',$due),false);
        } elseif (!get_option('wfca_tick_due_at','')) {
            $next=wp_next_scheduled('wfca_minute_tick');
            if ($next) update_option('wfca_tick_due_at',gmdate('c',(int)$next),false);
        }
    }
}

register_activation_hook(__FILE__, ['WFCA_Plugin', 'activate']);
register_deactivation_hook(__FILE__, ['WFCA_Plugin', 'deactivate']);
WFCA_Plugin::init();
