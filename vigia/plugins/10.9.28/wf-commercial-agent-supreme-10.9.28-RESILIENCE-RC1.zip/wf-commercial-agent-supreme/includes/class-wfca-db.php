<?php
if (!defined('ABSPATH')) exit;

final class WFCA_DB {
    public static function t(string $name): string {
        global $wpdb;
        return $wpdb->prefix . 'wfca_' . $name;
    }

    public static function maybe_upgrade(): void {
        if (get_option('wfca_schema_version') !== WFCA_SCHEMA_VERSION || get_option('wfca_followup_schema_v1') !== '1') {
            self::install();
            if (get_option('wfca_schema_error','') === '') update_option('wfca_followup_schema_v1','1',false);
        }
    }

    public static function install(): void {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $c = $wpdb->get_charset_collate();

        dbDelta("CREATE TABLE " . self::t('conversations') . " (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            phone_e164 varchar(32) NOT NULL,
            lead_record_id varchar(32) NULL,
            airtable_record_id varchar(32) NULL,
            state varchar(64) NOT NULL DEFAULT 'COMMERCIAL_NOT_ELIGIBLE',
            version bigint unsigned NOT NULL DEFAULT 1,
            permission_status varchar(32) NOT NULL DEFAULT 'UNKNOWN',
            service_window_until datetime NULL,
            human_hold tinyint(1) NOT NULL DEFAULT 1,
            conversation_owner varchar(24) NOT NULL DEFAULT 'DANIEL',
            owner_revision bigint unsigned NOT NULL DEFAULT 1,
            owner_sync_pending tinyint(1) NOT NULL DEFAULT 0,
            owner_changed_at datetime NULL,
            owner_reason varchar(220) NULL,
            luna_resumed_at datetime NULL,
            last_manual_at datetime NULL,
            initial_arm varchar(32) NULL,
            opt_out tinyint(1) NOT NULL DEFAULT 0,
            summary text NULL,
            last_inbound_at datetime NULL,
            last_outbound_at datetime NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY phone_e164 (phone_e164),
            KEY lead_record_id (lead_record_id),
            KEY state (state)
        ) $c;");

        dbDelta("CREATE TABLE " . self::t('events') . " (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            provider_event_id varchar(191) NOT NULL,
            provider_message_id varchar(191) NULL,
            provider varchar(32) NOT NULL,
            direction varchar(16) NOT NULL,
            event_type varchar(48) NOT NULL,
            origin varchar(32) NULL,
            sender_id varchar(64) NULL,
            occurred_at datetime NULL,
            phone_e164 varchar(32) NULL,
            body text NULL,
            media_json longtext NULL,
            payload_hash char(64) NOT NULL,
            signature_status varchar(32) NOT NULL DEFAULT 'UNVERIFIED',
            status varchar(32) NOT NULL DEFAULT 'RECEIVED',
            attempts int unsigned NOT NULL DEFAULT 0,
            received_at datetime NOT NULL,
            processing_started_at datetime NULL,
            processed_at datetime NULL,
            error text NULL,
            PRIMARY KEY (id),
            UNIQUE KEY provider_event_id (provider_event_id),
            KEY provider_message_id (provider_message_id),
            KEY phone_e164 (phone_e164),
            KEY status_received (status, received_at)
        ) $c;");

        dbDelta("CREATE TABLE " . self::t('outbox') . " (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            idempotency_key varchar(191) NOT NULL,
            lead_record_id varchar(32) NULL,
            conversation_id bigint unsigned NULL,
            action_type varchar(48) NOT NULL,
            body text NULL,
            content_sid varchar(128) NULL,
            owner_revision bigint unsigned NOT NULL DEFAULT 0,
            initial_arm varchar(32) NULL,
            approved_at datetime NULL,
            alert_id bigint unsigned NULL,
            destination varchar(191) NULL,
            provider varchar(32) NOT NULL DEFAULT 'KAPSO',
            delivery_status varchar(32) NULL,
            delivery_at datetime NULL,
            sent_at datetime NULL,
            content_variables longtext NULL,
            offer_code varchar(64) NULL,
            state_after varchar(64) NULL,
            related_order_id bigint unsigned NULL,
            scheduled_action_at datetime NULL,
            followup_step varchar(64) NULL,
            sync_pending tinyint(1) NOT NULL DEFAULT 0,
            status varchar(32) NOT NULL DEFAULT 'PENDING',
            attempts int unsigned NOT NULL DEFAULT 0,
            next_attempt_at datetime NULL,
            lease_owner varchar(96) NULL,
            lease_until datetime NULL,
            send_started_at datetime NULL,
            uncertain_alerted tinyint(1) NOT NULL DEFAULT 0,
            provider_message_id varchar(191) NULL,
            last_error text NULL,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY idempotency_key (idempotency_key),
            UNIQUE KEY provider_message_id (provider_message_id),
            KEY status_due (status, next_attempt_at),
            KEY lead_record_id (lead_record_id),
            KEY related_order_id (related_order_id)
        ) $c;");

        dbDelta("CREATE TABLE " . self::t('orders') . " (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            order_nsu varchar(191) NOT NULL,
            outbox_id bigint unsigned NULL,
            lead_record_id varchar(32) NULL,
            conversation_id bigint unsigned NULL,
            offer_code varchar(64) NOT NULL,
            expected_amount_cents bigint unsigned NOT NULL,
            checkout_url text NULL,
            invoice_slug varchar(191) NULL,
            transaction_nsu varchar(191) NULL,
            pending_invoice_slug varchar(191) NULL,
            pending_transaction_nsu varchar(191) NULL,
            state varchar(32) NOT NULL DEFAULT 'CREATED',
            webhook_payload longtext NULL,
            paid_amount_cents bigint unsigned NULL,
            verify_attempts int unsigned NOT NULL DEFAULT 0,
            next_verify_at datetime NULL,
            verified_at datetime NULL,
            paid_at datetime NULL,
            airtable_synced_at datetime NULL,
            error text NULL,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY order_nsu (order_nsu),
            UNIQUE KEY outbox_id (outbox_id),
            UNIQUE KEY transaction_nsu (transaction_nsu),
            KEY state_due (state, next_verify_at),
            KEY lead_record_id (lead_record_id)
        ) $c;");

        // v10 trust-boundary migration: older unverified rows may have stored
        // webhook identifiers directly in the verified columns. Preserve their
        // ability to reconcile while future webhooks use pending candidates.
        $wpdb->query("UPDATE " . self::t('orders') . "
            SET pending_transaction_nsu=transaction_nsu, pending_invoice_slug=invoice_slug,
                transaction_nsu=NULL, invoice_slug=NULL
            WHERE state IN ('WEBHOOK_RECEIVED','VERIFY_ERROR')
              AND pending_transaction_nsu IS NULL AND pending_invoice_slug IS NULL
              AND transaction_nsu IS NOT NULL AND invoice_slug IS NOT NULL");

        dbDelta("CREATE TABLE " . self::t('alerts') . " (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            alert_key varchar(191) NOT NULL,
            lead_record_id varchar(32) NULL,
            conversation_id bigint unsigned NULL,
            event_id bigint unsigned NULL,
            severity varchar(16) NOT NULL DEFAULT 'WARN',
            reason varchar(191) NOT NULL,
            prospect_message text NULL,
            status varchar(24) NOT NULL DEFAULT 'OPEN',
            email_status varchar(24) NOT NULL DEFAULT 'PENDING',
            whatsapp_status varchar(24) NOT NULL DEFAULT 'NOT_CONFIGURED',
            attempts int unsigned NOT NULL DEFAULT 0,
            next_attempt_at datetime NULL,
            last_error text NULL,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY alert_key (alert_key),
            KEY status_due (status, next_attempt_at),
            KEY lead_record_id (lead_record_id)
        ) $c;");

        if (get_option('wfca_schema_version') !== WFCA_SCHEMA_VERSION) {
            $wpdb->query("UPDATE ".self::t('outbox')." SET status='CANCELLED',last_error='LEGACY_TRANSPORT_REQUIRES_REVIEW' WHERE status IN ('PENDING','APPROVED','PENDING_APPROVAL','DRAFT_SHADOW') AND owner_revision=0");
            $wpdb->query("UPDATE ".self::t('outbox')." SET status='UNCERTAIN',last_error='LEGACY_PROCESSING_REQUIRES_REVIEW' WHERE status='PROCESSING' AND owner_revision=0");
            $wpdb->query("UPDATE ".self::t('outbox')." SET provider='TWILIO',sync_pending=1 WHERE status='SENT' AND owner_revision=0");
            $wpdb->query("UPDATE ".self::t('conversations')." SET conversation_owner='STOPPED',human_hold=1 WHERE opt_out=1 OR state='NO_INTEREST'");
            $wpdb->query("UPDATE ".self::t('conversations')." SET conversation_owner='HANDOFF_PENDING',human_hold=1 WHERE state='HUMAN_HANDOFF' AND opt_out=0");
        }
        if (!empty($wpdb->last_error)) { update_option('wfca_schema_error','SCHEMA_MIGRATION_FAILED',false);return; }
        update_option('wfca_schema_error','',false);
        if (!empty($wpdb->last_error)) { update_option('wfca_schema_error','SCHEMA_MIGRATION_FAILED',false);return; }
        update_option('wfca_schema_error','',false);
        update_option('wfca_schema_version', WFCA_SCHEMA_VERSION, false);
        update_option('wfca_followup_schema_v1','1',false);
    }

    public static function insert_inbound(array $data): array {
        return self::insert_event(array_merge($data,['direction'=>'INBOUND']));
    }

    public static function insert_event(array $data): array {
        global $wpdb;
        $provider=(string)($data['provider']??'KAPSO');
        $id=(string)$data['event_id'];
        $row=[
            'provider_event_id'=>$id,'provider_message_id'=>$data['message_sid']??null,
            'provider'=>$provider,'direction'=>$data['direction']??'INBOUND',
            'event_type'=>$data['event_type']??'MESSAGE','phone_e164'=>$data['phone']??'',
            'body'=>$data['body']??'','media_json'=>WFCA_Util::json($data['media']??[]),
            'payload_hash'=>$data['payload_hash']??hash('sha256',WFCA_Util::json($data)),
            'signature_status'=>$data['signature_status']??'VALID',
            'status'=>$data['status']??'RECEIVED','attempts'=>0,
            'received_at'=>WFCA_Util::now_mysql(),'occurred_at'=>$data['occurred_at']??WFCA_Util::now_mysql(),
            'origin'=>$data['origin']??'','sender_id'=>$data['sender_id']??'',
        ];
        $ok=$wpdb->insert(self::t('events'),$row);
        if ($ok!==false) return ['duplicate'=>false,'id'=>(int)$wpdb->insert_id];
        $existing=$wpdb->get_var($wpdb->prepare("SELECT id FROM ".self::t('events')." WHERE provider_event_id=%s",$id));
        if ($existing) return ['duplicate'=>true,'id'=>(int)$existing];
        return ['duplicate'=>false,'id'=>0,'error'=>'EVENT_PERSISTENCE_FAILED'];
    }

    public static function insert_outbound_event(string $provider_message_id,string $phone,string $body,string $event_type='MESSAGE',string $provider='KAPSO'): void {
        if ($provider_message_id==='') return;
        self::insert_event(['event_id'=>$provider.':OUT:'.hash('sha256',$provider_message_id),
            'message_sid'=>$provider_message_id,'provider'=>$provider,'phone'=>$phone,'body'=>$body,
            'direction'=>'OUTBOUND','event_type'=>$event_type,'status'=>'PROCESSED','origin'=>'cloud_api','signature_status'=>'N/A']);
    }

    public static function get_event(int $id): ?array {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::t('events') . " WHERE id=%d", $id), ARRAY_A);
        return $row ?: null;
    }

    public static function claim_event(int $id): ?array {
        global $wpdb;
        $now = WFCA_Util::now_mysql();
        $affected = $wpdb->query($wpdb->prepare(
            "UPDATE " . self::t('events') . " SET status='PROCESSING',processing_started_at=%s,attempts=attempts+1,error=NULL
             WHERE id=%d AND status='RECEIVED'",
            $now, $id
        ));
        if ($affected !== 1) return null;
        return self::get_event($id);
    }

    public static function requeue_event(int $id,string $error): void {
        global $wpdb;
        $wpdb->update(self::t('events'),[
            'status'=>'RECEIVED','processing_started_at'=>null,
            'error'=>WFCA_Util::redact_error($error,600)
        ],['id'=>$id]);
    }

    public static function exhausted_stale_events(int $stale_seconds=300,int $limit=10): array {
        global $wpdb;
        $cutoff=gmdate('Y-m-d H:i:s',time()-max(60,$stale_seconds));
        $limit=max(1,min(50,$limit));
        $rows=$wpdb->get_results($wpdb->prepare(
            "SELECT * FROM " . self::t('events') . "
             WHERE status='PROCESSING' AND processing_started_at IS NOT NULL
               AND processing_started_at<%s AND attempts>=5
             ORDER BY id ASC LIMIT %d",$cutoff,$limit
        ),ARRAY_A);
        return $rows?:[];
    }

    public static function recover_stale_events(int $stale_seconds=300): int {
        global $wpdb;
        $cutoff = gmdate('Y-m-d H:i:s', time() - max(60, $stale_seconds));
        $now = WFCA_Util::now_mysql();
        return (int)$wpdb->query($wpdb->prepare(
            "UPDATE " . self::t('events') . " SET status='RECEIVED',processing_started_at=NULL,error='RECOVERED_STALE_PROCESSING'
             WHERE status='PROCESSING' AND processing_started_at IS NOT NULL AND processing_started_at<%s AND attempts<5",
            $cutoff
        ));
    }

    public static function pending_event_ids(int $limit=8): array {
        global $wpdb;
        $limit = max(1, min(50, $limit));
        $rows = $wpdb->get_col("SELECT id FROM " . self::t('events') . " WHERE status='RECEIVED' ORDER BY id ASC LIMIT " . (int)$limit);
        return array_map('intval', $rows ?: []);
    }

    public static function finish_event(int $id, string $status, string $error=''): void {
        global $wpdb;
        $wpdb->update(self::t('events'), [
            'status' => $status,
            'processed_at' => WFCA_Util::now_mysql(),
            'processing_started_at' => null,
            'error' => $error !== '' ? WFCA_Util::redact_error($error, 600) : null,
        ], ['id' => $id]);
    }

    public static function get_conversation_by_phone(string $phone): ?array {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::t('conversations') . " WHERE phone_e164=%s", $phone), ARRAY_A);
        return $row ?: null;
    }

    public static function get_conversation(int $id): ?array {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::t('conversations') . " WHERE id=%d", $id), ARRAY_A);
        return $row ?: null;
    }

    /** Materialize an already-read Airtable conversation snapshot locally. */
    public static function materialize_remote_snapshot(int $id, array $remote): bool {
        global $wpdb;
        $owner=(string)($remote['Conversation Owner']??'');
        $revision=(int)($remote['Owner Revision']??0);
        if (!in_array($owner,WFCA_Ownership::OWNERS,true) || $revision<1) return false;
        $c=self::get_conversation($id);
        if (!$c) return false;
        $fields=[
            'conversation_owner'=>$owner,
            'owner_revision'=>$revision,
            'owner_sync_pending'=>0,
            'owner_changed_at'=>!empty($remote['Owner Changed At']) ? gmdate('Y-m-d H:i:s',strtotime((string)$remote['Owner Changed At'])) : null,
            'owner_reason'=>WFCA_Util::short_text((string)($remote['Owner Change Reason']??''),220),
            'initial_arm'=>WFCA_Ownership::is_config_arm((string)($c['initial_arm']??''))?(string)$c['initial_arm']:WFCA_Ownership::arm((string)($remote['Initial Arm']??'')),
            'state'=>(string)($remote['State']??$c['state']),
            'permission_status'=>(string)($remote['WhatsApp Permission Status']??$c['permission_status']),
            'opt_out'=>!empty($remote['Opt Out']) ? 1 : 0,
            'human_hold'=>($owner==='LUNA' && empty($remote['Opt Out']) && ($remote['State']??'')!=='OPT_OUT') ? 0 : 1,
            'updated_at'=>WFCA_Util::now_mysql(),
        ];
        if (empty($remote['Enabled'])) $fields['human_hold']=1;
        return $wpdb->update(self::t('conversations'),$fields,['id'=>$id])!==false;
    }

    public static function upsert_conversation(string $phone, array $fields): array {
        global $wpdb;
        $existing = self::get_conversation_by_phone($phone);
        if ($existing) {
            if (!empty($existing['initial_arm'])) unset($fields['initial_arm']);
            if (($existing['conversation_owner']??'DANIEL')!=='LUNA') {
                $fields['human_hold']=1;
                if (isset($fields['state']) && !in_array($fields['state'],['OPT_OUT','NO_INTEREST','HUMAN_HANDOFF'],true)) unset($fields['state']);
            }
        }
        $now = WFCA_Util::now_mysql();

        if ($existing) {
            $fields['version'] = ((int)$existing['version']) + 1;
            $fields['updated_at'] = $now;
            $wpdb->update(self::t('conversations'), $fields, ['id' => (int)$existing['id']]);
            $current=self::get_conversation((int)$existing['id']) ?: [];
            if ($current && ($fields['state']??'')==='HUMAN_HANDOFF' && $current['conversation_owner']==='LUNA') {
                WFCA_Ownership::change((int)$current['id'],'HANDOFF_PENDING',(string)($fields['summary']??'ENGINE_HOLD'),(int)$current['owner_revision']);
                $current=self::get_conversation((int)$current['id'])?:[];
            }
            return $current;
        }

        $fields = array_merge([
            'phone_e164' => $phone,
            'state' => 'COMMERCIAL_NOT_ELIGIBLE',
            'version' => 1,
            'permission_status' => 'UNKNOWN',
            'human_hold' => 1,
            'conversation_owner'=>'DANIEL','owner_revision'=>1,
            'opt_out' => 0,
            'updated_at' => $now,
        ], $fields);
        $ok = $wpdb->insert(self::t('conversations'), $fields);
        if (!$ok) {
            // Another worker may have won the unique phone race.
            $existing = self::get_conversation_by_phone($phone);
            if ($existing) return $existing;
            return [];
        }
        return self::get_conversation((int)$wpdb->insert_id) ?: [];
    }

    /**
     * Rebind a local conversation from a synthetic/legacy lead to the canonical
     * Factory lead for the same phone. This does not alter owner, opt-out,
     * timestamps or payment state; callers must separately reconcile ownership
     * when an arm mismatch requires a more restrictive owner.
     */
    public static function rebind_conversation(int $id,string $lead_id,string $initial_arm=''): ?array {
        global $wpdb;
        $c=self::get_conversation($id);
        if (!$c || $lead_id==='') return null;
        $fields=['lead_record_id'=>$lead_id,'updated_at'=>WFCA_Util::now_mysql(),'version'=>(int)$c['version']+1];
        if ($initial_arm!=='') $fields['initial_arm']=$initial_arm;
        $ok=$wpdb->update(self::t('conversations'),$fields,['id'=>$id]);
        return $ok===false?null:self::get_conversation($id);
    }

    public static function recent_thread(string $phone, int $limit=8): array {
        global $wpdb;
        $limit = max(1, min(20, $limit));
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT direction,body,received_at FROM " . self::t('events') . "
             WHERE phone_e164=%s AND body IS NOT NULL AND body<>''
             ORDER BY id DESC LIMIT %d",
            $phone, $limit
        ), ARRAY_A);
        $rows = array_reverse($rows ?: []);
        foreach ($rows as &$row) {
            $row['body'] = WFCA_Util::short_text((string)$row['body'], 900);
        }
        unset($row);
        return $rows;
    }

    public static function queue(array $item): int {
        global $wpdb;
        $conv=self::get_conversation((int)($item['conversation_id']??0));
        if (!$conv) return 0;
        $now=WFCA_Util::now_mysql();
        $item=array_merge(['status'=>WFCA_Ownership::queue_status(),'attempts'=>0,
            'next_attempt_at'=>$now,'created_at'=>$now,'updated_at'=>$now,
            'owner_revision'=>(int)$conv['owner_revision'],'initial_arm'=>$conv['initial_arm']??'',
            'provider'=>'KAPSO'], $item);
        if (isset($item['content_variables']) && is_array($item['content_variables'])) $item['content_variables']=WFCA_Util::json($item['content_variables']);
        $ok=$wpdb->insert(self::t('outbox'),$item);
        if ($ok!==false) return (int)$wpdb->insert_id;
        return (int)$wpdb->get_var($wpdb->prepare("SELECT id FROM ".self::t('outbox')." WHERE idempotency_key=%s",$item['idempotency_key']));
    }

    /**
     * INITIAL-specific durable reservation. Preserves the lifetime idempotency key
     * and may re-drive only a proven-never-sent technical cancellation on the SAME row.
     * It never mints a replacement idempotency key and never revives semantic/ambiguous stops.
     */
    public static function initial_reservation_decision(array $row): string {
        $status=strtoupper(trim((string)($row['status']??'')));
        if (!empty($row['provider_message_id']) || !empty($row['sent_at']) || $status==='SENT') return 'CONSUMED';
        if (!empty($row['send_started_at']) || $status==='UNCERTAIN') return 'AMBIGUOUS';
        if (in_array($status,['PENDING','APPROVED','PENDING_APPROVAL','PROCESSING'],true)) return 'ACTIVE';
        $safe=['OWNER_CHANGED','OWNER_REVISION_CHANGED','OWNER_CHANGED_DURING_READ'];
        if ($status==='CANCELLED' && in_array((string)($row['last_error']??''),$safe,true)) return 'SAFE_REDRIVE';
        return 'TERMINAL';
    }

    public static function queue_initial_idempotent(array $item): array {
        global $wpdb;
        $key=trim((string)($item['idempotency_key']??''));
        if ($key==='') return ['ok'=>false,'queued'=>false,'error'=>'INITIAL_IDEMPOTENCY_KEY_MISSING'];
        $conv=self::get_conversation((int)($item['conversation_id']??0));
        if (!$conv) return ['ok'=>false,'queued'=>false,'error'=>'INITIAL_CONVERSATION_MISSING'];

        $existing=self::get_outbox_by_idempotency_key($key);
        if (!$existing) {
            $id=self::queue($item);
            if ($id<=0) return ['ok'=>false,'queued'=>false,'error'=>'INITIAL_QUEUE_INSERT_FAILED'];
            $existing=self::get_outbox($id);
            if (!$existing) return ['ok'=>false,'queued'=>false,'error'=>'INITIAL_QUEUE_READBACK_FAILED'];
        }

        if ((string)($existing['action_type']??'')!=='TEMPLATE_INITIAL') {
            return ['ok'=>false,'queued'=>false,'id'=>(int)$existing['id'],'error'=>'INITIAL_IDEMPOTENCY_ACTION_MISMATCH'];
        }
        if ((string)($existing['lead_record_id']??'')!==(string)($item['lead_record_id']??'')) {
            return ['ok'=>false,'queued'=>false,'id'=>(int)$existing['id'],'error'=>'INITIAL_IDEMPOTENCY_LEAD_MISMATCH'];
        }
        if ((int)($existing['conversation_id']??0)!==(int)($item['conversation_id']??0)) {
            return ['ok'=>false,'queued'=>false,'id'=>(int)$existing['id'],'error'=>'INITIAL_IDEMPOTENCY_CONVERSATION_MISMATCH'];
        }

        $decision=self::initial_reservation_decision($existing);
        if ($decision==='ACTIVE') {
            return ['ok'=>true,'queued'=>true,'id'=>(int)$existing['id'],'disposition'=>'ACTIVE_EXISTING'];
        }
        if ($decision==='CONSUMED') {
            return ['ok'=>true,'queued'=>false,'id'=>(int)$existing['id'],'disposition'=>'CONSUMED'];
        }
        if ($decision==='AMBIGUOUS') {
            return ['ok'=>false,'queued'=>false,'id'=>(int)$existing['id'],'error'=>'INITIAL_OUTBOX_AMBIGUOUS'];
        }
        if ($decision!=='SAFE_REDRIVE') {
            return ['ok'=>false,'queued'=>false,'id'=>(int)$existing['id'],'error'=>'INITIAL_OUTBOX_TERMINAL_NOT_REDRIVEABLE'];
        }

        $now=WFCA_Util::now_mysql();
        $lease_until=(string)($existing['lease_until']??'');
        if (!empty($existing['lease_owner']) || ($lease_until!=='' && strtotime($lease_until.' UTC')>time())) {
            return ['ok'=>false,'queued'=>false,'id'=>(int)$existing['id'],'error'=>'INITIAL_OUTBOX_LEASE_ACTIVE'];
        }

        $vars=$item['content_variables']??null;
        if (is_array($vars)) $vars=WFCA_Util::json($vars);
        $new_status=(string)($item['status']??WFCA_Ownership::queue_status());
        if (!in_array($new_status,['PENDING','PENDING_APPROVAL','APPROVED'],true)) $new_status='PENDING';
        $safe_reason=(string)($existing['last_error']??'');
        $changed=$wpdb->query($wpdb->prepare(
            "UPDATE ".self::t('outbox')." SET status=%s,lead_record_id=%s,conversation_id=%d,content_sid=%s,content_variables=%s,owner_revision=%d,initial_arm=%s,state_after=%s,provider=%s,next_attempt_at=%s,lease_owner=NULL,lease_until=NULL,approved_at=NULL,last_error=%s,updated_at=%s
             WHERE id=%d AND status='CANCELLED' AND last_error=%s AND send_started_at IS NULL AND provider_message_id IS NULL AND sent_at IS NULL AND (lease_owner IS NULL OR lease_owner='') AND (lease_until IS NULL OR lease_until<%s)",
            $new_status,(string)($item['lead_record_id']??''),(int)($item['conversation_id']??0),(string)($item['content_sid']??''),(string)$vars,
            (int)$conv['owner_revision'],(string)($conv['initial_arm']??''),(string)($item['state_after']??''),(string)($item['provider']??'KAPSO'),$now,
            'SAFE_REDRIVE:'.$safe_reason,$now,(int)$existing['id'],$safe_reason,$now
        ));
        if ($changed!==1) return ['ok'=>false,'queued'=>false,'id'=>(int)$existing['id'],'error'=>'INITIAL_OUTBOX_REDRIVE_CONFLICT'];
        $fresh=self::get_outbox((int)$existing['id']);
        if (!$fresh || !in_array((string)$fresh['status'],['PENDING','PENDING_APPROVAL','APPROVED'],true)) {
            return ['ok'=>false,'queued'=>false,'id'=>(int)$existing['id'],'error'=>'INITIAL_OUTBOX_REDRIVE_READBACK_FAIL'];
        }
        return ['ok'=>true,'queued'=>true,'id'=>(int)$existing['id'],'disposition'=>'SAFE_REDRIVEN_SAME_ROW'];
    }

    public static function get_outbox(int $id): ?array {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::t('outbox') . " WHERE id=%d", $id), ARRAY_A);
        return $row ?: null;
    }

    public static function get_outbox_by_provider_sid(string $sid): ?array {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::t('outbox') . " WHERE provider_message_id=%s", $sid), ARRAY_A);
        return $row ?: null;
    }

    public static function get_outbox_by_idempotency_key(string $key): ?array {
        global $wpdb;
        $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::t('outbox') . " WHERE idempotency_key=%s",$key),ARRAY_A);
        return $row ?: null;
    }

    public static function update_outbox(int $id, array $fields): void {
        global $wpdb;
        $fields['updated_at'] = WFCA_Util::now_mysql();
        $wpdb->update(self::t('outbox'), $fields, ['id'=>$id]);
    }

    public static function claim_outbox(string $worker,string $mode='ASSISTED',bool $draining=false,bool $provider_hold=false): ?array {
        global $wpdb;
        $now = WFCA_Util::now_mysql();
        $approval=$mode==='ASSISTED' ? ' AND approved_at IS NOT NULL ' : '';
        $drain=$draining ? " AND action_type NOT IN ('TEMPLATE_INITIAL','FOLLOWUP','TEMPLATE_NURTURE') " : '';
        // 10.9.28: while the Kapso balance is exhausted only e-mail alerts (no Kapso call) are claimable; nothing else burns attempts.
        if ($provider_hold) $drain.=" AND action_type='ALERT_EMAIL' ";
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . self::t('outbox') . "
             WHERE status IN ('PENDING','APPROVED') $approval $drain AND (next_attempt_at IS NULL OR next_attempt_at<=%s)
             AND (lease_until IS NULL OR lease_until<%s)
             ORDER BY
               CASE
                 WHEN action_type='TEMPLATE_INITIAL' THEN 0
                 WHEN action_type='FOLLOWUP' THEN 2
                 ELSE 1
               END ASC,
               id ASC
             LIMIT 1", $now, $now
        ), ARRAY_A);
        if (!$row) return null;

        $lease_until = gmdate('Y-m-d H:i:s', time()+180);
        $affected = $wpdb->query($wpdb->prepare(
            "UPDATE " . self::t('outbox') . " SET status='PROCESSING',lease_owner=%s,lease_until=%s,updated_at=%s
             WHERE id=%d AND status IN ('PENDING','APPROVED') $approval $drain AND (lease_until IS NULL OR lease_until<%s)",
            $worker, $lease_until, $now, (int)$row['id'], $now
        ));
        if ($affected !== 1) return null;
        return self::get_outbox((int)$row['id']);
    }

    public static function sent_sync_pending(int $limit=5): array {
        global $wpdb;
        $limit=max(1,min(20,$limit));
        $rows=$wpdb->get_results("SELECT * FROM " . self::t('outbox') . " WHERE status='SENT' AND sync_pending=1 ORDER BY id ASC LIMIT ".(int)$limit,ARRAY_A);
        return $rows?:[];
    }

    public static function begin_send(int $id): bool {
        global $wpdb;
        $now=WFCA_Util::now_mysql();
        $n=$wpdb->query($wpdb->prepare("UPDATE ".self::t('outbox')." o JOIN ".self::t('conversations')." c ON c.id=o.conversation_id
            SET o.send_started_at=%s,o.updated_at=%s
            WHERE o.id=%d AND o.status='PROCESSING' AND o.send_started_at IS NULL
            AND o.lease_until>%s AND o.owner_revision=c.owner_revision AND c.owner_sync_pending=0",$now,$now,$id,$now));
        return $n===1;
    }

    public static function uncertain_outbox(int $limit=10): array {
        global $wpdb;
        $limit=max(1,min(50,$limit));
        $rows=$wpdb->get_results("SELECT * FROM " . self::t('outbox') . "
            WHERE status='UNCERTAIN' AND uncertain_alerted=0 ORDER BY id ASC LIMIT ".(int)$limit,ARRAY_A);
        return $rows?:[];
    }

    public static function recover_stale_outbox(int $stale_seconds=600): int {
        global $wpdb;
        $cutoff = gmdate('Y-m-d H:i:s', time()-max(180,$stale_seconds));
        $now=WFCA_Util::now_mysql();
        // Safe recovery: worker died before the external send phase.
        $safe=(int)$wpdb->query($wpdb->prepare(
            "UPDATE " . self::t('outbox') . "
             SET status='PENDING',lease_owner=NULL,lease_until=NULL,last_error='RECOVERED_STALE_LEASE',updated_at=%s
             WHERE status='PROCESSING' AND send_started_at IS NULL
               AND lease_until IS NOT NULL AND lease_until<%s",$now,$cutoff
        ));
        // Ambiguous recovery: worker died after entering the external send phase.
        // Never auto-resend because Twilio may already have accepted the message.
        $uncertain=(int)$wpdb->query($wpdb->prepare(
            "UPDATE " . self::t('outbox') . "
             SET status='UNCERTAIN',lease_owner=NULL,lease_until=NULL,last_error='AMBIGUOUS_SEND_CRASH_WINDOW',updated_at=%s
             WHERE status='PROCESSING' AND send_started_at IS NOT NULL
               AND lease_until IS NOT NULL AND lease_until<%s",$now,$cutoff
        ));
        return $safe+$uncertain;
    }

    public static function mark_outbox_sent(int $id, string $sid): bool {
        global $wpdb;
        $changed=$wpdb->update(self::t('outbox'), [
            'status'=>'SENT','provider_message_id'=>$sid,'sync_pending'=>1,'sent_at'=>WFCA_Util::now_mysql(),'lease_owner'=>null,'lease_until'=>null,
            'updated_at'=>WFCA_Util::now_mysql(),'last_error'=>null
        ], ['id'=>$id]);
        return $changed!==false;
    }

    /** Returns true if terminal FAILED was reached. */
    public static function retry_outbox(array $row, string $error, int $max_attempts=5): bool {
        global $wpdb;
        $attempts = ((int)$row['attempts']) + 1;
        $error = WFCA_Util::redact_error($error, 500);
        if ($attempts >= $max_attempts) {
            $wpdb->update(self::t('outbox'), [
                'status'=>'FAILED','attempts'=>$attempts,'last_error'=>$error,'lease_owner'=>null,'lease_until'=>null,'send_started_at'=>null,'updated_at'=>WFCA_Util::now_mysql()
            ], ['id'=>(int)$row['id']]);
            return true;
        }
        $base = min(3600, 30 * (2 ** $attempts));
        $jitter = function_exists('random_int') ? random_int(0,max(1,min(30,(int)floor($base/4)))) : 0;
        $delay = min(3600, $base + $jitter);
        $wpdb->update(self::t('outbox'), [
            'status'=>'PENDING','attempts'=>$attempts,'last_error'=>$error,'lease_owner'=>null,'lease_until'=>null,'send_started_at'=>null,
            'next_attempt_at'=>gmdate('Y-m-d H:i:s', time()+$delay),'updated_at'=>WFCA_Util::now_mysql()
        ], ['id'=>(int)$row['id']]);
        return false;
    }

    /**
     * 10.9.28: provider hold (Kapso HTTP 402). The provider rejected the call definitively (nothing was sent), so the row goes back to PENDING
     * with the send boundary cleared and WITHOUT counting an attempt. Only a row this worker holds (PROCESSING) is touched.
     */
    public static function hold_outbox_for_provider(array $row,string $reason,int $delay_seconds): bool {
        global $wpdb;
        $n=$wpdb->query($wpdb->prepare(
            "UPDATE ".self::t('outbox')." SET status='PENDING',last_error=%s,lease_owner=NULL,lease_until=NULL,send_started_at=NULL,next_attempt_at=%s,updated_at=%s
             WHERE id=%d AND status='PROCESSING' AND provider_message_id IS NULL AND sent_at IS NULL",
            WFCA_Util::redact_error($reason,500),gmdate('Y-m-d H:i:s',time()+max(60,$delay_seconds)),WFCA_Util::now_mysql(),(int)$row['id']
        ));
        return $n===1;
    }

    /**
     * 10.9.28: idempotent reset of a FAILED row that never reached the provider (no sid, no sent_at) back to PENDING on the SAME row/idempotency key.
     * attempts back to 0, owner_revision re-bound to the conversation's current revision. Returns true only when this call changed the row.
     */
    public static function reset_failed_outbox(int $id,int $owner_revision,string $status,string $note): bool {
        global $wpdb;
        $now=WFCA_Util::now_mysql();
        $n=$wpdb->query($wpdb->prepare(
            "UPDATE ".self::t('outbox')." SET status=%s,attempts=0,owner_revision=%d,next_attempt_at=%s,last_error=%s,lease_owner=NULL,lease_until=NULL,send_started_at=NULL,approved_at=NULL,updated_at=%s
             WHERE id=%d AND status='FAILED' AND provider_message_id IS NULL AND sent_at IS NULL AND send_started_at IS NULL",
            $status,$owner_revision,$now,WFCA_Util::redact_error($note,500),$now,$id
        ));
        return $n===1;
    }

    /** 10.9.28: handoffs created only by a transient outbox failure (candidates for the auto-reconciler). */
    public static function transient_handoff_candidates(int $limit): array {
        global $wpdb;
        $rows=$wpdb->get_results("SELECT * FROM ".self::t('conversations')." WHERE conversation_owner='HANDOFF_PENDING' AND state='HUMAN_HANDOFF' AND human_hold=1 AND opt_out=0 AND owner_reason LIKE 'OUTBOX\\_FAILED:%' ORDER BY id ASC LIMIT ".max(1,min(100,(int)$limit)),ARRAY_A);
        return $rows?:[];
    }

    public static function latest_failed_outbox(int $conversation_id): ?array {
        global $wpdb;
        $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".self::t('outbox')." WHERE conversation_id=%d AND status='FAILED' AND action_type IN ('TEMPLATE_INITIAL','FOLLOWUP') ORDER BY id DESC LIMIT 1",$conversation_id),ARRAY_A);
        return $row?:null;
    }

    public static function defer_outbox(array $row, string $reason, int $delay_seconds): void {
        global $wpdb;
        $wpdb->update(self::t('outbox'), [
            'status'=>'PENDING','last_error'=>WFCA_Util::redact_error($reason,500),'lease_owner'=>null,'lease_until'=>null,
            'next_attempt_at'=>gmdate('Y-m-d H:i:s', time()+max(60,$delay_seconds)),'updated_at'=>WFCA_Util::now_mysql()
        ], ['id'=>(int)$row['id']]);
    }

    /**
     * Admin-only safe re-arm for a row deferred solely by OUTSIDE_COMMERCIAL_WINDOW.
     * It never resets attempts, approval, idempotency, owner revision or send markers.
     */
    public static function rearm_after_window(int $id): array {
        global $wpdb;
        $row=self::get_outbox($id);
        if (!$row) return ['ok'=>false,'error'=>'OUTBOX_NOT_FOUND'];
        if (!in_array((string)$row['status'],['PENDING','APPROVED'],true)) return ['ok'=>false,'error'=>'OUTBOX_STATUS_NOT_REARMABLE'];
        if ((string)($row['last_error']??'')!=='OUTSIDE_COMMERCIAL_WINDOW') return ['ok'=>false,'error'=>'OUTBOX_NOT_WINDOW_DEFERRED'];
        if (!empty($row['send_started_at']) || !empty($row['provider_message_id'])) return ['ok'=>false,'error'=>'OUTBOX_SEND_ALREADY_STARTED'];
        if (!empty($row['lease_owner']) || (!empty($row['lease_until']) && strtotime((string)$row['lease_until'].' UTC')>time())) return ['ok'=>false,'error'=>'OUTBOX_LEASE_ACTIVE'];
        $changed=$wpdb->query($wpdb->prepare(
            "UPDATE ".self::t('outbox')." SET next_attempt_at=NULL,last_error='ADMIN_REARMED_AFTER_OUTSIDE_COMMERCIAL_WINDOW',updated_at=%s
             WHERE id=%d AND status IN ('PENDING','APPROVED') AND last_error='OUTSIDE_COMMERCIAL_WINDOW'
             AND send_started_at IS NULL AND provider_message_id IS NULL AND lease_owner IS NULL",
            WFCA_Util::now_mysql(),$id
        ));
        return $changed===1?['ok'=>true,'id'=>$id,'attempts'=>(int)$row['attempts'],'status'=>(string)$row['status']]:['ok'=>false,'error'=>'OUTBOX_REARM_CONFLICT'];
    }

    public static function cancel_pending_followups(int $conversation_id, string $reason='FOLLOWUP_SUPERSEDED'): int {
        global $wpdb;
        return (int)$wpdb->query($wpdb->prepare(
            "UPDATE ".self::t('outbox')." SET status='CANCELLED',last_error=%s,lease_owner=NULL,lease_until=NULL,send_started_at=NULL,updated_at=%s
             WHERE conversation_id=%d AND action_type='FOLLOWUP'
             AND status IN ('DRAFT_SHADOW','PENDING','APPROVED','PENDING_APPROVAL','PROCESSING')
             AND send_started_at IS NULL",
            WFCA_Util::redact_error($reason,500),WFCA_Util::now_mysql(),$conversation_id
        ));
    }

    public static function cancel_pending_action(int $conversation_id,string $action_type,string $reason='SUPERSEDED'): int {
        global $wpdb;
        $action_type=substr(preg_replace('/[^A-Z0-9_\-]/i','',$action_type),0,48);
        if ($action_type==='') return 0;
        return (int)$wpdb->query($wpdb->prepare(
            "UPDATE ".self::t('outbox')." SET status='CANCELLED',last_error=%s,lease_owner=NULL,lease_until=NULL,send_started_at=NULL,updated_at=%s
             WHERE conversation_id=%d AND action_type=%s
             AND status IN ('DRAFT_SHADOW','PENDING','APPROVED','PENDING_APPROVAL','PROCESSING')
             AND send_started_at IS NULL",
            WFCA_Util::redact_error($reason,500),WFCA_Util::now_mysql(),$conversation_id,$action_type
        ));
    }

    public static function set_outbox_status(int $id, string $status, string $error=''): void {
        global $wpdb;
        if ($status==='APPROVED') {
            $wpdb->query($wpdb->prepare("UPDATE ".self::t('outbox')." SET status='APPROVED',approved_at=%s WHERE id=%d AND status IN ('PENDING_APPROVAL','DRAFT_SHADOW','PENDING') AND send_started_at IS NULL",WFCA_Util::now_mysql(),$id));
            return;
        }
        $wpdb->update(self::t('outbox'), [
            'status'=>$status,
            'last_error'=>$error !== '' ? WFCA_Util::redact_error($error,500) : null,
            'lease_owner'=>null,
            'lease_until'=>null,
            'send_started_at'=>null,
            'updated_at'=>WFCA_Util::now_mysql()
        ], ['id'=>$id]);
    }

    public static function count_initial_queued_in_range(string $start_utc, string $end_utc): int {
        global $wpdb;
        return (int)$wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . self::t('outbox') . "
             WHERE action_type='TEMPLATE_INITIAL' AND created_at>=%s AND created_at<%s
             AND status NOT IN ('CANCELLED','DRAFT_SHADOW')",
            $start_utc, $end_utc
        ));
    }

    /**
     * Durable reservation point for the next autonomous initial contact.
     * A queued item counts before it is sent so missed ticks cannot create a
     * catch-up burst; the unique idempotency key remains the final duplicate
     * guard when the same lead is considered again.
     */
    public static function latest_initial_contact_at(): ?string {
        global $wpdb;
        $value = $wpdb->get_var(
            "SELECT MAX(COALESCE(sent_at,created_at)) FROM " . self::t('outbox') . "
             WHERE action_type='TEMPLATE_INITIAL' AND status NOT IN ('CANCELLED','DRAFT_SHADOW')"
        );
        return $value ? (string)$value : null;
    }

    /**
     * Last autonomous proactive transport boundary for a different lead.
     * SENT uses provider-accepted local sent_at. UNCERTAIN and PROCESSING
     * with send_started_at use that boundary conservatively because the provider
     * may already have accepted the message before local commit/recovery.
     * Daniel/manual messages are not represented by these autonomous outbox actions.
     */
    public static function latest_proactive_boundary_except_lead(string $lead_id,int $exclude_id=0): ?array {
        global $wpdb;
        $sql="SELECT id,lead_record_id,action_type,status,COALESCE(sent_at,send_started_at) AS boundary_at
              FROM ".self::t('outbox')."
              WHERE id<>%d AND lead_record_id<>%s
                AND action_type IN ('TEMPLATE_INITIAL','FOLLOWUP','TEMPLATE_NURTURE')
                AND ((sent_at IS NOT NULL AND (status='SENT' OR provider_message_id IS NOT NULL))
                     OR (status IN ('UNCERTAIN','PROCESSING') AND send_started_at IS NOT NULL))
              ORDER BY COALESCE(sent_at,send_started_at) DESC LIMIT 1";
        $row=$wpdb->get_row($wpdb->prepare($sql,$exclude_id,$lead_id),ARRAY_A);
        return is_array($row)?$row:null;
    }

    /** Last provider/send boundary for one proactive class, excluding current lead. */
    public static function latest_proactive_class_boundary_except_lead(string $class,string $lead_id,int $exclude_id=0): ?array {
        global $wpdb;
        $class=strtoupper(trim($class));
        $actions=$class==='D0'?["'TEMPLATE_INITIAL'"]:($class==='FOLLOWUP'?["'FOLLOWUP'","'TEMPLATE_NURTURE'"]:[]);
        if(!$actions) return null;
        $in=implode(',',$actions);
        $sql="SELECT id,lead_record_id,action_type,status,COALESCE(sent_at,send_started_at) AS boundary_at
              FROM ".self::t('outbox')."
              WHERE id<>%d AND lead_record_id<>%s AND action_type IN (".$in.")
                AND ((sent_at IS NOT NULL AND (status='SENT' OR provider_message_id IS NOT NULL))
                     OR (status IN ('UNCERTAIN','PROCESSING') AND send_started_at IS NOT NULL))
              ORDER BY COALESCE(sent_at,send_started_at) DESC LIMIT 1";
        $row=$wpdb->get_row($wpdb->prepare($sql,$exclude_id,$lead_id),ARRAY_A);
        return is_array($row)?$row:null;
    }

    /**
     * Lifetime initial-outreach fence. A prospect that already has an initial
     * template/outbound event is never treated as a fresh D0 again merely
     * because the calendar date changed.
     */
    public static function initial_outreach_exists(string $lead_id,string $phone): bool {
        global $wpdb;
        $phone=WFCA_Util::normalize_phone($phone);
        $conv=$phone!==''?self::get_conversation_by_phone($phone):null;
        $conv_id=(int)($conv['id']??0);
        $conditions=[];$args=[];
        if ($lead_id!=='') { $conditions[]='lead_record_id=%s';$args[]=$lead_id; }
        if ($conv_id>0) { $conditions[]='conversation_id=%d';$args[]=$conv_id; }
        if ($conditions) {
            $sql="SELECT COUNT(*) FROM ".self::t('outbox')." WHERE action_type='TEMPLATE_INITIAL' AND (status='SENT' OR provider_message_id IS NOT NULL OR sent_at IS NOT NULL) AND (".implode(' OR ',$conditions).')';
            $prepared=$args?$wpdb->prepare($sql,...$args):$sql;
            if ((int)$wpdb->get_var($prepared)>0) return true;
        }
        if ($phone!=='') {
            $n=(int)$wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM ".self::t('events')." WHERE phone_e164=%s AND direction='OUTBOUND' AND event_type IN ('TEMPLATE_INITIAL','MESSAGE')",
                $phone
            ));
            if ($n>0) return true;
        }
        return false;
    }

    public static function count_followups_in_range(string $start_utc, string $end_utc): int {
        global $wpdb;
        return (int)$wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . self::t('outbox') . "
             WHERE action_type='FOLLOWUP' AND created_at>=%s AND created_at<%s
             AND status NOT IN ('CANCELLED')",
            $start_utc,$end_utc
        ));
    }

    public static function has_terminal_payment(int $conversation_id): bool {
        global $wpdb;
        return (int)$wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . self::t('orders') . " WHERE conversation_id=%d AND state IN ('PAID','SETTLED','COMPLETED')",
            $conversation_id
        ))>0;
    }

    public static function create_order(array $row): int {
        global $wpdb;
        $now = WFCA_Util::now_mysql();
        $row = array_merge([
            'state'=>'CREATED','verify_attempts'=>0,'next_verify_at'=>null,'created_at'=>$now,'updated_at'=>$now
        ], $row);
        $ok = $wpdb->insert(self::t('orders'), $row);
        if ($ok) return (int)$wpdb->insert_id;
        if (!empty($row['outbox_id'])) {
            $existing = self::get_order_by_outbox_id((int)$row['outbox_id']);
            if ($existing) return (int)$existing['id'];
        }
        return 0;
    }

    public static function get_order(int $id): ?array {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::t('orders') . " WHERE id=%d", $id), ARRAY_A);
        return $row ?: null;
    }

    public static function get_order_by_nsu(string $nsu): ?array {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::t('orders') . " WHERE order_nsu=%s", $nsu), ARRAY_A);
        return $row ?: null;
    }

    public static function get_order_by_outbox_id(int $outbox_id): ?array {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::t('orders') . " WHERE outbox_id=%d", $outbox_id), ARRAY_A);
        return $row ?: null;
    }

    public static function get_order_by_transaction(string $transaction_nsu): ?array {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::t('orders') . " WHERE transaction_nsu=%s", $transaction_nsu), ARRAY_A);
        return $row ?: null;
    }

    public static function update_order(int $id, array $fields): bool {
        global $wpdb;
        $fields['updated_at'] = WFCA_Util::now_mysql();
        return $wpdb->update(self::t('orders'), $fields, ['id'=>$id])!==false;
    }

    public static function paid_unsynced_order_ids(int $limit=4): array {
        global $wpdb;
        $limit=max(1,min(20,$limit));
        $rows=$wpdb->get_col("SELECT id FROM " . self::t('orders') . " WHERE state='PAID' AND airtable_synced_at IS NULL ORDER BY id ASC LIMIT ".(int)$limit);
        return array_map('intval',$rows?:[]);
    }

    public static function due_order_ids(int $limit=4): array {
        global $wpdb;
        $now = WFCA_Util::now_mysql();
        $limit = max(1, min(20, $limit));
        $rows = $wpdb->get_col($wpdb->prepare(
            "SELECT id FROM " . self::t('orders') . "
             WHERE state IN ('WEBHOOK_RECEIVED','VERIFY_ERROR')
             AND pending_transaction_nsu IS NOT NULL AND pending_invoice_slug IS NOT NULL
             AND (next_verify_at IS NULL OR next_verify_at<=%s)
             ORDER BY id ASC LIMIT %d",
            $now, $limit
        ));
        return array_map('intval', $rows ?: []);
    }

    /** Returns true when verification has exhausted retries. */
    public static function retry_order_verification(array $order, string $error, int $max_attempts=8): bool {
        $attempts = ((int)($order['verify_attempts'] ?? 0)) + 1;
        if ($attempts >= $max_attempts) {
            self::update_order((int)$order['id'], [
                'state'=>'VERIFY_FAILED','verify_attempts'=>$attempts,'next_verify_at'=>null,'error'=>WFCA_Util::redact_error($error,500)
            ]);
            return true;
        }
        $delay = min(3600, 20 * (2 ** $attempts));
        self::update_order((int)$order['id'], [
            'state'=>'VERIFY_ERROR','verify_attempts'=>$attempts,
            'next_verify_at'=>gmdate('Y-m-d H:i:s', time()+$delay),
            'error'=>WFCA_Util::redact_error($error,500)
        ]);
        return false;
    }

    public static function create_alert(array $row): int {
        global $wpdb;
        $now = WFCA_Util::now_mysql();
        $defaults = [
            'lead_record_id'=>null,'conversation_id'=>null,'event_id'=>null,'severity'=>'WARN','prospect_message'=>null,
            'status'=>'OPEN','email_status'=>'PENDING','whatsapp_status'=>'NOT_CONFIGURED','attempts'=>0,
            'next_attempt_at'=>$now,'last_error'=>null,'created_at'=>$now,'updated_at'=>$now
        ];
        $row = array_merge($defaults, $row);
        $ok = $wpdb->query($wpdb->prepare(
            "INSERT IGNORE INTO " . self::t('alerts') . "
            (alert_key,lead_record_id,conversation_id,event_id,severity,reason,prospect_message,status,email_status,whatsapp_status,attempts,next_attempt_at,last_error,created_at,updated_at)
            VALUES (%s,%s,%d,%d,%s,%s,%s,%s,%s,%s,%d,%s,%s,%s,%s)",
            $row['alert_key'],$row['lead_record_id'],(int)$row['conversation_id'],(int)$row['event_id'],$row['severity'],
            WFCA_Util::short_text((string)$row['reason'],191),WFCA_Util::short_text((string)$row['prospect_message'],2000),
            $row['status'],$row['email_status'],$row['whatsapp_status'],(int)$row['attempts'],$row['next_attempt_at'],$row['last_error'],
            $row['created_at'],$row['updated_at']
        ));
        if ($ok === 1) return (int)$wpdb->insert_id;
        $existing = $wpdb->get_var($wpdb->prepare("SELECT id FROM " . self::t('alerts') . " WHERE alert_key=%s", $row['alert_key']));
        return (int)$existing;
    }

    public static function get_alert(int $id): ?array {
        global $wpdb;
        $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::t('alerts') . " WHERE id=%d",$id),ARRAY_A);
        return $row ?: null;
    }

    public static function due_alerts(int $limit=5): array {
        global $wpdb;
        $now=WFCA_Util::now_mysql();
        $limit=max(1,min(20,$limit));
        $rows=$wpdb->get_results($wpdb->prepare(
            "SELECT * FROM " . self::t('alerts') . " WHERE status='OPEN' AND attempts<4
             AND (email_status IN ('PENDING','FAILED') OR whatsapp_status IN ('PENDING','FAILED'))
             AND (next_attempt_at IS NULL OR next_attempt_at<=%s)
             ORDER BY id ASC LIMIT %d",$now,$limit
        ),ARRAY_A);
        return $rows ?: [];
    }

    public static function update_alert(int $id,array $fields): void {
        global $wpdb;
        $fields['updated_at']=WFCA_Util::now_mysql();
        $wpdb->update(self::t('alerts'),$fields,['id'=>$id]);
    }

    public static function resolve_alert_by_key(string $alert_key): void {
        global $wpdb;
        $wpdb->update(self::t('alerts'),[
            'status'=>'RESOLVED','next_attempt_at'=>null,'updated_at'=>WFCA_Util::now_mysql()
        ],['alert_key'=>$alert_key]);
    }

    public static function maintenance_state(): array {
        global $wpdb;
        $processing=(int)$wpdb->get_var("SELECT COUNT(*) FROM ".self::t('outbox')." WHERE status='PROCESSING'");
        $send_boundary=(int)$wpdb->get_var("SELECT COUNT(*) FROM ".self::t('outbox')." WHERE status='PROCESSING' AND send_started_at IS NOT NULL");
        $events_processing=(int)$wpdb->get_var("SELECT COUNT(*) FROM ".self::t('events')." WHERE status='PROCESSING'");
        $owner_sync=(int)$wpdb->get_var("SELECT COUNT(*) FROM ".self::t('conversations')." WHERE owner_sync_pending=1");
        $sent_sync=(int)$wpdb->get_var("SELECT COUNT(*) FROM ".self::t('outbox')." WHERE status='SENT' AND sync_pending=1");
        return [
            'maintenance_ready'=>$processing===0 && $events_processing===0,
            'processing_outbox'=>$processing,
            'processing_after_send_boundary'=>$send_boundary,
            'processing_events'=>$events_processing,
            'owner_sync_pending'=>$owner_sync,
            'sent_sync_pending'=>$sent_sync,
        ];
    }

    public static function stats(): array {
        global $wpdb;
        return [
            'conversations'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM ".self::t('conversations')),
            'events'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM ".self::t('events')),
            'pending'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM ".self::t('outbox')." WHERE status IN ('PENDING','APPROVED','PENDING_APPROVAL','DRAFT_SHADOW','PROCESSING')"),
            'failed'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM ".self::t('outbox')." WHERE status='FAILED'"),
            'uncertain'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM ".self::t('outbox')." WHERE status='UNCERTAIN'"),
            'sent_delivery_pending'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM ".self::t('outbox')." WHERE status='SENT' AND (delivery_status IS NULL OR delivery_status='' OR delivery_status IN ('accepted','sent'))"),
            'delivered_or_read'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM ".self::t('outbox')." WHERE status='SENT' AND delivery_status IN ('delivered','read')"),
            'delivery_failed'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM ".self::t('outbox')." WHERE delivery_status='failed'"),
            'alerts'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM ".self::t('alerts')." WHERE status='OPEN'"),
            'paid'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM ".self::t('orders')." WHERE state='PAID'"),
        ];
    }

    public static function backlog(): array {
        global $wpdb;
        $oldest_event = $wpdb->get_var("SELECT received_at FROM ".self::t('events')." WHERE status='RECEIVED' ORDER BY id ASC LIMIT 1");
        $oldest_outbox = $wpdb->get_var("SELECT created_at FROM ".self::t('outbox')." WHERE status IN ('PENDING','APPROVED','PROCESSING') ORDER BY id ASC LIMIT 1");
        return [
            'oldest_received_event'=>$oldest_event ?: null,
            'oldest_sendable_outbox'=>$oldest_outbox ?: null,
        ];
    }
}
