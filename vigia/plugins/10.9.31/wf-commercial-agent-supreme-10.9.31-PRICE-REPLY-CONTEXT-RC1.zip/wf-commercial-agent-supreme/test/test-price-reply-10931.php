<?php
// 10.9.31: price reply carries context from the catalog only; never invents scope.
define('ABSPATH', __DIR__.'/');define('MINUTE_IN_SECONDS',60);define('DAY_IN_SECONDS',86400);
function sanitize_email($x){return $x;} function is_email($x){return false;} function get_option($k,$d=null){return $d;} function wp_strip_all_tags($x){return strip_tags($x);} function update_option($k,$v,$a=null){return true;}
require_once __DIR__.'/../includes/class-wfca-util.php';
final class WFCA_Airtable {public static function lead_is_commercial_ready(array $l): bool {return true;} public static function mode(): string {return "LIVE";} public static function config(): array {return [];}}
final class WFCA_Ownership {public static function queue_status(): string {return 'PENDING';}}
final class WFCA_Alerts {public static function raise(...$a): void {}}
final class WFCA_DB {}
require_once __DIR__.'/../includes/class-wfca-engine.php';
$pass=0;$fail=0;function t($n,$c){global $pass,$fail;if($c){echo "PASS $n\n";$pass++;}else{echo "FAIL $n\n";$fail++;}}
$m=new ReflectionMethod('WFCA_Engine','price_reply');$m->setAccessible(true);
$r=$m->invoke(null,['name'=>'Landing Page Premium','amount'=>70000,'terms'=>'R$700 à vista ou 12x de R$58,33 sem juros']);
t('uses catalog name and payment terms',str_contains($r,'Landing Page Premium')&&str_contains($r,'R$700 à vista ou 12x de R$58,33 sem juros'));
t('offers to explain what is included instead of claiming it',str_contains($r,'o que está incluso'));
t('no dry one-liner anymore',$r!=='R$700 na opção de entrada.');
foreach(['prazo','dias','domínio','dominio','hospedagem','revisões','revisoes','garantia','ilimitad'] as $w) t("never invents scope word: $w",!str_contains(mb_strtolower($r),$w));
$r=$m->invoke(null,['name'=>'Landing Page Premium','amount'=>70000,'terms'=>'R$700']);
t('fallback terms still read well',str_contains($r,'R$700')&&str_contains($r,'Posso te explicar'));
$r=$m->invoke(null,['name'=>'','amount'=>70000,'terms'=>'']);
t('missing name and terms falls back to the amount',str_contains($r,'R$700'));
echo "\nPASS=$pass FAIL=$fail\n";exit($fail?1:0);
