<?php
define('ABSPATH', __DIR__.'/');
foreach (['wp_strip_all_tags','sanitize_email','is_email','get_option','apply_filters','wp_json_encode','home_url','esc_url_raw'] as $fn) { if(!function_exists($fn)) { eval('function '.$fn.'(...$a){return $a[0]??"";}'); } }
final class WFCA_Airtable { public static $cfg=[]; public static function config(bool $force=false): array {return self::$cfg;} }
require_once __DIR__.'/../includes/class-wfca-util.php';
require_once __DIR__.'/../includes/class-wfca-kapso.php';
$pass=0;$fail=0;function t($n,$c){global $pass,$fail;if($c){echo "PASS $n\n";$pass++;}else{echo "FAIL $n\n";$fail++;}}
function setcfg($v){WFCA_Airtable::$cfg=$v;}
setcfg([]);$r=WFCA_Util::rules();t('defaults without config',$r['auto_resume_enabled']===true&&$r['auto_resume_after_seconds']===1800&&$r['gatekeeper_email_redirect_enabled']===true&&$r['auto_resume_extra_blocked_states']===[]);
setcfg(['WFCA_RULES_V1'=>'not json']);$r=WFCA_Util::rules();t('bad json falls back to defaults',$r['auto_resume_after_seconds']===1800);
setcfg(['WFCA_RULES_V1'=>'{"auto_resume_after_seconds":60}']);t('delay floor 10 min',WFCA_Util::rules()['auto_resume_after_seconds']===600);
setcfg(['WFCA_RULES_V1'=>'{"auto_resume_after_seconds":9999999}']);t('delay ceiling 24 h',WFCA_Util::rules()['auto_resume_after_seconds']===86400);
setcfg(['WFCA_RULES_V1'=>'{"auto_resume_after_seconds":3600}']);t('valid delay applied',WFCA_Util::rules()['auto_resume_after_seconds']===3600);
setcfg(['WFCA_RULES_V1'=>'{"auto_resume_enabled":false,"gatekeeper_email_redirect_enabled":false}']);$r=WFCA_Util::rules();t('switches can be turned off',$r['auto_resume_enabled']===false&&$r['gatekeeper_email_redirect_enabled']===false);
setcfg(['WFCA_RULES_V1'=>'{"auto_resume_extra_blocked_states":["VIP_LEAD","bad state","x"],"gatekeeper_extra_hostile_words":["Cansei","a"]}']);$r=WFCA_Util::rules();t('extra states only valid ones',$r['auto_resume_extra_blocked_states']===['VIP_LEAD']);
t('extra hostile words lowercased and filtered',$r['gatekeeper_extra_hostile_words']===['cansei']);
setcfg(['WFCA_RULES_V1'=>'{"auto_resume_extra_blocked_states":[]}']);t('floors stay in code (no removal key exists)',!array_key_exists('auto_resume_blocked_states',WFCA_Util::rules()));
setcfg([]);t('owner whatsapp empty without config',WFCA_Util::owner_whatsapp()==='');
setcfg(['WFCA_OWNER_WHATSAPP'=>'+55 11 91234-5678']);t('owner whatsapp from Airtable Config',WFCA_Util::owner_whatsapp()!==''&&str_contains(WFCA_Util::owner_whatsapp(),'5511'));
setcfg(['WFCA_OWNER_WHATSAPP'=>'abc']);t('invalid owner whatsapp rejected',WFCA_Util::owner_whatsapp()==='');
setcfg([]);t('OWNER_ALERT template empty without config',WFCA_Kapso::template('OWNER_ALERT')==='');
setcfg(['WFCA_KAPSO_TEMPLATE_OWNER_ALERT'=>'wf_owner_alert_v1']);t('OWNER_ALERT template from Airtable Config',WFCA_Kapso::template('OWNER_ALERT')==='wf_owner_alert_v1');
setcfg(['WFCA_KAPSO_TEMPLATE_OWNER_ALERT'=>'Bad Name!']);t('invalid template name rejected',WFCA_Kapso::template('OWNER_ALERT')==='');
setcfg(['WFCA_KAPSO_TEMPLATE_OWNER_ALERT'=>'wf_owner_alert_v1']);t('INITIAL template NOT resurrected from this key',WFCA_Kapso::template('INITIAL')==='');
echo "TOTAL PASS=$pass FAIL=$fail\n";exit($fail?1:0);
