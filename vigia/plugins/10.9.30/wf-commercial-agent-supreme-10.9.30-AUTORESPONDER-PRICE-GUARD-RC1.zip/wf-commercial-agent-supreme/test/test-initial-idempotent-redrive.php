<?php
define('ABSPATH', __DIR__.'/');
define('ARRAY_A','ARRAY_A');
final class WFCA_Util {
    public static function now_mysql(): string { return '2026-09-25 01:40:00'; }
    public static function json($v): string { return json_encode($v,JSON_UNESCAPED_SLASHES); }
}
final class WFCA_Ownership {
    public static function queue_status(): string { return 'PENDING'; }
}
final class FakeWPDB {
    public string $prefix='wp_';
    public int $insert_id=0;
    public array $conversations=[];
    public array $outbox=[];
    private int $next_id=100;
    public function prepare($query,...$args){ return ['query'=>$query,'args'=>$args]; }
    public function get_row($prepared,$fmt=null){
        $q=is_array($prepared)?$prepared['query']:$prepared; $a=is_array($prepared)?$prepared['args']:[];
        if (str_contains($q,'wfca_conversations') && str_contains($q,'WHERE id=')) return $this->conversations[(int)($a[0]??0)]??null;
        if (str_contains($q,'wfca_outbox') && str_contains($q,'idempotency_key=')) {
            $key=(string)($a[0]??''); foreach($this->outbox as $r) if (($r['idempotency_key']??'')===$key) return $r; return null;
        }
        if (str_contains($q,'wfca_outbox') && str_contains($q,'WHERE id=')) return $this->outbox[(int)($a[0]??0)]??null;
        return null;
    }
    public function get_var($prepared){ $r=$this->get_row($prepared,ARRAY_A); return $r['id']??null; }
    public function insert($table,$item){
        if (str_contains($table,'wfca_outbox')) {
            foreach($this->outbox as $r) if (($r['idempotency_key']??'')===($item['idempotency_key']??'')) return false;
            $id=$this->next_id++; $item['id']=$id; $this->outbox[$id]=$item; $this->insert_id=$id; return 1;
        }
        return false;
    }
    public function query($prepared){
        if (!is_array($prepared)) return 0;
        $q=$prepared['query']; $a=$prepared['args'];
        if (!str_contains($q,'UPDATE wp_wfca_outbox SET status=')) return 0;
        $id=(int)$a[12]; $expected=(string)$a[13];
        if (!isset($this->outbox[$id])) return 0;
        $r=$this->outbox[$id];
        if (($r['status']??'')!=='CANCELLED' || ($r['last_error']??'')!==$expected || !empty($r['send_started_at']) || !empty($r['provider_message_id']) || !empty($r['sent_at']) || !empty($r['lease_owner'])) return 0;
        $this->outbox[$id]=array_merge($r,[
            'status'=>$a[0],'lead_record_id'=>$a[1],'conversation_id'=>(int)$a[2],'content_sid'=>$a[3],
            'content_variables'=>$a[4],'owner_revision'=>(int)$a[5],'initial_arm'=>$a[6],'state_after'=>$a[7],
            'provider'=>$a[8],'next_attempt_at'=>$a[9],'lease_owner'=>null,'lease_until'=>null,'approved_at'=>null,
            'last_error'=>$a[10],'updated_at'=>$a[11]
        ]);
        return 1;
    }
}
$GLOBALS['wpdb']=new FakeWPDB();
require_once __DIR__.'/../includes/class-wfca-db.php';

$pass=0;$fail=0;
function t($name,$cond){global $pass,$fail;if($cond){echo "PASS $name\n";$pass++;}else{echo "FAIL $name\n";$fail++;}}
function base_item($key='k1'){ return [
    'idempotency_key'=>$key,'lead_record_id'=>'recPIC','conversation_id'=>75,'action_type'=>'TEMPLATE_INITIAL',
    'content_sid'=>'wf_site_preview_intro_media_v1','content_variables'=>['1'=>'Pic','2'=>'obs','3'=>'url'],
    'state_after'=>'WAITING_REPLY','status'=>'PENDING','provider'=>'KAPSO'
];}
function base_row($id,$key,$status,$error=''){ return [
    'id'=>$id,'idempotency_key'=>$key,'lead_record_id'=>'recPIC','conversation_id'=>75,'action_type'=>'TEMPLATE_INITIAL',
    'status'=>$status,'last_error'=>$error,'send_started_at'=>null,'provider_message_id'=>null,'sent_at'=>null,
    'lease_owner'=>null,'lease_until'=>null,'content_variables'=>'{}','owner_revision'=>1,'initial_arm'=>'LUNA_COLD_WHATSAPP'
];}
$wpdb=$GLOBALS['wpdb'];
$wpdb->conversations[75]=['id'=>75,'owner_revision'=>3,'initial_arm'=>'LUNA_COLD_WHATSAPP'];

$r=WFCA_DB::queue_initial_idempotent(base_item('new'));
t('new INITIAL creates one sendable row',!empty($r['queued']) && ($r['disposition']??'')==='ACTIVE_EXISTING' && count($wpdb->outbox)===1);
$newid=(int)$r['id'];
$r2=WFCA_DB::queue_initial_idempotent(base_item('new'));
t('repeat INITIAL reuses active row without duplicate',!empty($r2['queued']) && (int)$r2['id']===$newid && count($wpdb->outbox)===1);

$wpdb->outbox[64]=base_row(64,'pic','CANCELLED','OWNER_REVISION_CHANGED');
$r=WFCA_DB::queue_initial_idempotent(base_item('pic'));
t('cancelled owner-revision technical row re-drives same id',!empty($r['queued']) && (int)$r['id']===64 && ($r['disposition']??'')==='SAFE_REDRIVEN_SAME_ROW');
t('safe re-drive keeps lifetime key and refreshes owner revision',($wpdb->outbox[64]['idempotency_key']??'')==='pic' && (int)$wpdb->outbox[64]['owner_revision']===3);
t('safe re-drive refreshes current media payload',str_contains((string)$wpdb->outbox[64]['content_variables'],'Pic') && ($wpdb->outbox[64]['content_sid']??'')==='wf_site_preview_intro_media_v1');

$wpdb->outbox[65]=base_row(65,'hold','CANCELLED','HUMAN_HOLD');
$r=WFCA_DB::queue_initial_idempotent(base_item('hold'));
t('semantic HUMAN_HOLD terminal never re-drives',empty($r['queued']) && ($r['error']??'')==='INITIAL_OUTBOX_TERMINAL_NOT_REDRIVEABLE' && ($wpdb->outbox[65]['status']??'')==='CANCELLED');

$wpdb->outbox[66]=base_row(66,'sent','CANCELLED','OWNER_REVISION_CHANGED'); $wpdb->outbox[66]['provider_message_id']='wamid.x';
$r=WFCA_DB::queue_initial_idempotent(base_item('sent'));
t('provider id consumes lifetime initial and never re-drives',empty($r['queued']) && ($r['disposition']??'')==='CONSUMED' && ($wpdb->outbox[66]['status']??'')==='CANCELLED');

$wpdb->outbox[67]=base_row(67,'amb','UNCERTAIN','SEND_EXCEPTION'); $wpdb->outbox[67]['send_started_at']='2026-09-25 01:00:00';
$r=WFCA_DB::queue_initial_idempotent(base_item('amb'));
t('ambiguous send_started/UNCERTAIN fails closed',empty($r['queued']) && ($r['error']??'')==='INITIAL_OUTBOX_AMBIGUOUS');

$wpdb->outbox[68]=base_row(68,'reject','CANCELLED','REJECTED_BY_DANIEL');
$r=WFCA_DB::queue_initial_idempotent(base_item('reject'));
t('explicit Daniel reject never re-drives',empty($r['queued']) && ($wpdb->outbox[68]['status']??'')==='CANCELLED');

$wpdb->outbox[69]=base_row(69,'mismatch','CANCELLED','OWNER_CHANGED'); $wpdb->outbox[69]['lead_record_id']='recOTHER';
$r=WFCA_DB::queue_initial_idempotent(base_item('mismatch'));
t('identity mismatch fails closed before re-drive',empty($r['queued']) && ($r['error']??'')==='INITIAL_IDEMPOTENCY_LEAD_MISMATCH');

$engine=file_get_contents(__DIR__.'/../includes/class-wfca-engine.php');
t('scheduler uses INITIAL-specific reservation helper',str_contains($engine,'WFCA_DB::queue_initial_idempotent(['));
t('lifetime INITIAL key format unchanged',str_contains($engine,"hash('sha256','INITIAL|'.\$lead_id.'|'.\$phone)"));
t('scheduler gates CONTACT_QUEUED on queued=true',str_contains($engine,"if (!empty(\$reservation['queued']))"));

echo "TOTAL PASS=$pass FAIL=$fail\n";
exit($fail?1:0);
