<?php
// 10.9.29: Airtable 429 backoff, Config error visibility / optional stale config, touch-index truncation flag, and the SQL shape of the new DB helpers.
define('ABSPATH', __DIR__.'/');define('ARRAY_A','ARRAY_A');define('WFCA_VERSION','t');define('MINUTE_IN_SECONDS',60);
define('WFCA_AIRTABLE_TOKEN','patFAKE'); define('WFCA_AIRTABLE_BASE_ID','appFAKE');
class WP_Error {} function is_wp_error($x){return $x instanceof WP_Error;}
function wp_remote_retrieve_response_code($r){return $r['code'];} function wp_remote_retrieve_body($r){return $r['body'];} function wp_remote_retrieve_header($r,$h){return $r['headers'][$h]??'';}
foreach (['wp_strip_all_tags','sanitize_email','is_email','apply_filters','wp_json_encode','home_url','esc_url_raw'] as $fn) { if(!function_exists($fn)) { eval('function '.$fn.'(...$a){return $a[0]??"";}'); } }
$OPT=[];$TR=[];$CALLS=0;$NEXT=[];
function get_option($k,$d=false){global $OPT;return $OPT[$k]??$d;} function update_option($k,$v,$a=null){global $OPT;$OPT[$k]=$v;return true;}
function get_transient($k){global $TR;return $TR[$k]??false;} function set_transient($k,$v,$t){global $TR;$TR[$k]=$v;return true;} function delete_transient($k){global $TR;unset($TR[$k]);return true;}
function wp_remote_request($url,$args){global $CALLS,$NEXT;$CALLS++;$r=array_shift($NEXT);return $r??['code'=>200,'body'=>'{"records":[]}','headers'=>[]];}
final class FakeWpdb { public $prefix='wp_'; public $sql=[]; public $affected=1; public $rows=[];
  public function prepare($q,...$a){ $i=0; return str_replace('%%','%',preg_replace_callback('/%[sd]/',function($m) use(&$i,$a){ $v=$a[$i++]??''; return $m[0]==='%d'?(string)(int)$v:"'".addslashes((string)$v)."'"; },$q)); }
  public function query($q){$this->sql[]=$q;return $this->affected;} public function get_row($q,$t=null){$this->sql[]=$q;return null;} public function get_results($q,$t=null){$this->sql[]=$q;return $this->rows;} public function get_var($q){$this->sql[]=$q;return '2026-10-12 11:00:00';} public function update(...$a){return 1;} }
$wpdb=new FakeWpdb();
require_once __DIR__.'/../includes/class-wfca-util.php';
require_once __DIR__.'/../includes/class-wfca-airtable.php';
require_once __DIR__.'/../includes/class-wfca-db.php';
$pass=0;$fail=0;function t($n,$c){global $pass,$fail;if($c){echo "PASS $n\n";$pass++;}else{echo "FAIL $n\n";$fail++;}}
function cfgrec($k,$v){return ['id'=>'r'.$k,'fields'=>['Key'=>$k,'Value'=>$v,'Status'=>'CURRENT']];}
function ok($recs,$off=null){return ['code'=>200,'body'=>json_encode(['records'=>$recs]+($off?['offset'=>$off]:[])),'headers'=>[]];}
function reset_env(){global $OPT,$TR,$CALLS,$NEXT;$OPT=[];$TR=[];$CALLS=0;$NEXT=[];}

// ---- 429 backoff
reset_env();$NEXT=[['code'=>429,'body'=>'{"error":{"type":"RATE_LIMIT_REACHED"}}','headers'=>['retry-after'=>'45']]];
$r=WFCA_Airtable::update_lead('recX',['a'=>1]);
t('a 429 is reported as an error to the caller (fail closed) and opens a back-off window = Retry-After (45 s)',empty($r['ok'])&&$r['code']===429&&(int)get_option('wfca_airtable_backoff_until')>=time()+44&&(int)get_option('wfca_airtable_backoff_until')<=time()+46);
$c0=$CALLS;$r2=WFCA_Airtable::update_lead('recX',['a'=>1]);$r3=WFCA_Airtable::get_lead('recX');
t('during the back-off NO request leaves the server (tick is not burned on calls that 429 again)',$CALLS===$c0&&$r2['error']==='HTTP_429_BACKOFF'&&empty($r3['ok']));
$OPT['wfca_airtable_backoff_until']=time()-1;WFCA_Airtable::update_lead('recX',['a'=>1]);
t('after the window requests flow again',$CALLS===$c0+1);
reset_env();$NEXT=[['code'=>429,'body'=>'{}','headers'=>['retry-after'=>'9999']]];WFCA_Airtable::update_lead('r',[]);
t('window is capped at 120 s and floored at 30 s',(int)get_option('wfca_airtable_backoff_until')<=time()+121);
reset_env();$NEXT=[['code'=>429,'body'=>'{}','headers'=>[]]];WFCA_Airtable::update_lead('r',[]);
t('no Retry-After => 30 s',(int)get_option('wfca_airtable_backoff_until')>=time()+29);
reset_env();$TR['wfca_config_current']=['WFCA_RULES_V1'=>'{"airtable_backoff_enabled":false}'];$OPT['wfca_airtable_backoff_until']=time()+60;$c0=$CALLS;WFCA_Airtable::update_lead('r',[]);
t('airtable_backoff_enabled=false in WFCA_RULES_V1 (read from the cached config, no recursion) disables it',$CALLS===$c0+1);

// ---- config(): errors visible, duplicate key named, optional stale config
reset_env();$NEXT=[ok([cfgrec('A','1'),cfgrec('WFCA_RULES_V1','{}')])];
$c=WFCA_Airtable::config(true);
t('healthy config: returned, cached, no error flag',$c['A']==='1'&&get_transient('wfca_config_current')!==false&&!get_option('wfca_config_error'));
reset_env();$NEXT=[ok([cfgrec('A','1'),cfgrec('A','2')])];
$c=WFCA_Airtable::config(true);$e=get_option('wfca_config_error');
t('DUPLICATE CURRENT key: still fails closed ([]) as before, but the offending key is recorded for health_v1',$c===[]&&$e['err']==='DUPLICATE_CURRENT_KEY:A'&&get_transient('wfca_config_current')===false);
$at=$e['at'];$NEXT=[ok([cfgrec('A','1'),cfgrec('A','2')])];WFCA_Airtable::config(true);
t('error timestamp is the START of the episode (age grows), not rewritten each tick',get_option('wfca_config_error')['at']===$at);
$NEXT=[ok([cfgrec('A','1')])];WFCA_Airtable::config(true);
t('fixed => error flag cleared',get_option('wfca_config_error')===[]);
reset_env();$NEXT=[['code'=>503,'body'=>'{}','headers'=>[]]];$c=WFCA_Airtable::config(true);
t('HTTP failure: [] (fail closed) + READ_FAIL recorded',$c===[]&&str_starts_with(get_option('wfca_config_error')['err'],'READ_FAIL:'));
// stale config (opt-in)
reset_env();$NEXT=[ok([cfgrec('COMMERCIAL_AGENT_MODE','LIVE'),cfgrec('WFCA_RULES_V1','{"config_stale_ttl_seconds":300}')])];WFCA_Airtable::config(true);
t('stale-while-error is only stored when the rule is on',!empty(get_option('wfca_config_lkg')['cfg']['COMMERCIAL_AGENT_MODE']));
$TR=[];$NEXT=[['code'=>503,'body'=>'{}','headers'=>[]]];$c=WFCA_Airtable::config(true);
t('rule on: an Airtable error serves the last good config (<=ttl) instead of SHADOW',($c['COMMERCIAL_AGENT_MODE']??'')==='LIVE'&&get_option('wfca_config_error')['err']!=='');
$OPT['wfca_config_lkg']['at']=time()-400;$NEXT=[['code'=>503,'body'=>'{}','headers'=>[]]];
t('...but not beyond the ttl',WFCA_Airtable::config(true)===[]);
reset_env();$NEXT=[ok([cfgrec('COMMERCIAL_AGENT_MODE','LIVE')])];WFCA_Airtable::config(true);$TR=[];$NEXT=[['code'=>503,'body'=>'{}','headers'=>[]]];
t('default (rule absent): fail closed, nothing stored',WFCA_Airtable::config(true)===[]&&!get_option('wfca_config_lkg'));

// ---- touch index truncation
reset_env();$TR['wfca_config_current']=[];
for($i=0;$i<25;$i++) $NEXT[]=ok([['id'=>'t'.$i,'fields'=>['Lead'=>['recL'.$i],'Notes'=>json_encode(['direction'=>'OUTBOUND','channel'=>'WHATSAPP'])]]],'off'.$i);
$NEXT[]=ok([]);
$idx=WFCA_Airtable::outbound_touch_index(true);
t('touch index now reads past 20 pages (was a silent 2000-touch cap): lead from page 25 is seen, not truncated',!empty($idx['by_lead']['recL24'])&&(int)get_option('wfca_touch_index_truncated')===0);
reset_env();$TR['wfca_config_current']=['WFCA_RULES_V1'=>'{"touch_index_max_pages":20}'];
for($i=0;$i<30;$i++) $NEXT[]=ok([['id'=>'t'.$i,'fields'=>['Lead'=>['recL'.$i],'Notes'=>json_encode(['direction'=>'OUTBOUND','channel'=>'WHATSAPP'])]]],'off'.$i);
$idx=WFCA_Airtable::outbound_touch_index(true);
t('when the cap IS hit the truncation is flagged for health_v1 (touch_index_truncated)',(int)get_option('wfca_touch_index_truncated')===1&&empty($idx['by_lead']['recL25']));

// ---- DB SQL shapes
$wpdb->sql=[];
WFCA_DB::ambiguous_d0_candidates(time()-21600,3);$q=end($wpdb->sql);
t('release candidates: UNCERTAIN D0, no sid, send boundary set, ambiguous marker, LUNA-owned and NOT in a human hold/opt-out',str_contains($q,"o.status='UNCERTAIN'")&&str_contains($q,"o.action_type='TEMPLATE_INITIAL'")&&str_contains($q,'o.provider_message_id IS NULL')&&str_contains($q,'o.send_started_at IS NOT NULL')&&str_contains($q,"LIKE 'AMBIGUOUS\\_%'")&&str_contains($q,'c.human_hold=0')&&str_contains($q,'c.opt_out=0')&&str_contains($q,"c.conversation_owner='LUNA'")&&str_contains($q,'LIMIT 3'));
t('the release marker can not match the candidate filter (no re-release loop)',!str_starts_with('RELEASED_AMBIGUOUS_NO_STATUS','AMBIGUOUS_')&&!str_starts_with('RESOLVED_BY_STATUS_WEBHOOK','AMBIGUOUS_'));
WFCA_DB::ambiguous_d0_for_status('+5511999990000',time(),7200);$q=end($wpdb->sql);
t('status mapping: that phone only, UNCERTAIN D0 without sid, bounded send window, LIMIT 2 (to detect ambiguity)',str_contains($q,"c.phone_e164='+5511999990000'")&&str_contains($q,"o.status='UNCERTAIN'")&&str_contains($q,'o.provider_message_id IS NULL')&&str_contains($q,'o.send_started_at<=')&&str_contains($q,'o.send_started_at>=')&&str_contains($q,'LIMIT 2'));
$ok=WFCA_DB::resolve_uncertain_outbox(50,'wamid.X');$q=end($wpdb->sql);
t('resolve: only a still-UNCERTAIN row without sid; becomes SENT with sync_pending=1 and sent_at=send_started_at (idempotent: 2nd call matches 0 rows)',$ok&&str_contains($q,"status='SENT'")&&str_contains($q,"provider_message_id='wamid.X'")&&str_contains($q,'sent_at=send_started_at')&&str_contains($q,'sync_pending=1')&&str_contains($q,"id=50 AND status='UNCERTAIN' AND provider_message_id IS NULL AND sent_at IS NULL"));
$wpdb->affected=0;t('resolve twice => false',WFCA_DB::resolve_uncertain_outbox(50,'wamid.X')===false);$wpdb->affected=1;
$ok=WFCA_DB::release_uncertain_outbox(50,'RELEASED_AMBIGUOUS_NO_STATUS');$q=end($wpdb->sql);
t('release: touches last_error only (status stays UNCERTAIN, key stays consumed), only ambiguous rows',$ok&&str_contains($q,"WHERE id=50 AND status='UNCERTAIN' AND last_error LIKE 'AMBIGUOUS\\_%'")&&!str_contains($q,"SET status"));
t('last sent ts query is a MAX(sent_at) per action',WFCA_DB::last_proactive_sent_ts('TEMPLATE_INITIAL')===strtotime('2026-10-12 11:00:00 UTC')&&str_contains(end($wpdb->sql),'MAX(sent_at)'));
echo "TOTAL PASS=$pass FAIL=$fail\n";exit($fail?1:0);
