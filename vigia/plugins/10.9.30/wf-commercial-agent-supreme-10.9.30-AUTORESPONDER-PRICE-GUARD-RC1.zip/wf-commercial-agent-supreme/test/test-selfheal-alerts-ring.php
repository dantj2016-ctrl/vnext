<?php
// 10.9.29 item 3: CRITICAL alerts survive SMTP/Kapso failure: ring option + Airtable 'Commercial Error' mirror + direct mail for conversation-less alerts.
define('ABSPATH', __DIR__.'/');
$GLOBALS['opts']=[];$GLOBALS['mails']=[];
foreach (['wp_strip_all_tags','sanitize_email','is_email','apply_filters','wp_json_encode','home_url','esc_url_raw'] as $fn) { if(!function_exists($fn)) { eval('function '.$fn.'(...$a){return $a[0]??"";}'); } }
function get_option($k,$d=false){return $GLOBALS['opts'][$k]??$d;}
function update_option($k,$v,$a=null){$GLOBALS['opts'][$k]=$v;return true;}
function wp_next_scheduled(...$a){return false;} function wp_schedule_single_event(...$a){return true;}
function wp_mail($to,$s,$b){$GLOBALS['mails'][]=[$to,$s,$b];return true;}
final class WFCA_Kapso { public static function template($k){return '';} }
final class WFCA_DB {
  public static $convs=[7=>['id'=>7,'phone_e164'=>'+5511999990000']]; public static $created=[];
  public static function create_alert(array $r): int {self::$created[]=$r;return count(self::$created);}
  public static function get_conversation(int $id): ?array {return self::$convs[$id]??null;}
}
final class WFCA_Airtable { public static $cfg=[]; public static $updates=[]; public static $ok=true;
  public static function config(bool $f=false): array {return self::$cfg;}
  public static function update_commercial_by_phone(string $p,array $f): array {self::$updates[]=[$p,$f];return ['ok'=>self::$ok];} }
require_once __DIR__.'/../includes/class-wfca-util.php';
require_once __DIR__.'/../includes/class-wfca-alerts.php';
$pass=0;$fail=0;function t($n,$c){global $pass,$fail;if($c){echo "PASS $n\n";$pass++;}else{echo "FAIL $n\n";$fail++;}}
function reset_all(){$GLOBALS['opts']=[];$GLOBALS['mails']=[];WFCA_Airtable::$cfg=[];WFCA_Airtable::$updates=[];WFCA_Airtable::$ok=true;WFCA_DB::$created=[];}
$ring=fn()=>get_option('wfca_alerts_ring',[]);

reset_all();
WFCA_Alerts::raise('INFO_ONLY','INFO','',0,0,'','k:info');WFCA_Alerts::raise('WARN_ONLY','WARN','',0,0,'','k:warn');
t('INFO/WARN never enter the CRITICAL ring (panel only, as before)',$ring()===[]);
WFCA_Alerts::raise('PROVIDER_CREDITS_EXHAUSTED:KAPSO_HTTP_402','CRITICAL','recL1',7,0,'','k:402');
t('CRITICAL alert is recorded in option wfca_alerts_ring (options only: works with SMTP and Kapso down)',count($ring())===1&&$ring()[0]['reason']==='PROVIDER_CREDITS_EXHAUSTED:KAPSO_HTTP_402'&&$ring()[0]['conv']===7&&$ring()[0]['mirrored']===0);
WFCA_Alerts::raise('PROVIDER_CREDITS_EXHAUSTED:KAPSO_HTTP_402','CRITICAL','recL1',7,0,'','k:402');
t('same alert key is not duplicated in the ring',count($ring())===1);
for($i=0;$i<60;$i++) WFCA_Alerts::raise('X'.$i,'CRITICAL','',0,0,'','k:'.$i);
t('ring keeps the last 50 only',count($ring())===50&&$ring()[49]['reason']==='X59');

// mirror + mail
reset_all();
WFCA_Alerts::raise('D0_STALL:SPACING_WAIT:3000s','CRITICAL','',0,0,'','k:stall');      // no conversation
WFCA_Alerts::raise('KAPSO_DELIVERY_FAILED','CRITICAL','recL1',7,3,'','k:del');           // conversation 7
WFCA_Alerts::flush_ring(2);
t('conversation alert is mirrored to the EXISTING Airtable field Commercial Error (no new table)',count(WFCA_Airtable::$updates)===1&&WFCA_Airtable::$updates[0][0]==='+5511999990000'&&str_starts_with(WFCA_Airtable::$updates[0][1]['Commercial Error'],'ALERT CRITICAL KAPSO_DELIVERY_FAILED @ ')&&array_keys(WFCA_Airtable::$updates[0][1])===['Commercial Error']);
t('mirror flag set, entry not mirrored twice',$ring()[1]['mirrored']===1);
WFCA_Alerts::flush_ring(2);
t('conversation-less alert: no owner e-mail configured => nothing to send, nothing breaks',$GLOBALS['mails']===[]);
// owner email
$GLOBALS['opts']['admin_email']='dono@example.com';
WFCA_Alerts::flush_ring(2);
t('conversation-less CRITICAL (never queued by enqueue()) gets ONE direct owner e-mail',count($GLOBALS['mails'])===1&&$GLOBALS['mails'][0][0]==='dono@example.com'&&str_contains($GLOBALS['mails'][0][2],'D0_STALL')&&$ring()[0]['mailed']===1);
WFCA_Alerts::flush_ring(2);WFCA_Alerts::flush_ring(2);
t('and never again',count($GLOBALS['mails'])===1);

// Airtable failure keeps it pending
reset_all();WFCA_Airtable::$ok=false;
WFCA_Alerts::raise('POST_SEND_LOCAL_COMMIT_FAIL','CRITICAL','recL1',7,0,'','k:a');WFCA_Alerts::raise('UNEXPECTED_PROCESSING_ERROR','CRITICAL','recL2',7,0,'','k:b');
WFCA_Alerts::flush_ring(2);
t('Airtable write fails => entry stays pending and the loop stops at the first failure (1 call)',count(WFCA_Airtable::$updates)===1&&$ring()[0]['mirrored']===0);
WFCA_Airtable::$ok=true;WFCA_Alerts::flush_ring(2);
t('retried next tick when Airtable is back',$ring()[0]['mirrored']===1&&$ring()[1]['mirrored']===1);

// age out
reset_all();
$GLOBALS['opts']['wfca_alerts_ring']=[['k'=>'old','at'=>gmdate('c',time()-90000),'reason'=>'OLD','lead'=>'','conv'=>7,'mirrored'=>0,'mailed'=>0]];
WFCA_Alerts::flush_ring(2);
t('entries older than 24 h are not retried',WFCA_Airtable::$updates===[]);

// health tail + switches
reset_all();WFCA_Alerts::raise('A','CRITICAL','',0,0,'','k1');WFCA_Alerts::raise('B','CRITICAL','',0,0,'','k2');
t('ring_tail(n) returns the last n for health_v1',count(WFCA_Alerts::ring_tail(1))===1&&WFCA_Alerts::ring_tail(1)[0]['reason']==='B');
reset_all();WFCA_Airtable::$cfg=['WFCA_RULES_V1'=>'{"alerts_ring_enabled":false}'];
WFCA_Alerts::raise('A','CRITICAL','recL1',7,0,'','k1');WFCA_Alerts::flush_ring();
t('alerts_ring_enabled=false switches the whole channel off',$ring()===[]&&WFCA_Airtable::$updates===[]);
reset_all();WFCA_Airtable::$cfg=['WFCA_RULES_V1'=>'{"alerts_airtable_mirror":false,"alerts_direct_mail":false}'];$GLOBALS['opts']['admin_email']='dono@example.com';
WFCA_Alerts::raise('A','CRITICAL','recL1',7,0,'','k1');WFCA_Alerts::raise('B','CRITICAL','',0,0,'','k2');WFCA_Alerts::flush_ring();
t('mirror and direct mail have their own switches',WFCA_Airtable::$updates===[]&&$GLOBALS['mails']===[]&&count($ring())===2);
t('flush_ring is wired in the tick after the alert queue',str_contains(file_get_contents(__DIR__.'/../includes/class-wfca-engine.php'),"WFCA_Alerts::process_queue(4);\n            WFCA_Alerts::flush_ring(2);"));
echo "TOTAL PASS=$pass FAIL=$fail\n";exit($fail?1:0);
