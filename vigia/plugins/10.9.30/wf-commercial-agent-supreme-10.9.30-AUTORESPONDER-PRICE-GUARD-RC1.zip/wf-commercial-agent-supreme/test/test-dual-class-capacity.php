<?php
define('ABSPATH', __DIR__.'/');
function wp_json_encode($v,$flags=0){return json_encode($v,$flags);}
function wp_strip_all_tags($x){return strip_tags((string)$x);}
require_once __DIR__.'/../includes/class-wfca-util.php';
$pass=0;$fail=0;function t($n,$c){global $pass,$fail;if($c){echo "PASS $n\n";$pass++;}else{echo "FAIL $n\n";$fail++;}}
$days=[];foreach(['mon','tue','wed','thu','fri'] as $d)$days[$d]=['proactive'=>true,'windows'=>['08:00-18:00'],'spacing_seconds'=>600];$days['sat']=['proactive'=>true,'windows'=>['08:00-13:00'],'spacing_seconds'=>600];$days['sun']=['proactive'=>false,'windows'=>[],'spacing_seconds'=>600];
$d0=json_encode(['version'=>'COMMERCIAL_CLASS_SCHEDULE_V1','timezone'=>'America/Sao_Paulo','days'=>$days]);
$fdays=[];foreach(['mon','tue','wed','thu','fri'] as $d)$fdays[$d]=['proactive'=>true,'windows'=>['09:00-18:00'],'spacing_seconds'=>600];$fdays['sat']=['proactive'=>true,'windows'=>['09:00-13:00'],'spacing_seconds'=>600];$fdays['sun']=['proactive'=>false,'windows'=>[],'spacing_seconds'=>600];
$fu=json_encode(['version'=>'COMMERCIAL_CLASS_SCHEDULE_V1','timezone'=>'America/Sao_Paulo','days'=>$fdays]);
$shared=json_encode(['version'=>'COMMERCIAL_WEEKLY_SCHEDULE_V1','timezone'=>'America/Sao_Paulo','days'=>$fdays]);
$cfg=['COMMERCIAL_WEEKLY_SCHEDULE_V1'=>$shared,'COMMERCIAL_D0_WEEKLY_SCHEDULE_V1'=>$d0,'COMMERCIAL_FOLLOWUP_WEEKLY_SCHEDULE_V1'=>$fu,'COMMERCIAL_GLOBAL_PROACTIVE_MIN_SECONDS_V1'=>'600'];
$tz=new DateTimeZone('America/Sao_Paulo');
$fri830=new DateTimeImmutable('2026-09-25 08:30:00',$tz);
$fri905=new DateTimeImmutable('2026-09-25 09:05:00',$tz);
$sat830=new DateTimeImmutable('2026-09-26 08:30:00',$tz);
$sat905=new DateTimeImmutable('2026-09-26 09:05:00',$tz);
$p=WFCA_Util::class_commercial_policy($cfg,'TEMPLATE_INITIAL',$fri830);t('Friday D0 source class policy',($p['source']??'')==='COMMERCIAL_D0_WEEKLY_SCHEDULE_V1');t('Friday D0 opens at08',WFCA_Util::inside_window((string)$p['windows'],$fri830));
$p=WFCA_Util::class_commercial_policy($cfg,'FOLLOWUP',$fri830);t('Friday FU closed before09',!WFCA_Util::inside_window((string)$p['windows'],$fri830));
t('Friday FU open after09',WFCA_Util::inside_window((string)$p['windows'],$fri905));
$p=WFCA_Util::class_commercial_policy($cfg,'TEMPLATE_INITIAL',$sat830);t('Saturday D0 open08',WFCA_Util::inside_window((string)$p['windows'],$sat830));
$p=WFCA_Util::class_commercial_policy($cfg,'FOLLOWUP',$sat830);t('Saturday FU closed08',!WFCA_Util::inside_window((string)$p['windows'],$sat830));t('Saturday FU open09',WFCA_Util::inside_window((string)$p['windows'],$sat905));
t('aggregate canary floor600',WFCA_Util::global_proactive_min_seconds($cfg,$fri905)===600);$cfg['COMMERCIAL_GLOBAL_PROACTIVE_MIN_SECONDS_V1']='300';t('aggregate promoted floor300',WFCA_Util::global_proactive_min_seconds($cfg,$fri905)===300);$cfg['COMMERCIAL_GLOBAL_PROACTIVE_MIN_SECONDS_V1']='299';t('aggregate below hard floor fails closed',WFCA_Util::global_proactive_min_seconds($cfg,$fri905)===86400);
$bad=$cfg;$bad['COMMERCIAL_D0_WEEKLY_SCHEDULE_V1']='not-json';$p=WFCA_Util::class_commercial_policy($bad,'TEMPLATE_INITIAL',$fri905);t('malformed present class policy fails closed',empty($p['valid']));
$inherit=$cfg;unset($inherit['COMMERCIAL_D0_WEEKLY_SCHEDULE_V1']);$p=WFCA_Util::class_commercial_policy($inherit,'TEMPLATE_INITIAL',$fri905);t('missing class policy inherits shared',($p['source']??'')==='WEEKLY_POLICY');
$engine=file_get_contents(__DIR__.'/../includes/class-wfca-engine.php');$db=file_get_contents(__DIR__.'/../includes/class-wfca-db.php');$rest=file_get_contents(__DIR__.'/../includes/class-wfca-rest.php');
t('initial scheduler uses D0 class policy',str_contains($engine,"class_commercial_policy(\$cfg,'TEMPLATE_INITIAL')"));
t('FU scheduler uses FU class policy',str_contains($engine,"class_commercial_policy(\$cfg,'FOLLOWUP')"));
t('final fence enforces class boundary',str_contains($engine,'latest_proactive_class_boundary_except_lead'));
t('final fence enforces aggregate boundary',str_contains($engine,'global_proactive_min_seconds'));
t('DB supports class boundary',str_contains($db,'latest_proactive_class_boundary_except_lead'));
t('health exposes dual class capability',str_contains($rest,"'dual_class_proactive_pacing_v1'=>true"));
echo "TOTAL PASS=$pass FAIL=$fail\n";exit($fail?1:0);
