<?php
define('ABSPATH', __DIR__.'/');
function wp_json_encode($v,$flags=0){return json_encode($v,$flags);}function wp_strip_all_tags($x){return strip_tags((string)$x);} 
require_once __DIR__.'/../includes/class-wfca-util.php';
$pass=0;$fail=0;function t($n,$c){global $pass,$fail;if($c){echo "PASS $n\n";$pass++;}else{echo "FAIL $n\n";$fail++;}}
$days=[];foreach(['mon','tue','wed','thu','fri'] as $d)$days[$d]=['proactive'=>true,'windows'=>['09:00-18:00'],'spacing_seconds'=>540];$days['sat']=['proactive'=>true,'windows'=>['09:00-13:00'],'spacing_seconds'=>240];$days['sun']=['proactive'=>false,'windows'=>[],'spacing_seconds'=>600];
$d0=json_encode(['version'=>'COMMERCIAL_CLASS_SCHEDULE_V1','timezone'=>'America/Sao_Paulo','days'=>$days]);
$fuDays=[];foreach(['mon','tue','wed','thu','fri'] as $d)$fuDays[$d]=['proactive'=>true,'windows'=>['09:00-18:00'],'spacing_seconds'=>600];$fuDays['sat']=['proactive'=>true,'windows'=>['09:00-13:00'],'spacing_seconds'=>600];$fuDays['sun']=['proactive'=>false,'windows'=>[],'spacing_seconds'=>600];
$fu=json_encode(['version'=>'COMMERCIAL_CLASS_SCHEDULE_V1','timezone'=>'America/Sao_Paulo','days'=>$fuDays]);
$shared=json_encode(['version'=>'COMMERCIAL_WEEKLY_SCHEDULE_V1','timezone'=>'America/Sao_Paulo','days'=>$fuDays]);
$global=json_encode(['version'=>'COMMERCIAL_GLOBAL_PROACTIVE_WEEKLY_POLICY_V1','timezone'=>'America/Sao_Paulo','days'=>['mon'=>['min_seconds'=>300],'tue'=>['min_seconds'=>300],'wed'=>['min_seconds'=>300],'thu'=>['min_seconds'=>300],'fri'=>['min_seconds'=>300],'sat'=>['min_seconds'=>120],'sun'=>['min_seconds'=>600]]]);
$cfg=['COMMERCIAL_WEEKLY_SCHEDULE_V1'=>$shared,'COMMERCIAL_D0_WEEKLY_SCHEDULE_V1'=>$d0,'COMMERCIAL_FOLLOWUP_WEEKLY_SCHEDULE_V1'=>$fu,'COMMERCIAL_GLOBAL_PROACTIVE_WEEKLY_POLICY_V1'=>$global];
$tz=new DateTimeZone('America/Sao_Paulo');$wed=new DateTimeImmutable('2026-09-30 12:00:00',$tz);$sat=new DateTimeImmutable('2026-10-03 10:00:00',$tz);
$p=WFCA_Util::class_commercial_policy($cfg,'TEMPLATE_INITIAL',$wed);t('weekday D0 540 valid',!empty($p['valid'])&&(int)$p['spacing_seconds']===540&&WFCA_Util::inside_window((string)$p['windows'],$wed));
$p=WFCA_Util::class_commercial_policy($cfg,'TEMPLATE_INITIAL',$sat);t('Saturday D0 240 valid',!empty($p['valid'])&&(int)$p['spacing_seconds']===240&&WFCA_Util::inside_window((string)$p['windows'],$sat));
t('Saturday aggregate 120 valid',WFCA_Util::global_proactive_min_seconds($cfg,$sat)===120);
$bad=json_decode($d0,true);$bad['days']['sat']['spacing_seconds']=239;$cfgBad=$cfg;$cfgBad['COMMERCIAL_D0_WEEKLY_SCHEDULE_V1']=json_encode($bad);$p=WFCA_Util::class_commercial_policy($cfgBad,'TEMPLATE_INITIAL',$wed);t('D0 below240 fails whole-week closed',empty($p['valid']));
$badFu=json_decode($fu,true);$badFu['days']['sat']['spacing_seconds']=240;$cfgBadFu=$cfg;$cfgBadFu['COMMERCIAL_FOLLOWUP_WEEKLY_SCHEDULE_V1']=json_encode($badFu);$p=WFCA_Util::class_commercial_policy($cfgBadFu,'FOLLOWUP',$wed);t('FU below300 still fails closed',empty($p['valid']));
$engine=file_get_contents(__DIR__.'/../includes/class-wfca-engine.php');$rest=file_get_contents(__DIR__.'/../includes/class-wfca-rest.php');
t('scheduler uses action-aware D0 floor',str_contains($engine,"class_min_spacing_seconds('TEMPLATE_INITIAL')"));
t('pre-send uses action-aware class floor',str_contains($engine,'class_min_spacing_seconds($action)'));
t('health accepts aggregate120 contract',str_contains($rest,'$global_spacing>=120'));
t('health advertises D0 240 capability',str_contains($rest,"'d0_240s_class_floor_v1'=>true"));
echo "TOTAL PASS=$pass FAIL=$fail\n";exit($fail?1:0);
