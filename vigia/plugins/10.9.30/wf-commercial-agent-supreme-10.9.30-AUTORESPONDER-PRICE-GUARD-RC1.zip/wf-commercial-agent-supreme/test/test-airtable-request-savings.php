<?php
// Guards the Airtable request-count savings: phone-policy snapshot in scans, batched conversation prefetch in
// inventory materialization (consumed once per phone), and no re-read of a record the caller just read.
define('ABSPATH', __DIR__.'/'); define('WFCA_VERSION','t'); define('MINUTE_IN_SECONDS',60); define('DAY_IN_SECONDS',86400);
define('WFCA_AIRTABLE_TOKEN','patFAKE'); define('WFCA_AIRTABLE_BASE_ID','appFAKE');
class WP_Error {} function is_wp_error($x){return $x instanceof WP_Error;}
function wp_remote_retrieve_response_code($r){return $r['code'];} function wp_remote_retrieve_body($r){return $r['body'];}
function wp_json_encode($v,$f=0){return json_encode($v,$f);} function sanitize_email($x){return $x;} function wp_strip_all_tags($x){return strip_tags((string)$x);}
$OPT=[];$TR=[];$LOG=[];$STORE=['Leads'=>[],'Commercial Conversations'=>[],'Config'=>[]];$CFG_FAIL=false;$BULK_FAIL=false;$BULK_BAD=false;$ON_POST=null;$TGET=0;
function get_option($k,$d=false){global $OPT;return $OPT[$k]??$d;} function update_option($k,$v,$a=null){global $OPT;$OPT[$k]=$v;return true;}
function get_transient($k){global $TR,$TGET;if($k==='wfca_config_current')$TGET++;return $TR[$k]??false;} function set_transient($k,$v,$t){global $TR;$TR[$k]=$v;return true;} function delete_transient($k){global $TR;unset($TR[$k]);return true;}
function wp_remote_request($url,$args){
  global $STORE,$LOG,$CFG_FAIL,$BULK_FAIL,$BULK_BAD,$ON_POST; $u=parse_url($url);$p=explode('/',trim($u['path'],'/'));$table=rawurldecode($p[2]);$rid=$p[3]??null;parse_str($u['query']??'',$q);$m=$args['method'];
  $f=$q['filterByFormula']??'';$LOG[]=[$m,$table,$rid,$f];
  $ok=fn($d)=>['code'=>200,'body'=>json_encode($d)];
  if($table==='Config'&&$CFG_FAIL) return ['code'=>503,'body'=>'{}'];
  if($m==='GET'){
    if($rid) return isset($STORE[$table][$rid])?$ok($STORE[$table][$rid]):['code'=>404,'body'=>'{}'];
    $rows=array_values($STORE[$table]??[]);
    if($table==='Commercial Conversations' && preg_match_all("/Conversation ID\}='([^']+)'/",$f,$mm)){ if($BULK_FAIL&&str_starts_with($f,'OR(')) return ['code'=>500,'body'=>'{}']; if($BULK_BAD&&str_starts_with($f,'OR(')) return ['code'=>200,'body'=>'<html>captive</html>']; $rows=array_values(array_filter($rows,fn($r)=>in_array($r['fields']['Conversation ID']??'',$mm[1],true))); }
    if($table==='Config') $rows=array_values(array_filter($rows,fn($r)=>($r['fields']['Status']??'')==='CURRENT'));
    $off=(int)($q['offset']??0);$ps=(int)($q['pageSize']??100);if(isset($q['maxRecords']))$ps=min($ps,(int)$q['maxRecords']);
    $o=['records'=>array_slice($rows,$off,$ps)]; if($off+$ps<count($rows)&&!isset($q['maxRecords'])) $o['offset']=(string)($off+$ps); return $ok($o);
  }
  $b=json_decode($args['body'],true);
  if($m==='POST'){ if($ON_POST&&$table==='Commercial Conversations'){$cb=$ON_POST;$ON_POST=null;$cb();} foreach($b['records'] as $r){ $id='recNEW'.count($STORE[$table]); $STORE[$table][$id]=['id'=>$id,'fields'=>$r['fields']]; } return $ok(['records'=>[['id'=>'x']]]); }
  foreach($b['records'] as $r){ $STORE[$table][$r['id']]['fields']=array_merge($STORE[$table][$r['id']]['fields'],$r['fields']); } return $ok(['records'=>[['id'=>'x']]]);
}
function nlog($m=null,$t=null){global $LOG;return count(array_filter($LOG,fn($l)=>($m===null||$l[0]===$m)&&($t===null||$l[1]===$t)));}
require_once __DIR__.'/../includes/class-wfca-util.php'; require_once __DIR__.'/../includes/class-wfca-airtable.php'; require_once __DIR__.'/../includes/class-wfca-ownership.php';
final class WFCA_DB { public static function t($n){return $n;} public static function get_conversation_by_phone($p){return null;} public static function initial_outreach_exists(...$a){return false;}
  public static function upsert_conversation($p,$f){return array_merge(['id'=>1,'phone_e164'=>$p],$f);} public static function materialize_remote_snapshot(...$a){} }
require_once __DIR__.'/../includes/class-wfca-engine.php';
$pass=0;$fail=0;function t($n,$c){global $pass,$fail;if($c){echo "PASS $n\n";$pass++;}else{echo "FAIL $n\n";$fail++;}}
function lead($i,$tel=null){$id='recL'.$i;return ['id'=>$id,'fields'=>['Lead'=>"C$i",'Telefone'=>$tel??('(11) 9'.str_pad((string)$i,8,'0',STR_PAD_LEFT)),'Site URL'=>'https://auracorp.online/x/','Build Status'=>'BUILT','Factory State'=>'FACTORY_COMPLETE','Public Smoke Status'=>'PASS','Assigned Arm'=>'LUNA_COLD_WHATSAPP']];}
function conv($i){$e='+55119'.str_pad((string)$i,8,'0',STR_PAD_LEFT);return ['id'=>'recC'.$i,'fields'=>['Conversation ID'=>'wa:'.ltrim($e,'+'),'Lead'=>['recL'.$i],'Phone E164'=>$e,'Version'=>4,'Initial Arm'=>'LUNA_COLD_WHATSAPP']];}
function e164($i){return '+55119'.str_pad((string)$i,8,'0',STR_PAD_LEFT);}
function reset_env(){global $LOG,$TR,$TGET,$STORE,$CFG_FAIL,$BULK_FAIL,$BULK_BAD,$ON_POST,$OPT;$LOG=[];$TR=[];$TGET=0;$CFG_FAIL=false;$BULK_FAIL=false;$BULK_BAD=false;$ON_POST=null;$OPT=['wfca_local_mode'=>'LIVE'];$STORE=['Leads'=>[],'Commercial Conversations'=>[],'Config'=>['k'=>['id'=>'k','fields'=>['Key'=>'COMMERCIAL_AGENT_MODE','Value'=>'LIVE','Status'=>'CURRENT']]]];}

// 1. canonical_factory_phone with a snapshot never touches config; same result as default
reset_env(); $pol=WFCA_Airtable::phone_policy(); $g=$GLOBALS['TGET'];
t('policy snapshot gives identical canonical phone',WFCA_Airtable::canonical_factory_phone('(11) 91234-5678',$pol)===WFCA_Airtable::canonical_factory_phone('(11) 91234-5678') && WFCA_Airtable::canonical_factory_phone('(11) 91234-5678',$pol)==='+5511912345678');
$GLOBALS['TGET']=0; for($i=0;$i<50;$i++) WFCA_Airtable::canonical_factory_phone('(11) 91234-5678',$pol); t('snapshot path makes zero config reads',$GLOBALS['TGET']===0);

// 2. find_lead scan reads config once, even when Config endpoint fails
reset_env(); for($i=1;$i<=250;$i++) $STORE['Leads']['recL'.$i]=lead($i); $TR=[];
$r=WFCA_Airtable::find_lead_by_phone(e164(240)); t('scan still finds the lead',!empty($r['ok'])&&$r['lead']['id']==='recL240');
t('scan config reads <=1 (was 1 per record)',$TGET<=1); 
reset_env(); for($i=1;$i<=250;$i++) $STORE['Leads']['recL'.$i]=lead($i); $CFG_FAIL=true;
$r=WFCA_Airtable::find_lead_by_phone(e164(240)); t('scan correct with Config failing (defaults)',!empty($r['ok'])&&$r['lead']['id']==='recL240');
t('Config HTTP during failing scan <=1 (was 1 per record)',nlog('GET','Config')<=1);

// 3. bulk read
reset_env(); for($i=1;$i<=45;$i++) if($i!==7) $STORE['Commercial Conversations']['recC'.$i]=conv($i);
$dup=conv(9);$dup['id']='recC9b';$STORE['Commercial Conversations']['recC9b']=$dup;
$phones=[];for($i=1;$i<=45;$i++)$phones[]=e164($i); $LOG=[]; $b=WFCA_Airtable::get_commercial_conversations_bulk($phones);
t('bulk: 45 phones = 3 HTTP calls',nlog()===3 && count($b)===45);
t('bulk: found/missing/duplicate shapes match single read',$b['wa:'.ltrim(e164(1),'+')]['record']['id']==='recC1' && $b['wa:'.ltrim(e164(7),'+')]===['ok'=>true,'record'=>null] && $b['wa:'.ltrim(e164(9),'+')]['error']==='DUPLICATE_COMMERCIAL_CONVERSATION');
$s=WFCA_Airtable::get_commercial_conversation(e164(1)); t('bulk record equals single-read record',$s['record']===$b['wa:'.ltrim(e164(1),'+')]['record']);
$BULK_FAIL=true; $b2=WFCA_Airtable::get_commercial_conversations_bulk($phones); t('bulk failure yields no entries (caller falls back to single reads)',$b2===[]);
$BULK_BAD=true; t('bulk: a 2xx without a records list is a failed chunk (no phantom absent rows)',WFCA_Airtable::get_commercial_conversations_bulk([e164(1),e164(2)])===[]); $BULK_BAD=false;
$BULK_FAIL=false; t('bulk ignores invalid phones',WFCA_Airtable::get_commercial_conversations_bulk(['abc',''])===[]);

// 4. upsert with a known fresh read skips the GET; Version still +1
reset_env(); $STORE['Commercial Conversations']['recC1']=conv(1); $known=WFCA_Airtable::get_commercial_conversation(e164(1)); $LOG=[];
$w=WFCA_Airtable::upsert_commercial_conversation(e164(1),'recL1',['State'=>'ENGAGED'],$known);
t('upsert(known) does no GET and one PATCH',nlog('GET')===0&&nlog('PATCH')===1&&$STORE['Commercial Conversations']['recC1']['fields']['Version']===5);
$LOG=[]; WFCA_Airtable::upsert_commercial_conversation(e164(1),'recL1',['State'=>'ENGAGED'],['ok'=>false,'error'=>'X']); t('upsert with failed known read re-reads',nlog('GET')===1);
$LOG=[]; WFCA_Airtable::upsert_commercial_conversation(e164(1),'recL1',['State'=>'ENGAGED']); t('upsert without known unchanged (GET+PATCH)',nlog('GET')===1&&nlog('PATCH')===1);

// 5. materialize: prefetch used, same outcome, duplicate-phone leads never trust a stale prefetch
$mat=(new ReflectionClass('WFCA_Engine'))->getMethod('materialize_commercial_ready_inventory');$mat->setAccessible(true);
reset_env(); for($i=1;$i<=60;$i++){ $STORE['Leads']['recL'.$i]=lead($i); if($i<=50) $STORE['Commercial Conversations']['recC'.$i]=conv($i); }
$LOG=[]; $out=$mat->invoke(null,250);
t('materialize ok: 50 preserved, 10 created',($out['ok']??false)&&$out['preserved']===50&&$out['created']===10);
t('materialize: 3 batched reads + 3 live reads per created lead (absent rows are never trusted) = 33 GET (was 80)',nlog('GET','Commercial Conversations')===33 && nlog('POST','Commercial Conversations')===10);
// 5b. RACE (adversarial review): a conversation created mid-pass (inbound/STOP/owner change) for a lead whose prefetched row was 'absent' must NOT be overwritten
reset_env(); $STORE['Leads']['recL1']=lead(1); $STORE['Leads']['recL2']=lead(2);
$ON_POST=function(){ global $STORE; $c=conv(2); $c['fields']['Conversation Owner']='DANIEL'; $c['fields']['State']='ENGAGED'; $c['fields']['Version']=3; $STORE['Commercial Conversations']['recC2']=$c; };
$LOG=[]; $out=$mat->invoke(null,250); $row=$STORE['Commercial Conversations']['recC2']['fields']??[];
t('race: conversation created mid-pass keeps owner/state/version (not reset to LUNA/READY)',($row['Conversation Owner']??'')==='DANIEL' && ($row['State']??'')==='ENGAGED' && ($row['Version']??0)===3);
reset_env(); $STORE['Leads']['recLA']=lead('A','(11) 900000777'); $STORE['Leads']['recLB']=lead('B','(11) 900000777'); $LOG=[];
$out=$mat->invoke(null,250); t('duplicate-phone leads: only one conversation created (second re-reads live)',nlog('POST','Commercial Conversations')===1);
// 6. wiring
$eng=file_get_contents(__DIR__.'/../includes/class-wfca-engine.php');
t('prefetch trusted only for existing+fresh rows',str_contains($eng,"!empty(\$prefetch[\$pf_key]['record']) && (microtime(true)-\$pf_at)<2.0"));
t('inbound upserts reuse the just-read conversation',substr_count($eng,'upsert_commercial_conversation($phone,$lead_id,$sync_fields,$got)')===1 && str_contains($eng,'upsert_commercial_conversation($phone,$lead_id,$fields,$got)'));
t('failed-delivery touch passes local arm (no lead re-fetch)',str_contains($eng,"'DELIVERY_FAILED','WA_DELIVERY_FAILED '.\$why.' tail='.\$tail,(string)\$e['provider_message_id'],'KAPSO','LUNA',(string)(\$cv['initial_arm']??'')"));
echo "TOTAL PASS=$pass FAIL=$fail\n";exit($fail?1:0);
