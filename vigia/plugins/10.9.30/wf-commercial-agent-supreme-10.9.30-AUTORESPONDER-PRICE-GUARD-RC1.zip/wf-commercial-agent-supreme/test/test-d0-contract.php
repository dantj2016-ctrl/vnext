<?php
define('ABSPATH', __DIR__.'/');
require_once __DIR__.'/../includes/class-wfca-airtable.php';

$pass=0;$fail=0;
function t($name,$cond){global $pass,$fail;if($cond){echo "PASS $name\n";$pass++;}else{echo "FAIL $name\n";$fail++;}}

$leadId='recTEST123456789';
$sha=str_repeat('a',64);
$url='https://auracorp.online/wf-d0-preview/'.$leadId.'/'.$sha.'/raw';
$generated='2026-09-22T09:15:57.000Z';
$factory='2026-09-22T09:33:53.000Z';
$run='WF-LANE_A-TEST-RUN';
$smoke=[
  'factory_run_id'=>$run,
  'reviewed_at'=>'2026-09-22T09:33:53Z',
  'canonical_visual'=>['screenshot_sha256'=>$sha],
  'd0_preview'=>[
    'url'=>$url,'sha256'=>$sha,'capture_sha256'=>$sha,
    'generated_at'=>'2026-09-22T09:15:57Z','status'=>'READY',
    'lead_record_id'=>$leadId,'factory_run_id'=>$run
  ]
];
$base=['id'=>$leadId,'fields'=>[
  'D0 Preview Status'=>'READY','D0 Preview Image URL'=>$url,'D0 Preview SHA256'=>$sha,
  'D0 Preview Generated At'=>$generated,'Last Factory At'=>$factory,'Public Smoke Status'=>'PASS',
  'Visual Smoke Evidence'=>json_encode($smoke,JSON_UNESCAPED_SLASHES)
]];
$r=WFCA_Airtable::d0_preview_contract($base);
t('stale timestamp accepted only when final smoke binds exact D0',!empty($r['ok']) && $r['sha256']===$sha);

$x=$base; $x['fields']['Visual Smoke Evidence']='{}';
$r=WFCA_Airtable::d0_preview_contract($x);
t('stale without smoke evidence fails closed',empty($r['ok']) && ($r['error']??'')==='D0_PREVIEW_STALE_BEFORE_FACTORY');

$x=$base; $bad=$smoke; $bad['canonical_visual']['screenshot_sha256']=str_repeat('b',64);$x['fields']['Visual Smoke Evidence']=json_encode($bad);
$r=WFCA_Airtable::d0_preview_contract($x);
t('stale with screenshot sha mismatch fails closed',empty($r['ok']) && ($r['error']??'')==='D0_PREVIEW_STALE_BEFORE_FACTORY');

$x=$base; $bad=$smoke; $bad['reviewed_at']='2026-09-22T09:34:10Z';$x['fields']['Visual Smoke Evidence']=json_encode($bad);
$r=WFCA_Airtable::d0_preview_contract($x);
t('stale with final smoke timestamp mismatch fails closed',empty($r['ok']) && ($r['error']??'')==='D0_PREVIEW_STALE_BEFORE_FACTORY');

$x=$base; $bad=$smoke; $bad['d0_preview']['lead_record_id']='recOTHER';$x['fields']['Visual Smoke Evidence']=json_encode($bad);
$r=WFCA_Airtable::d0_preview_contract($x);
t('stale with lead binding mismatch fails closed',empty($r['ok']) && ($r['error']??'')==='D0_PREVIEW_STALE_BEFORE_FACTORY');

$x=$base; $x['fields']['D0 Preview Generated At']='2026-09-22T09:32:00Z'; $x['fields']['Visual Smoke Evidence']='';
$r=WFCA_Airtable::d0_preview_contract($x);
t('fresh preview still passes without smoke evidence',!empty($r['ok']));

$x=$base; $x['fields']['D0 Preview Status']='PENDING';
$r=WFCA_Airtable::d0_preview_contract($x);
t('non-ready preview fails',empty($r['ok']) && ($r['error']??'')==='D0_PREVIEW_NOT_READY');

$x=$base; $x['fields']['D0 Preview Image URL']='http://auracorp.online/x';
$r=WFCA_Airtable::d0_preview_contract($x);
t('non-https preview fails',empty($r['ok']) && ($r['error']??'')==='D0_PREVIEW_URL_INVALID');

exit($fail?1:0);
