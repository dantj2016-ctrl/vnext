<?php
define('ABSPATH', __DIR__.'/');
function wp_strip_all_tags($x){return strip_tags((string)$x);}
final class WFCA_Util {
    public static function short_text(string $text,int $max=1200): string {return substr(trim($text),0,$max);}
    public static function lower(string $text): string {return strtolower($text);}
    public static function rules(): array {return ['auto_resume_enabled'=>true,'auto_resume_after_seconds'=>1800,'auto_resume_extra_blocked_states'=>[],'gatekeeper_email_redirect_enabled'=>true,'gatekeeper_extra_hostile_words'=>[]];}
}
final class WFCA_DB { public static $conv=[]; public static function get_conversation($id){return self::$conv;} }
final class WFCA_Ownership {
    public static $calls=[]; public static $synced=0;
    public static function change($id,$owner,$reason,$rev,$explicit=false,$at=''){self::$calls[]=[$owner,$reason,$explicit,$at];WFCA_DB::$conv['conversation_owner']=$owner;WFCA_DB::$conv['owner_reason']=$reason;return ['ok'=>true,'revision'=>$rev+1];}
    public static function sync($id){self::$synced++;return true;}
    public static function arm(string $a): string {return $a;}
    public static function remote_arm(string $a): string {return $a;}
}
require_once __DIR__.'/../includes/class-wfca-engine.php';
$m=(new ReflectionClass('WFCA_Engine'))->getMethod('maybe_auto_resume');$m->setAccessible(true);
$pass=0;$fail=0;function t($n,$c){global $pass,$fail;if($c){echo "PASS $n\n";$pass++;}else{echo "FAIL $n\n";$fail++;}}
function run($conv,$remote=['Conversation Owner'=>'DANIEL']){ WFCA_Ownership::$calls=[];WFCA_Ownership::$synced=0;WFCA_DB::$conv=$conv;
  global $m; $r=$m->invoke(null,$conv,$remote); return $r; }
$old=gmdate('Y-m-d H:i:s',time()-3600);$fresh=gmdate('Y-m-d H:i:s',time()-600);
$base=['id'=>1,'owner_revision'=>3,'conversation_owner'=>'DANIEL','owner_reason'=>'WHATSAPP_BUSINESS_MANUAL','state'=>'ENGAGED','opt_out'=>0,'last_manual_at'=>$old];
$r=run($base);t('resumes after 30 min',count(WFCA_Ownership::$calls)===1&&WFCA_Ownership::$calls[0][0]==='LUNA'&&WFCA_Ownership::$calls[0][2]===true&&WFCA_Ownership::$synced===1&&$r['conversation_owner']==='LUNA');
run(array_merge($base,['last_manual_at'=>$fresh]));t('holds inside 30 min',count(WFCA_Ownership::$calls)===0);
run(array_merge($base,['owner_reason'=>'WHATSAPP_BUSINESS_MANUAL_TAKEOVER']));t('eu assumo keeps Luna out',count(WFCA_Ownership::$calls)===0);
run(array_merge($base,['owner_reason'=>'AIRTABLE_OWNER_CHANGE']));t('explicit Airtable owner change keeps Luna out',count(WFCA_Ownership::$calls)===0);
run(array_merge($base,['opt_out'=>1]));t('opt-out never resumes',count(WFCA_Ownership::$calls)===0);
run($base,['Conversation Owner'=>'DANIEL','Opt Out'=>true]);t('remote opt-out never resumes',count(WFCA_Ownership::$calls)===0);
run($base,['Conversation Owner'=>'DANIEL','State'=>'HUMAN_HANDOFF']);t('remote handoff state keeps Luna out',count(WFCA_Ownership::$calls)===0);
foreach(['HUMAN_HANDOFF','PRICE_STATE','HIGH_INTENT','CHECKOUT_SENT','PAYMENT_PENDING','PAID','ERROR_HOLD'] as $st){run(array_merge($base,['state'=>$st]));t("local $st keeps Luna out",count(WFCA_Ownership::$calls)===0);}
run($base,['Conversation Owner'=>'STOPPED']);t('remote owner not DANIEL keeps hands off',count(WFCA_Ownership::$calls)===0);
run(array_merge($base,['conversation_owner'=>'LUNA']));t('already Luna is a no-op',count(WFCA_Ownership::$calls)===0);
run(array_merge($base,['last_manual_at'=>null]));t('missing manual timestamp does not resume',count(WFCA_Ownership::$calls)===0);
$src=file_get_contents(__DIR__.'/../includes/class-wfca-engine.php');
t('takeover keyword wired in manual_receipt',str_contains($src,'WHATSAPP_BUSINESS_MANUAL_TAKEOVER')&&str_contains($src,'eu\\s+assumo'));
t('resume runs before the REPLY fence',strpos($src,'self::maybe_auto_resume($conv,$cf)')<strpos($src,"WFCA_Ownership::fence((int)\$conv['id'],'REPLY'"));
echo "TOTAL PASS=$pass FAIL=$fail\n";exit($fail?1:0);
