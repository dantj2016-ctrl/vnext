<?php
define('ABSPATH', __DIR__.'/');
$openai=file_get_contents(__DIR__.'/../includes/class-wfca-openai.php');
$main=file_get_contents(__DIR__.'/../wf-commercial-agent.php');
$rest=file_get_contents(__DIR__.'/../includes/class-wfca-rest.php');
$pass=0;$fail=0;function t($n,$c){global $pass,$fail;if($c){echo "PASS $n\n";$pass++;}else{echo "FAIL $n\n";$fail++;}}
t('brain class required before OpenAI',strpos($main,'class-wfca-luna-brain-v2.php')!==false && strpos($main,'class-wfca-luna-brain-v2.php')<strpos($main,'class-wfca-openai.php'));
t('prompt receives brain context',str_contains($openai,"'luna_sales_brain_v2'=>\$brain"));
t('prompt forbids book copy',str_contains($openai,'Never copy book text'));
t('schema records actor',str_contains($openai,"'actor'=>['type'=>'string'"));
t('schema records tactic ids',str_contains($openai,"'selected_tactic_ids'=>['type'=>'array'"));
t('model tactics constrained to candidate retrieval',str_contains($openai,'validate_tactics'));
t('payment mismatch pre-model hard gate',str_contains($openai,"\$hard==='PAYMENT_MISMATCH'"));
t('complaint pre-model hard gate',str_contains($openai,"\$hard==='COMPLAINT'"));
t('safety pre-model hard gate',str_contains($openai,"\$hard==='SAFETY_OUT_OF_SCOPE'"));
t('metadata telemetry recorded',str_contains($openai,'WFCA_Luna_Brain_V2::record_decision'));
t('health exposes brain capability',str_contains($rest,"'luna_sales_brain_v2'=>true"));
echo "TOTAL PASS=$pass FAIL=$fail\n";exit($fail?1:0);
