<?php
define('ABSPATH', __DIR__.'/');
function wp_strip_all_tags($x){return strip_tags((string)$x);}
final class WFCA_Util {
    public static function short_text(string $text,int $max=1200): string {$text=preg_replace('/\s+/u',' ',strip_tags($text));$text=trim((string)$text);return function_exists('mb_substr')?mb_substr($text,0,$max,'UTF-8'):substr($text,0,$max);}
    public static function lower(string $text): string {return function_exists('mb_strtolower')?mb_strtolower($text,'UTF-8'):strtolower($text);}
}
final class WFCA_Ownership {
    public static function arm(string $arm): string {return match(strtoupper(trim($arm))){'CALL_FIRST','DANIEL_CALL'=>'DANIEL_CALL','ASYNC_FIRST','DANIEL_ASYNC'=>'DANIEL_ASYNC','LUNA_COLD_WHATSAPP'=>'LUNA_COLD_WHATSAPP',default=>''};}
    public static function remote_arm(string $arm): string {return match(self::arm($arm)){'DANIEL_CALL'=>'CALL_FIRST','DANIEL_ASYNC'=>'ASYNC_FIRST','LUNA_COLD_WHATSAPP'=>'LUNA_COLD_WHATSAPP',default=>''};}
}
require_once __DIR__.'/../includes/class-wfca-engine.php';
$ref=new ReflectionClass('WFCA_Engine');$m=$ref->getMethod('initial_arm_decision');$m->setAccessible(true);
$pass=0;$fail=0;function t($n,$c){global $pass,$fail;if($c){echo "PASS $n\n";$pass++;}else{echo "FAIL $n\n";$fail++;}}
$lead=['Assigned Arm'=>'LUNA_COLD_WHATSAPP'];
$d=$m->invoke(null,['Initial Arm'=>'ASYNC_FIRST'],$lead,false);t('untouched async residue reconciles to current luna',($d['raw_arm']??'')==='LUNA_COLD_WHATSAPP'&&!empty($d['reconcile_remote']));
$d=$m->invoke(null,['Initial Arm'=>'CALL_FIRST'],$lead,false);t('untouched call-first residue reconciles to current luna',($d['raw_arm']??'')==='LUNA_COLD_WHATSAPP'&&!empty($d['reconcile_remote']));
$d=$m->invoke(null,['Initial Arm'=>'ASYNC_FIRST','Last Outbound At'=>'2026-09-18T12:00:00Z'],$lead,false);t('outbound history preserves async arm',($d['raw_arm']??'')==='ASYNC_FIRST'&&empty($d['reconcile_remote']));
$d=$m->invoke(null,['Initial Arm'=>'CALL_FIRST','Last Inbound At'=>'2026-09-18T12:00:00Z'],$lead,false);t('inbound history preserves call-first arm',($d['raw_arm']??'')==='CALL_FIRST'&&empty($d['reconcile_remote']));
$d=$m->invoke(null,['Initial Arm'=>'ASYNC_FIRST'],$lead,true);t('prior touch-outbox history preserves legacy arm',($d['raw_arm']??'')==='ASYNC_FIRST'&&empty($d['reconcile_remote']));
$d=$m->invoke(null,['Initial Arm'=>'LUNA_COLD_WHATSAPP'],$lead,false);t('already luna stays luna no rewrite',($d['raw_arm']??'')==='LUNA_COLD_WHATSAPP'&&empty($d['reconcile_remote']));
$d=$m->invoke(null,[],$lead,false);t('empty remote uses current lead luna',($d['raw_arm']??'')==='LUNA_COLD_WHATSAPP'&&empty($d['reconcile_remote']));
$d=$m->invoke(null,['Initial Arm'=>'ASYNC_FIRST'],['Assigned Arm'=>'ASYNC_FIRST'],false);t('matching legacy lead does not auto-luna',($d['raw_arm']??'')==='ASYNC_FIRST'&&empty($d['reconcile_remote']));
$d=$m->invoke(null,['Initial Arm'=>'ASYNC_FIRST'],['Assigned Arm'=>''],false);t('missing current lead assignment preserves remote',($d['raw_arm']??'')==='ASYNC_FIRST'&&empty($d['reconcile_remote']));
$src=file_get_contents(__DIR__.'/../includes/class-wfca-engine.php');
t('scheduler calls decision helper',str_contains($src,'self::initial_arm_decision($f,$lead[\'fields\'],false)'));
t('reconcile writes canonical conversation not lead history',str_contains($src,'WFCA_Airtable::update_commercial_by_phone($phone,['));
t('native sender remains downstream',str_contains($src,'WFCA_DB::queue_initial_idempotent(['));
echo "TOTAL PASS=$pass FAIL=$fail\n";exit($fail?1:0);
