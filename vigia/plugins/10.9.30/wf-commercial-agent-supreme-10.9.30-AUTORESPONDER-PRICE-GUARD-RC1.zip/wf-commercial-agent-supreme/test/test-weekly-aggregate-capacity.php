<?php
define('ABSPATH', __DIR__.'/');
function wp_json_encode($v,$flags=0){return json_encode($v,$flags);} function wp_strip_all_tags($x){return strip_tags((string)$x);} require_once __DIR__.'/../includes/class-wfca-util.php';
$pass=0;$fail=0;function t($n,$c){global $pass,$fail;if($c){echo "PASS $n\n";$pass++;}else{echo "FAIL $n\n";$fail++;}}
$days=[];foreach(['mon','tue','wed','thu','fri'] as $d)$days[$d]=['min_seconds'=>300];$days['sat']=['min_seconds'=>120];$days['sun']=['min_seconds'=>600];
$weekly=json_encode(['version'=>'COMMERCIAL_GLOBAL_PROACTIVE_WEEKLY_POLICY_V1','timezone'=>'America/Sao_Paulo','days'=>$days]);
$cfg=['COMMERCIAL_GLOBAL_PROACTIVE_MIN_SECONDS_V1'=>'600','COMMERCIAL_GLOBAL_PROACTIVE_WEEKLY_POLICY_V1'=>$weekly];$tz=new DateTimeZone('America/Sao_Paulo');
$fri=new DateTimeImmutable('2026-09-25 10:00:00',$tz);$sat=new DateTimeImmutable('2026-09-26 10:00:00',$tz);
t('Friday aggregate weekly300',WFCA_Util::global_proactive_min_seconds($cfg,$fri)===300);
t('Saturday aggregate weekly120',WFCA_Util::global_proactive_min_seconds($cfg,$sat)===120);
$bad=$cfg;$x=json_decode($weekly,true);$x['days']['sat']['min_seconds']=119;$bad['COMMERCIAL_GLOBAL_PROACTIVE_WEEKLY_POLICY_V1']=json_encode($x);t('weekly below120 fails closed',WFCA_Util::global_proactive_min_seconds($bad,$sat)===86400);
$bad2=$cfg;$bad2['COMMERCIAL_GLOBAL_PROACTIVE_WEEKLY_POLICY_V1']='broken';t('malformed weekly fails closed',WFCA_Util::global_proactive_min_seconds($bad2,$sat)===86400);
$fallback=$cfg;unset($fallback['COMMERCIAL_GLOBAL_PROACTIVE_WEEKLY_POLICY_V1']);t('absent weekly preserves scalar600',WFCA_Util::global_proactive_min_seconds($fallback,$sat)===600);
$util=file_get_contents(__DIR__.'/../includes/class-wfca-util.php');$rest=file_get_contents(__DIR__.'/../includes/class-wfca-rest.php');
t('weekly config key wired',str_contains($util,'COMMERCIAL_GLOBAL_PROACTIVE_WEEKLY_POLICY_V1'));
t('health advertises weekly aggregate capability',str_contains($rest,"'weekly_aggregate_policy_v1'=>true"));
echo "TOTAL PASS=$pass FAIL=$fail\n";exit($fail?1:0);
