<?php
define('ABSPATH', __DIR__.'/');
function wp_strip_all_tags($x){return strip_tags((string)$x);} 
final class WFCA_Util {
    public static function short_text(string $text,int $max=1200): string {$text=preg_replace('/\s+/u',' ',strip_tags($text));$text=trim((string)$text);return function_exists('mb_substr')?mb_substr($text,0,$max,'UTF-8'):substr($text,0,$max);} 
    public static function lower(string $text): string {return function_exists('mb_strtolower')?mb_strtolower($text,'UTF-8'):strtolower($text);} 
}
require_once __DIR__.'/../includes/class-wfca-engine.php';
$ref=new ReflectionClass('WFCA_Engine');
$get=function($n)use($ref){$m=$ref->getMethod($n);$m->setAccessible(true);return $m;};
$fu=$get('commercial_followup_insight');$build=$get('build_safe_followup_insight');
$pass=0;$fail=0;function t($n,$c){global $pass,$fail;if($c){echo "PASS $n\n";$pass++;}else{echo "FAIL $n\n";$fail++;}}
$raw='Operação pública em Campinas com telefone, endereço, Maps e Instagram; busca atual não encontrou site próprio forte. Perfil organizacional permite hero por logo/fachada após inspeção visual.';
$lead=['fields'=>['Lead'=>'Estima & Estética','Cidade'=>'Campinas','Especialidade / Posicionamento'=>'Estética Avançada','Observação Específica'=>$raw,'Follow-up Insight'=>'']];
t('empty dedicated field fails closed',$fu->invoke(null,$lead)==='');
$out=$build->invoke(null,$lead);
t('builder avoids observation vocabulary',!str_contains($out,'Operação pública')&&!str_contains($out,'Maps')&&!str_contains($out,'hero')&&!str_contains($out,'fachada')&&!str_contains($out,'inspeção'));
t('builder uses grounded specialty',str_contains($out,'Estética Avançada'));
t('builder stays provider safe',(function_exists('mb_strlen')?mb_strlen($out,'UTF-8'):strlen($out))<=220);
t('builder complete sentence',preg_match('/[.!?]$/u',$out)===1);
$unsafe=$lead;$unsafe['fields']['Follow-up Insight']='CURRENT feeder proof: public phone +5511999999999';
t('unsafe dedicated value fails closed',$fu->invoke(null,$unsafe)==='');
$safe=$lead;$safe['fields']['Follow-up Insight']='A página organiza apresentação, serviços e contato em um único lugar.';
t('safe dedicated field is used',$fu->invoke(null,$safe)===$safe['fields']['Follow-up Insight']);
$src=file_get_contents(__DIR__.'/../includes/class-wfca-engine.php');
t('materializer writes only Follow-up Insight',str_contains($src,"['Follow-up Insight'=>\$copy]") && !str_contains($src,"['Observação Específica'=>\$copy]"));
t('materializer never schedules same tick after write',str_contains($src,'Persist first, schedule only on a later tick after Airtable reread.'));
$rest=file_get_contents(__DIR__.'/../includes/class-wfca-rest.php');
t('health accepts 10 minute followup delay',str_contains($rest,'$followup_delay>=10'));
echo "TOTAL PASS=$pass FAIL=$fail\n";exit($fail?1:0);
