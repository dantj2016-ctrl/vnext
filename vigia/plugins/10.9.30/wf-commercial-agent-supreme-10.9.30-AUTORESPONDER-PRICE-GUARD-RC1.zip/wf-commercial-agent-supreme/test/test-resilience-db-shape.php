<?php
// 10.9.28: SQL shape of the new DB helpers (real WFCA_DB, fake wpdb): hold never counts an attempt, reset only touches never-sent FAILED rows.
define('ABSPATH', __DIR__.'/');define('ARRAY_A','ARRAY_A');
$GLOBALS['opts']=[];
foreach (['wp_strip_all_tags','sanitize_email','is_email','apply_filters','wp_json_encode','home_url','esc_url_raw'] as $fn) { if(!function_exists($fn)) { eval('function '.$fn.'(...$a){return $a[0]??"";}'); } }
function get_option($k,$d=false){return $GLOBALS['opts'][$k]??$d;}
function update_option($k,$v,$a=null){$GLOBALS['opts'][$k]=$v;return true;}
final class FakeWpdb { public $prefix='wp_'; public $sql=[]; public $affected=1; public $row=null;
  public function prepare($q,...$a){ $i=0; return preg_replace_callback('/%[sd]/',function($m) use(&$i,$a){ $v=$a[$i++]??''; return $m[0]==='%d'?(string)(int)$v:"'".addslashes((string)$v)."'"; },$q); }
  public function query($q){$this->sql[]=$q;return $this->affected;} public function get_row($q,$t=null){$this->sql[]=$q;return $this->row;} public function get_results($q,$t=null){$this->sql[]=$q;return [];} public function get_var($q){return 0;} public function update(...$a){return 1;} }
$wpdb=new FakeWpdb();
require_once __DIR__.'/../includes/class-wfca-util.php';
require_once __DIR__.'/../includes/class-wfca-db.php';
$pass=0;$fail=0;function t($n,$c){global $pass,$fail;if($c){echo "PASS $n\n";$pass++;}else{echo "FAIL $n\n";$fail++;}}
$ok=WFCA_DB::hold_outbox_for_provider(['id'=>9],'PROVIDER_HOLD_KAPSO_402',600);$q=end($wpdb->sql);
t('hold: back to PENDING, send boundary cleared, NO attempts change',$ok===true&&str_contains($q,"status='PENDING'")&&str_contains($q,'send_started_at=NULL')&&!str_contains($q,'attempts'));
t('hold: only a PROCESSING row that never reached the provider',str_contains($q,"status='PROCESSING'")&&str_contains($q,'provider_message_id IS NULL')&&str_contains($q,'sent_at IS NULL'));
$wpdb->affected=0;t('hold on a row that is not ours reports false',WFCA_DB::hold_outbox_for_provider(['id'=>9],'x',600)===false);$wpdb->affected=1;
$ok=WFCA_DB::reset_failed_outbox(60,4,'PENDING','RECONCILED_FROM:KAPSO_HTTP_402');$q=end($wpdb->sql);
t('reset: attempts=0, new owner_revision, same row (no new key)',$ok&&str_contains($q,'attempts=0')&&str_contains($q,'owner_revision=4')&&str_contains($q,'id=60')&&!str_contains($q,'idempotency_key'));
t('reset: only FAILED rows never sent (idempotent: second call matches 0 rows)',str_contains($q,"status='FAILED'")&&str_contains($q,'provider_message_id IS NULL')&&str_contains($q,'sent_at IS NULL')&&str_contains($q,'send_started_at IS NULL'));
$wpdb->affected=0;t('reset twice => false the second time',WFCA_DB::reset_failed_outbox(60,4,'PENDING','x')===false);$wpdb->affected=1;
WFCA_DB::claim_outbox('w','LIVE',false,true);$q=$wpdb->sql[count($wpdb->sql)-1];
t('claim during provider hold only offers ALERT_EMAIL (no Kapso call can happen)',str_contains($q,"action_type='ALERT_EMAIL'"));
$wpdb->sql=[];WFCA_DB::claim_outbox('w','LIVE',false,false);$q=$wpdb->sql[0];
t('claim without hold is unchanged',!str_contains($q,"action_type='ALERT_EMAIL'"));
WFCA_DB::transient_handoff_candidates(10);$q=end($wpdb->sql);
t('candidates: HANDOFF_PENDING + HUMAN_HANDOFF + OUTBOX_FAILED reason only, not opted out',str_contains($q,"conversation_owner='HANDOFF_PENDING'")&&str_contains($q,"state='HUMAN_HANDOFF'")&&str_contains($q,'OUTBOX\_FAILED:%')&&str_contains($q,'opt_out=0')&&str_contains($q,'LIMIT 10'));
WFCA_DB::latest_failed_outbox(7);$q=end($wpdb->sql);
t('latest failed outbox only for D0/follow-up',str_contains($q,"status='FAILED'")&&str_contains($q,"'TEMPLATE_INITIAL','FOLLOWUP'"));
echo "TOTAL PASS=$pass FAIL=$fail\n";exit($fail?1:0);
