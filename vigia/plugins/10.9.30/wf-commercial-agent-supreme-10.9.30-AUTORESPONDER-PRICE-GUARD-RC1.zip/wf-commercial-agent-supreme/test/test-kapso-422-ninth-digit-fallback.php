<?php
define('ABSPATH', __DIR__.'/');
define('WFCA_KAPSO_API_KEY','test-key');define('WFCA_KAPSO_PHONE_NUMBER_ID','123456');define('WFCA_KAPSO_WEBHOOK_SECRET','s');
function wp_json_encode($v,$f=0){return json_encode($v,$f);}
foreach (['wp_strip_all_tags','sanitize_email','is_email','get_option','apply_filters','wp_json_encode','home_url','esc_url_raw'] as $fn) { if(!function_exists($fn)) { eval('function '.$fn.'(...$a){return $a[0]??"";}'); } }
$GLOBALS['calls']=[];$GLOBALS['script']=[];$GLOBALS['opt']=[];
function is_wp_error($x){return false;}
function wp_remote_post($url,$args){ $GLOBALS['calls'][]=json_decode($args['body'],true); $r=array_shift($GLOBALS['script']); return $r; }
function wp_remote_retrieve_response_code($r){return $r['code'];}
function wp_remote_retrieve_body($r){return $r['body'];}
function update_option($k,$v,$a=null){$GLOBALS['opt'][$k]=$v;return true;}
require_once __DIR__.'/../includes/class-wfca-util.php';
require_once __DIR__.'/../includes/class-wfca-kapso.php';
$pass=0;$fail=0;function t($n,$c){global $pass,$fail;if($c){echo "PASS $n\n";$pass++;}else{echo "FAIL $n\n";$fail++;}}
$ok=['code'=>200,'body'=>json_encode(['messages'=>[['id'=>'wamid.ABC']]])];
$e422=['code'=>422,'body'=>json_encode(['error'=>['message'=>'Recipient 5534988610000 not allowed']])];
$guard=fn()=>['ok'=>true];
function run($to,$script){ $GLOBALS['calls']=[];$GLOBALS['script']=$script; global $guard; return WFCA_Kapso::send($to,'Oi','',[],$guard); }
$r=run('+5534988610000',[$e422,$ok]);
t('422 on 9-digit retries once with 8-digit form',count($GLOBALS['calls'])===2&&$GLOBALS['calls'][0]['to']==='5534988610000'&&$GLOBALS['calls'][1]['to']==='553488610000');
t('second attempt success returns ok with variant',!empty($r['ok'])&&($r['variant']??'')==='NO_NINTH_DIGIT');
$r=run('+5534988610000',[$e422,$e422]);
t('both fail returns 422 with provider detail and masked digits',empty($r['ok'])&&$r['error']==='KAPSO_HTTP_422'&&str_contains($r['detail'],'alt8')&&!preg_match('/\d{6,}/',$r['detail']));
$r=run('+5534988610000',[$ok]);
t('success first time sends exactly once',count($GLOBALS['calls'])===1&&!empty($r['ok']));
$r=run('+551133334444',[$e422]);
t('landline 13-digit is not retried',count($GLOBALS['calls'])===1&&empty($r['ok']));
$r=run('+5534988610000',[['code'=>500,'body'=>'x']]);
t('500 is not retried (ambiguous delivery)',count($GLOBALS['calls'])===1&&!empty($r['ambiguous']));
$r=run('+5534988610000',[['code'=>400,'body'=>'{}']]);
t('400 is not retried',count($GLOBALS['calls'])===1);
$r=run('+5534988610000',[$e422,$ok]);
t('last-send option records detail-free success',!empty($GLOBALS['opt']['wfca_last_kapso_send']['ok']));
$r=WFCA_Kapso::send('+5534988610000','Oi','',[],fn()=>['ok'=>false,'error'=>'FENCE']);
t('guard still blocks before any request',!empty($r['blocked']));
echo "TOTAL PASS=$pass FAIL=$fail\n";exit($fail?1:0);
