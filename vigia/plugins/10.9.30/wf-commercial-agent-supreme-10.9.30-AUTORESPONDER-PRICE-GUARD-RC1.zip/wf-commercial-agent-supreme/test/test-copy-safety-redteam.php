<?php
define('ABSPATH', __DIR__.'/');
function wp_strip_all_tags($x){return strip_tags((string)$x);} 
final class WFCA_Util {
    public static function short_text(string $text,int $max=1200): string {$text=preg_replace('/\s+/u',' ',strip_tags($text));$text=trim((string)$text);return function_exists('mb_substr')?mb_substr($text,0,$max,'UTF-8'):substr($text,0,$max);} 
    public static function lower(string $text): string {return function_exists('mb_strtolower')?mb_strtolower($text,'UTF-8'):strtolower($text);} 
}
require_once __DIR__.'/../includes/class-wfca-engine.php';
$ref=new ReflectionClass('WFCA_Engine');
$get=function($n)use($ref){$m=$ref->getMethod($n);$m->setAccessible(true);return $m;};
$obs=$get('commercial_observation');$fu=$get('commercial_followup_insight');$name=$get('commercial_display_name');$clip=$get('prospect_sentence_text');
$pass=0;$fail=0;function rt($n,$c){global $pass,$fail;if($c){echo "PASS $n\n";$pass++;}else{echo "FAIL $n\n";$fail++;}}
$telemetry=[
 'CURRENT feeder proof 2026-09-16: exact Google Business listing in Cambuí, Campinas, current hours including Saturday, public phone +55 19 99999-9999.',
 'LEAD_INTELLIGENCE_V4_EXTERNAL_FEEDER | verified=2026-09-17 | discovery=ChatGPT local_business+web | economic plausibility=strong',
 'BUILDABLE_OPPORTUNITY_PREFILTER_V1=PASS | FINAL DEDUPE | public phone +5511999999999',
 'CERTIFICATION_CANDIDATE_V1 | CLOUDFLARE_SUPPLY_V1 | run=WF-XYZ | gap_codes=A,B',
];
foreach($telemetry as $i=>$raw){rt('telemetry variant '.($i+1).' blocked',$obs->invoke(null,['fields'=>['Observação Específica'=>$raw]])==='');}
$th='CURRENT feeder proof | improvement_thesis=Organizar serviços e agendamento em uma jornada clara. | public phone +55 19 99999-9999';
rt('technical record can expose only explicit grounded thesis',$obs->invoke(null,['fields'=>['Observação Específica'=>$th]])==='Organizar serviços e agendamento em uma jornada clara.');
$prefixes=['Outro ponto concreto: ','Um ponto concreto: ','Outro ponto: ','Só queria deixar um ponto mais claro: ','Só um ponto mais concreto: '];
foreach($prefixes as $i=>$p){rt('opener '.($i+1).' stripped',$fu->invoke(null,['fields'=>['Follow-up Insight'=>$p.'A clínica já tem agenda online e serviços bem definidos.']])==='A clínica já tem agenda online e serviços bem definidos.');}
$long='Primeira frase completa e comercial. '.str_repeat('Segunda parte muito longa sem ponto ',12);
$out=$clip->invoke(null,$long,100,false);rt('long copy ends at sentence boundary',$out==='Primeira frase completa e comercial.');
rt('long copy never ends alphanumeric fragment',preg_match('/[.!?]$/u',$out)===1);
$utf='A clínica já oferece estética avançada, harmonização e agendamento online. Tudo em um fluxo mais claro.';
rt('utf8 accents preserved',$clip->invoke(null,$utf,220,false)===$utf);
$url=['fields'=>['Observação Específica'=>'A clínica concentra serviços em https://example.com e pode organizar o agendamento numa jornada mais clara.']];
rt('raw observation URL stripped',!str_contains($obs->invoke(null,$url),'http'));
$names=[
 [['Lead'=>'Clínica Alfa — Campinas','Cidade'=>'Campinas','Especialidade / Posicionamento'=>'Estética Avançada'],'Clínica Alfa'],
 [['Lead'=>'Dra. Beta — Harmonização Facial','Cidade'=>'São Paulo','Especialidade / Posicionamento'=>'Harmonização Facial; Estética Avançada'],'Dra. Beta'],
 [['Lead'=>'Studio — Prime','Cidade'=>'Campinas','Especialidade / Posicionamento'=>'Estética Avançada'],'Studio'],
 [['Lead'=>'Dra. Camila Gaia — Harmonização Facial','Cidade'=>'Campinas','Especialidade / Posicionamento'=>'Dentista com atuação em Harmonização Orofacial, atendimento privado em Campinas/Taquaral e foco em estética facial.'],'Dra. Camila Gaia'],
 [['Lead'=>'Clínica Alfa','Cidade'=>'Campinas','Especialidade / Posicionamento'=>'Estética Avançada'],'Clínica Alfa'],
];
foreach($names as $i=>$pair){rt('display-name case '.($i+1),$name->invoke(null,['fields'=>$pair[0]])===$pair[1]);}
$unsafe=['fields'=>['Follow-up Insight'=>'CURRENT feeder proof: public phone +5511999999999']];rt('unsafe dedicated insight fails closed instead of fallback',$fu->invoke(null,$unsafe)==='');
$empty=['fields'=>['Follow-up Insight'=>'','Observação Específica'=>'Uma apresentação própria pode reunir serviços e agendamento.']];rt('empty dedicated insight does not fall back',$fu->invoke(null,$empty)==='');
echo "TOTAL PASS=$pass FAIL=$fail\n";exit($fail?1:0);
