<?php
define('ABSPATH', __DIR__.'/');
foreach (['wp_strip_all_tags','sanitize_email','is_email','get_option','apply_filters','wp_json_encode','home_url','esc_url_raw'] as $fn) { if(!function_exists($fn)) { eval('function '.$fn.'(...$a){return $a[0]??"";}'); } }
final class WFCA_Airtable { public static $cfg=[]; public static function config(bool $force=false): array {return self::$cfg;} }
require_once __DIR__.'/../includes/class-wfca-util.php';
require_once __DIR__.'/../includes/class-wfca-ownership.php';
$pass=0;$fail=0;function t($n,$c){global $pass,$fail;if($c){echo "PASS $n\n";$pass++;}else{echo "FAIL $n\n";$fail++;}}
function setcfg($v){WFCA_Airtable::$cfg=$v;}
$ARMS=json_encode(['arms'=>[[
 'id'=>'SITES_INBOUND','tag_regex'=>'-\\s*([A-Za-z0-9])\\s*$','owner'=>'LUNA','untagged_inbound'=>false,'default_tag'=>'organico',
 'prompt_key'=>'WFCA_ARM_PROMPT_SITES_INBOUND','checkout_without_site'=>true,
 'static_checkout'=>['LANDING_PAGE_PREMIUM'=>'https://link.infinitepay.io/daniel-freire-xv6/VC1DLUMtSQ-GIu4NA8DDh-700,00','SOCIAL_GROWTH'=>'https://invoice.infinitepay.io/plans/daniel-freire-xv6/Ydzf1kTPc2','BAD'=>'http://evil.example/pay','BAD2'=>'https://evil.example/pay']
]]]);
setcfg([]);t('no config: no arms',WFCA_Util::arms()===[]&&WFCA_Util::arm_for_inbound('Quero minha prévia - A')===null);
setcfg(['WFCA_ARMS_V1'=>'not json']);t('bad json: no arms',WFCA_Util::arms()===[]);
setcfg(['WFCA_ARMS_V1'=>$ARMS]);
$a=WFCA_Util::arm_for_inbound('Quero minha prévia - A');t('tag A detected',$a&&$a['id']==='SITES_INBOUND'&&$a['tag']==='A'&&$a['owner']==='LUNA');
$a=WFCA_Util::arm_for_inbound('Quero minha prévia - b  ');t('tag b uppercased, trailing spaces ok',$a&&$a['tag']==='B');
t('untagged first message stays out by default',WFCA_Util::arm_for_inbound('Oi, tudo bem?')===null);
t('hyphen in the middle is not a tag',WFCA_Util::arm_for_inbound('Quero - A prévia de um site')===null);
setcfg(['WFCA_ARMS_V1'=>str_replace('"untagged_inbound":false','"untagged_inbound":true',$ARMS)]);
$a=WFCA_Util::arm_for_inbound('Oi, tudo bem?');t('untagged routed only when Airtable enables it',$a&&$a['tag']==='organico');
setcfg(['WFCA_ARMS_V1'=>$ARMS]);
$arm=WFCA_Util::arm_by_id('SITES_INBOUND');
t('static checkout keeps only https InfinitePay links',array_keys($arm['static_checkout'])===['LANDING_PAGE_PREMIUM','SOCIAL_GROWTH']);
t('subscription (invoice) links accepted',str_starts_with($arm['static_checkout']['SOCIAL_GROWTH'],'https://invoice.infinitepay.io/plans/'));
t('default blocked actions include SEND_SITE and PRICE',in_array('SEND_SITE',$arm['blocked_actions'],true)&&in_array('PRICE',$arm['blocked_actions'],true));
t('canned clinic replies are not whitelisted',!in_array('HOW_IT_WORKS',$arm['allow_deterministic'],true)&&!in_array('WHAT_IS_THIS',$arm['allow_deterministic'],true)&&in_array('EXPLICIT_OPT_OUT',$arm['allow_deterministic'],true));
t('built-in arm ids cannot be redefined',WFCA_Util::arm_by_id('LUNA_COLD_WHATSAPP')===null);
setcfg(['WFCA_ARMS_V1'=>json_encode(['arms'=>[['id'=>'LUNA_COLD_WHATSAPP','owner'=>'LUNA'],['id'=>'ab','owner'=>'LUNA']]])]);t('reserved/invalid ids ignored',WFCA_Util::arms()===[]);
setcfg(['WFCA_ARMS_V1'=>$ARMS]);
t('ownership accepts configured arm',WFCA_Ownership::arm('SITES_INBOUND')==='SITES_INBOUND'&&WFCA_Ownership::is_config_arm('SITES_INBOUND'));
t('ownership rejects unknown arm',WFCA_Ownership::arm('NOPE_ARM')===''&&!WFCA_Ownership::is_config_arm('NOPE_ARM'));
t('configured arm never written to the Airtable singleSelect',WFCA_Ownership::remote_arm('SITES_INBOUND')==='');
t('built-in arms still map as before',WFCA_Ownership::remote_arm('CALL_FIRST')==='CALL_FIRST'&&WFCA_Ownership::remote_arm('ASYNC_FIRST')==='ASYNC_FIRST');
setcfg(['WFCA_ARMS_V1'=>str_replace('"id":"SITES_INBOUND"','"id":"SITES_INBOUND","enabled":false',$ARMS)]);t('enabled=false switches the arm off (no new routing, ownership fails safe)',WFCA_Util::arm_for_inbound('Quero - A')===null&&WFCA_Ownership::arm('SITES_INBOUND')===''&&WFCA_Util::arm_by_id('SITES_INBOUND')===null);
setcfg([]);t('arm removed from Airtable: ownership stops accepting it (fails safe)',WFCA_Ownership::arm('SITES_INBOUND')==='');
$src=file_get_contents(__DIR__.'/../includes/class-wfca-engine.php').file_get_contents(__DIR__.'/../includes/class-wfca-openai.php');
t('engine routes tagged unknown number via arm_for_inbound only for NEW organic conversations',str_contains($src,'elseif ($organic && !$existing)')&&str_contains($src,'WFCA_Util::arm_for_inbound($body)'));
t('deterministic replies filtered by arm whitelist',str_contains($src,'$arm_cfg[\'allow_deterministic\']'));
t('arm prompt comes from Airtable and states there is no site template',str_contains($src,'prompt_key')&&str_contains($src,'there is no site template'));
t('offer_code enum extended by arm static keys',str_contains($src,"array_keys(\$arm_cfg['static_checkout'])"));
t('static checkout raises a WARN alert for manual payment confirmation',str_contains($src,'STATIC_CHECKOUT_SENT'));
echo "TOTAL PASS=$pass FAIL=$fail\n";exit($fail?1:0);
