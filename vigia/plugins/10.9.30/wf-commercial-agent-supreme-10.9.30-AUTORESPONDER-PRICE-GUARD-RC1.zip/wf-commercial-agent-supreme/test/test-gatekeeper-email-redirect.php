<?php
define('ABSPATH', __DIR__.'/');
foreach (['wp_strip_all_tags','sanitize_email','is_email','get_option','apply_filters','wp_json_encode','home_url','esc_url_raw'] as $fn) { if(!function_exists($fn)) { eval('function '.$fn.'(...$a){return $a[0]??"";}'); } }
require_once __DIR__.'/../includes/class-wfca-util.php';
final class WFCA_Ownership { public static function arm(string $a): string {return $a;} public static function remote_arm(string $a): string {return $a;} }
require_once __DIR__.'/../includes/class-wfca-engine.php';
$m=(new ReflectionClass('WFCA_Engine'))->getMethod('deterministic_decision');$m->setAccessible(true);
$pass=0;$fail=0;function t($n,$c){global $pass,$fail;if($c){echo "PASS $n\n";$pass++;}else{echo "FAIL $n\n";$fail++;}}
function d($body){global $m;return $m->invoke(null,$body,['fields'=>[]],[]);}
$r=d('Para contato comercial pode enviar uma apresentação para o email: clinic.ensoul@gmail.com');
t('ensoul message routes to SEND_SITE',($r['action']??'')==='SEND_SITE'&&($r['reason']??'')==='GATEKEEPER_EMAIL_REDIRECT');
$r=d('Manda a proposta pro e-mail contato@clinica.com.br');t('proposta por e-mail routes to SEND_SITE',($r['action']??'')==='SEND_SITE');
$r=d('Pode mandar o material por email');t('material por email routes to SEND_SITE',($r['action']??'')==='SEND_SITE');
$r=d('Obrigada');t('plain thanks is untouched',$r===null||($r['reason']??'')!=='GATEKEEPER_EMAIL_REDIRECT');
$r=d('Bom dia');t('greeting is untouched',$r===null||($r['reason']??'')!=='GATEKEEPER_EMAIL_REDIRECT');
$r=d('Qual o valor?');t('price question is untouched',$r===null||($r['reason']??'')!=='GATEKEEPER_EMAIL_REDIRECT');
$r=d('Não tenho interesse, não me mande mais nada por email');t('rejection still wins',($r['action']??'')==='NO_INTEREST');
$r=d('PARE de mandar mensagem, mande email');t('stop-like message is not hijacked',($r['action']??'')!=='SEND_SITE');
$r=d('Não envie mais nada, só por email mesmo');t('hostile wording not hijacked',($r['action']??'')!=='SEND_SITE');
$src=file_get_contents(__DIR__.'/../includes/class-wfca-engine.php');
t('reply text never promises e-mail delivery',!str_contains($src,'eu mando também por e-mail')&&str_contains($src,'repassar pra quem decide'));
echo "TOTAL PASS=$pass FAIL=$fail\n";exit($fail?1:0);
