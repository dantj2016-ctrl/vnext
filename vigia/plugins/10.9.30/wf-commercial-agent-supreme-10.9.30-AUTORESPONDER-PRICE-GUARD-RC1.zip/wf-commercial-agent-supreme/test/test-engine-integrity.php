<?php
$src=file_get_contents(__DIR__.'/../includes/class-wfca-engine.php');
$pass=0;$fail=0;function t($n,$c){global $pass,$fail;if($c){echo "PASS $n\n";$pass++;}else{echo "FAIL $n\n";$fail++;}}
preg_match_all('/\bfunction\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(/',$src,$dm);
preg_match_all('/\bself::([A-Za-z_][A-Za-z0-9_]*)\s*\(/',$src,$cm);
$defs=array_unique($dm[1]??[]);$calls=array_unique($cm[1]??[]);$missing=array_values(array_diff($calls,$defs));
t('every WFCA_Engine self call resolves to a defined method',count($missing)===0);
$unguarded=false;
foreach(explode("\n",$src) as $line){
    if(preg_match('/\bmb_(?:strlen|substr|strtolower)\s*\(/',$line) && !str_contains($line,'function_exists')){$unguarded=true;break;}
}
t('engine does not require mbstring without a fallback',!$unguarded);
echo "TOTAL PASS=$pass FAIL=$fail\n";exit($fail?1:0);
