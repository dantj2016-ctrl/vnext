<?php
define('ABSPATH', __DIR__.'/');
final class WFCA_Airtable { public static array $cfg=[]; public static function config(): array {return self::$cfg;} }
final class WFCA_Util { public static function c($k,$d=''){ return $d; } public static function normalize_phone($x){return $x;} public static function short_text($x,$n=500){return substr((string)$x,0,$n);} public static function now_iso(){return gmdate('c');} public static function json($x){return json_encode($x);} }
require_once __DIR__.'/../includes/class-wfca-kapso.php';
$pass=0;$fail=0; function t($n,$c){global $pass,$fail;if($c){echo "PASS $n\n";$pass++;}else{echo "FAIL $n\n";$fail++;}}

WFCA_Airtable::$cfg=['COMMERCIAL_INITIAL_WHATSAPP_TEMPLATE_SPEC'=>json_encode([
 'name'=>'wf_site_preview_intro_media_v1','variables'=>['lead_name','specific_observation','site_url'],
 'header'=>['type'=>'image','source'=>'d0_preview_image_url']
])];
$s=WFCA_Kapso::template_spec('INITIAL');
t('media_v1 exact spec accepted',($s['name']??'')==='wf_site_preview_intro_media_v1' && ($s['header']['type']??'')==='image');

WFCA_Airtable::$cfg=['COMMERCIAL_INITIAL_WHATSAPP_TEMPLATE_SPEC'=>json_encode([
 'name'=>'wf_site_preview_intro_v3','variables'=>['lead_name','site_url']
])];
$s=WFCA_Kapso::template_spec('INITIAL');
t('legacy v3 json spec rejected',($s['name']??'')==='');

WFCA_Airtable::$cfg=['COMMERCIAL_INITIAL_WHATSAPP_TEMPLATE_SPEC'=>'wf_site_preview_intro_v3'];
$s=WFCA_Kapso::template_spec('INITIAL');
t('legacy v3 plain name rejected',($s['name']??'')==='');

WFCA_Airtable::$cfg=[];
$s=WFCA_Kapso::template_spec('INITIAL');
t('missing media spec fails closed',($s['name']??'')==='' && ($s['source']??'')==='NONE');

exit($fail?1:0);
