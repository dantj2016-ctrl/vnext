<?php
define('ABSPATH', __DIR__.'/');
define('WFCA_KAPSO_PHONE_NUMBER_ID','1276743235526569');define('WFCA_KAPSO_API_KEY','k');define('WFCA_KAPSO_WEBHOOK_SECRET','s');
$GLOBALS['opts']=[];
foreach (['wp_strip_all_tags','sanitize_email','is_email','apply_filters','wp_json_encode','home_url','esc_url_raw'] as $fn) { if(!function_exists($fn)) { eval('function '.$fn.'(...$a){return $a[0]??"";}'); } }
function get_option($k,$d=false){return $GLOBALS['opts'][$k]??$d;}
function update_option($k,$v,$a=null){$GLOBALS['opts'][$k]=$v;return true;}
function wp_json_encode($v,$f=0){return json_encode($v,$f);}
final class WFCA_Ownership { public static function arm(string $a): string {return $a;} public static function remote_arm(string $a): string {return $a;} }
require_once __DIR__.'/../includes/class-wfca-util.php';
require_once __DIR__.'/../includes/class-wfca-kapso.php';
require_once __DIR__.'/../includes/class-wfca-engine.php';
$pass=0;$fail=0;function t($n,$c){global $pass,$fail;if($c){echo "PASS $n\n";$pass++;}else{echo "FAIL $n\n";$fail++;}}
function payload($dir,$origin,$body,$media=false){return ['phone_number_id'=>'1276743235526569','conversation'=>['phone_number'=>'+5562994770805'],'message'=>['id'=>'wamid.X'.mt_rand(),'timestamp'=>(string)time(),'type'=>$media?'image':'text','from'=>'5562994770805','to'=>'5562994770805','text'=>['body'=>$body],'kapso'=>['origin'=>$origin,'direction'=>$dir,'has_media'=>$media]]];}
function norm($event,$dir,$origin,$body,$media=false){$r=WFCA_Kapso::normalize(payload($dir,$origin,$body,$media),$event);return $r['data']??$r;}
$a=norm('whatsapp.message.sent','outbound','business_app','Oi, aqui é o Daniel');t('real manual text from the Business app is MANUAL_OUTBOUND',($a['event_type']??'')==='MANUAL_OUTBOUND');
$a=norm('whatsapp.message.sent','outbound','business_app','',true);t('manual media from the Business app is MANUAL_OUTBOUND',($a['event_type']??'')==='MANUAL_OUTBOUND');
$a=norm('whatsapp.message.sent','outbound','business_app','');t('EMPTY business_app echo is NOT a manual reply',($a['event_type']??'')!=='MANUAL_OUTBOUND'&&str_starts_with((string)($a['status']??''),'IGNORED'));
foreach(['whatsapp.message.delivered','whatsapp.message.read','whatsapp.message.failed'] as $ev){$a=norm($ev,'outbound','business_app','texto qualquer');t("business_app $ev status never becomes MANUAL_OUTBOUND",($a['event_type']??'')!=='MANUAL_OUTBOUND');}
$a=norm('whatsapp.message.delivered','outbound','cloud_api','Luna msg');t('cloud_api delivered stays a DELIVERY_DELIVERED event',($a['event_type']??'')==='DELIVERY_DELIVERED');
$a=norm('whatsapp.message.sent','outbound','cloud_api','Luna msg');t('cloud_api sent stays a DELIVERY_SENT event',($a['event_type']??'')==='DELIVERY_SENT');
// courtesy
$m=(new ReflectionClass('WFCA_Engine'))->getMethod('deterministic_decision');$m->setAccessible(true);
function dec($b,$id='recL1'){global $m;return $m->invoke(null,$b,['id'=>$id,'fields'=>[]],[]);}
$r=dec('Desejo um excelente dia para você e para toda a equipe!');t('Sofia\'s closing wish gets a warm short reply',($r['action']??'')==='REPLY'&&($r['reason']??'')==='COURTESY_CLOSING'&&str_contains($r['message'],'😊'));
$r=dec('Desejo um excelente dia para você e para toda a equipe!');t('only one courtesy reply per conversation per day (no loop)',($r['reason']??'')!=='COURTESY_CLOSING');
$GLOBALS['opts']=[];$r=dec('*Sofia:* Olá, Luna! Muito obrigada pelas informações.','recL2');t('thanks with a name prefix is a courtesy',($r['reason']??'')==='COURTESY_CLOSING');
$GLOBALS['opts']=[];$r=dec('Muito obrigada! Quanto custa?','recL3');t('thanks + question is not a courtesy',($r['reason']??'')!=='COURTESY_CLOSING');
$r=dec('Obrigado, mas não temos interesse','recL4');t('thanks + rejection is handled as rejection, not courtesy',($r['action']??'')==='NO_INTEREST');
$r=dec('Pode me mandar a proposta? obrigado','recL5');t('thanks + request is not a courtesy',($r['reason']??'')!=='COURTESY_CLOSING');
$r=dec('Bom dia','recL6');t('plain greeting is not treated as a courtesy closing',($r['reason']??'')!=='COURTESY_CLOSING');
echo "TOTAL PASS=$pass FAIL=$fail\n";exit($fail?1:0);
