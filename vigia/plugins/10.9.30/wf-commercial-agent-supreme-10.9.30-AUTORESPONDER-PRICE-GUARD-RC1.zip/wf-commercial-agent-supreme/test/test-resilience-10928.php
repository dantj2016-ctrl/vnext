<?php
// 10.9.28 RESILIENCE: transient D0 failures (131053/5xx) do not brake and are re-queued once safely; Kapso 402 holds instead of burning leads;
// auto-reconciler restores transient handoffs; health snapshot. Offline, in-memory stubs.
define('ABSPATH', __DIR__.'/');
define('ARRAY_A','ARRAY_A');
$GLOBALS['opts']=[];
foreach (['wp_strip_all_tags','sanitize_email','is_email','apply_filters','wp_json_encode','home_url','esc_url_raw'] as $fn) { if(!function_exists($fn)) { eval('function '.$fn.'(...$a){return $a[0]??"";}'); } }
function get_option($k,$d=false){return $GLOBALS['opts'][$k]??$d;}
function update_option($k,$v,$a=null){$GLOBALS['opts'][$k]=$v;return true;}
final class WFCA_Alerts { public static $raised=[]; public static $resolved=[]; public static function raise(...$a){self::$raised[]=$a;return 1;} public static function resolve_source($k){self::$resolved[]=$k;} }
final class WFCA_Airtable {
  public static $cfg=[]; public static $updates=[]; public static $stuck=['ok'=>true,'data'=>['records'=>[]]];
  public static function config(bool $f=false): array {return self::$cfg;}
  public static function update_commercial_by_phone(string $p,array $f): array {self::$updates[]=[$p,$f];return ['ok'=>true];}
  public static function stuck_followup_scheduled(string $c,int $m=5): array {return self::$stuck;}
}
final class WFCA_Ownership {
  public static $changes=[]; public static $syncs=[]; public static $change_ok=true;
  public static function arm(string $a): string {return $a;} public static function remote_arm(string $a): string {return $a;} public static function is_only_daniel(string $a): bool {return $a==='DANIEL_CALL';}
  public static function queue_status(): string {return 'PENDING';}
  public static function change(int $id,string $owner,string $reason,int $exp,bool $explicit=false){ self::$changes[]=[$id,$owner,$reason,$exp,$explicit]; if(!self::$change_ok) return ['ok'=>false,'error'=>'REMOTE_RESUME_BLOCKED']; WFCA_DB::$convs[$id]['conversation_owner']=$owner; WFCA_DB::$convs[$id]['owner_revision']=$exp+1; return ['ok'=>true,'revision'=>$exp+1]; }
  public static function sync(int $id){ self::$syncs[]=$id; return true; }
}
final class WFCA_DB {
  public static $convs=[]; public static $out=[]; public static $queued=[]; public static $cands=[]; public static $failed=null; public static $resets=[];
  public static function t($n){return 'wp_wfca_'.$n;}
  public static function get_conversation(int $id): ?array {return self::$convs[$id]??null;}
  public static function get_conversation_by_phone(string $p): ?array {foreach(self::$convs as $c) if($c['phone_e164']===$p) return $c; return null;}
  public static function get_outbox_by_idempotency_key(string $k): ?array {return self::$out[$k]??null;}
  public static function queue(array $i): int {$id=count(self::$out)+100;$i['id']=$id;self::$out[$i['idempotency_key']]=$i;self::$queued[]=$i;return $id;}
  public static function upsert_conversation(string $p,array $f): array {foreach(self::$convs as $id=>$c) if($c['phone_e164']===$p){self::$convs[$id]=array_merge($c,$f);if(isset($f['human_hold']))self::$convs[$id]['human_hold']=$f['human_hold'];return self::$convs[$id];} return [];}
  public static function transient_handoff_candidates(int $l): array {return self::$cands;}
  public static $failed_by=[]; public static function has_terminal_payment(int $c): bool {return false;}
  public static function latest_failed_outbox(int $c): ?array {return self::$failed_by[$c]??self::$failed;}
  public static function reset_failed_outbox(int $id,int $rev,string $st,string $note): bool {self::$resets[]=[$id,$rev,$st,$note];return true;}
}
require_once __DIR__.'/../includes/class-wfca-util.php';
require_once __DIR__.'/../includes/class-wfca-engine.php';
$pass=0;$fail=0;function t($n,$c){global $pass,$fail;if($c){echo "PASS $n\n";$pass++;}else{echo "FAIL $n\n";$fail++;}}
function E($name){$m=(new ReflectionClass('WFCA_Engine'))->getMethod($name);$m->setAccessible(true);return $m;}
function reset_all(){$GLOBALS['opts']=[];WFCA_Alerts::$raised=[];WFCA_Alerts::$resolved=[];WFCA_Airtable::$updates=[];WFCA_Airtable::$cfg=[];WFCA_Airtable::$stuck=['ok'=>true,'data'=>['records'=>[]]];WFCA_Ownership::$changes=[];WFCA_Ownership::$syncs=[];WFCA_Ownership::$change_ok=true;WFCA_DB::$convs=[];WFCA_DB::$out=[];WFCA_DB::$queued=[];WFCA_DB::$cands=[];WFCA_DB::$failed=null;WFCA_DB::$failed_by=[];WFCA_DB::$resets=[];}
$LEAD='recLEAD1';$PH='+5511999990000';
$B53='WA_ERR code=131053 title=Media upload error msg=Media upload error details=Downloading media from weblink failed with http code 503';
$B49='WA_ERR code=131049 title=This message was not delivered to maintain healthy ecosystem engagement. msg=x details=y';
$BTXT='WA_ERR code=999999 title=x msg=x details=Downloading media from weblink failed with http code 502';
$CODES=['131053','131016','131000'];

// ---- A. pure helpers
t('131053 is transient',WFCA_Util::delivery_fail_is_transient($B53,$CODES));
t('unknown code quoting http code 502 is transient',WFCA_Util::delivery_fail_is_transient($BTXT,$CODES));
t('131049 (Meta engagement limit) is NOT transient',!WFCA_Util::delivery_fail_is_transient($B49,$CODES));
t('NO_DETAIL / empty are NOT transient',!WFCA_Util::delivery_fail_is_transient('WA_ERR NO_DETAIL m_keys=a',$CODES)&&!WFCA_Util::delivery_fail_is_transient('',$CODES));
t('empty transient list still honors text http 5xx but not the code',!WFCA_Util::delivery_fail_is_transient('WA_ERR code=131053 title=x',[]));
t('credit error: http_code 402',WFCA_Util::is_provider_credit_error(['ok'=>false,'error'=>'KAPSO_HTTP_402','http_code'=>402]));
t('credit error: insufficient_credits in detail',WFCA_Util::is_provider_credit_error(['ok'=>false,'error'=>'KAPSO_HTTP_403','detail'=>'{"error":"insufficient_credits"}']));
t('credit error: 422/500 are not credit errors',!WFCA_Util::is_provider_credit_error(['error'=>'KAPSO_HTTP_422','http_code'=>422])&&!WFCA_Util::is_provider_credit_error(['error'=>'KAPSO_HTTP_500','http_code'=>500]));
t('transient outbox errors: 402/429/5xx/read fails/worker',WFCA_Util::transient_outbox_error('KAPSO_HTTP_402')&&WFCA_Util::transient_outbox_error('KAPSO_HTTP_429')&&WFCA_Util::transient_outbox_error('KAPSO_HTTP_503')&&WFCA_Util::transient_outbox_error('AIRTABLE_LEAD_READ_FAIL')&&WFCA_Util::transient_outbox_error('WORKER_EXCEPTION'));
t('permanent errors are NOT transient',!WFCA_Util::transient_outbox_error('KAPSO_HTTP_400')&&!WFCA_Util::transient_outbox_error('KAPSO_HTTP_422')&&!WFCA_Util::transient_outbox_error('INVALID_DESTINATION')&&!WFCA_Util::transient_outbox_error('TEMPLATE_PAYLOAD_INVALID'));
$fpe=E('followup_permanent_error');
t('follow-up: 402 and 429 are never permanent',$fpe->invoke(null,'KAPSO_HTTP_402')===false&&$fpe->invoke(null,'KAPSO_HTTP_429')===false);
t('follow-up: other 4xx stay permanent (unchanged)',$fpe->invoke(null,'KAPSO_HTTP_400')===true&&$fpe->invoke(null,'INVALID_DESTINATION')===true);

// ---- B. rules
reset_all();
$r=WFCA_Util::rules();
t('defaults: transient codes, free=2, retry max 2, gap 600, hold 600',$r['d0_delivery_brake_transient_codes']===$CODES&&$r['d0_brake_transient_free']===2&&$r['d0_transient_retry_max']===2&&$r['d0_transient_retry_gap_seconds']===600&&$r['provider_hold_seconds']===600);
t('defaults keep the 10.9.27 ignore list',$r['d0_delivery_brake_ignore_codes']===['130472','131026']);
WFCA_Airtable::$cfg=['WFCA_RULES_V1'=>'{"d0_delivery_brake_transient_codes":["131053","x","12"],"d0_brake_transient_free":99,"d0_transient_retry_max":9,"d0_transient_retry_gap_seconds":5,"provider_hold_seconds":1,"d0_transient_retry_enabled":false}'];
$r=WFCA_Util::rules();
t('rules are validated and clamped (codes digits only, free<=10, retry max<=2, gap>=600, hold>=120)',$r['d0_delivery_brake_transient_codes']===['131053']&&$r['d0_brake_transient_free']===10&&$r['d0_transient_retry_max']===2&&$r['d0_transient_retry_gap_seconds']===600&&$r['provider_hold_seconds']===120&&$r['d0_transient_retry_enabled']===false);

// ---- C. brake
final class FakeWpdb { public $rows=[]; public function prepare($q,...$a){return $q;} public function get_results($q,$t=null){return $this->rows;} }
$wpdb=new FakeWpdb();
$brake=E('d0_delivery_brake_active');
$R=['d0_delivery_brake_enabled'=>true,'d0_delivery_brake_failure_ratio'=>0.30,'d0_delivery_brake_ignore_codes'=>['130472','131026'],'d0_delivery_brake_transient_codes'=>$CODES,'d0_brake_transient_free'=>2];
function D(){return ['delivery_status'=>'delivered','fail_body'=>null];} function F($b){return ['delivery_status'=>'failed','fail_body'=>$b];}
reset_all();$wpdb->rows=[D(),F($B49),F($B53),D(),F($B53),D()];
t('INCIDENT 10/10: 131049 + 2x131053(503) of 6 does NOT brake (only 1 quality failure)',$brake->invoke(null,$R)===false&&!WFCA_Alerts::$raised);
reset_all();$wpdb->rows=[D(),F($B49),F($B53),D(),F($B53),D()];
t('same sample with transient_free=0 reproduces the old brake',$brake->invoke(null,['d0_brake_transient_free'=>0]+$R)===true);
reset_all();$wpdb->rows=[D(),D(),D(),F($B53),F($B53),F($B53)];
t('3rd transient in the window counts: 1 of 4 resolved... ',$brake->invoke(null,$R)===false);
reset_all();$wpdb->rows=[D(),D(),F($B53),F($B53),F($B53),F($B53),F($B53),F($B53)];
$x=$brake->invoke(null,$R);
t('persistent infra problem (6 transient) still brakes after the free ones; alert names them',$x===true&&str_contains((string)WFCA_Alerts::$raised[0][0],'4/6_FAILED')&&str_contains((string)WFCA_Alerts::$raised[0][0],'+2_TRANSIENT_FREE'));
reset_all();$wpdb->rows=[D(),D(),D(),F($BTXT),F($BTXT),D()];
t('text-detected http 5xx is transient too',$brake->invoke(null,$R)===false);
reset_all();$wpdb->rows=[D(),D(),D(),F($B49),F($B49),F($B49)];
t('quality failures (131049) still brake exactly as before',$brake->invoke(null,$R)===true);
reset_all();$wpdb->rows=[D(),D(),D(),F($B49),F($B49),F($B49)];
t('rules without the new keys (old callers) behave as 10.9.27',$brake->invoke(null,['d0_delivery_brake_enabled'=>true,'d0_delivery_brake_failure_ratio'=>0.3])===true);

// ---- D. D0 re-queue
function conv($over=[]){global $PH;return array_merge(['id'=>7,'phone_e164'=>$PH,'conversation_owner'=>'LUNA','human_hold'=>0,'opt_out'=>0,'last_inbound_at'=>null,'owner_revision'=>3,'state'=>'WAITING_REPLY'],$over);}
function d0row($key,$id=50,$over=[]){global $LEAD;return array_merge(['id'=>$id,'idempotency_key'=>$key,'lead_record_id'=>$LEAD,'conversation_id'=>7,'action_type'=>'TEMPLATE_INITIAL','status'=>'SENT','provider_message_id'=>'wamid.X'.$id,'sent_at'=>gmdate('Y-m-d H:i:s',time()-120),'content_sid'=>'d0_media_v1','content_variables'=>'{"1":"Dr X","_header_image_url":"https://auracorp.online/wf-d0-preview/recLEAD1/'.str_repeat('a',64).'/raw"}','state_after'=>'WAITING_REPLY','delivery_status'=>'failed'],$over);}
$base=hash('sha256','INITIAL|'.$LEAD.'|'.$PH);$k1=hash('sha256','INITIAL|'.$LEAD.'|'.$PH.'|R1');$k2=hash('sha256','INITIAL|'.$LEAD.'|'.$PH.'|R2');
$rq=E('maybe_requeue_failed_d0');
reset_all();WFCA_DB::$convs[7]=conv();WFCA_DB::$out[$base]=d0row($base);
$rq->invoke(null,WFCA_DB::$out[$base],'accepted',$B53);
$q=WFCA_DB::$queued[0]??null;
t('131053 on a never-delivered D0 queues ONE new row with the R1 key',count(WFCA_DB::$queued)===1&&$q['idempotency_key']===$k1&&$q['action_type']==='TEMPLATE_INITIAL');
t('retry is spaced >= 10 min and keeps template + variables (preview binding intact)',strtotime($q['next_attempt_at'].' UTC')>=time()+590&&$q['content_sid']==='d0_media_v1'&&$q['content_variables']===WFCA_DB::$out[$base]['content_variables']&&$q['status']==='PENDING');
t('original row is untouched (still SENT with its sid, idempotency key unchanged)',WFCA_DB::$out[$base]['status']==='SENT'&&WFCA_DB::$out[$base]['provider_message_id']==='wamid.X50');
$rq->invoke(null,WFCA_DB::$out[$base],'failed',$B53);
t('redelivered failed webhook does NOT queue a second retry (idempotent)',count(WFCA_DB::$queued)===1);
// R1 sent and failed again -> R2
WFCA_DB::$out[$k1]=d0row($k1,100,['idempotency_key'=>$k1]);
$rq->invoke(null,WFCA_DB::$out[$k1],'sent',$B53);
t('R1 failing with 131053 queues R2',count(WFCA_DB::$queued)===2&&WFCA_DB::$queued[1]['idempotency_key']===$k2);
WFCA_DB::$out[$k2]=d0row($k2,101,['idempotency_key'=>$k2]);
$rq->invoke(null,WFCA_DB::$out[$k2],'sent',$B53);
t('R2 failing does NOT queue a third (max 2) and raises one exhausted alert',count(WFCA_DB::$queued)===2&&WFCA_Alerts::$raised&&str_contains((string)end(WFCA_Alerts::$raised)[0],'D0_TRANSIENT_RETRY_EXHAUSTED'));
$rq->invoke(null,WFCA_DB::$out[$base],'failed',$B53);
t('an older attempt failing late does not queue anything',count(WFCA_DB::$queued)===2);
foreach ([['delivered','delivered before'],['read','read before']] as [$prev,$lbl]) { reset_all();WFCA_DB::$convs[7]=conv();WFCA_DB::$out[$base]=d0row($base);$rq->invoke(null,WFCA_DB::$out[$base],$prev,$B53); t("no re-send when it was $lbl failing",!WFCA_DB::$queued); }
reset_all();WFCA_DB::$convs[7]=conv();WFCA_DB::$out[$base]=d0row($base);$rq->invoke(null,WFCA_DB::$out[$base],'accepted',$B49);
t('quality/engagement failure (131049) is NOT re-queued',!WFCA_DB::$queued);
reset_all();WFCA_DB::$convs[7]=conv(['last_inbound_at'=>gmdate('Y-m-d H:i:s',time()-30)]);WFCA_DB::$out[$base]=d0row($base);$rq->invoke(null,WFCA_DB::$out[$base],'accepted',$B53);
t('prospect wrote after the D0: no re-queue',!WFCA_DB::$queued);
foreach ([['human_hold'=>1],['opt_out'=>1],['conversation_owner'=>'DANIEL']] as $o) { reset_all();WFCA_DB::$convs[7]=conv($o);WFCA_DB::$out[$base]=d0row($base);$rq->invoke(null,WFCA_DB::$out[$base],'accepted',$B53); t('no re-queue when '.key($o).'='.current($o),!WFCA_DB::$queued); }
reset_all();WFCA_DB::$convs[7]=conv();WFCA_DB::$out[$base]=d0row($base,50,['provider_message_id'=>null,'status'=>'UNCERTAIN']);$rq->invoke(null,WFCA_DB::$out[$base],'accepted',$B53);
t('UNCERTAIN / no provider id is never re-queued',!WFCA_DB::$queued);
reset_all();WFCA_Airtable::$cfg=['WFCA_RULES_V1'=>'{"d0_transient_retry_enabled":false}'];WFCA_DB::$convs[7]=conv();WFCA_DB::$out[$base]=d0row($base);$rq->invoke(null,WFCA_DB::$out[$base],'accepted',$B53);
t('retry can be switched off by Config',!WFCA_DB::$queued);

// ---- E. follow-up never rides on a failed D0
$eff=E('effective_initial');
reset_all();WFCA_DB::$out[$base]=d0row($base,50,['delivery_status'=>'delivered']);
t('delivered D0 is the effective initial',($eff->invoke(null,$LEAD,$PH)['id']??0)===50);
WFCA_DB::$out[$base]=d0row($base,50,['delivery_status'=>null]);
t('accepted (delivery unknown yet) D0 is still effective: no behaviour change',($eff->invoke(null,$LEAD,$PH)['id']??0)===50);
WFCA_DB::$out[$base]=d0row($base);
t('failed D0 with no successful retry => no follow-up base',$eff->invoke(null,$LEAD,$PH)===null);
WFCA_DB::$out[$k1]=d0row($k1,100,['delivery_status'=>'delivered']);
t('failed D0 + delivered R1 => R1 is the base (due counted from the retry)',($eff->invoke(null,$LEAD,$PH)['id']??0)===100);
$nfs=E('next_followup_stage');
reset_all();WFCA_DB::$out[$base]=d0row($base);
t('next_followup_stage returns nothing for a failed D0',$nfs->invoke(null,$LEAD,$PH,['COMMERCIAL_D0_FOLLOWUP_DELAY_MINUTES'=>'60'])===[]);
WFCA_DB::$out[$base]=d0row($base,50,['delivery_status'=>'delivered']);
t('and a due for a delivered one',(int)($nfs->invoke(null,$LEAD,$PH,['COMMERCIAL_D0_FOLLOWUP_DELAY_MINUTES'=>'60'])['stage']??0)===1);

// ---- F. provider hold
$hb=E('provider_hold_begin');$he=E('provider_hold_end');
reset_all();
$hb->invoke(null,5,$LEAD,7);
t('402: wfca_provider_hold_until set ~10 min ahead',(int)get_option('wfca_provider_hold_until')>=time()+590&&WFCA_Util::provider_hold_remaining()>0);
t('402: exactly one CRITICAL alert for the episode',count(WFCA_Alerts::$raised)===1&&WFCA_Alerts::$raised[0][1]==='CRITICAL'&&str_contains((string)WFCA_Alerts::$raised[0][0],'PROVIDER_CREDITS_EXHAUSTED'));
$hb->invoke(null,6,$LEAD,7);$hb->invoke(null,7,$LEAD,7);
t('renewals inside the episode do not re-alert',count(WFCA_Alerts::$raised)===1);
$GLOBALS['opts']['wfca_provider_hold_until']=time()-7200;
$hb->invoke(null,8,$LEAD,7);
t('a new episode (>1 h after expiry) alerts again',count(WFCA_Alerts::$raised)===2);
$he->invoke(null);
t('first accepted send ends the hold and resolves the alert',WFCA_Util::provider_hold_remaining()===0&&(int)get_option('wfca_provider_hold_started_at')===0&&count(WFCA_Alerts::$resolved)===1);
$src=file_get_contents(__DIR__.'/../includes/class-wfca-engine.php');
$ex=substr($src,strpos($src,'private static function execute_outbox'),30000);
t('execute_outbox handles credit errors BEFORE retry/fail-fast and never via retry_or_alert',strpos($ex,'is_provider_credit_error($sent)')!==false&&strpos($ex,'is_provider_credit_error($sent)')<strpos($ex,'followup_permanent_error($error)')&&preg_match('/is_provider_credit_error\(\$sent\)\).*?hold_outbox_for_provider.*?return;/s',$ex)===1);
t('process_outbox claims with the provider-hold flag',str_contains($src,'WFCA_DB::claim_outbox($worker,$mode,$draining,WFCA_Util::provider_hold_remaining()>0)'));
t('D0 and follow-up schedulers do not reserve during the hold',str_contains($src,'if (WFCA_Util::provider_hold_remaining()>0) return; // 10.9.28')&&str_contains($src,"'skip_reason'=>'PROVIDER_HOLD'"));
t('hold ends on the first accepted send (after mark_outbox_sent)',strpos($src,'self::provider_hold_end()')>strpos($src,'mark_outbox_sent($id,(string)$sent[\'sid\'])'));

// ---- G. reconciler
function cand($over=[]){global $PH;return conv(array_merge(['conversation_owner'=>'HANDOFF_PENDING','human_hold'=>1,'state'=>'HUMAN_HANDOFF','owner_reason'=>'OUTBOX_FAILED:KAPSO_HTTP_402','lead_record_id'=>'recLEAD1'],$over));}
function failed($over=[]){return array_merge(['id'=>60,'action_type'=>'TEMPLATE_INITIAL','status'=>'FAILED','last_error'=>'KAPSO_HTTP_402','provider_message_id'=>null,'sent_at'=>null,'lead_record_id'=>'recLEAD1','scheduled_action_at'=>null],$over);}
$rec=E('reconcile_one_handoff');
reset_all();WFCA_DB::$convs[7]=cand();WFCA_DB::$failed=failed();
$ok=$rec->invoke(null,WFCA_DB::$convs[7]);
t('402 handoff is restored: ownership LUNA (explicit, revision-checked)',$ok===true&&WFCA_Ownership::$changes===[[7,'LUNA','AUTO_RECOVER_TRANSIENT_OUTBOX',3,true]]);
t('local state READY_FOR_CONTACT and human_hold=0',WFCA_DB::$convs[7]['state']==='READY_FOR_CONTACT'&&(int)WFCA_DB::$convs[7]['human_hold']===0);
t('Airtable updated (State READY_FOR_CONTACT, handoff reason and error cleared)',WFCA_Airtable::$updates&&WFCA_Airtable::$updates[0][1]['State']==='READY_FOR_CONTACT'&&WFCA_Airtable::$updates[0][1]['Human Handoff Reason']===''&&WFCA_Airtable::$updates[0][1]['Commercial Error']==='');
t('FAILED outbox reset on the same row with the NEW owner revision',WFCA_DB::$resets===[[60,4,'PENDING','RECONCILED_FROM:KAPSO_HTTP_402']]&&WFCA_Ownership::$syncs===[7]);
// follow-up variant
reset_all();WFCA_DB::$convs[7]=cand(['owner_reason'=>'OUTBOX_FAILED:KAPSO_HTTP_429']);WFCA_DB::$failed=failed(['action_type'=>'FOLLOWUP','last_error'=>'KAPSO_HTTP_429','scheduled_action_at'=>'2026-10-10 15:00:00']);
$rec->invoke(null,WFCA_DB::$convs[7]);
t('failed follow-up: back to FOLLOWUP_SCHEDULED with its original due so the transport guard still matches',WFCA_DB::$convs[7]['state']==='FOLLOWUP_SCHEDULED'&&WFCA_Airtable::$updates[0][1]['State']==='FOLLOWUP_SCHEDULED'&&WFCA_Airtable::$updates[0][1]['Next Commercial Action At']===gmdate('c',strtotime('2026-10-10 15:00:00 UTC')));
// negatives
$neg=[
 'prospect replied (last_inbound_at set)'=>[cand(['last_inbound_at'=>'2026-10-10 12:00:00']),failed()],
 'real handoff reason'=>[cand(['owner_reason'=>'DANIEL_PERSONAL_TOUCH']),failed()],
 'ambiguous transport send'=>[cand(['owner_reason'=>'AMBIGUOUS_TRANSPORT_SEND']),failed()],
 'permanent error (TEMPLATE_PAYLOAD_INVALID)'=>[cand(['owner_reason'=>'OUTBOX_FAILED:TEMPLATE_PAYLOAD_INVALID']),failed(['last_error'=>'TEMPLATE_PAYLOAD_INVALID'])],
 'opt-out'=>[cand(['opt_out'=>1]),failed()],
 'owner is Daniel'=>[cand(['conversation_owner'=>'DANIEL']),failed()],
 'failed outbox has a provider id (was sent)'=>[cand(),failed(['provider_message_id'=>'wamid.1'])],
 'no failed outbox found'=>[cand(),null],
];
foreach ($neg as $n=>[$c,$f]) { reset_all();WFCA_DB::$convs[7]=$c;WFCA_DB::$failed=$f;$r=$rec->invoke(null,$c); t("reconciler leaves alone: $n",$r===false&&!WFCA_Ownership::$changes&&!WFCA_DB::$resets&&!WFCA_Airtable::$updates); }
reset_all();WFCA_DB::$convs[7]=cand();WFCA_DB::$failed=failed();WFCA_Ownership::$change_ok=false;
t('remote opt-out/permission block (change refuses) => nothing else is touched',$rec->invoke(null,WFCA_DB::$convs[7])===false&&!WFCA_DB::$resets&&!WFCA_Airtable::$updates);
// loop breaker
reset_all();WFCA_DB::$convs[7]=cand();WFCA_DB::$failed=failed();
$n=0;for($i=0;$i<5;$i++){WFCA_DB::$convs[7]=cand();if($rec->invoke(null,WFCA_DB::$convs[7]))$n++;}
t('loop breaker: same outbox recovered at most 3 times, then a WARN alert',$n===3&&str_contains((string)end(WFCA_Alerts::$raised)[0],'AUTO_RECOVER_GAVE_UP'));
// driver
$run=E('reconcile_transient');
reset_all();WFCA_DB::$convs[7]=cand();WFCA_DB::$failed=failed();WFCA_DB::$cands=[WFCA_DB::$convs[7]];
$o=$run->invoke(null);
t('driver recovers a candidate and raises one aggregated INFO alert',$o['recovered']===1&&count(array_filter(WFCA_Alerts::$raised,fn($a)=>str_contains((string)$a[0],'AUTO_RECOVERED_TRANSIENT_HANDOFF')))===1);
$o=$run->invoke(null);
t('driver is rate-limited (interval 600 s)',$o['skipped']==='NOT_DUE');
reset_all();$GLOBALS['opts']['wfca_provider_hold_until']=time()+300;WFCA_DB::$convs[7]=cand();WFCA_DB::$failed=failed();WFCA_DB::$cands=[WFCA_DB::$convs[7]];
t('driver does nothing while the provider is still on hold',$run->invoke(null)['skipped']==='PROVIDER_HOLD'&&!WFCA_DB::$resets);
reset_all();WFCA_DB::$failed=failed();WFCA_DB::$cands=[];for($i=1;$i<=9;$i++){WFCA_DB::$convs[$i]=cand(['id'=>$i,'phone_e164'=>'+55119999900'.$i]);WFCA_DB::$cands[]=WFCA_DB::$convs[$i];WFCA_DB::$failed_by[$i]=failed(['id'=>200+$i]);}
$o=$run->invoke(null);
t('driver respects the per-run cap (default 5)',$o['recovered']===5);
reset_all();WFCA_Airtable::$cfg=['WFCA_RULES_V1'=>'{"reconcile_enabled":false}'];WFCA_DB::$convs[7]=cand();WFCA_DB::$cands=[WFCA_DB::$convs[7]];WFCA_DB::$failed=failed();
t('reconciler can be switched off by Config',$run->invoke(null)['skipped']==='DISABLED'&&!WFCA_DB::$resets);

// ---- H. stuck FOLLOWUP_SCHEDULED
$stuck=E('reconcile_stuck_followups');
$due=time()-4*3600;
$rec_fields=['Lead'=>[$LEAD],'Phone E164'=>$PH,'Next Commercial Action At'=>gmdate('c',$due),'Enabled'=>true,'Conversation Owner'=>'LUNA','State'=>'FOLLOWUP_SCHEDULED','Opt Out'=>false];
reset_all();WFCA_DB::$convs[7]=conv(['state'=>'FOLLOWUP_SCHEDULED','lead_record_id'=>$LEAD,'initial_arm'=>'LUNA_COLD_WHATSAPP']);
WFCA_Airtable::$stuck=['ok'=>true,'data'=>['records'=>[['id'=>'recC1','fields'=>$rec_fields]]]];
$cleared=$stuck->invoke(null,5,WFCA_Util::rules());
t('overdue FOLLOWUP_SCHEDULED with no D0 proof/no outbox is cleared back to WAITING_REPLY',$cleared===1&&WFCA_Airtable::$updates&&WFCA_Airtable::$updates[0][1]['State']==='WAITING_REPLY'&&array_key_exists('Next Commercial Action At',WFCA_Airtable::$updates[0][1])&&WFCA_Airtable::$updates[0][1]['Next Commercial Action At']===null);
reset_all();WFCA_DB::$convs[7]=conv(['state'=>'FOLLOWUP_SCHEDULED','lead_record_id'=>$LEAD]);
WFCA_DB::$out[$base]=d0row($base,50,['delivery_status'=>'delivered','sent_at'=>gmdate('Y-m-d H:i:s',$due-3600)]);
WFCA_Airtable::$cfg=['COMMERCIAL_D0_FOLLOWUP_DELAY_MINUTES'=>'60'];
$fk=hash('sha256','FOLLOWUP|D0_1|'.$LEAD.'|'.$PH);WFCA_DB::$out[$fk]=['id'=>77,'status'=>'FAILED'];
WFCA_Airtable::$stuck=['ok'=>true,'data'=>['records'=>[['id'=>'recC1','fields'=>$rec_fields]]]];
t('when an outbox exists the outbox pipeline owns it: untouched',$stuck->invoke(null,5,WFCA_Util::rules())===0&&!WFCA_Airtable::$updates);
reset_all();WFCA_Airtable::$stuck=['ok'=>false];
t('Airtable read failure => no action',$stuck->invoke(null,5,WFCA_Util::rules())===0);

// ---- I. health snapshot
$hw=E('health_write');
reset_all();
update_option('wfca_d0_brake_until',time()+1800);update_option('wfca_provider_hold_until',time()+300);update_option('wfca_last_tick_at','2026-10-12T11:00:00+00:00');
WFCA_Util::record_delivery_failure($B53,'+5511999990000');WFCA_Util::record_delivery_failure($B53,'+5511999990001');WFCA_Util::record_delivery_failure($B49,'+5511999990002');WFCA_Util::health_note('KAPSO_HTTP_402');WFCA_Util::health_note('D0_REQUEUED');
WFCA_Util::health_note('OLD',time()-7200);
$hw->invoke(null,'COMPLETED','DONE','');
$h=get_option('wfca_health_v1');
t('wfca_health_v1: tick, brake and provider hold',is_array($h)&&$h['v']===1&&$h['tick_result']==='COMPLETED'&&$h['last_tick_at']==='2026-10-12T11:00:00+00:00'&&$h['brake_active']===true&&$h['brake_until']!==''&&$h['provider_hold_active']===true&&$h['provider_hold_until']!=='');
t('wfca_health_v1: failures by code in the last hour (old ones dropped), events separated',$h['fail_by_code_1h']==['code_131053'=>2,'code_131049'=>1,'KAPSO_HTTP_402'=>1]&&$h['events_1h']==['D0_REQUEUED'=>1]);
reset_all();$hw->invoke(null,'SKIPPED','BOOT','MODE_OFF');$h=get_option('wfca_health_v1');
t('health with no brake/hold reports inactive',$h['brake_active']===false&&$h['provider_hold_active']===false&&$h['brake_until']===''&&$h['fail_by_code_1h']===[]);
t('tick writes the health snapshot in finally and runs the reconciler',str_contains($src,'self::health_write($result,$stage,$skip);')&&str_contains($src,'self::reconcile_transient();'));
t('health is exposed on /commercial/health details',str_contains(file_get_contents(__DIR__.'/../includes/class-wfca-rest.php'),"'health_v1'=>get_option('wfca_health_v1',null)"));
t('version bumped in header and constant (10.9.28 line kept green by accepting its successor)',preg_match('/Version: 10\.9\.(28-RESILIENCE|29-SELFHEAL|30-AUTORESPONDER-PRICE-GUARD)-RC1/',file_get_contents(__DIR__.'/../wf-commercial-agent.php'))&&preg_match("/define\('WFCA_VERSION', '10\.9\.(28-RESILIENCE|29-SELFHEAL|30-AUTORESPONDER-PRICE-GUARD)-RC1'\)/",file_get_contents(__DIR__.'/../wf-commercial-agent.php')));
t('send-time preview probe defers (no attempt burned) before the template send, behind a rules switch',str_contains($src,'d0_preview_probe((string)$live_media[\'url\'])')&&str_contains($src,"'D0_PREVIEW_PRESEND_UNREACHABLE_'")&&strpos($src,'d0_preview_probe(')<strpos($src,'WFCA_Transport::send($row,\'\',$content_sid,$variables)'));
echo "TOTAL PASS=$pass FAIL=$fail\n";exit($fail?1:0);
