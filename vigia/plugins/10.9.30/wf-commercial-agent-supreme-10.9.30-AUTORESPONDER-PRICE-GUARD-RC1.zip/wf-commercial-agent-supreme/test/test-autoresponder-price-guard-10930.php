<?php
// 10.9.30: real clinic auto-replies of 2026-10-10 (identifiers removed) must be autoresponders; real humans must not.
define('ABSPATH', __DIR__.'/');
define('MINUTE_IN_SECONDS',60);define('DAY_IN_SECONDS',86400);
function sanitize_email($x){return $x;} function is_email($x){return false;} function get_option($k,$d=null){return $d;} function wp_strip_all_tags($x){return strip_tags($x);}
function update_option($k,$v,$a=null){return true;}
require_once __DIR__.'/../includes/class-wfca-util.php';
final class WFCA_Airtable {public static function lead_is_commercial_ready(array $l): bool {return true;} public static function mode(): string {return "LIVE";} public static function config(): array {return [];}}
final class WFCA_Ownership {public static function queue_status(): string {return 'PENDING';}}
final class WFCA_Alerts {public static function raise(...$a): void {}}
final class WFCA_DB {}
require_once __DIR__.'/../includes/class-wfca-engine.php';
$pass=0;$fail=0;function t($n,$c){global $pass,$fail;if($c){echo "PASS $n\n";$pass++;}else{echo "FAIL $n\n";$fail++;}}
$auto=(new ReflectionMethod('WFCA_Engine','is_likely_autoresponder'));$auto->setAccessible(true);
$dec=(new ReflectionMethod('WFCA_Engine','deterministic_decision'));$dec->setAccessible(true);
$bots=[
 'goud (address+hours+price)'=>"Olá! Nosso atendimento é de segunda a sábado.\n\n📍 Estamos localizados no Rio de Janeiro:\n• Barra: Av. Almirante Júlio de Sá Bierrembach, 65 (próx. Parque Olímpico)\n• Botafogo: Rua Voluntários da Pátria, 190\n\n💳 O investimento para a consulta é de R$ 290, com agendamento confirmado mediante 50% de sinal.\nA consulta dura cerca de 1h30, com avaliação minuciosa, análise das queixas e, se necessário, solicitação de exames para montar um plano exclusivo.\n\nAguarde um momento que você já será atendido ❤️",
 'saldanha concierge hours'=>"Olá! Que bom receber você na Clínica Exemplo. 🤍 _Nosso atendimento é de segunda à sexta, das 08:30h às 18:30h. Sua mensagem é importante e vou retornar pessoalmente assim que possível._ Enquanto isso, fique a vontade para me contar o que te trouxe até nós.",
 'team unavailable'=>"Olá! Que alegria receber sua mensagem. 💫 No momento, nossa equipe não está disponível. *Nosso horário de funcionamento é:* *• Segunda a quinta:* 09:00 às 17:30 *• Sexta-feira:* 09:00 às 20:00 Você pode adiantar a sua dúvida ou solicitação por aqui! Responderemos o mais breve possível.",
 'secretary will answer'=>"Olá! 😊 Aqui é a clínica do Dr. Exemplo, médico dermatologista. Recebemos sua mensagem, e o secretário do doutor já te responde por aqui.",
 'leave a message'=>"Agradecemos por entrar em contato conosco. Para facilitar o processo de atendimento, por favor deixe uma mensagem com um resumo sucinto da sua solicitação, será um prazer respondê-la assim que possível. Att., Equipe Exemplo",
 'casa greeter'=>"Olá seja bem-vindo(a) à Casa Exemplo! 💖✨ Aqui é a Ana! Em breve, vou seguir com o seu atendimento por aqui. 🥰 Vi que você se interessou pelo nosso protocolo e, para eu entender melhor, me conta: O que está te incomodando hoje?",
 'short breve retornamos'=>"Olá. É um prazer receber o seu contato. Breve te retornamos 💚",
 'menu'=>"🌟 Bem-vindo(a) à Clínica Exemplo! 🌟 Para começar, por favor, escolha uma das opções abaixo: 1️⃣ Rejuvenescimento 2️⃣ Medidas 3️⃣ Flacidez 5️⃣ Falar com um especialista",
];
foreach($bots as $l=>$m) t('real auto-reply detected: '.$l,$auto->invoke(null,$m)===true);
$humans=[
 'warm lead'=>'Eu amei. Mas no momento não posso. Ainda estou pagando o outro',
 'did you make the site'=>'Você fez o site?',
 'already have company'=>'Olá, boa tarde Já temos uma empresa responsável por essa área, obrigada.',
 'hold on human'=>'Um momento, por favor.',
 'ask price'=>'Oi, vi o site. Quanto custa para colocar no ar?',
 'ask invest'=>'Qual o investimento para fazer um site assim? Tem parcelamento?',
 'secretary forward'=>'Vou encaminhar para a Dra Marta',
 'long human with question'=>'Boa tarde! Recebi o seu site e achei bonito, mas moramos na Barra e atendemos de segunda a sexta, das 9h às 18h. Qual o valor e como funciona o pagamento? R$ 500 é o que posso pagar.',
];
foreach($humans as $l=>$m) t('human not misclassified: '.$l,$auto->invoke(null,$m)===false);
// price guard
$lead=['id'=>'recT','fields'=>[]];
$r=$dec->invoke(null,$bots['goud (address+hours+price)'],$lead,[]);
t('clinic quoting its own price never yields a PRICE reply',($r['action']??'')!=='PRICE'&&($r['reason']??'')!=='PRICE_ASK');
$r=$dec->invoke(null,'Quanto custa?',$lead,[]);t('short price ask still yields PRICE',($r['action']??'')==='PRICE');
$r=$dec->invoke(null,'Qual o investimento para fazer um site assim? Tem parcelamento?',$lead,[]);t('longer price question still yields PRICE',($r['action']??'')==='PRICE');
$r=$dec->invoke(null,$humans['long human with question'],$lead,[]);t('long message WITH a question still handled as ask',($r['reason']??'')==='PRICE_ASK'||($r['action']??'')==='PRICE');
echo "\nPASS=$pass FAIL=$fail\n";exit($fail?1:0);
