<?php
define('ABSPATH', __DIR__.'/');
define('ARRAY_A','ARRAY_A');
$GLOBALS['opts']=[];
foreach (['wp_strip_all_tags','sanitize_email','is_email','apply_filters','wp_json_encode','home_url','esc_url_raw'] as $fn) { if(!function_exists($fn)) { eval('function '.$fn.'(...$a){return $a[0]??"";}'); } }
function get_option($k,$d=false){return $GLOBALS['opts'][$k]??$d;}
function update_option($k,$v,$a=null){$GLOBALS['opts'][$k]=$v;return true;}
final class WFCA_DB { public static function t($n){return 'wp_wfca_'.$n;} }
final class WFCA_Alerts { public static $raised=[]; public static function raise(...$a){self::$raised[]=$a;return 1;} }
final class WFCA_Ownership { public static function arm(string $a): string {return $a;} public static function remote_arm(string $a): string {return $a;} }
final class FakeWpdb { public $rows=[]; public function prepare($q,...$a){return $q;} public function get_results($q,$t=null){return $this->rows;} }
$wpdb=new FakeWpdb();
require_once __DIR__.'/../includes/class-wfca-util.php';
require_once __DIR__.'/../includes/class-wfca-engine.php';
$pass=0;$fail=0;function t($n,$c){global $pass,$fail;if($c){echo "PASS $n\n";$pass++;}else{echo "FAIL $n\n";$fail++;}}
// --- jitter
$all=[];for($i=0;$i<200;$i++){$all[]=WFCA_Util::jitter_up(540,1760000000+$i*540);}
t('jitter never goes below the configured floor',min($all)>=540);
t('jitter never exceeds +25%',max($all)<=(int)round(540*1.25));
t('jitter really varies (not a fixed interval)',count(array_unique($all))>40);
t('jitter is stable for the same seed',WFCA_Util::jitter_up(540,1760000123)===WFCA_Util::jitter_up(540,1760000123));
t('jitter max 0 means exact interval',WFCA_Util::jitter_up(540,99,0.0)===540);
t('jitter max is capped at +50%',WFCA_Util::jitter_up(1000,5,5.0)<=1500);
// --- jargon + guard
foreach(['animações GSAP','com Three.js','WebGL','um framework','novo CMS','motion premium'] as $x) t("jargon detected: $x",WFCA_Util::has_tech_jargon("Evoluir com $x e mais"));
foreach(['animações premium e experiências 3D','Apresentar Toxina Botulínica com clareza'] as $x) t("clean text not flagged: $x",!WFCA_Util::has_tech_jargon($x));
$raw="SERVIÇOS VERIFICADOS: Limpeza de pele fotônica; Peeling químico; Bioestimulador de colágeno VNEXT_BUILDABILITY_CERTIFIED_V2_EXT | run=X";
t('clean line passes through untouched',WFCA_Util::customer_safe_observation('Uma página mais elegante e direta.',$raw)==='Uma página mais elegante e direta.');
t('jargon line is replaced by the clinic\'s verified services',WFCA_Util::customer_safe_observation('Evoluir com animações GSAP e 3D.',$raw)==='Apresentar Limpeza de pele fotônica, Peeling químico e Bioestimulador de colágeno com mais clareza e deixar o caminho até o agendamento mais direto.');
t('jargon line without services falls back to the generic benefit',WFCA_Util::customer_safe_observation('Usar Three.js aqui','')==='Apresentar os tratamentos com mais clareza e deixar o caminho até o agendamento mais direto.');
t('empty line stays empty (caller fails closed as before)',WFCA_Util::customer_safe_observation('','x')==='');
// --- brake
$m=(new ReflectionClass('WFCA_Engine'))->getMethod('d0_delivery_brake_active');$m->setAccessible(true);
$rules=['d0_delivery_brake_enabled'=>true,'d0_delivery_brake_failure_ratio'=>0.30];
function rows($d,$f,$s=0){$r=[];for($i=0;$i<$d;$i++)$r[]=['delivery_status'=>'delivered'];for($i=0;$i<$f;$i++)$r[]=['delivery_status'=>'failed'];for($i=0;$i<$s;$i++)$r[]=['delivery_status'=>'sent'];return $r;}
function reset_brake(){$GLOBALS['opts']=[];WFCA_Alerts::$raised=[];}
reset_brake();$wpdb->rows=rows(8,2);t('2 of 10 failed (20%) does not brake',$m->invoke(null,$rules)===false);
reset_brake();$wpdb->rows=rows(6,4);t('4 of 10 failed (40%) brakes',$m->invoke(null,$rules)===true&&count(WFCA_Alerts::$raised)===1);
t('while paused it stays paused without re-alerting',$m->invoke(null,$rules)===true&&count(WFCA_Alerts::$raised)===1);
reset_brake();$wpdb->rows=rows(2,2,6);t('too few resolved results (4) never brakes',$m->invoke(null,$rules)===false);
reset_brake();$wpdb->rows=rows(6,4);$m->invoke(null,$rules);$GLOBALS['opts']['wfca_d0_brake_until']=time()-5;$wpdb->rows=[];t('after the pause expires only newer sends count, so it releases',$m->invoke(null,$rules)===false);
reset_brake();$wpdb->rows=rows(6,4);t('brake can be switched off by rules',$m->invoke(null,['d0_delivery_brake_enabled'=>false,'d0_delivery_brake_failure_ratio'=>0.3])===false);
$src=file_get_contents(__DIR__.'/../includes/class-wfca-engine.php');
t('scheduler applies jitter and brake before reserving a D0',str_contains($src,'WFCA_Util::jitter_up($interval')&&str_contains($src,'if (self::d0_delivery_brake_active($rules)) return;'));
t('D0 personalised line goes through the jargon guard',str_contains($src,'WFCA_Util::customer_safe_observation(self::commercial_observation($lead)'));
echo "TOTAL PASS=$pass FAIL=$fail\n";exit($fail?1:0);
