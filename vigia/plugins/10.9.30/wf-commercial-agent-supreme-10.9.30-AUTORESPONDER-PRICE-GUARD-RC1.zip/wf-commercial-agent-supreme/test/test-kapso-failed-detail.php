<?php
define('ABSPATH', __DIR__.'/');
define('WFCA_KAPSO_API_KEY','test-key');define('WFCA_KAPSO_PHONE_NUMBER_ID','123456');define('WFCA_KAPSO_WEBHOOK_SECRET','s');
foreach (['wp_strip_all_tags','sanitize_email','is_email','get_option','apply_filters','wp_json_encode','home_url','esc_url_raw'] as $fn) { if(!function_exists($fn)) { eval('function '.$fn.'(...$a){return $a[0]??"";}'); } }
function update_option($k,$v,$a=null){return true;}
require_once __DIR__.'/../includes/class-wfca-util.php';
require_once __DIR__.'/../includes/class-wfca-kapso.php';
$pass=0;$fail=0;function t($n,$c){global $pass,$fail;if($c){echo "PASS $n\n";$pass++;}else{echo "FAIL $n\n";$fail++;}}
function ev(array $msg,array $kx=[]){
  return ['phone_number_id'=>'123456','conversation'=>['phone_number'=>'+5534988610000'],
    'message'=>array_merge(['id'=>'wamid.F1','timestamp'=>(string)time(),'to'=>'5534988610000','type'=>'text','kapso'=>array_merge(['direction'=>'outbound','origin'=>'cloud_api'],$kx)],$msg)];
}
function err($c,$t,$m,$d=''){return ['code'=>$c,'title'=>$t,'message'=>$m,'error_data'=>['details'=>$d],'href'=>'https://developers.facebook.com/docs/whatsapp/cloud-api/support/error-codes/'];}
function st($status,$errs=null){$s=['id'=>'wamid.F1','status'=>$status,'timestamp'=>'1','recipient_id'=>'5534988610000'];if($errs!==null)$s['errors']=$errs;return $s;}
function body(array $p){$r=WFCA_Kapso::normalize($p,'whatsapp.message.failed');return $r['ok']?$r['data']['body']:'ERR:'.$r['error'];}

// v2 template, 131047
$p=ev(['type'=>'template'],['statuses'=>[st('sent'),st('failed',[err(131047,'Re-engagement message','More than 24 hours have passed since the recipient last replied','Message failed to send because more than 24 hours have passed')])]]);
$b=body($p);
t('v2 template 131047 code/title',str_contains($b,'code=131047')&&str_contains($b,'title=Re-engagement message'));
t('v2 message included',str_contains($b,'More than 24 hours'));
$d=WFCA_Kapso::failure_detail($p);
t('failure_detail source is statuses failed',$d['source']==='kapso.statuses[failed]'&&$d['code']==='131047');
// v2 text message with body: text must not leak, error wins
$p=ev(['type'=>'text','text'=>['body'=>'Ola Dra, segredo comercial XYZ'],],['statuses'=>[st('failed',[err('131049','This message was not delivered to maintain healthy ecosystem engagement.','Ecosystem')])]]);
$b=body($p);
t('text message: error not text',str_contains($b,'code=131049')&&!str_contains($b,'segredo')&&!str_contains($b,'Ola Dra'));
t('string code accepted',WFCA_Kapso::failure_detail($p)['code']==='131049');
// 131026
$p=ev([],['statuses'=>[st('failed',[err(131026,'Message undeliverable','Unable to deliver message. Reasons can include: the recipient phone number is not a WhatsApp phone number')])]]);
t('131026',str_contains(body($p),'code=131026')&&str_contains(body($p),'Message undeliverable'));
// last failed wins
$p=ev([],['statuses'=>[st('failed',[err(1,'Old','o')]),st('sent'),st('failed',[err(2,'New','n')])]]);
t('last failed entry first',WFCA_Kapso::failure_detail($p)['code']==='2');
// failed status without errors falls to message.errors
$p=ev(['errors'=>[err(131000,'Something went wrong','x')]],['statuses'=>[st('failed')]]);
t('fallback to message.errors',WFCA_Kapso::failure_detail($p)['source']==='message.errors'&&WFCA_Kapso::failure_detail($p)['code']==='131000');
$p=ev([],['errors'=>[['code'=>5,'title'=>'KE']]]);
t('kapso.errors',WFCA_Kapso::failure_detail($p)['source']==='kapso.errors');
$p=ev(['error'=>'plain string error']);
t('message.error string',WFCA_Kapso::failure_detail($p)['title']==='plain string error');
$p=ev([],['status_details'=>['code'=>7,'message'=>'sd']]);
t('kapso.status_details',WFCA_Kapso::failure_detail($p)['source']==='kapso.status_details'&&WFCA_Kapso::failure_detail($p)['code']==='7');
// raw Meta
$p=ev([]);$p['entry']=[['changes'=>[['value'=>['statuses'=>[['status'=>'failed','errors'=>[err(131047,'Re-engagement message','More than 24 hours')]]]]]]]];
t('raw Meta format',WFCA_Kapso::failure_detail($p)['source']==='meta.entry'&&str_contains(body($p),'code=131047'));
// empty -> NO_DETAIL with status keys
$p=ev([],['statuses'=>[st('failed')]]);
$b=body($p);
t('empty -> NO_DETAIL',str_starts_with($b,'WA_ERR NO_DETAIL')&&str_contains($b,'s_keys=id,status,timestamp,recipient_id')&&str_contains($b,'k_keys='));
t('NO_DETAIL has only key names',!str_contains($b,'wamid'));
t('no statuses at all -> NO_DETAIL',str_contains(body(ev([])),'NO_DETAIL'));
// phone masking, incl. formatted
$p=ev([],['statuses'=>[st('failed',[err(131026,'Undeliverable','Number +5534988610000 and 34 98861-0000 and 5534988610000 invalid','id 553498861000012')])]]);
$b=body($p);
t('phone masked',!preg_match('/\d{9}/',$b)&&str_contains($b,'[num]')&&!str_contains($b,'98861'));
t('short numbers kept (code)',str_contains($b,'code=131026'));
// truncation
$p=ev([],['statuses'=>[st('failed',[err(str_repeat('9',50),str_repeat('T',500),str_repeat('M',900),str_repeat('D',900))])]]);
$d=WFCA_Kapso::failure_detail($p);
t('fields truncated',strlen($d['code'])<=20&&strlen($d['title'])<=80&&strlen($d['message'])<=160&&strlen($d['details'])<=120);
// contract: engine short_text 300 still holds a useful prefix
t('body starts with WA_ERR code=',str_starts_with(body($p),'WA_ERR code='));
// non-failed events keep message text
$r=WFCA_Kapso::normalize(ev(['text'=>['body'=>'oi']],['statuses'=>[st('sent')]]),'whatsapp.message.sent');
t('non-failed event body unchanged',$r['ok']&&$r['data']['body']==='oi');
// 10.9.26 review hardening: odd shapes, no warnings, wider mask
$w=0;set_error_handler(function($n,$s)use(&$w){$w++;return true;});
$p=ev([],['statuses'=>[['id'=>'w','status'=>['x'],'errors'=>[err(1,'t','m')]],['id'=>'w','status'=>'failed','errors'=>['code'=>131047,'title'=>'Re-engagement message']]]]);
$d=WFCA_Kapso::failure_detail($p);
t('errors as a single object is read; array status does not warn',$d['code']==='131047'&&$d['title']==='Re-engagement message'&&$w===0);
$p=ev([],['statuses'=>[['id'=>'w','status'=>'failed','errors'=>'Template not found']]]);
t('errors as a plain string becomes the title',WFCA_Kapso::failure_detail($p)['title']==='Template not found');
restore_error_handler();
t('mask: slash and underscore separators',!preg_match('/\d{9}/',preg_replace('/\D/','',WFCA_Kapso::mask_nums('call 34/98861/0000 or 34_98861_0000 now'))) );
echo "TOTAL PASS=$pass FAIL=$fail\n";exit($fail?1:0);
