<?php
define('ABSPATH', __DIR__.'/');
foreach (['wp_strip_all_tags','sanitize_email','is_email','get_option','apply_filters','wp_json_encode','home_url','esc_url_raw','update_option','set_transient','get_transient','delete_transient'] as $fn) { if(!function_exists($fn)) { eval('function '.$fn.'(...$a){return $a[0]??"";}'); } }
$GLOBALS['urls']=[];
function wp_remote_request($url,$args){$GLOBALS['urls'][]=$url;return ['response'=>['code'=>200],'body'=>json_encode(['records'=>[]])];}
function wp_remote_retrieve_response_code($r){return 200;}
function wp_remote_retrieve_body($r){return $r['body'];}
function is_wp_error($x){return false;}
require_once __DIR__.'/../includes/class-wfca-util.php';
require_once __DIR__.'/../includes/class-wfca-airtable.php';
$pass=0;$fail=0;function t($n,$c){global $pass,$fail;if($c){echo "PASS $n\n";$pass++;}else{echo "FAIL $n\n";$fail++;}}
$src=file_get_contents(__DIR__.'/../includes/class-wfca-airtable.php');
$eng=file_get_contents(__DIR__.'/../includes/class-wfca-engine.php');
t('list query sorts newest factory completion first',str_contains($src,"'sort'=>[['field'=>'Last Factory At','direction'=>'desc']]"));
t('airtable sort syntax is encoded as sort[0][field]/[direction]',str_contains($src,"'sort%5B'.(int)\$i.'%5D%5Bfield%5D='")&&str_contains($src,"'%5D%5Bdirection%5D='"));
t('materializer window raised to 250 at the call site',str_contains($eng,'self::materialize_commercial_ready_inventory(250);'));
t('materializer default window raised to 250',str_contains($eng,'function materialize_commercial_ready_inventory(int $max=250)'));
t('the old unordered 100 window is gone',!str_contains($eng,'materialize_commercial_ready_inventory(100)'));
t('formula still requires BUILT, FACTORY_COMPLETE, smoke PASS, site and phone',str_contains($src,"{Build Status}='BUILT',{Factory State}='FACTORY_COMPLETE',{Public Smoke Status}='PASS',{Site URL}!='',{Telefone}!=''"));
t('per-lead gates (commercial ready, phone, arm, opt-out) untouched',str_contains($eng,'lead_is_commercial_ready($lead)')&&str_contains($eng,'canonical_factory_phone'));
echo "TOTAL PASS=$pass FAIL=$fail\n";exit($fail?1:0);
