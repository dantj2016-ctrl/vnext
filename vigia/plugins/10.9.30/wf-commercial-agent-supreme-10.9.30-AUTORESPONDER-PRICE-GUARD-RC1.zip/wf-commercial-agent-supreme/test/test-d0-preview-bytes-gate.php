<?php
define('ABSPATH', __DIR__.'/');
define('HOUR_IN_SECONDS',3600);
foreach (['wp_strip_all_tags','sanitize_email','is_email','get_option','apply_filters','wp_json_encode','home_url','esc_url_raw'] as $fn) { if(!function_exists($fn)) { eval('function '.$fn.'(...$a){return $a[0]??"";}'); } }
$GLOBALS['tr']=[];$GLOBALS['http']=[];$GLOBALS['calls']=0;
function get_transient($k){return $GLOBALS['tr'][$k]??false;}
function set_transient($k,$v,$t=0){$GLOBALS['tr'][$k]=$v;return true;}
class WP_Error{}
function is_wp_error($x){return $x instanceof WP_Error;}
function wp_remote_get($u,$a=[]){$GLOBALS['calls']++;$GLOBALS['last_args']=$a;return array_shift($GLOBALS['http']);}
function wp_remote_retrieve_response_code($r){return $r['code']??0;} function wp_remote_retrieve_body($r){return $r['body']??'';}
final class WFCA_Airtable_Stub { }
require_once __DIR__.'/../includes/class-wfca-airtable.php';
$rules=['d0_min_preview_bytes'=>150000];
if(!class_exists('WFCA_Util')){ final class WFCA_Util { public static function rules(): array { return $GLOBALS['rules']; } } }
$GLOBALS['rules']=$rules;
$pass=0;$fail=0;function t($n,$c){global $pass,$fail;if($c){echo "PASS $n\n";$pass++;}else{echo "FAIL $n\n";$fail++;}}
$m=['ok'=>true,'url'=>'https://auracorp.online/wf-d0-preview/recX/'.str_repeat('a',64).'/raw','sha256'=>str_repeat('a',64)];
$GLOBALS['http']=[['code'=>200,'body'=>str_repeat('x',160000)]];
$r=WFCA_Airtable::d0_preview_bytes_gate($m);t('a real preview (>=150 KB) passes',!empty($r['ok'])&&$GLOBALS['last_args']['limit_response_size']===151024);
$GLOBALS['calls']=0;$r=WFCA_Airtable::d0_preview_bytes_gate($m);t('OK result is cached (no second fetch)',!empty($r['ok'])&&$GLOBALS['calls']===0);
$GLOBALS['tr']=[];$GLOBALS['http']=[['code'=>200,'body'=>str_repeat('x',23939)]];
$r=WFCA_Airtable::d0_preview_bytes_gate($m);t('the 24 KB bot-check page is blocked',empty($r['ok'])&&$r['error']==='D0_PREVIEW_IMAGE_TOO_SMALL'&&$r['bytes']===23939);
$GLOBALS['calls']=0;$r=WFCA_Airtable::d0_preview_bytes_gate($m);t('BAD result is cached too',empty($r['ok'])&&$GLOBALS['calls']===0);
$GLOBALS['tr']=[];$GLOBALS['http']=[['code'=>503,'body'=>'']];
$r=WFCA_Airtable::d0_preview_bytes_gate($m);t('unreachable raw route fails closed at queue time',empty($r['ok'])&&$r['error']==='D0_PREVIEW_UNREACHABLE');
$GLOBALS['tr']=[];$GLOBALS['rules']=['d0_min_preview_bytes'=>0];$GLOBALS['http']=[];$GLOBALS['calls']=0;
$r=WFCA_Airtable::d0_preview_bytes_gate($m);t('0 turns the gate off (Airtable kill-switch) without any fetch',!empty($r['ok'])&&$GLOBALS['calls']===0);
$GLOBALS['rules']=$rules;
$r=WFCA_Airtable::d0_preview_bytes_gate(['ok'=>false,'error'=>'D0_PREVIEW_NOT_READY']);t('an already failed contract is passed through untouched',empty($r['ok'])&&$r['error']==='D0_PREVIEW_NOT_READY');
$src=file_get_contents(__DIR__.'/../includes/class-wfca-engine.php');
t('queue-time gate wraps the contract in initial_template_variables',str_contains($src,'d0_preview_bytes_gate(WFCA_Airtable::d0_preview_contract($lead))'));
t('send-time gate enforces only TOO_SMALL (unreachable stays fail-open)',str_contains($src,"D0_PREVIEW_IMAGE_TOO_SMALL') \$live_media=\$size_gate"));
$u=file_get_contents(__DIR__.'/../includes/class-wfca-util.php');
t('rules() exposes d0_min_preview_bytes with default 150000 and a 0..1 MB clamp',str_contains($u,"'d0_min_preview_bytes'=>150000")&&str_contains($u,'max(0,min(1000000'));
echo "TOTAL PASS=$pass FAIL=$fail\n";exit($fail?1:0);
