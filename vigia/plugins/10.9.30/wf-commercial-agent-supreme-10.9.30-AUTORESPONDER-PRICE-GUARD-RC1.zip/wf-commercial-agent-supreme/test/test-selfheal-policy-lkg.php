<?php
// 10.9.29 item 1: class_commercial_policy last-known-good. Real WFCA_Util, stubbed WP/Airtable/Alerts.
define('ABSPATH', __DIR__.'/');
$GLOBALS['opts']=[];
foreach (['wp_strip_all_tags','sanitize_email','is_email','apply_filters','wp_json_encode','home_url','esc_url_raw'] as $fn) { if(!function_exists($fn)) { eval('function '.$fn.'(...$a){return $a[0]??"";}'); } }
function get_option($k,$d=false){return $GLOBALS['opts'][$k]??$d;}
function update_option($k,$v,$a=null){$GLOBALS['opts'][$k]=$v;return true;}
final class WFCA_Alerts { public static $raised=[]; public static $resolved=[]; public static function raise(...$a){self::$raised[]=$a;return 1;} public static function resolve_source($k){self::$resolved[]=$k;} }
final class WFCA_Airtable { public static $cfg=[]; public static function config(bool $f=false): array {return self::$cfg;} }
require_once __DIR__.'/../includes/class-wfca-util.php';
$pass=0;$fail=0;function t($n,$c){global $pass,$fail;if($c){echo "PASS $n\n";$pass++;}else{echo "FAIL $n\n";$fail++;}}
function day($proactive=true,$spacing=300){return ['proactive'=>$proactive,'windows'=>$proactive?['08:00-18:00']:[],'spacing_seconds'=>$spacing];}
function pol($spacing=300){$d=[];foreach(['mon','tue','wed','thu','fri','sat','sun'] as $k)$d[$k]=day(true,$spacing);return json_encode(['version'=>'COMMERCIAL_CLASS_SCHEDULE_V1','timezone'=>'America/Sao_Paulo','days'=>$d]);}
function reset_all(){$GLOBALS['opts']=[];WFCA_Alerts::$raised=[];WFCA_Alerts::$resolved=[];WFCA_Airtable::$cfg=[];}
$K='COMMERCIAL_D0_WEEKLY_SCHEDULE_V1';
$monday=new DateTimeImmutable('2026-10-12 11:00:00',new DateTimeZone('UTC')); // 08:00 BRT

reset_all();
$cfg=[$K=>pol(300)];
$p=WFCA_Util::class_commercial_policy($cfg,'TEMPLATE_INITIAL',$monday);
t('valid policy passes through unchanged and is remembered as last-known-good',!empty($p['valid'])&&empty($p['lkg'])&&!empty(get_option('wfca_policy_lkg_v1')[$K]['raw']));
t('no alert, no episode while valid',!WFCA_Alerts::$raised&&!get_option('wfca_policy_state_v1'));

// the policy gets edited by hand and breaks
$bad=[$K=>'{"version":"COMMERCIAL_CLASS_SCHEDULE_V1","days":'];
$p=WFCA_Util::class_commercial_policy($bad,'TEMPLATE_INITIAL',$monday);
t('INVALID NOW: previous policy keeps D0 alive (valid, proactive, same window, flagged lkg)',!empty($p['valid'])&&!empty($p['proactive'])&&$p['windows']==='08:00-18:00 America/Sao_Paulo'&&$p['lkg']===true&&$p['error_current']==='CLASS_POLICY_INVALID');
t('exactly one CRITICAL alert for the episode, naming the key',count(WFCA_Alerts::$raised)===1&&WFCA_Alerts::$raised[0][1]==='CRITICAL'&&str_contains((string)WFCA_Alerts::$raised[0][0],'POLICY_INVALID:'.$K));
$st=get_option('wfca_policy_state_v1');
t('reason + source recorded for health_v1 (error, source, lkg flag)',$st[$K]['error']==='CLASS_POLICY_INVALID'&&$st[$K]['source']===$K&&$st[$K]['lkg']===true);
for($i=0;$i<5;$i++) WFCA_Util::class_commercial_policy($bad,'TEMPLATE_INITIAL',$monday);
t('repeated calls (outbox, scheduler, REST) do not re-alert',count(WFCA_Alerts::$raised)===1);
t('the follow-up class is unaffected (own key)',!empty(WFCA_Util::class_commercial_policy([$K=>pol(),'COMMERCIAL_FOLLOWUP_WEEKLY_SCHEDULE_V1'=>pol(300)],'FOLLOWUP',$monday)['valid']));

// LKG expiry (N hours since it was last seen valid)
$o=$GLOBALS['opts'];$GLOBALS['opts']['wfca_policy_lkg_v1'][$K]['seen']=time()-49*3600;
$p=WFCA_Util::class_commercial_policy($bad,'TEMPLATE_INITIAL',$monday);
t('after policy_lkg_max_hours (48 h default) the stop is back (fail closed), the state says so and a 2nd CRITICAL announces the expiry',empty($p['valid'])&&get_option('wfca_policy_state_v1')[$K]['lkg']===false&&count(WFCA_Alerts::$raised)===2&&str_contains((string)WFCA_Alerts::$raised[1][0],'POLICY_LKG_EXPIRED'));
WFCA_Util::class_commercial_policy($bad,'TEMPLATE_INITIAL',$monday);
t('the expiry alert is not repeated',count(WFCA_Alerts::$raised)===2);
t('the 49 h-old LKG is still used with a longer rule (policy_lkg_max_hours=72)',(function() use($K,$bad,$monday){WFCA_Airtable::$cfg=['WFCA_RULES_V1'=>'{"policy_lkg_max_hours":72}'];$r=!empty(WFCA_Util::class_commercial_policy($bad,'TEMPLATE_INITIAL',$monday)['valid']);WFCA_Airtable::$cfg=[];return $r;})());
$GLOBALS['opts']=$o;

// recovery
$p=WFCA_Util::class_commercial_policy([$K=>pol(300)],'TEMPLATE_INITIAL',$monday);
t('fixed policy ends the episode and resolves the alert',!empty($p['valid'])&&empty($p['lkg'])&&!get_option('wfca_policy_state_v1')&&count(WFCA_Alerts::$resolved)===1&&str_starts_with(WFCA_Alerts::$resolved[0],'policy-invalid:'.$K));
WFCA_Util::class_commercial_policy($bad,'TEMPLATE_INITIAL',$monday);
t('a NEW episode alerts again',count(WFCA_Alerts::$raised)===3);

// no LKG
reset_all();
$p=WFCA_Util::class_commercial_policy($bad,'TEMPLATE_INITIAL',$monday);
t('no last-known-good: still fails closed (as in 10.9.28) but now alerts CRITICAL once and records the reason',empty($p['valid'])&&count(WFCA_Alerts::$raised)===1&&str_contains(WFCA_Alerts::$raised[0][5],'STOPPED')&&get_option('wfca_policy_state_v1')[$K]['lkg']===false);

// LKG must itself be valid: a invalid cfg never becomes LKG
reset_all();
WFCA_Util::class_commercial_policy([$K=>'{"nope":1}'],'TEMPLATE_INITIAL',$monday);
t('an invalid policy is never stored as last-known-good',!get_option('wfca_policy_lkg_v1'));

// switch off
reset_all();WFCA_Util::class_commercial_policy([$K=>pol()],'TEMPLATE_INITIAL',$monday);
WFCA_Airtable::$cfg=['WFCA_RULES_V1'=>'{"policy_lkg_enabled":false}'];
$p=WFCA_Util::class_commercial_policy($bad,'TEMPLATE_INITIAL',$monday);
t('policy_lkg_enabled=false in WFCA_RULES_V1 restores the 10.9.28 behaviour (invalid)',empty($p['valid']));

// spacing floor still enforced on the LKG (it is re-evaluated, not trusted blindly)
reset_all();
$p=WFCA_Util::class_commercial_policy([$K=>pol(240)],'TEMPLATE_INITIAL',$monday);
t('D0 floor 240 s still honoured by a valid policy',!empty($p['valid'])&&$p['spacing_seconds']===240);
// weekly policy (no class key) uses its own LKG
reset_all();
$wk=json_encode(['version'=>'COMMERCIAL_WEEKLY_SCHEDULE_V1','timezone'=>'America/Sao_Paulo','days'=>array_fill_keys(['mon','tue','wed','thu','fri','sat','sun'],day(true,600))]);
$p=WFCA_Util::class_commercial_policy(['COMMERCIAL_WEEKLY_SCHEDULE_V1'=>$wk],'TEMPLATE_INITIAL',$monday);
$p2=WFCA_Util::class_commercial_policy(['COMMERCIAL_WEEKLY_SCHEDULE_V1'=>'garbage'],'TEMPLATE_INITIAL',$monday);
t('weekly-policy fallback path is covered too',!empty($p['valid'])&&!empty($p2['valid'])&&$p2['lkg']===true);
// legacy fallback unaffected
reset_all();$p=WFCA_Util::class_commercial_policy([],'TEMPLATE_INITIAL',$monday);
t('absent policy => legacy fallback exactly as before (no state written)',!empty($p['valid'])&&$p['source']==='LEGACY_FALLBACK'&&!get_option('wfca_policy_state_v1')&&!get_option('wfca_policy_lkg_v1'));
t('rules defaults exist and are clamped',(function(){WFCA_Airtable::$cfg=['WFCA_RULES_V1'=>'{"policy_lkg_max_hours":9999,"stall_alert_after_seconds":1}'];$r=WFCA_Util::rules();WFCA_Airtable::$cfg=[];return $r['policy_lkg_max_hours']===168&&$r['stall_alert_after_seconds']===300&&WFCA_Util::rules()['policy_lkg_max_hours']===48;})());
echo "TOTAL PASS=$pass FAIL=$fail\n";exit($fail?1:0);
