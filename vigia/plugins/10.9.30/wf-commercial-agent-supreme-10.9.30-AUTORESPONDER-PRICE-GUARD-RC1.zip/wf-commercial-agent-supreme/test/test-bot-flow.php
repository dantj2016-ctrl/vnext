<?php
define('ABSPATH', __DIR__.'/');
define('MINUTE_IN_SECONDS',60);
define('DAY_IN_SECONDS',86400);

// Minimal WP shims needed by the utility class when invoked.
function sanitize_email($x){return $x;} function is_email($x){return false;} function get_option($k,$d=null){return $d;} function wp_strip_all_tags($x){return strip_tags($x);}

require_once __DIR__.'/../includes/class-wfca-util.php';

final class WFCA_Airtable {
  public static function lead_is_commercial_ready(array $lead): bool {return true;}
  public static function mode(): string {return 'LIVE';}
  public static function update_commercial_by_phone(...$a): array {return ['ok'=>true];}
}
final class WFCA_Ownership {
  public static function queue_status(): string {return 'PENDING';}
  public static function fence(...$a): array {return ['ok'=>true];}
  public static function change(...$a): array {return ['ok'=>true];}
  public static function sync(...$a): void {}
}
final class WFCA_Alerts {public static function raise(...$a): void {}}
final class WFCA_DB {
  public static array $queued=[];
  public static array $byKey=[];
  public static array $conv=[];
  public static function get_conversation($id){return self::$conv ?: null;}
  public static function get_outbox_by_idempotency_key($k){return self::$byKey[$k]??null;}
  public static function queue($item){self::$queued[]=$item;self::$byKey[$item['idempotency_key']]=$item;return count(self::$queued);}
  public static function upsert_conversation($phone,$fields){self::$conv=array_merge(self::$conv?:['id'=>1,'phone_e164'=>$phone,'owner_revision'=>1,'initial_arm'=>'LUNA_COLD_WHATSAPP','conversation_owner'=>'LUNA','human_hold'=>0,'opt_out'=>0],$fields);return self::$conv;}
}

require_once __DIR__.'/../includes/class-wfca-engine.php';

$pass=0;$fail=0;
function t($name,$cond){global $pass,$fail;if($cond){echo "PASS $name\n";$pass++;}else{echo "FAIL $name\n";$fail++;}}
function priv($name){$r=new ReflectionMethod('WFCA_Engine',$name);$r->setAccessible(true);return $r;}

$auto=priv('is_likely_autoresponder');
$luana='Olá! Espero que você esteja bem! Obrigada por entrar em contato com o consultório. Assim que possível, retornaremos a sua mensagem.';
t('Luana clinic message classified as autoresponder',$auto->invoke(null,$luana)===true);
t('human site question not misclassified',$auto->invoke(null,'Oi, vi o site. Quanto custa para colocar no ar?')===false);

// 10.9.13: real EMPTY_MODEL_REPLY greeters that 10.9.12 failed to classify (identifiers removed).
$greeters=[
 'away message'=>'Agradecemos sua mensagem. Não estamos disponíveis no momento, mas responderemos assim que possível.',
 'team greeter'=>'Olá! Seja muito bem-vinda(o) 💎 Que bom ter você por aqui! Sou da equipe da Dra. e vou te ajudar. Me conta o que mais te incomoda hoje na sua face?',
 'secretary opener'=>'Olá! Como vai? Ficamos felizes em receber o seu contato. Meu nome é Juliana, sou secretária da Clínica e estarei responsável pelo seu atendimento hoje. *Poderia me informar como eu posso estar te ajudando hoje?*',
 'welcome + triage'=>'Olá! 😊 Seja muito bem-vindo à Yoshida Estética! Eu sou a Fernanda. Que bom receber sua mensagem por aqui. 💙 Me conta, como posso te ajudar? Você já sabe qual procedimento está procurando?',
];
foreach($greeters as $label=>$msg) t('autoresponder variant detected: '.$label,$auto->invoke(null,$msg)===true);
$humans=[
 'price'=>'Quanto custa?','no interest'=>'Não tenho interesse, obrigada.','more info'=>'Pode me mandar mais informações?',
 'who are you'=>'Boa tarde! Quem é você?','payment'=>'Gostei do site, como funciona o pagamento?',
 'doctor'=>'Oi, sou a Dra. Ana. Quem te passou meu contato?','call'=>'Pode ligar amanhã às 10h?',
 'thanks'=>'Obrigada pelo site! Vou ver com meu sócio e retorno.','forward'=>'Sou a secretária, vou encaminhar para a doutora.',
 'meeting'=>'Quero marcar uma call para entender melhor.','joke'=>'Como posso te ajudar? kkk achei interessante o site',
 'bem-vindo'=>'Muito bem-vindo ao mundo digital, rs. Me manda o valor.',
];
foreach($humans as $label=>$msg) t('human reply not misclassified: '.$label,$auto->invoke(null,$msg)===false);

// 10.9.13 red-team: a hard stop / clear rejection must never be swallowed as an autoresponder,
// even when it also contains a greeter phrase (the autoresponder branch returns before opt-out handling).
$hardstops=[
 'opt-out + greeter'=>'Agradecemos sua mensagem, mas pare de me mandar mensagens.',
 'opt-out old phrase'=>'Obrigada por entrar em contato. Não me chame mais, por favor.',
 'rejection + greeter'=>'Obrigado pelo contato. Não temos interesse.',
 'rejection variant'=>'Seja muito bem-vindo ao nosso canal, mas sem interesse no site.',
 'stop keyword'=>'Agradecemos sua mensagem. STOP',
 'no purchase'=>'Agradecemos sua mensagem, mas não quero contratar nada.',
 'pare de me enviar'=>'Agradecemos sua mensagem, pare de me enviar mensagens.',
 'nao me mande'=>'Obrigada pelo contato. Não me mande mais nada.',
 'parem de ligar'=>'Seja muito bem-vindo ao canal, mas parem de nos ligar.',
 'descadastrar'=>'Agradecemos sua mensagem. Favor descadastrar este número.',
 'sair da lista'=>'Obrigado pelo contato, quero sair da lista.',
];
foreach($hardstops as $label=>$msg) t('hard stop never swallowed as autoresponder: '.$label,$auto->invoke(null,$msg)===false);

// 10.9.13 red-team: direct human commercial intent must reach deterministic_decision(), not be dropped as noise.
$intents=[
 'buy + thanks'=>'Obrigado pelo contato! Quero fechar, manda o pagamento.',
 'price + away phrase'=>'Agradecemos sua mensagem. Quanto custa?',
 'call + welcome'=>'Seja muito bem-vinda a conversa. Quero marcar uma call com o Daniel.',
 'daniel'=>'Obrigada por entrar em contato. Posso falar com o Daniel?',
 'checkout'=>'Agradecemos sua mensagem, pode mandar o checkout?',
];
foreach($intents as $label=>$msg) t('direct commercial intent not swallowed: '.$label,$auto->invoke(null,$msg)===false);
// ...and the greeters themselves must still be detected after the guards (no over-correction).
foreach($greeters as $label=>$msg) t('still detected after guards: '.$label,$auto->invoke(null,$msg)===true);

$conv=['id'=>1,'phone_e164'=>'+5511999999999','owner_revision'=>1,'initial_arm'=>'LUNA_COLD_WHATSAPP','conversation_owner'=>'LUNA','human_hold'=>0,'opt_out'=>0,'service_window_until'=>gmdate('Y-m-d H:i:s',time()+86400),'last_inbound_at'=>gmdate('Y-m-d H:i:s',time())];
WFCA_DB::$conv=$conv;
$lead=['id'=>'recLEAD123','fields'=>['Lead'=>'Clínica Exemplo','Build Status'=>'BUILT','Factory State'=>'FACTORY_COMPLETE','Public Smoke Status'=>'PASS','Site URL'=>'https://auracorp.online/exemplo/']];
$sched=priv('schedule_autoresponder_followup');
$sched->invoke(null,$conv,$lead);
t('one delayed gatekeeper row queued',count(WFCA_DB::$queued)===1 && WFCA_DB::$queued[0]['action_type']==='AUTO_REPLY_GATEKEEPER');
$row=WFCA_DB::$queued[0]??[];
$due=strtotime(($row['scheduled_action_at']??'').' UTC');
t('gatekeeper delayed about 30 minutes',$due>=time()+1770 && $due<=time()+1830);
t('gatekeeper asks an easy routing question',str_contains((string)($row['body']??''),'quem cuida do site/marketing'));
$sched->invoke(null,$conv,$lead);
t('gatekeeper lifetime idempotency prevents duplicate',count(WFCA_DB::$queued)===1);

// Model/policy handoff with no explicit message must not queue generic HANDOFF_ACK.
WFCA_DB::$queued=[]; WFCA_DB::$byKey=[]; WFCA_DB::$conv=$conv;
$apply=priv('apply_decision');
$event=['phone_e164'=>$conv['phone_e164'],'provider_message_id'=>'wamid-test','id'=>99,'body'=>'mensagem ambígua'];
$apply->invoke(null,['action'=>'HANDOFF','message'=>'','reason'=>'EMPTY_MODEL_REPLY'],$lead,$conv,$event);
t('empty model handoff stays silent',count(WFCA_DB::$queued)===0);

// Explicit deterministic Daniel handoff keeps its specific acknowledgement.
WFCA_DB::$queued=[]; WFCA_DB::$byKey=[]; WFCA_DB::$conv=$conv;
$apply->invoke(null,['action'=>'HANDOFF','message'=>'Claro. Vou chamar o Daniel e deixar o contexto certinho pra ele te responder por aqui.','reason'=>'DANIEL_PERSONAL_TOUCH'],$lead,$conv,$event);
t('explicit Daniel handoff still queues specific ack',count(WFCA_DB::$queued)===1 && WFCA_DB::$queued[0]['action_type']==='HANDOFF_ACK' && str_contains(WFCA_DB::$queued[0]['body'],'chamar o Daniel'));

exit($fail?1:0);
