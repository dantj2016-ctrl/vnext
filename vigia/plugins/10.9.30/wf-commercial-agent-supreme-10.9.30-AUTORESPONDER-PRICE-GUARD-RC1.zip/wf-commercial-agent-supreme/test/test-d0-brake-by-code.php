<?php
// 10.9.27: the D0 delivery brake ignores recipient-side Meta codes (130472 experiment, 131026 undeliverable); quality codes still brake.
define('ABSPATH', __DIR__.'/');
define('ARRAY_A','ARRAY_A');
$GLOBALS['opts']=[];
foreach (['wp_strip_all_tags','sanitize_email','is_email','apply_filters','wp_json_encode','home_url','esc_url_raw'] as $fn) { if(!function_exists($fn)) { eval('function '.$fn.'(...$a){return $a[0]??"";}'); } }
function get_option($k,$d=false){return $GLOBALS['opts'][$k]??$d;}
function update_option($k,$v,$a=null){$GLOBALS['opts'][$k]=$v;return true;}
final class WFCA_DB { public static function t($n){return 'wp_wfca_'.$n;} }
final class WFCA_Alerts { public static $raised=[]; public static function raise(...$a){self::$raised[]=$a;return 1;} }
final class WFCA_Ownership { public static function arm(string $a): string {return $a;} public static function remote_arm(string $a): string {return $a;} }
final class WFCA_Airtable { public static $cfg=[]; public static function config(bool $f=false): array {return self::$cfg;} }
final class FakeWpdb { public $rows=[]; public $lastSql=''; public function prepare($q,...$a){$this->lastSql=$q;return $q;} public function get_results($q,$t=null){return $this->rows;} }
$wpdb=new FakeWpdb();
require_once __DIR__.'/../includes/class-wfca-util.php';
require_once __DIR__.'/../includes/class-wfca-engine.php';
$pass=0;$fail=0;function t($n,$c){global $pass,$fail;if($c){echo "PASS $n\n";$pass++;}else{echo "FAIL $n\n";$fail++;}}
$m=(new ReflectionClass('WFCA_Engine'))->getMethod('d0_delivery_brake_active');$m->setAccessible(true);
$IGN=['130472','131026'];
$rules=['d0_delivery_brake_enabled'=>true,'d0_delivery_brake_failure_ratio'=>0.30,'d0_delivery_brake_ignore_codes'=>$IGN];
$B49='WA_ERR code=131049 title=This message was not delivered to maintain healthy ecosystem engagement. msg=x details=y';
$B26='WA_ERR code=131026 title=Message undeliverable msg=Message undeliverable details=Message Undeliverable.';
$B72="WA_ERR code=130472 title=User's number is part of an experiment msg=x details=y";
function D(){return ['delivery_status'=>'delivered','fail_body'=>null];}
function F($b){return ['delivery_status'=>'failed','fail_body'=>$b];}
function reset_brake(){$GLOBALS['opts']=[];WFCA_Alerts::$raised=[];}
// real incident 2026-10-10 13:39Z: 6 resolved, 3 failed (131049, 131026, 130472): old rule braked (50%), only 1 failure is a quality signal
reset_brake();$wpdb->rows=[D(),F($B49),F($B26),D(),F($B72),D()];
t('real incident sample (1 quality + 2 recipient-side failures of 6) does NOT brake',$m->invoke(null,$rules)===false&&count(WFCA_Alerts::$raised)===0);
reset_brake();$wpdb->rows=[D(),F($B49),F($B26),D(),F($B72),D()];
t('same sample with ignore list [] reproduces the old brake (rollback by Config)',$m->invoke(null,['d0_delivery_brake_enabled'=>true,'d0_delivery_brake_failure_ratio'=>0.30,'d0_delivery_brake_ignore_codes'=>[]])===true);
reset_brake();$wpdb->rows=[D(),D(),D(),F($B49),F($B49),F($B49)];
t('3 of 6 quality failures (131049) still brake',$m->invoke(null,$rules)===true&&count(WFCA_Alerts::$raised)===1);
reset_brake();$wpdb->rows=[D(),D(),D(),D(),D(),D(),F($B49),F($B49),F($B49),F($B26)];
$r=$m->invoke(null,$rules);
t('ignored rows are left out of both sides: 3/9 quality failures brake and the alert names the ignored one',$r===true&&str_contains((string)WFCA_Alerts::$raised[0][0],'3/9_FAILED')&&str_contains((string)WFCA_Alerts::$raised[0][0],'+1_RECIPIENT_SIDE_IGNORED'));
reset_brake();$wpdb->rows=[D(),D(),D(),D(),D(),D(),F($B49),F($B26),F($B72),F($B26)];
t('many recipient-side failures with only 1 quality failure of 7 resolved do not brake',$m->invoke(null,$rules)===false);
reset_brake();$wpdb->rows=[D(),D(),D(),F(''),F(''),F('')];
t('legacy failed rows without a stored code still count as failures (fail closed)',$m->invoke(null,$rules)===true);
reset_brake();$wpdb->rows=[D(),D(),D(),F('WA_ERR NO_DETAIL m_keys=id k_keys=origin'),F('WA_ERR NO_DETAIL x'),F('WA_ERR NO_DETAIL y')];
t('NO_DETAIL failures count as failures',$m->invoke(null,$rules)===true);
reset_brake();$wpdb->rows=[D(),D(),D(),F('WA_ERR code=1304720 title=x'),F('WA_ERR code=1304720 title=x'),F('WA_ERR code=1304720 title=x')];
t('a longer code that merely starts like an ignored one is NOT ignored',$m->invoke(null,$rules)===true);
reset_brake();$wpdb->rows=[D(),D(),D(),D(),D(),F($B49)];
t('1 quality failure of 6 does not brake (unchanged)',$m->invoke(null,$rules)===false);
reset_brake();$wpdb->rows=[['delivery_status'=>'delivered'],['delivery_status'=>'delivered'],['delivery_status'=>'delivered'],['delivery_status'=>'failed'],['delivery_status'=>'failed'],['delivery_status'=>'failed']];
t('rows from a query without fail_body (old shape) behave exactly as in 10.9.26',$m->invoke(null,$rules)===true);
reset_brake();$wpdb->rows=[D(),F($B26),F($B26),F($B26),F($B72),F($B72)];
t('only recipient-side failures: resolved 1 < 6, never brakes',$m->invoke(null,$rules)===false);
reset_brake();$wpdb->rows=[D(),D(),D(),F($B49),F($B49),F($B49)];$m->invoke(null,$rules);
t('while paused it stays paused without re-alerting',$m->invoke(null,$rules)===true&&count(WFCA_Alerts::$raised)===1);
reset_brake();$wpdb->rows=[D(),D(),D(),F($B49),F($B49),F($B49)];
t('brake can still be switched off by rules',$m->invoke(null,['d0_delivery_brake_enabled'=>false,'d0_delivery_brake_failure_ratio'=>0.3,'d0_delivery_brake_ignore_codes'=>$IGN])===false);
// SQL shape: only failed rows pay for the event lookup, indexed by provider_message_id, only DELIVERY_FAILED events
reset_brake();$wpdb->rows=[];$m->invoke(null,$rules);
t('query reads the failure body from the events table for failed rows only',str_contains($wpdb->lastSql,"o.delivery_status='failed'")&&str_contains($wpdb->lastSql,'wp_wfca_events')&&str_contains($wpdb->lastSql,"e.event_type='DELIVERY_FAILED'")&&str_contains($wpdb->lastSql,'e.provider_message_id=o.provider_message_id'));
t('query still limits to the last 10 D0 after the last release',str_contains($wpdb->lastSql,"action_type='TEMPLATE_INITIAL'")&&str_contains($wpdb->lastSql,'LIMIT 10')&&str_contains($wpdb->lastSql,'sent_at>'));
// rules(): default and Airtable override
WFCA_Airtable::$cfg=[];
t('default rules ignore 130472 and 131026',WFCA_Util::rules()['d0_delivery_brake_ignore_codes']===['130472','131026']);
WFCA_Airtable::$cfg=['WFCA_RULES_V1'=>'{"d0_delivery_brake_ignore_codes":[]}'];
t('Config can clear the ignore list (full rollback)',WFCA_Util::rules()['d0_delivery_brake_ignore_codes']===[]);
WFCA_Airtable::$cfg=['WFCA_RULES_V1'=>'{"d0_delivery_brake_ignore_codes":["131026","abc","12","131026",{"x":1},"9999999999"]}'];
t('Config values are validated (digits 3-8, unique, scalar)',WFCA_Util::rules()['d0_delivery_brake_ignore_codes']===['131026']);
WFCA_Airtable::$cfg=['WFCA_RULES_V1'=>'{"d0_delivery_brake_ignore_codes":"130472"}'];
t('a non-array value is ignored and the default stays',WFCA_Util::rules()['d0_delivery_brake_ignore_codes']===['130472','131026']);
WFCA_Airtable::$cfg=['WFCA_RULES_V1'=>'{"d0_delivery_brake_failure_ratio":0.4}'];
t('other rules keys keep working and ignore list stays default',WFCA_Util::rules()['d0_delivery_brake_failure_ratio']===0.4&&WFCA_Util::rules()['d0_delivery_brake_ignore_codes']===['130472','131026']);
// helper
t('code digits parser reads the provider code',WFCA_Util::delivery_fail_code_digits($B49)==='131049'&&WFCA_Util::delivery_fail_code_digits($B72)==='130472');
t('code digits parser returns empty for NO_DETAIL, empty and garbage',WFCA_Util::delivery_fail_code_digits('WA_ERR NO_DETAIL m_keys=a')===''&&WFCA_Util::delivery_fail_code_digits('')===''&&WFCA_Util::delivery_fail_code_digits('hello WA_ERR code=131049')==='');
// the counters stay diagnostic only: the brake never reads them
$src=file_get_contents(__DIR__.'/../includes/class-wfca-engine.php');
t('brake does not read the diagnostic counters option',!preg_match('/d0_delivery_brake_active.*?wfca_delivery_fail_counters/s',substr($src,strpos($src,'function d0_delivery_brake_active'),2500)));
t('scheduler still applies the brake before reserving a D0',str_contains($src,'if (self::d0_delivery_brake_active($rules)) return;'));
echo "TOTAL PASS=$pass FAIL=$fail\n";exit($fail?1:0);
