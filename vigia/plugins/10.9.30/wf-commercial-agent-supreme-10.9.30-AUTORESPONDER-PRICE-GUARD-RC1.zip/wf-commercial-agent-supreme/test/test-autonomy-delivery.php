<?php
define('ABSPATH', __DIR__.'/');
function wp_strip_all_tags($x){return strip_tags((string)$x);}
final class WFCA_Util {
    public static function short_text(string $text,int $max=1200): string {
        $text=preg_replace('/\s+/u',' ',strip_tags($text));$text=trim((string)$text);
        return function_exists('mb_substr')?mb_substr($text,0,$max,'UTF-8'):substr($text,0,$max);
    }
}
require_once __DIR__.'/../includes/class-wfca-engine.php';
$pass=0;$fail=0; function t($n,$c){global $pass,$fail;if($c){echo "PASS $n\n";$pass++;}else{echo "FAIL $n\n";$fail++;}}
$ref=new ReflectionClass('WFCA_Engine');
$obs=$ref->getMethod('commercial_observation');$obs->setAccessible(true);
$fu=$ref->getMethod('commercial_followup_insight');$fu->setAccessible(true);
$lead=['fields'=>['Observação Específica'=>'CERTIFICATION_CANDIDATE_V1 | CLOUDFLARE_SUPPLY_V1 | run=WF-X | gap_codes=A,B | improvement_thesis=Reestruturar o site em torno da Dra. Taís Rodrigues como autoridade principal, com páginas individuais para tratamentos prioritários e jornada mais clara.']];
$o=$obs->invoke(null,$lead);
t('technical observation extracts human improvement thesis',str_starts_with($o,'Reestruturar o site') && !str_contains($o,'CERTIFICATION_') && strlen($o)<=260);
$lead2=['fields'=>['Observação Específica'=>'a organização dos procedimentos e a clareza da jornada até o agendamento']];
t('already-commercial observation preserved',$obs->invoke(null,$lead2)==='a organização dos procedimentos e a clareza da jornada até o agendamento');
$lead3=['fields'=>['Observação Específica'=>'CERTIFICATION_CANDIDATE_V1 | run=WF-X | gap_codes=A']];
t('technical telemetry without safe thesis fails closed',$obs->invoke(null,$lead3)==='');
$eliza=['fields'=>['Observação Específica'=>'SERVIÇOS VERIFICADOS: Dermatologia e Cosmiatria; VNEXT_BUILDABILITY_CERTIFIED_V2_EXT | run=WF-VNEXT-ADMISSION-20260930222522-8D561428 | Um novo site poderia preservar a autoridade da Dra. Eliza Minami e reorganizar a oferta em jornadas claras de cirurgia plástica, dermatologia, cosmiatria e la…']];
$eliza_obs=$obs->invoke(null,$eliza);
t('current Eliza telemetry tail becomes bounded commercial observation',str_starts_with($eliza_obs,'Um novo site poderia preservar a autoridade') && !str_contains($eliza_obs,'VNEXT_') && strlen($eliza_obs)<=220);
$daya=['fields'=>['Observação Específica'=>'SERVIÇOS VERIFICADOS: Dermatologia clínica; V2_EXT_MEDIA_SOURCE: https://clinicadaya.com.br/dermatologistas/index.php | VNEXT_BUILDABILITY_CERTIFIED_V2_EXT | run=WF-VNEXT-ADMISSION-20260930004551-43B4C77B | Um novo site poderia organizar a jornada por queixa, indicação, região e perfil profissional, conectar cada tratamento a uma avaliação e apresentar CTAs de agendamento persistentes, reduzindo a dependência de o paciente entender previamente qual tecnologia escolher.']];
$daya_obs=$obs->invoke(null,$daya);
t('current Daya telemetry tail is bounded at a grounded clause',str_starts_with($daya_obs,'Um novo site poderia organizar a jornada') && substr($daya_obs,-1)==='.' && strlen($daya_obs)<=220 && !str_contains($daya_obs,'VNEXT_'));
t('followup insight never falls back to observation',$fu->invoke(null,$lead2)==='');
$lead4=['fields'=>['Observação Específica'=>'obs base','Follow-up Insight'=>'insight dedicado']];
t('dedicated followup insight wins',$fu->invoke(null,$lead4)==='insight dedicado');
$engine=file_get_contents(__DIR__.'/../includes/class-wfca-engine.php');
$air=file_get_contents(__DIR__.'/../includes/class-wfca-airtable.php');
t('tick invokes native due materializer',str_contains($engine,'self::materialize_due_d0_followup(1);'));
t('native materializer uses waiting candidate source',str_contains($engine,'WFCA_Airtable::waiting_followup_candidates(100'));
t('native materializer preserves lifetime followup key',str_contains($engine,"hash('sha256','FOLLOWUP|D0_1|'"));
t('native materializer persists safe insight before scheduling',str_contains($engine,'self::materialize_safe_followup_insight($lead)') && str_contains($engine,'Persist first, schedule only on a later tick'));
t('followup delay supports 10 minutes',str_contains($engine,'if ($delay<10 || $delay>10080)'));
t('waiting followup query is LUNA WAITING_REPLY',str_contains($air,"{Conversation Owner}='LUNA'") && str_contains($air,"{State}='WAITING_REPLY'"));
t('delivery truth distinguishes delivered/read',str_contains($engine,"['delivered','read']"));
t('accepted followup summary says delivery pending',str_contains($engine,'accepted by provider; recipient delivery pending'));
echo "TOTAL PASS=$pass FAIL=$fail\n";exit($fail?1:0);
