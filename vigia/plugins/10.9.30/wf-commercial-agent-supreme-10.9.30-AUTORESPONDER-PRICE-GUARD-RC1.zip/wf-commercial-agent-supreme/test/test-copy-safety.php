<?php
define('ABSPATH', __DIR__.'/');
function wp_strip_all_tags($x){return strip_tags((string)$x);} 
final class WFCA_Util {
    public static function short_text(string $text,int $max=1200): string {
        $text=preg_replace('/\s+/u',' ',strip_tags($text));$text=trim((string)$text);
        return function_exists('mb_substr')?mb_substr($text,0,$max,'UTF-8'):substr($text,0,$max);
    }
    public static function lower(string $text): string {return function_exists('mb_strtolower')?mb_strtolower($text,'UTF-8'):strtolower($text);}
}
require_once __DIR__.'/../includes/class-wfca-engine.php';
$pass=0;$fail=0;
function t($name,$cond){global $pass,$fail;if($cond){echo "PASS $name\n";$pass++;}else{echo "FAIL $name\n";$fail++;}}
$ref=new ReflectionClass('WFCA_Engine');
$get=function($name) use($ref){$m=$ref->getMethod($name);$m->setAccessible(true);return $m;};
$obs=$get('commercial_observation');
$fu=$get('commercial_followup_insight');
$name=$get('commercial_display_name');
$clip=$get('prospect_sentence_text');
$tech=$get('commercial_text_is_technical');
$build=$get('build_safe_followup_insight');

$gm=['fields'=>[
  'Lead'=>'GM Beauty Clinic — Campinas','Cidade'=>'Campinas','Especialidade / Posicionamento'=>'Estética Avançada',
  'Observação Específica'=>'LEAD_INTELLIGENCE_V4_EXTERNAL_FEEDER | verified=2026-09-17 | discovery=ChatGPT local_business+web | LEAD_OPPORTUNITY_CLASS=BUILD_PRIORITY | BUILDABLE_OPPORTUNITY_PREFILTER_V1=PASS | economic plausibility=private clinic | FINAL DEDUPE ok',
  'Follow-up Insight'=>'Outro ponto concreto: a GM Beauty já aparece com agenda e serviços ativos no Trinks, além do Linktree/Instagram. Um site próprio pode reunir essa oferta num único caminho de descoberta e agendamento, em vez de espalhar a jornada entre plataformas.'
]];
$ellen=['fields'=>[
  'Lead'=>'Dra. Ellen Andrade — Harmonização Facial','Cidade'=>'Campinas','Especialidade / Posicionamento'=>'Harmonização Facial; Estética Avançada',
  'Observação Específica'=>'CURRENT feeder proof 2026-09-16: exact Google Business listing in Cambuí, Campinas (5.0/37, current hours including Saturday, public phone +55 19 99714-4463) plus current harmonização directory listing at the same Silva Telles 1002 address establish live/local niche fit and economic plausibility.'
]];

t('GM raw feeder telemetry recognized technical',$tech->invoke(null,$gm['fields']['Observação Específica'])===true);
t('Ellen CURRENT feeder proof recognized technical',$tech->invoke(null,$ellen['fields']['Observação Específica'])===true);
t('Ellen raw telemetry fails closed',$obs->invoke(null,$ellen)==='');
$ellenSafe=$ellen;$ellenSafe['fields']['Follow-up Insight']='A Dra. Ellen já aparece em buscas locais de harmonização em Campinas. Um site próprio pode concentrar apresentação, serviços e agendamento com mais clareza.';
t('dedicated Ellen safe insight passes',$fu->invoke(null,$ellenSafe)===$ellenSafe['fields']['Follow-up Insight']);
$gmFu=$fu->invoke(null,$gm);
t('GM redundant opener removed',!str_starts_with($gmFu,'Outro ponto concreto:'));
t('GM output is complete sentence',preg_match('/[.!?]$/u',$gmFu)===1);
t('GM output not dangling fragment',!str_ends_with($gmFu,'espalhar a'));
t('GM output within 220 chars',(function_exists('mb_strlen')?mb_strlen($gmFu,'UTF-8'):strlen($gmFu))<=220);
t('GM display name strips city metadata',$name->invoke(null,$gm)==='GM Beauty Clinic');
t('Ellen display name strips specialty metadata',$name->invoke(null,$ellen)==='Dra. Ellen Andrade');
$brand=['fields'=>['Lead'=>'Studio — Prime','Cidade'=>'Campinas','Especialidade / Posicionamento'=>'Estética Avançada']];
t('em dash CRM suffix always stripped in prospect display',$name->invoke(null,$brand)==='Studio');
$camila=['fields'=>['Lead'=>'Dra. Camila Gaia — Harmonização Facial','Cidade'=>'Campinas','Especialidade / Posicionamento'=>'Dentista com atuação em Harmonização Orofacial, atendimento privado em Campinas/Taquaral e foco em estética facial.']];
t('Camila live canary suffix stripped',$name->invoke(null,$camila)==='Dra. Camila Gaia');
$plain=['fields'=>['Observação Específica'=>'a organização dos procedimentos e a clareza da jornada até o agendamento']];
t('short human observation preserved',$obs->invoke(null,$plain)==='a organização dos procedimentos e a clareza da jornada até o agendamento');
$thesis=['fields'=>['Observação Específica'=>'CERTIFICATION_CANDIDATE_V1 | run=WF-X | improvement_thesis=Reunir serviços e agendamento em uma jornada mais clara. | gap_codes=A']];
t('grounded improvement thesis preserved',$obs->invoke(null,$thesis)==='Reunir serviços e agendamento em uma jornada mais clara.');
$longNoSentence=str_repeat('palavra ',40);
t('long text without complete sentence fails closed',$clip->invoke(null,$longNoSentence,120,false)==='');
$pref='Só queria deixar um ponto mais claro: Outro ponto concreto: A clínica tem agenda ativa e serviços bem definidos.';
t('multiple redundant opener prefixes stripped',$clip->invoke(null,$pref,220,true)==='A clínica tem agenda ativa e serviços bem definidos.');

$estima=['fields'=>['Lead'=>'Estima & Estética','Cidade'=>'Campinas','Especialidade / Posicionamento'=>'Estética Avançada','Observação Específica'=>'Operação pública em Campinas com telefone, endereço, Maps e Instagram; busca atual não encontrou site próprio forte. Perfil organizacional permite hero por logo/fachada após inspeção visual.','Follow-up Insight'=>'']];
t('Estima raw observation never becomes followup copy',$fu->invoke(null,$estima)==='');
$estimaBuilt=$build->invoke(null,$estima);
t('safe builder ignores raw technical observation',!str_contains($estimaBuilt,'Maps') && !str_contains($estimaBuilt,'hero') && !str_contains($estimaBuilt,'inspeção visual'));
t('safe builder is grounded on specialty',str_contains($estimaBuilt,'Estética Avançada'));
t('safe builder returns complete sentence',preg_match('/[.!?]$/u',$estimaBuilt)===1);

$engine=file_get_contents(__DIR__.'/../includes/class-wfca-engine.php');
t('INITIAL and FOLLOWUP lead_name use display sanitizer',substr_count($engine,'commercial_display_name($lead)')>=2);
t('no AI copy generation added',!str_contains($engine,'draft_followup('));
t('raw observation fallback removed',!str_contains($engine,'return self::commercial_observation($lead);'));
t('safe insight update is dedicated field only',str_contains($engine,"WFCA_Airtable::update_lead(\$lead_id,['Follow-up Insight'=>\$copy])"));

echo "TOTAL PASS=$pass FAIL=$fail\n";exit($fail?1:0);
