<?php
$engine=file_get_contents(__DIR__.'/../includes/class-wfca-engine.php');
$rest=file_get_contents(__DIR__.'/../includes/class-wfca-rest.php');
$main=file_get_contents(__DIR__.'/../wf-commercial-agent.php');
$pass=0;$fail=0;function t($n,$c){global $pass,$fail;if($c){echo "PASS $n\n";$pass++;}else{echo "FAIL $n\n";$fail++;}}
t('version successor preserves ladder',(bool)preg_match('/WFCA_VERSION\',\s*\'10\.9\.(1[2-9]|[2-9][0-9])-/',$main));
t('ladder config wired',str_contains($engine,'COMMERCIAL_FOLLOWUP_LADDER_POLICY_V2'));
t('FU2 idempotency key',str_contains($engine,"FOLLOWUP|D0_2|"));
t('FU3 idempotency key',str_contains($engine,"FOLLOWUP|D0_3|"));
t('FU2 D3 default',str_contains($engine,"fu2_due_from_initial_minutes']??4320"));
t('FU3 D7 default',str_contains($engine,"fu3_due_from_initial_minutes']??10080"));
t('FU2 min after FU1',str_contains($engine,"fu2_min_after_fu1_minutes']??1440"));
t('FU3 min after FU2',str_contains($engine,"fu3_min_after_fu2_minutes']??4320"));
t('stage two copy distinct',str_contains($engine,'Além da apresentação, a página já deixa uma base pronta'));
t('stage three final copy distinct',str_contains($engine,'A página continua guardada como uma base pronta'));
t('same approved template path retained',substr_count($engine,"WFCA_Kapso::template_spec('FOLLOWUP')")>=1);
t('post-send schedules next stage',str_contains($engine,'schedule_next_followup_after_followup'));
t('health advertises ladder',str_contains($rest,"'followup_ladder_d3_d7_v2'=>true"));
t('ladder validity in readiness',str_contains($rest,'$ladder_valid'));
t('no FU4 idempotency',!str_contains($engine,'FOLLOWUP|D0_4|'));
echo "TOTAL PASS=$pass FAIL=$fail\n";exit($fail?1:0);
