<?php
define('ABSPATH', __DIR__.'/');
foreach (['wp_strip_all_tags','sanitize_email','is_email','get_option','apply_filters','wp_json_encode','home_url','esc_url_raw'] as $fn) { if(!function_exists($fn)) { eval('function '.$fn.'(...$a){return $a[0]??"";}'); } }
require_once __DIR__.'/../includes/class-wfca-util.php';
$pass=0;$fail=0;function t($n,$c){global $pass,$fail;if($c){echo "PASS $n\n";$pass++;}else{echo "FAIL $n\n";$fail++;}}
t('max off when not above base',WFCA_Util::spacing_max(240,0)===0&&WFCA_Util::spacing_max(240,240)===0&&WFCA_Util::spacing_max(240,100)===0);
t('max capped at 30 min',WFCA_Util::spacing_max(240,99999)===1800);
t('valid max kept',WFCA_Util::spacing_max(240,600)===600);
$min=9999;$max=0;$sum=0;$n=2000;$buckets=array_fill(4,7,0);
for($i=0;$i<$n;$i++){$g=WFCA_Util::spread_gap(240,600,1791600000+$i*271);$min=min($min,$g);$max=max($max,$g);$sum+=$g;$buckets[(int)floor($g/60)]++;}
t('gaps never below the 240 s base',$min>=240);
t('gaps never above the 600 s max',$max<=600);
t('mean near the middle (~420 s)',abs($sum/$n-420)<25);
t('every minute bucket 4..9 is used (cadence really varies)',count(array_filter($buckets))>=6);
t('stable for the same seed',WFCA_Util::spread_gap(240,600,1791600123)===WFCA_Util::spread_gap(240,600,1791600123));
t('degenerate max returns base',WFCA_Util::spread_gap(240,0,5)===240);
$src=file_get_contents(__DIR__.'/../includes/class-wfca-engine.php');
t('engine uses spread only when spacing_max_seconds is set, else old jitter',str_contains($src,'spread_gap($interval,$spacing_max')&&str_contains($src,'jitter_up($interval'));
$u=file_get_contents(__DIR__.'/../includes/class-wfca-util.php');
t('class policy carries spacing_max_seconds for proactive days only',str_contains($u,"'spacing_max_seconds'=>self::spacing_max"));
echo "TOTAL PASS=$pass FAIL=$fail\n";exit($fail?1:0);
