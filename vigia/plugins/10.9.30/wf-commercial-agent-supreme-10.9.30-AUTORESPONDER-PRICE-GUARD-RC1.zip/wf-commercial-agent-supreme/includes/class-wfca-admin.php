<?php
if (!defined('ABSPATH')) exit;

final class WFCA_Admin {
    public static function menu(): void {
        add_management_page('WF Commercial Agent','WF Commercial Agent','manage_options','wf-commercial-agent',[__CLASS__,'page']);
    }

    public static function actions(): void {
        if (!is_admin() || !current_user_can('manage_options')) return;

        if (isset($_POST['wfca_owner_submit']) && check_admin_referer('wfca_owner','wfca_owner_nonce')) {
            $id=(int)($_POST['conversation_id']??0);
            $r=WFCA_Ownership::change($id,strtoupper((string)($_POST['owner']??'')),'EXPLICIT_ADMIN_CHANGE',(int)($_POST['expected_revision']??0),true);
            if (!empty($r['ok'])) $r['airtable_synced']=WFCA_Ownership::sync($id);
            update_option('wfca_owner_admin_result',$r,false);
            wp_safe_redirect(admin_url('tools.php?page=wf-commercial-agent'));exit;
        }
        if (isset($_POST['wfca_mode_submit']) && check_admin_referer('wfca_mode','wfca_nonce')) {
            WFCA_Util::set_local_mode((string)($_POST['wfca_local_mode']??'OFF'));
            wp_safe_redirect(admin_url('tools.php?page=wf-commercial-agent&saved=1')); exit;
        }

        if (isset($_POST['wfca_outbox_action']) && check_admin_referer('wfca_outbox','wfca_outbox_nonce')) {
            $id=(int)($_POST['outbox_id']??0);
            $act=sanitize_text_field((string)$_POST['wfca_outbox_action']);
            if ($id && $act==='approve') WFCA_DB::set_outbox_status($id,'APPROVED');
            if ($id && $act==='reject') WFCA_DB::set_outbox_status($id,'CANCELLED','REJECTED_BY_DANIEL');
            if ($id && $act==='rearm_window') update_option('wfca_outbox_admin_result',WFCA_DB::rearm_after_window($id),false);
            wp_safe_redirect(admin_url('tools.php?page=wf-commercial-agent')); exit;
        }

        if (isset($_POST['wfca_alert_action']) && check_admin_referer('wfca_alert','wfca_alert_nonce')) {
            $id=(int)($_POST['alert_id']??0);
            $act=sanitize_text_field((string)$_POST['wfca_alert_action']);
            if ($id && $act==='ack') WFCA_Alerts::acknowledge($id);
            if ($id && $act==='resolve') WFCA_Alerts::resolve($id);
            wp_safe_redirect(admin_url('tools.php?page=wf-commercial-agent')); exit;
        }

        if (isset($_POST['wfca_run_now']) && check_admin_referer('wfca_run_now','wfca_run_nonce')) {
            WFCA_Engine::tick();
            wp_safe_redirect(admin_url('tools.php?page=wf-commercial-agent&ran=1')); exit;
        }

        if (isset($_POST['wfca_refresh_integrations']) && check_admin_referer('wfca_refresh','wfca_refresh_nonce')) {
            WFCA_Airtable::clear_cache();
            WFCA_Airtable::probe(true);
            wp_safe_redirect(admin_url('tools.php?page=wf-commercial-agent&refreshed=1')); exit;
        }
    }

    public static function page(): void {
        global $wpdb;
        $mode_state=WFCA_Airtable::mode_state();
        $mode=(string)$mode_state['mode'];
        $stats=WFCA_DB::stats();
        $probe=WFCA_Airtable::probe();
        $events=$wpdb->get_results("SELECT * FROM ".WFCA_DB::t('events')." ORDER BY id DESC LIMIT 25",ARRAY_A);
        $outbox=$wpdb->get_results("SELECT * FROM ".WFCA_DB::t('outbox')." ORDER BY id DESC LIMIT 25",ARRAY_A);
        $alerts=$wpdb->get_results("SELECT * FROM ".WFCA_DB::t('alerts')." WHERE status IN ('OPEN','ACKED') ORDER BY id DESC LIMIT 40",ARRAY_A);
        $sig=WFCA_Kapso::last_signature_check();
        $ai=WFCA_OpenAI::telemetry();
        $usage=WFCA_OpenAI::usage();
        $last_tick=(string)get_option('wfca_last_tick_at','');
        $next_tick=wp_next_scheduled('wfca_minute_tick');
        $tick_stale=false;
        if ($last_tick!=='') {
            $ts=strtotime($last_tick);
            $tick_stale=$ts!==false && $ts<time()-5*MINUTE_IN_SECONDS;
        }
        ?>
        <div class="wrap">
            <h1>Website Factory — Commercial Agent v<?php echo esc_html(WFCA_VERSION); ?></h1>
            <p><strong>Local mode:</strong> <?php echo esc_html(WFCA_Util::local_mode()); ?> · <strong>Effective mode:</strong> <?php echo esc_html($mode); ?> · <strong>Base authorization:</strong> <?php echo esc_html((string)$mode_state['base_mode']); ?> · <strong>Drain:</strong> <?php echo !empty($mode_state['draining'])?'ACTIVE':'OFF'; ?></p>
            <?php $maintenance=WFCA_DB::maintenance_state(); ?>
            <p><strong>Maintenance:</strong> <code><?php echo esc_html(WFCA_Util::json($maintenance)); ?></code></p>

            <?php if($stats['alerts']>0): ?>
                <div class="notice notice-warning"><p><strong>⚠️ Daniel needed:</strong> <?php echo (int)$stats['alerts']; ?> open handoff/operational alert(s). See “Needs Daniel” below.</p></div>
            <?php endif; ?>
            <?php if($tick_stale): ?>
                <div class="notice notice-error"><p><strong>WP-Cron looks stale.</strong> Last engine tick: <?php echo esc_html($last_tick); ?> UTC.</p></div>
            <?php endif; ?>

            <form method="post" style="margin:18px 0">
                <?php wp_nonce_field('wfca_mode','wfca_nonce'); ?>
                <select name="wfca_local_mode">
                    <?php foreach(['OFF','SHADOW','ASSISTED','LIVE','DRAINING'] as $m): ?>
                        <option value="<?php echo esc_attr($m); ?>" <?php selected(WFCA_Util::local_mode(),$m); ?>><?php echo esc_html($m); ?></option>
                    <?php endforeach; ?>
                </select>
                <button class="button button-primary" name="wfca_mode_submit" value="1">Save local ceiling</button>
                <span style="margin-left:8px">Airtable <code>COMMERCIAL_AGENT_MODE</code> is the remote ceiling. <code>DRAINING</code> blocks new proactive work while inbound/sync/payment reconciliation continue.</span>
            </form>

            <div style="display:grid;grid-template-columns:repeat(6,minmax(105px,1fr));gap:10px;max-width:1100px">
                <?php foreach($stats as $k=>$v): ?>
                    <div style="background:#fff;border:1px solid #ccd0d4;padding:12px"><strong><?php echo esc_html(ucfirst($k)); ?></strong><br><?php echo esc_html((string)$v); ?></div>
                <?php endforeach; ?>
            </div>

            <h2>Conversation owner</h2>
            <p>Returning to Luna is explicit. Initial arm remains unchanged. Missing Airtable owner fields keep sending blocked.</p>
            <pre><?php echo esc_html(WFCA_Util::json(get_option('wfca_owner_admin_result',[]))); ?></pre>
            <table class="widefat striped"><thead><tr><th>Conversation</th><th>Initial arm</th><th>Owner / revision</th><th>Change owner</th></tr></thead><tbody>
            <?php foreach (($wpdb->get_results('SELECT * FROM '.WFCA_DB::t('conversations').' ORDER BY id DESC LIMIT 100',ARRAY_A)?:[]) as $c): ?>
                <tr><td><?php echo esc_html($c['phone_e164']); ?></td><td><?php echo esc_html($c['initial_arm']??''); ?></td>
                <td><?php echo esc_html($c['conversation_owner'].' / '.$c['owner_revision'].(!empty($c['owner_sync_pending'])?' (sync pending)':'')); ?></td>
                <td><form method="post"><?php wp_nonce_field('wfca_owner','wfca_owner_nonce'); ?>
                <input type="hidden" name="conversation_id" value="<?php echo (int)$c['id']; ?>">
                <input type="hidden" name="expected_revision" value="<?php echo (int)$c['owner_revision']; ?>">
                <select name="owner"><?php foreach(WFCA_Ownership::OWNERS as $o): ?><option <?php selected($c['conversation_owner'],$o); ?>><?php echo esc_html($o); ?></option><?php endforeach; ?></select>
                <button class="button" name="wfca_owner_submit" value="1">Apply explicit change</button></form></td></tr>
            <?php endforeach; ?></tbody></table>
            <h2>Integration gates</h2>
            <table class="widefat striped" style="max-width:1100px">
                <tbody>
                    <tr><td>Airtable PAT</td><td><?php echo WFCA_Airtable::available()?'✅ configured':'❌ missing'; ?> · <?php echo !empty($probe['ok'])?'✅ authenticated/reachable':'❌ not proven reachable'; ?></td></tr>
                    <tr><td>Kapso API key + phone number ID</td><td><?php echo WFCA_Kapso::ready()?'✅ configured':'❌ missing/invalid format'; ?></td></tr>
                    <tr><td>OpenAI API</td><td><?php echo WFCA_OpenAI::ready()?'✅ configured — '.esc_html(WFCA_OpenAI::model()):'⚠️ missing — deterministic branches + safe handoff'; ?></td></tr>
                    <tr><td>InfinitePay handle</td><td><?php echo WFCA_InfinitePay::ready()?'✅ configured':'⚠️ missing — checkout becomes human handoff'; ?></td></tr>
                    <?php $initial_spec=WFCA_Kapso::template_spec('INITIAL'); ?>
                    <tr><td>Initial WhatsApp template</td><td><?php echo !empty($initial_spec['name'])?'✅ '.esc_html((string)$initial_spec['name']).' · '.esc_html((string)($initial_spec['source']??'')):'⚠️ missing/invalid — autonomous business initiation disabled'; ?></td></tr>
                    <tr><td>Daniel alert email</td><td><?php echo WFCA_Util::owner_email()!==''?'✅ configured/fallback to WordPress admin email':'⚠️ no valid email'; ?></td></tr>
                    <tr><td>Daniel WhatsApp alert template</td><td><?php echo WFCA_Util::owner_whatsapp()!=='' && WFCA_Kapso::template('OWNER_ALERT')!=='' ?'✅ configured':'Optional — dashboard + email remain active'; ?></td></tr>
                </tbody>
            </table>

            <form method="post" style="margin:10px 0">
                <?php wp_nonce_field('wfca_refresh','wfca_refresh_nonce'); ?>
                <button class="button" name="wfca_refresh_integrations" value="1">Refresh integration checks</button>
            </form>

            <h2>Runtime / recovery</h2>
            <table class="widefat striped" style="max-width:1100px">
                <tbody>
                    <tr><td>Last engine tick</td><td><?php echo esc_html($last_tick?:'not recorded yet'); ?></td></tr>
                    <tr><td>Next WP-Cron tick</td><td><?php echo $next_tick?esc_html(gmdate('c',$next_tick)):'❌ not scheduled'; ?></td></tr>
                    <tr><td>Handoff fallback reply</td><td><code><?php echo esc_html(WFCA_Util::handoff_ack_text()); ?></code></td></tr>
                    <tr><td>Recovery</td><td>Stale inbound and stale outbox leases are automatically recovered; checkout links are idempotent across retries.</td></tr>
                </tbody>
            </table>

            <h2>OpenAI guardrail / cost telemetry</h2>
            <table class="widefat striped" style="max-width:1100px">
                <tbody>
                    <tr><td>Last API result</td><td><?php echo !empty($ai['ok'])?'✅ OK':(!empty($ai)?'⚠️ '.esc_html((string)($ai['reason']??'failed')):'No call yet'); ?></td></tr>
                    <tr><td>Model</td><td><code><?php echo esc_html(WFCA_OpenAI::model()); ?></code></td></tr>
                    <tr><td>Luna Commercial Context</td><td><code>v<?php echo esc_html(WFCA_Commercial_Context::VERSION); ?></code> · Strategy Express <?php echo esc_html(WFCA_Commercial_Context::strategy_price_label(WFCA_Airtable::config())); ?></td></tr>
                    <tr><td>Calls / failures</td><td><?php echo (int)($usage['calls']??0); ?> / <?php echo (int)($usage['failures']??0); ?></td></tr>
                    <tr><td>Input / output tokens</td><td><?php echo number_format((int)($usage['input_tokens']??0)); ?> / <?php echo number_format((int)($usage['output_tokens']??0)); ?></td></tr>
                    <tr><td>Estimated API spend</td><td>US$ <?php echo esc_html(number_format((float)($usage['estimated_usd']??0),4,'.','')); ?> <em>(informational estimate; OpenAI billing is authoritative)</em></td></tr>
                </tbody>
            </table>

            <h2>Delivery failures by error code</h2>
            <?php $dfc=WFCA_Util::delivery_fail_counters(); ?>
            <p><em>Read-only diagnostic; not used by any send decision.</em></p>
            <table class="widefat striped" style="max-width:1100px"><tbody>
                <?php if (!$dfc['codes']): ?><tr><td>No delivery failure recorded.</td></tr><?php endif; ?>
                <?php foreach ($dfc['codes'] as $k=>$v): ?>
                    <tr><td><code><?php echo esc_html((string)$k); ?></code></td><td><?php echo (int)($v['count']??0); ?></td><td><?php echo esc_html((string)($v['last_at']??'')); ?></td><td>tail=<?php echo esc_html((string)($v['last_tail4']??'')); ?></td></tr>
                <?php endforeach; ?>
            </tbody></table>

            <h2>Kapso signature telemetry</h2>
            <?php if (!$sig): ?>
                <p>No Kapso signature check recorded yet.</p>
            <?php else: ?>
                <table class="widefat striped" style="max-width:1100px">
                    <tbody>
                        <tr><td>Last check</td><td><?php echo !empty($sig['valid']) ? '✅ VALID' : '❌ INVALID'; ?></td></tr>
                        <tr><td>UTC</td><td><?php echo esc_html((string)($sig['at'] ?? '')); ?></td></tr>
                        <tr><td>Kind / reason</td><td><code><?php echo esc_html((string)($sig['kind'] ?? '')); ?></code> / <code><?php echo esc_html((string)($sig['reason'] ?? '')); ?></code></td></tr>
                        <tr><td>Validation URL</td><td><code><?php echo esc_html((string)($sig['validation_url'] ?? '')); ?></code></td></tr>
                        <tr><td>Request route</td><td><code><?php echo esc_html((string)($sig['route'] ?? '')); ?></code></td></tr>
                    </tbody>
                </table>
                <p><em>No Auth Token or X-Kapso-Signature value is stored in telemetry.</em></p>
            <?php endif; ?>

            <h2>Needs Daniel</h2>
            <table class="widefat striped">
                <thead><tr><th>UTC</th><th>Severity</th><th>Lead</th><th>Reason</th><th>Prospect message</th><th>Notify</th><th>Action</th></tr></thead>
                <tbody>
                <?php if(!$alerts): ?><tr><td colspan="7">No open/acknowledged alerts. ✅</td></tr><?php endif; ?>
                <?php foreach($alerts as $a):
                    $lead_name=(string)$a['lead_record_id']; $lead_site='';
                    if ($lead_name!=='') {
                        $lr=WFCA_Airtable::get_lead($lead_name);
                        if (!empty($lr['ok']) && !empty($lr['data']['fields'])) {
                            $lf=$lr['data']['fields'];
                            if (!empty($lf['Lead'])) $lead_name=(string)$lf['Lead'];
                            if (!empty($lf['Site URL']) && filter_var((string)$lf['Site URL'],FILTER_VALIDATE_URL)) $lead_site=(string)$lf['Site URL'];
                        }
                    }
                    $ac=$a['conversation_id']?WFCA_DB::get_conversation((int)$a['conversation_id']):null;
                    $ap=WFCA_Util::normalize_phone((string)($ac['phone_e164']??''));
                    $wa=$ap!==''?'https://wa.me/'.preg_replace('/\D+/','',$ap):'';
                ?>
                    <tr>
                        <td><?php echo esc_html($a['created_at']); ?></td>
                        <td><strong><?php echo esc_html($a['severity']); ?></strong></td>
                        <td>
                            <strong><?php echo esc_html($lead_name?:'—'); ?></strong><br>
                            <?php if($lead_site!==''): ?><a href="<?php echo esc_url($lead_site); ?>" target="_blank" rel="noopener">Abrir site</a><?php endif; ?>
                        </td>
                        <td><?php echo esc_html(WFCA_Util::short_text((string)$a['reason'],220)); ?><?php if(str_contains((string)$a['reason'],'DANIEL_PERSONAL_TOUCH')): ?><br><strong>🎙️ Áudio pessoal indicado</strong><?php endif; ?></td>
                        <td><?php echo esc_html(WFCA_Util::short_text((string)$a['prospect_message'],260)); ?></td>
                        <td>Email: <?php echo esc_html($a['email_status']); ?><br>WA: <?php echo esc_html($a['whatsapp_status']); ?></td>
                        <td>
                            <?php if($wa!==''): ?><a class="button button-primary button-small" href="<?php echo esc_url($wa); ?>" target="_blank" rel="noopener">Abrir WhatsApp</a><?php endif; ?>
                            <form method="post" style="display:inline">
                                <?php wp_nonce_field('wfca_alert','wfca_alert_nonce'); ?>
                                <input type="hidden" name="alert_id" value="<?php echo (int)$a['id']; ?>">
                                <button class="button button-small" name="wfca_alert_action" value="ack">Acknowledge</button>
                                <button class="button button-small" name="wfca_alert_action" value="resolve">Resolve</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>

            <h2>Endpoints</h2>
            <p><code><?php echo esc_html(rest_url(WFCA_NS.'/commercial/twilio-webhook')); ?></code> — Kapso inbound</p>
            <p><code><?php echo esc_html(rest_url(WFCA_NS.'/commercial/twilio-status')); ?></code> — Kapso status callback</p>
            <p><code><?php echo esc_html(rest_url(WFCA_NS.'/commercial/infinitepay-webhook')); ?></code> — InfinitePay</p>
            <p><code><?php echo esc_html(rest_url(WFCA_NS.'/commercial/health')); ?></code> — public response is minimal; detailed health is protected</p>

            <form method="post">
                <?php wp_nonce_field('wfca_run_now','wfca_run_nonce'); ?>
                <button class="button" name="wfca_run_now" value="1">Run engine now</button>
            </form>

            <h2>Outbox observability</h2>
            <p><code><?php echo esc_html(WFCA_Util::json(get_option('wfca_outbox_admin_result',[]))); ?></code></p>
            <table class="widefat striped">
                <thead><tr><th>ID / status</th><th>Lead</th><th>Arm / owner</th><th>URL</th><th>Template</th><th>Next attempt</th><th>Last error</th><th>Provider ID</th><th>Control</th></tr></thead>
                <tbody>
                <?php if(!$outbox): ?><tr><td colspan="9">No rows.</td></tr><?php endif; ?>
                <?php foreach($outbox as $r):
                    $oc=!empty($r['conversation_id'])?WFCA_DB::get_conversation((int)$r['conversation_id']):null;
                    $lead_name=(string)($r['lead_record_id']??'');$lead_url='';
                    if ($lead_name!=='') {
                        $lr=WFCA_Airtable::get_lead($lead_name);
                        if (!empty($lr['ok']) && !empty($lr['data']['fields'])) {
                            $lf=$lr['data']['fields'];
                            if (!empty($lf['Lead'])) $lead_name=(string)$lf['Lead'];
                            $lead_url=(string)($lf['Site URL']??'');
                        }
                    }
                    $url_host=strtolower((string)parse_url($lead_url,PHP_URL_HOST));
                    $stale_url=$lead_url!=='' && !in_array($url_host,['auracorp.online','www.auracorp.online'],true);
                    $can_rearm=in_array((string)$r['status'],['PENDING','APPROVED'],true)
                        && (string)($r['last_error']??'')==='OUTSIDE_COMMERCIAL_WINDOW'
                        && empty($r['send_started_at']) && empty($r['provider_message_id']);
                ?>
                    <tr>
                        <td><strong>#<?php echo (int)$r['id']; ?></strong><br><?php echo esc_html((string)$r['status']); ?></td>
                        <td><strong><?php echo esc_html($lead_name?:'—'); ?></strong><br><code><?php echo esc_html((string)$r['lead_record_id']); ?></code></td>
                        <td><?php echo esc_html((string)($r['initial_arm']??$oc['initial_arm']??'')); ?><br><strong><?php echo esc_html((string)($oc['conversation_owner']??'—')); ?></strong></td>
                        <td><?php if($lead_url!==''): ?><a href="<?php echo esc_url($lead_url); ?>" target="_blank" rel="noopener"><?php echo esc_html(WFCA_Util::short_text($lead_url,80)); ?></a><?php if($stale_url): ?><br><strong style="color:#b32d2e">STALE HOST</strong><?php endif; ?><?php else: ?>—<?php endif; ?></td>
                        <td><code><?php echo esc_html((string)($r['content_sid']??'')); ?></code></td>
                        <td><?php echo esc_html((string)($r['next_attempt_at']??'')); ?></td>
                        <td><?php echo esc_html(WFCA_Util::short_text((string)($r['last_error']??''),180)); ?></td>
                        <td><code><?php echo esc_html(WFCA_Util::short_text((string)($r['provider_message_id']??''),80)); ?></code></td>
                        <td>
                        <?php if($r['status']==='PENDING_APPROVAL'): ?>
                            <form method="post" style="display:inline">
                                <?php wp_nonce_field('wfca_outbox','wfca_outbox_nonce'); ?>
                                <input type="hidden" name="outbox_id" value="<?php echo (int)$r['id']; ?>">
                                <button class="button button-small" name="wfca_outbox_action" value="approve">Approve</button>
                                <button class="button button-small" name="wfca_outbox_action" value="reject">Reject</button>
                            </form>
                        <?php endif; ?>
                        <?php if($can_rearm): ?>
                            <form method="post" style="display:inline">
                                <?php wp_nonce_field('wfca_outbox','wfca_outbox_nonce'); ?>
                                <input type="hidden" name="outbox_id" value="<?php echo (int)$r['id']; ?>">
                                <button class="button button-small" name="wfca_outbox_action" value="rearm_window">Re-evaluate once</button>
                            </form>
                        <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>

            <h2>Recent message telemetry</h2>
            <table class="widefat striped">
                <thead><tr><th>UTC</th><th>Direction</th><th>Phone</th><th>Status</th><th>Body</th><th>Provider ID</th><th>Error</th></tr></thead>
                <tbody>
                <?php foreach($events as $e): ?>
                    <tr>
                        <td><?php echo esc_html($e['received_at']); ?></td><td><?php echo esc_html($e['direction']); ?></td><td><?php echo esc_html((string)$e['phone_e164']); ?></td>
                        <td><?php echo esc_html($e['status']); ?></td><td><?php echo esc_html(WFCA_Util::short_text((string)$e['body'],220)); ?></td>
                        <td><code><?php echo esc_html((string)$e['provider_message_id']); ?></code></td><td><?php echo esc_html(WFCA_Util::short_text((string)$e['error'],160)); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>

            <h2>Security</h2>
            <p>Secrets remain server-side only. This panel never prints API keys, PATs, Auth Tokens or request signatures. Public health is intentionally minimal. Payment is only accepted after server-side InfinitePay verification.</p>
        </div>
        <?php
    }
}
