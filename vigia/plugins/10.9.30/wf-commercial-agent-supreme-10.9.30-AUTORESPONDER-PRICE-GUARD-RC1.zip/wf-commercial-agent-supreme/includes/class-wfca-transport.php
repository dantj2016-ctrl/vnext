<?php
if (!defined('ABSPATH')) exit;

/** All external commercial notifications pass through this outbox facade. */
final class WFCA_Transport {
    public static function guard(array $row): array {
        if (get_option('wfca_schema_version')!==WFCA_SCHEMA_VERSION || get_option('wfca_schema_error')) return ['ok'=>false,'error'=>'SCHEMA_NOT_READY'];
        $mode_state=WFCA_Airtable::mode_state(true);
        $mode=(string)$mode_state['base_mode'];
        if (!in_array($mode,['ASSISTED','LIVE'],true)) return ['ok'=>false,'error'=>'MODE_BLOCKED'];
        $fresh=WFCA_DB::get_outbox((int)$row['id']);
        if (!$fresh || $fresh['status']!=='PROCESSING' || $fresh['lease_owner']!==$row['lease_owner'] || strtotime($fresh['lease_until'].' UTC')<=time()) return ['ok'=>false,'error'=>'OUTBOX_LEASE_LOST'];
        if ($mode==='ASSISTED' && empty($fresh['approved_at'])) return ['ok'=>false,'error'=>'APPROVAL_REQUIRED'];
        if (($fresh['provider']??'')!=='KAPSO') return ['ok'=>false,'error'=>'LEGACY_PROVIDER_BLOCKED'];
        $action=(string)$fresh['action_type'];
        if (!empty($mode_state['draining']) && in_array($action,['TEMPLATE_INITIAL','FOLLOWUP','TEMPLATE_NURTURE'],true)) return ['ok'=>false,'error'=>'DRAINING_PROACTIVE_BLOCKED'];
        $f=WFCA_Ownership::fence((int)$fresh['conversation_id'],$action,(int)$fresh['owner_revision']);
        if (empty($f['ok'])) return $f;
        $c=$f['conversation'];$cf=$f['fields'];
        if (($fresh['initial_arm']??'')!==($c['initial_arm']??'')) return ['ok'=>false,'error'=>'INITIAL_ARM_CHANGED'];
        if ($action==='FOLLOWUP') {
            if (trim((string)($fresh['content_sid']??''))==='') return ['ok'=>false,'error'=>'FOLLOWUP_TEMPLATE_REQUIRED'];
            $cfg=WFCA_Airtable::config();
            if ((int)($cfg['COMMERCIAL_MAX_FOLLOWUPS_DAY']??0)<=0) return ['ok'=>false,'error'=>'FOLLOWUP_DISABLED_BY_CONFIG'];
            $scheduled=(string)($fresh['scheduled_action_at']??'');
            $due=$scheduled!==''?strtotime($scheduled.' UTC'):0;
            $remote_due=strtotime((string)($cf['Next Commercial Action At']??''));
            if (!$due || !$remote_due || $due!==$remote_due) return ['ok'=>false,'error'=>'FOLLOWUP_STALE_SCHEDULE'];
            if (($cf['State']??'')!=='FOLLOWUP_SCHEDULED') return ['ok'=>false,'error'=>'FOLLOWUP_STATE_CHANGED'];
            $last_inbound=!empty($c['last_inbound_at'])?strtotime((string)$c['last_inbound_at'].' UTC'):0;
            if ($last_inbound && $last_inbound>$due) return ['ok'=>false,'error'=>'FOLLOWUP_SUPERSEDED_BY_INBOUND'];
            if (WFCA_DB::has_terminal_payment((int)$c['id'])) return ['ok'=>false,'error'=>'PAYMENT_TERMINAL'];
        }
        if (str_starts_with($action,'ALERT_')) {
            $a=WFCA_DB::get_alert((int)$fresh['alert_id']);
            if (!$a || $a['status']!=='OPEN' || (int)$a['conversation_id']!==(int)$c['id']) return ['ok'=>false,'error'=>'ALERT_CLOSED_OR_SOURCE_MISMATCH'];
            $expected=$action==='ALERT_EMAIL'?WFCA_Util::owner_email():WFCA_Util::owner_whatsapp();
            if ($expected==='' || !hash_equals($expected,(string)$fresh['destination'])) return ['ok'=>false,'error'=>'OWNER_DESTINATION_CHANGED'];
        } else {
            $followup_template=$action==='FOLLOWUP' && trim((string)($fresh['content_sid']??''))!=='';
            $template=in_array($action,['TEMPLATE_INITIAL','TEMPLATE_NURTURE'],true) || $followup_template;
            if ($followup_template) {
                $active=WFCA_Kapso::template_spec('FOLLOWUP');
                if (empty($active['name']) || !hash_equals((string)$active['name'],(string)$fresh['content_sid'])) return ['ok'=>false,'error'=>'FOLLOWUP_TEMPLATE_NOT_ACTIVE'];
            }
            if ($template) {
                $perm=$cf['WhatsApp Permission Status']??'UNKNOWN';
                if (!in_array($perm,['OPTED_IN','LIVE_HANDOFF'],true)) return ['ok'=>false,'error'=>'PERMISSION_BLOCKED'];
                if ($action==='TEMPLATE_INITIAL' && ($c['initial_arm']??'')!=='LUNA_COLD_WHATSAPP') return ['ok'=>false,'error'=>'HUMAN_INITIAL_ARM'];
            } else {
                $until=strtotime((string)($cf['WhatsApp 24h Window Until']??''));
                if (!$until || $until<=time()) return ['ok'=>false,'error'=>'24H_SERVICE_WINDOW_CLOSED'];
            }
        }
        return WFCA_DB::begin_send((int)$fresh['id'])?['ok'=>true]:['ok'=>false,'error'=>'BEGIN_SEND_FENCE_FAILED'];
    }
    public static function send(array $row,string $body,string $template='',array $variables=[]): array {
        $c=WFCA_DB::get_conversation((int)$row['conversation_id']);
        if (!$c) return ['ok'=>false,'blocked'=>true,'error'=>'CONVERSATION_MISSING'];
        $guard=static fn():array=>self::guard($row);
        if ($row['action_type']==='ALERT_EMAIL') {
            $g=$guard();if (empty($g['ok'])) return ['ok'=>false,'blocked'=>true,'error'=>$g['error']];
            $ok=wp_mail((string)$row['destination'],'[Website Factory] Commercial Agent',$body);
            // wp_mail cannot prove delivery or non-delivery; false/exception is ambiguous.
            return $ok?['ok'=>true,'sid'=>'EMAIL:'.$row['id'],'status'=>'accepted']:['ok'=>false,'error'=>'MAIL_RESULT_UNCERTAIN','ambiguous'=>true];
        }
        $to=$row['action_type']==='ALERT_WHATSAPP'?(string)$row['destination']:(string)$c['phone_e164'];
        return WFCA_Kapso::send($to,$body,$template,$variables,$guard);
    }
}
