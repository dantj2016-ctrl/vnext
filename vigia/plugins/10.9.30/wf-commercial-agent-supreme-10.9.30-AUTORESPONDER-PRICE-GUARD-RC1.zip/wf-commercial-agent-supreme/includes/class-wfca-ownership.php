<?php
if (!defined('ABSPATH')) exit;

/** Business owner is independent of initial prospecting arm and sales/payment stage. */
final class WFCA_Ownership {
    public const OWNERS=['DANIEL','LUNA','HANDOFF_PENDING','STOPPED'];
    public static function arm(string $arm): string {
        $arm=['CALL_FIRST'=>'DANIEL_CALL','ASYNC_FIRST'=>'DANIEL_ASYNC'][$arm]??$arm;
        if (in_array($arm,['DANIEL_CALL','DANIEL_ASYNC','LUNA_COLD_WHATSAPP'],true)) return $arm;
        return ($arm!=='' && class_exists('WFCA_Util') && WFCA_Util::arm_by_id($arm))?strtoupper($arm):'';
    }
    /** Config-driven arm (WFCA_ARMS_V1): kept only in the local DB, never written to the Airtable singleSelect. */
    public static function is_config_arm(string $arm): bool {
        return $arm!=='' && !in_array($arm,['DANIEL_CALL','DANIEL_ASYNC','LUNA_COLD_WHATSAPP'],true) && class_exists('WFCA_Util') && (bool)WFCA_Util::arm_by_id($arm);
    }
    /** Airtable currently stores the human lane as CALL_FIRST/ASYNC_FIRST. */
    public static function remote_arm(string $arm): string {
        $arm=self::arm($arm);
        // Config-driven arms (WFCA_ARMS_V1) live only in the local DB: the Airtable singleSelect has no such option, so omit them remotely.
        if ($arm!=='' && !in_array($arm,['DANIEL_CALL','DANIEL_ASYNC','LUNA_COLD_WHATSAPP'],true)) return '';
        return ['DANIEL_CALL'=>'CALL_FIRST','DANIEL_ASYNC'=>'ASYNC_FIRST'][$arm]??$arm;
    }
    public static function is_only_daniel(string $arm): bool {
        return self::arm($arm)==='DANIEL_CALL';
    }
    /** CURRENT deterministic split; health and runtime use the same parser. */
    public static function routing_split(): array {
        $daniel_pct=15;
        $cfg=class_exists('WFCA_Airtable')?WFCA_Airtable::config():[];
        $raw=(string)($cfg['COMMERCIAL_ROUTING_SPLIT_V2']??'');
        $source='SAFE_FALLBACK';
        if ($raw!=='' && preg_match('/(?:^|\|)\s*(\d{1,3})%\s+(?:ONLY_DANIEL|CALL_FIRST)/i',$raw,$m)) {
            $v=(int)$m[1];
            if ($v>=0 && $v<=100) { $daniel_pct=$v; $source='AIRTABLE_CURRENT'; }
        }
        return ['call_first_pct'=>$daniel_pct,'luna_pct'=>100-$daniel_pct,'source'=>$source,'raw'=>$raw];
    }
    public static function route_for_lead(string $lead_id): string {
        $split=self::routing_split();
        $daniel_pct=(int)$split['call_first_pct'];
        $hex=substr(hash('sha256',$lead_id),0,8);
        $bucket=((int)hexdec($hex))%100;
        return $bucket<$daniel_pct?'CALL_FIRST':'LUNA_COLD_WHATSAPP';
    }
    public static function queue_status(): string {
        return ['LIVE'=>'PENDING','ASSISTED'=>'PENDING_APPROVAL','SHADOW'=>'DRAFT_SHADOW','OFF'=>'CANCELLED'][WFCA_Airtable::base_mode()]??'CANCELLED';
    }
    public static function lock(string $key): bool {
        global $wpdb;
        return (string)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,0)','wfca:'.substr(hash('sha256',$key),0,48)))==='1';
    }
    public static function unlock(string $key): void {
        global $wpdb;
        $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)','wfca:'.substr(hash('sha256',$key),0,48)));
    }
    public static function change(int $id,string $owner,string $reason,int $expected,bool $explicit=false,?string $manual_at=null): array {
        global $wpdb;
        if (!in_array($owner,self::OWNERS,true)) return ['ok'=>false,'error'=>'INVALID_OWNER'];
        $c=WFCA_DB::get_conversation($id);
        if (!$c || (int)$c['owner_revision']!==$expected) return ['ok'=>false,'error'=>'OWNER_REVISION_CONFLICT'];
        if ($owner==='LUNA' && (!$explicit || !empty($c['opt_out']))) return ['ok'=>false,'error'=>'EXPLICIT_RESUME_REQUIRED_OR_OPT_OUT'];
        if ($owner==='LUNA') {
            $remote=WFCA_Airtable::get_commercial_conversation((string)$c['phone_e164']);
            $f=$remote['record']['fields']??[];
            if (empty($remote['ok']) || empty($remote['record']) || !empty($f['Opt Out']) || ($f['WhatsApp Permission Status']??'')==='OPT_OUT') return ['ok'=>false,'error'=>'REMOTE_RESUME_BLOCKED'];
        }
        if (($c['conversation_owner']??'')==='STOPPED' && $owner!=='STOPPED' && !$explicit) return ['ok'=>true,'stopped'=>true];
        if ($manual_at && !empty($c['luna_resumed_at']) && $manual_at<$c['luna_resumed_at']) return ['ok'=>true,'stale'=>true];
        if ($manual_at && !empty($c['last_manual_at']) && $manual_at<=$c['last_manual_at']) return ['ok'=>true,'stale'=>true];
        if (!$manual_at && $owner!=='LUNA' && $owner===$c['conversation_owner'] && $reason===($c['owner_reason']??'')) return ['ok'=>true,'revision'=>$expected];
        $now=WFCA_Util::now_mysql();
        $fields=['conversation_owner'=>$owner,'owner_revision'=>$expected+1,'owner_sync_pending'=>1,
            'owner_changed_at'=>$now,'owner_reason'=>WFCA_Util::short_text($reason,220),'human_hold'=>$owner==='LUNA'?0:1];
        if ($owner==='LUNA') $fields['luna_resumed_at']=$now;
        if ($manual_at) $fields['last_manual_at']=$manual_at;
        if ($owner==='HANDOFF_PENDING') $fields['state']='HUMAN_HANDOFF';
        if ($owner==='STOPPED' && !empty($c['opt_out'])) $fields['state']='OPT_OUT';
        if ($owner==='LUNA' && in_array($c['state'],['HUMAN_HANDOFF','ERROR_HOLD','NO_INTEREST'],true)) $fields['state']='ENGAGED';
        $ok=$wpdb->update(WFCA_DB::t('conversations'),$fields,['id'=>$id,'owner_revision'=>$expected]);
        if ($ok!==1) return ['ok'=>false,'error'=>'OWNER_WRITE_CONFLICT'];
        // No pending or claimed-but-not-sent job survives an owner transition.
        $wpdb->query($wpdb->prepare("UPDATE ".WFCA_DB::t('outbox')." SET status='CANCELLED',last_error='OWNER_CHANGED' WHERE conversation_id=%d AND owner_revision<=%d AND status IN ('PENDING','APPROVED','PENDING_APPROVAL','DRAFT_SHADOW','PROCESSING') AND send_started_at IS NULL",$id,$expected));
        WFCA_DB::insert_event(['event_id'=>'OWNER:'.$id.':'.($expected+1),'provider'=>'LOCAL','phone'=>$c['phone_e164'],
            'direction'=>'CONTROL','event_type'=>'OWNER_CHANGE','status'=>'PROCESSED','signature_status'=>'N/A',
            'body'=>WFCA_Util::json(['owner'=>$owner,'revision'=>$expected+1,'reason'=>$reason,'initial_arm'=>$c['initial_arm']??''])]);
        return ['ok'=>true,'revision'=>$expected+1];
    }
    public static function sync(int $id): bool {
        global $wpdb;
        if (!self::lock('owner-sync:'.$id)) return false;
        try {
            $c=WFCA_DB::get_conversation($id);
            if (!$c) return false;
            if (empty($c['owner_sync_pending'])) return true;
            if (empty($c['lead_record_id'])) return false;
            $fields=['Conversation Owner'=>$c['conversation_owner'],'Owner Revision'=>(int)$c['owner_revision'],
                'Owner Changed At'=>gmdate('c',strtotime($c['owner_changed_at'].' UTC')),
                'Owner Change Reason'=>$c['owner_reason']??''];
            // Airtable singleSelect fields reject an empty string. Preserve an existing
            // remote arm when local conversation creation has no arm snapshot.
            if (!empty($c['initial_arm'])) $fields['Initial Arm']=self::remote_arm((string)$c['initial_arm']);
            if ($c['conversation_owner']==='LUNA') {
                $fields['Enabled']=true;
                $fields['State']=$c['state'];
                $fields['Human Handoff Reason']='';
            } elseif ($c['conversation_owner']==='HANDOFF_PENDING') {
                $fields['State']='HUMAN_HANDOFF';$fields['Human Handoff Reason']=$c['owner_reason']??'';
            } elseif ($c['conversation_owner']==='STOPPED') {
                $fields['Enabled']=false;
                if (!empty($c['opt_out'])) { $fields['Opt Out']=true;$fields['State']='OPT_OUT';$fields['WhatsApp Permission Status']='OPT_OUT'; }
            }
            $r=WFCA_Airtable::upsert_commercial_conversation($c['phone_e164'],$c['lead_record_id'],$fields);
            if (empty($r['ok'])) return false;
            return $wpdb->update(WFCA_DB::t('conversations'),['owner_sync_pending'=>0],['id'=>$id,'owner_revision'=>(int)$c['owner_revision']])!==false;
        } finally { self::unlock('owner-sync:'.$id); }
    }
    public static function recover(): void {
        global $wpdb;
        foreach (($wpdb->get_col('SELECT id FROM '.WFCA_DB::t('conversations').' WHERE owner_sync_pending=1 ORDER BY id LIMIT 20')?:[]) as $id) self::sync((int)$id);
    }
    public static function fence(int $id,string $action='REPLY',int $expected=0): array {
        global $wpdb;
        $c=WFCA_DB::get_conversation($id);
        if (!$c) return ['ok'=>false,'error'=>'CONVERSATION_MISSING'];
        if (!empty($c['owner_sync_pending'])) return ['ok'=>false,'error'=>'OWNER_SYNC_PENDING'];
        if ($expected && (int)$c['owner_revision']!==$expected) return ['ok'=>false,'error'=>'OWNER_REVISION_CHANGED'];
        $r=WFCA_Airtable::get_commercial_conversation((string)$c['phone_e164']);
        $f=$r['record']['fields']??[];
        if (empty($r['ok']) || empty($r['record'])) return ['ok'=>false,'error'=>'OWNER_TRUTH_UNAVAILABLE'];
        $owner=(string)($f['Conversation Owner']??'');
        if (!in_array($owner,self::OWNERS,true)) return ['ok'=>false,'error'=>'OWNER_SCHEMA_OR_VALUE_MISSING'];
        if (!empty($f['Opt Out']) || ($f['WhatsApp Permission Status']??'')==='OPT_OUT' || ($f['State']??'')==='OPT_OUT') {
            WFCA_DB::upsert_conversation($c['phone_e164'],['opt_out'=>1,'human_hold'=>1]);
            self::change($id,'STOPPED','AIRTABLE_OPT_OUT',(int)$c['owner_revision']);
            return ['ok'=>false,'error'=>'OPT_OUT_HARD_STOP'];
        }
        if ($owner!==$c['conversation_owner']) {
            // Remote restrictive edits are honored; granting Luna is an explicit admin action only.
            if ($owner!=='LUNA') self::change($id,$owner,'AIRTABLE_OWNER_CHANGE',(int)$c['owner_revision']);
            return ['ok'=>false,'error'=>'OWNER_MISMATCH_EXPLICIT_RESUME_REQUIRED'];
        }
        if ((int)($f['Owner Revision']??0)!==(int)$c['owner_revision']) return ['ok'=>false,'error'=>'REMOTE_OWNER_REVISION_MISMATCH'];
        $remote_arm=self::arm((string)($f['Initial Arm']??''));
        if (!empty($c['initial_arm']) && $remote_arm!==$c['initial_arm'] && !self::is_config_arm((string)$c['initial_arm'])) return ['ok'=>false,'error'=>'INITIAL_ARM_TRUTH_MISMATCH'];
        $fresh=WFCA_DB::get_conversation($id);
        if (!$fresh || (int)$fresh['owner_revision']!==(int)$c['owner_revision'] || !empty($fresh['owner_sync_pending'])) return ['ok'=>false,'error'=>'OWNER_CHANGED_DURING_READ'];
        $internal=in_array($action,['ALERT_EMAIL','ALERT_WHATSAPP'],true);
        // CALL_FIRST is the hard ONLY_DANIEL lane. A remote/local LUNA value by
        // itself cannot seize it; the plugin's explicit owner change is the only
        // path that stamps luna_resumed_at and unlocks Luna for that lead.
        if (!$internal && $owner==='LUNA' && self::is_only_daniel((string)($fresh['initial_arm']??'')) && empty($fresh['luna_resumed_at'])) {
            return ['ok'=>false,'error'=>'ONLY_DANIEL_REQUIRES_EXPLICIT_HANDOFF'];
        }
        $allowed=$internal?['LUNA','DANIEL','HANDOFF_PENDING']:($action==='HANDOFF_ACK'?['HANDOFF_PENDING']:['LUNA']);
        if (!in_array($owner,$allowed,true) || !empty($fresh['opt_out'])) return ['ok'=>false,'error'=>'OWNER_BLOCKS_ACTION'];
        if (!$internal && empty($f['Enabled'])) return ['ok'=>false,'error'=>'CONVERSATION_DISABLED'];
        if (!$internal && $action!=='HANDOFF_ACK' && (!empty($fresh['human_hold']) || in_array($f['State']??'',['HUMAN_HANDOFF','NO_INTEREST'],true))) return ['ok'=>false,'error'=>'PERSISTENT_HUMAN_HOLD'];
        return ['ok'=>true,'conversation'=>$fresh,'fields'=>$f];
    }
}
