<?php
if (!defined('ABSPATH')) exit;

final class WFCA_Airtable {
    public const DEFAULT_BASE = 'appVvU0hjfcOL9ugx';

    public static function available(): bool {
        return trim((string)self::token()) !== '';
    }

    private static function token(): string {
        foreach (['WFCA_AIRTABLE_TOKEN','WEBSITE_FACTORY_AIRTABLE_TOKEN','WF_AIRTABLE_PAT','WF4_AIRTABLE_TOKEN'] as $c) {
            if (defined($c) && trim((string)constant($c)) !== '') return trim((string)constant($c));
        }
        return '';
    }

    public static function base(): string {
        return (string)WFCA_Util::c('WFCA_AIRTABLE_BASE_ID', self::DEFAULT_BASE);
    }

    private static function record_transport(bool $ok, string $operation, string $error=''): void {
        update_option('wfca_last_airtable_transport', [
            'at'=>WFCA_Util::now_iso(),
            'ok'=>$ok,
            'operation'=>$operation,
            'error'=>$error !== '' ? WFCA_Util::redact_error($error) : '',
        ], false);
    }

    public static function last_transport(): array {
        $v=get_option('wfca_last_airtable_transport',[]);
        return is_array($v)?$v:[];
    }

    private static function req(string $method, string $table, string $suffix='', ?array $body=null, array $query=[]): array {
        if (!self::available()) {
            self::record_transport(false, $method.' '.$table, 'AIRTABLE_TOKEN_MISSING');
            return ['ok'=>false,'error'=>'AIRTABLE_TOKEN_MISSING'];
        }
        // 10.9.29: after an HTTP 429 the whole base is rate limited (Airtable: 5 req/s, 30 s penalty). Fail fast (callers already fail closed) instead of
        // burning the tick on calls that will 429 again; the window is the Retry-After header (default 30 s, max 120 s).
        if ((int)get_option('wfca_airtable_backoff_until',0)>time() && self::rule_flag('airtable_backoff_enabled',true)) {
            return ['ok'=>false,'error'=>'HTTP_429_BACKOFF','code'=>429,'data'=>[]];
        }
        $url = 'https://api.airtable.com/v0/' . rawurlencode(self::base()) . '/' . rawurlencode($table) . $suffix;
        if ($query) {
            $parts = [];
            foreach ($query as $key => $value) {
                if ($key==='sort' && is_array($value)) {
                    // Airtable list sort syntax: sort[0][field]=X&sort[0][direction]=desc
                    foreach (array_values($value) as $i=>$s) {
                        $parts[] = 'sort%5B'.(int)$i.'%5D%5Bfield%5D=' . rawurlencode((string)($s['field']??''));
                        $parts[] = 'sort%5B'.(int)$i.'%5D%5Bdirection%5D=' . rawurlencode((string)($s['direction']??'asc'));
                    }
                } elseif (is_array($value)) {
                    foreach ($value as $v) {
                        $parts[] = rawurlencode((string)$key) . '%5B%5D=' . rawurlencode((string)$v);
                    }
                } else {
                    $parts[] = rawurlencode((string)$key) . '=' . rawurlencode((string)$value);
                }
            }
            $url .= '?' . implode('&', $parts);
        }
        $args = [
            'method'=>$method,
            'timeout'=>15,
            'redirection'=>3,
            'headers'=>[
                'Authorization'=>'Bearer '.self::token(),
                'Content-Type'=>'application/json'
            ]
        ];
        if ($body !== null) $args['body'] = WFCA_Util::json($body);
        $res = wp_remote_request($url, $args);
        if (is_wp_error($res)) {
            $err=WFCA_Util::redact_error($res->get_error_message());
            self::record_transport(false,$method.' '.$table,$err);
            return ['ok'=>false,'error'=>$err];
        }
        $code = wp_remote_retrieve_response_code($res);
        $raw = wp_remote_retrieve_body($res);
        $data = json_decode($raw, true);
        if ($code === 429) {
            $ra=(int)wp_remote_retrieve_header($res,'retry-after');
            update_option('wfca_airtable_backoff_until',time()+max(30,min(120,$ra)),false);
            if (class_exists('WFCA_Util')) WFCA_Util::health_note('AIRTABLE_429');
        }
        if ($code < 200 || $code >= 300) {
            $api_type=(string)($data['error']['type']??'');
            $api_message=(string)($data['error']['message']??'');
            $err='HTTP_'.$code.($api_type!==''?':'.$api_type:'').($api_message!==''?':'.$api_message:'');
            $err=WFCA_Util::redact_error($err);
            self::record_transport(false,$method.' '.$table,$err);
            return ['ok'=>false,'error'=>$err,'code'=>$code,'data'=>is_array($data)?$data:[]];
        }
        self::record_transport(true,$method.' '.$table);
        return ['ok'=>true,'code'=>$code,'data'=>is_array($data)?$data:[]];
    }

    /** Reads one boolean/int key of WFCA_RULES_V1 from the CACHED config only (never an HTTP call: req() uses it, so config()/rules() would recurse). */
    private static function rule_flag(string $key,$default) {
        $cfg=get_transient('wfca_config_current');
        if (!is_array($cfg)) { $l=get_option('wfca_config_lkg',[]); $cfg=is_array($l) && is_array($l['cfg']??null)?$l['cfg']:[]; }
        $j=json_decode(trim((string)($cfg['WFCA_RULES_V1']??'')),true);
        return is_array($j) && array_key_exists($key,$j)?$j[$key]:$default;
    }

    public static function probe(bool $force=false): array {
        if (!$force) {
            $cached=get_transient('wfca_airtable_probe');
            if (is_array($cached)) return $cached;
        }
        if (!self::available()) return ['ok'=>false,'error'=>'AIRTABLE_TOKEN_MISSING'];
        $r=self::req('GET','Config','',null,['pageSize'=>1,'fields'=>['Key']]);
        $probe=['ok'=>(bool)($r['ok']??false),'error'=>(string)($r['error']??'')];
        set_transient('wfca_airtable_probe',$probe,60);
        return $probe;
    }

    public static function config(bool $force=false): array {
        if (!$force) { $v=get_transient('wfca_config_current'); if (is_array($v)) return $v; }
        $out=[];$offset=null;$seen=[];$err='';
        do {
            $q=['pageSize'=>100,'fields'=>['Key','Value','Status'],'filterByFormula'=>"{Status}='CURRENT'"];
            if ($offset) $q['offset']=$offset;
            $r=self::req('GET','Config','',null,$q);
            if (empty($r['ok'])) { $err='READ_FAIL:'.(string)($r['error']??''); break; }
            foreach (($r['data']['records']??[]) as $rec) {
                $f=$rec['fields']??[];
                if (($f['Status']??'')!=='CURRENT' || empty($f['Key'])) continue;
                $key=(string)$f['Key'];
                if (array_key_exists($key,$out)) { self::record_transport(false,'CONFIG','DUPLICATE_CURRENT_KEY');$err='DUPLICATE_CURRENT_KEY:'.substr(preg_replace('/[^A-Za-z0-9_]/','',$key),0,60);break 2; }
                $out[$key]=(string)($f['Value']??'');
            }
            $offset=$r['data']['offset']??null;
            if ($offset && isset($seen[$offset])) { $err='PAGINATION_LOOP';break; }
            if ($offset) $seen[$offset]=true;
        } while ($offset);
        if ($err!=='') {
            delete_transient('wfca_config_current');
            // 10.9.29: visible to health_v1 (a duplicated CURRENT key used to stop everything with no trace but "SHADOW").
            $e=get_option('wfca_config_error',[]);
            update_option('wfca_config_error',['at'=>(is_array($e) && !empty($e['err']) && $e['err']===$err)?$e['at']:time(),'err'=>$err],false);
            // Optional stale-while-error (rule config_stale_ttl_seconds, default 0 = off = fail closed as before): serve the last good config for N s.
            $ttl=(int)self::rule_flag('config_stale_ttl_seconds',0);
            $lkg=get_option('wfca_config_lkg',[]);
            if ($ttl>0 && is_array($lkg) && !empty($lkg['cfg']) && time()-(int)$lkg['at']<=min(900,$ttl)) return (array)$lkg['cfg'];
            return [];
        }
        if (get_option('wfca_config_error',false)) update_option('wfca_config_error',[],false);
        $rj=json_decode(trim((string)($out['WFCA_RULES_V1']??'')),true);
        if (is_array($rj) && (int)($rj['config_stale_ttl_seconds']??0)>0) update_option('wfca_config_lkg',['at'=>time(),'cfg'=>$out],false); // only paid for when the rule is on
        set_transient('wfca_config_current',$out,60);
        return $out;
    }

    /** Runtime phone policy is Airtable-driven so market/country changes do not require code churn. */
    public static function phone_policy(): array {
        $cfg=self::config();
        $raw=trim((string)($cfg['COMMERCIAL_PHONE_POLICY_V1']??''));
        $decoded=$raw!==''?json_decode($raw,true):null;
        $policy=is_array($decoded)?$decoded:[];
        $cc=preg_replace('/\D+/','',(string)($policy['default_country_code']??'55'));
        if ($cc==='' || strlen($cc)>3) $cc='55';
        $lengths=[];
        foreach((array)($policy['local_nsn_lengths']??[10,11]) as $n) {
            $n=(int)$n; if ($n>=7 && $n<=12) $lengths[$n]=$n;
        }
        if (!$lengths) $lengths=[10=>10,11=>11];
        sort($lengths);
        return ['default_country_code'=>$cc,'local_nsn_lengths'=>array_values($lengths),
            'reject_noncanonical_conversation_for_factory_lead'=>!array_key_exists('reject_noncanonical_conversation_for_factory_lead',$policy) || !empty($policy['reject_noncanonical_conversation_for_factory_lead'])];
    }

    /** Canonicalize a Factory lead phone; provider inbound E.164 is never rewritten by this helper. */
    public static function canonical_factory_phone(string $value, ?array $policy=null): string {
        // Loops pass one phone_policy() snapshot: otherwise every record costs a config() read
        // (and one Config HTTP GET per record while the Config endpoint is failing).
        $policy??=self::phone_policy();
        return WFCA_Util::extract_factory_phone($value,(string)$policy['default_country_code'],(array)$policy['local_nsn_lengths']);
    }

    public static function clear_cache(): void {
        delete_transient('wfca_config_current');
        delete_transient('wfca_airtable_probe');
    }

    /**
     * Commercial authorization and maintenance drain are separate dimensions.
     * DRAINING is not a fifth permission level: the stricter OFF/SHADOW/ASSISTED/LIVE
     * base mode still governs external effects while the drain flag independently
     * forbids new proactive acquisition/reservation.
     */
    public static function mode_state(bool $force=false): array {
        $local_raw=WFCA_Util::local_mode();
        $cfg=self::config($force);
        $remote_raw=strtoupper((string)($cfg['COMMERCIAL_AGENT_MODE']??'SHADOW'));
        $allowed=['OFF','SHADOW','ASSISTED','LIVE','DRAINING'];
        if (!in_array($local_raw,$allowed,true)) $local_raw='OFF';
        if (!in_array($remote_raw,$allowed,true)) $remote_raw='OFF';
        $draining=$local_raw==='DRAINING' || $remote_raw==='DRAINING';
        $local=$local_raw==='DRAINING'?'LIVE':$local_raw;
        $remote=$remote_raw==='DRAINING'?'LIVE':$remote_raw;
        $rank=['OFF'=>0,'SHADOW'=>1,'ASSISTED'=>2,'LIVE'=>3];
        $base=$rank[$local]<$rank[$remote]?$local:$remote;
        $effective=$draining && $base==='LIVE'?'DRAINING':$base;
        return [
            'mode'=>$effective,
            'base_mode'=>$base,
            'draining'=>$draining,
            'local_raw'=>$local_raw,
            'remote_raw'=>$remote_raw,
        ];
    }

    public static function mode(bool $force=false): string { return (string)self::mode_state($force)['mode']; }
    public static function base_mode(bool $force=false): string { return (string)self::mode_state($force)['base_mode']; }
    public static function draining(bool $force=false): bool { return (bool)self::mode_state($force)['draining']; }

    public static function find_lead_by_phone(string $phone): array {
        $target = WFCA_Util::normalize_phone($phone);
        if ($target === '') return ['ok'=>false,'error'=>'INVALID_PHONE'];

        $cache_key='wfca_lead_phone_'.md5($target);
        $cached_id=(string)get_transient($cache_key);
        if ($cached_id!=='') {
            $cached=self::get_lead($cached_id);
            if ($cached['ok']) {
                $p=(string)($cached['data']['fields']['Telefone']??'');
                if (hash_equals(self::canonical_factory_phone($p),$target) || WFCA_Util::phone_equivalent($p,$target)) {
                    $lead=$cached['data']; $lead['id']=$cached_id;
                    return ['ok'=>true,'lead'=>$lead,'cached'=>true];
                }
            }
            delete_transient($cache_key);
        }

        $offset = null;
        $matches = [];
        $policy = self::phone_policy();
        $fields = ['Lead','Telefone','Site URL','Build Status','Factory State','Public Smoke Status','Assigned Arm',
                   'Observação Específica','Google Maps','Instagram','Source URL','Price Presented','Paid','Amount Received',
                   'Cidade','Especialidade / Posicionamento','Notes'];
        for ($page=0; $page<50; $page++) {
            $q = ['pageSize'=>100,'fields'=>$fields];
            if ($offset) $q['offset']=$offset;
            $r = self::req('GET','Leads','',null,$q);
            if (!$r['ok']) return $r;
            foreach (($r['data']['records'] ?? []) as $rec) {
                $p = (string)($rec['fields']['Telefone'] ?? '');
                if (hash_equals(self::canonical_factory_phone($p,$policy),$target) || WFCA_Util::phone_equivalent($p,$target)) $matches[] = $rec;
            }
            $offset = $r['data']['offset'] ?? null;
            if (!$offset) break;
        }
        if (count($matches) === 1) {
            set_transient($cache_key,(string)$matches[0]['id'],5*MINUTE_IN_SECONDS);
            return ['ok'=>true,'lead'=>$matches[0]];
        }
        if (count($matches) > 1) {
            // A historical bug could create a synthetic WFCA_ORGANIC_INBOUND_V1 row
            // for a number that already belonged to a Factory lead without +55 in
            // Leads.Telefone. Prefer the single non-organic business record and keep
            // the duplicate only as audit history; never let it steal routing.
            $canonical=array_values(array_filter($matches,static fn(array $r):bool=>!self::lead_is_organic_intake($r)));
            if (count($canonical)===1) {
                set_transient($cache_key,(string)$canonical[0]['id'],5*MINUTE_IN_SECONDS);
                return ['ok'=>true,'lead'=>$canonical[0],'deduped'=>true,'duplicate_matches'=>count($matches)];
            }
            return ['ok'=>false,'error'=>'AMBIGUOUS_PHONE_MATCH','matches'=>count($matches),'canonical_matches'=>count($canonical)];
        }
        return ['ok'=>false,'error'=>'LEAD_NOT_FOUND'];
    }


    public static function lead_is_organic_intake(array $lead): bool {
        $f=$lead['fields']??[];
        return str_contains((string)($f['Notes']??''),'WFCA_ORGANIC_INBOUND_V1');
    }

    public static function create_organic_inbound_lead(string $phone,string $initial_message=''): array {
        $target=WFCA_Util::normalize_phone($phone);
        if ($target==='') return ['ok'=>false,'error'=>'INVALID_PHONE'];

        // Race-safe best effort: another worker/message may have created it first.
        $again=self::find_lead_by_phone($target);
        if (!empty($again['ok'])) return $again;
        if (($again['error']??'')!=='LEAD_NOT_FOUND') return $again;

        $last4=substr(preg_replace('/\D+/','',$target),-4);
        $label='WhatsApp Prospect '.($last4!==''?'••'.$last4:'orgânico');
        $notes="WFCA_ORGANIC_INBOUND_V1\nUser-initiated organic WhatsApp intake. Not a Factory-built lead.\nFirst message: ".WFCA_Util::short_text($initial_message,500);
        $r=self::req('POST','Leads','',[
            'typecast'=>true,
            'records'=>[[
                'fields'=>[
                    'Lead'=>$label,
                    'Telefone'=>$target,
                    'Qualificação'=>'HOLD',
                    'Build Status'=>'SKIP',
                    'Factory State'=>'HOLD',
                    'Public Smoke Status'=>'NOT_STARTED',
                    'Factory Fit'=>'VERIFY',
                    'Notes'=>$notes,
                    'Observação Específica'=>'Organic inbound: diagnose need before proposing any service.'
                ]
            ]]
        ]);
        if (empty($r['ok'])) return $r;
        $rec=$r['data']['records'][0]??null;
        if (!$rec || empty($rec['id'])) return ['ok'=>false,'error'=>'ORGANIC_LEAD_CREATE_EMPTY'];
        set_transient('wfca_lead_phone_'.md5($target),(string)$rec['id'],5*MINUTE_IN_SECONDS);
        return ['ok'=>true,'lead'=>$rec,'organic'=>true,'created'=>true];
    }

    public static function get_lead(string $record_id): array {
        return self::req('GET','Leads','/'.rawurlencode($record_id));
    }

    /**
     * Resolve the only outbound artifact host allowed by the current Factory.
     * Legacy danielfreireditor.online paths are deterministically mapped to the
     * same path on auracorp.online, public-smoke probed and written back to the
     * Lead before any site-bearing commercial message can leave the server.
     */
    public static function canonical_site_url(string $lead_id, array $lead, bool $repair=true): array {
        $raw=trim((string)($lead['fields']['Site URL']??''));
        if (!filter_var($raw,FILTER_VALIDATE_URL)) return ['ok'=>false,'error'=>'SITE_URL_INVALID'];
        $parts=parse_url($raw);
        $host=strtolower((string)($parts['host']??''));
        $path=(string)($parts['path']??'/');
        if ($path==='') $path='/';

        if (!in_array($host,['auracorp.online','www.auracorp.online','danielfreireditor.online','www.danielfreireditor.online'],true)) {
            return ['ok'=>false,'error'=>'SITE_URL_HOST_BLOCKED'];
        }
        $candidate='https://auracorp.online'.$path;
        $probe=self::probe_public_site($candidate);
        if (empty($probe['ok'])) return ['ok'=>false,'error'=>(string)($probe['error']??'CANONICAL_SITE_PROBE_FAILED'),'url'=>$candidate];

        $normalized_raw=preg_replace('#^https?://(?:www\.)?#i','https://',$raw);
        $canonical_changed=$normalized_raw!==$candidate;
        if ($canonical_changed && $repair) {
            $write=self::update_lead($lead_id,['Site URL'=>$candidate]);
            if (empty($write['ok'])) return ['ok'=>false,'error'=>'CANONICAL_SITE_URL_WRITE_FAIL','url'=>$candidate];
        }
        return ['ok'=>true,'url'=>$candidate,'repaired'=>$canonical_changed && $repair,'http_code'=>$probe['http_code']??200];
    }

    private static function probe_public_site(string $url): array {
        $cache='wfca_site_probe_'.md5($url);
        $cached=get_transient($cache);
        if (is_array($cached)) return $cached;
        $p=parse_url($url);
        $host=strtolower((string)($p['host']??''));
        if ($host!=='auracorp.online' || strtolower((string)($p['scheme']??''))!=='https') return ['ok'=>false,'error'=>'CANONICAL_SITE_HOST_INVALID'];
        $res=wp_remote_get($url,[
            'timeout'=>8,'redirection'=>3,'sslverify'=>true,'limit_response_size'=>131072,
            'headers'=>['User-Agent'=>'WFCA/'.WFCA_VERSION.' canonical-preflight']
        ]);
        if (is_wp_error($res)) {
            $out=['ok'=>false,'error'=>'CANONICAL_SITE_NETWORK'];
            set_transient($cache,$out,60);
            return $out;
        }
        $code=(int)wp_remote_retrieve_response_code($res);
        $body=(string)wp_remote_retrieve_body($res);
        if ($code!==200) {
            $out=['ok'=>false,'error'=>'CANONICAL_SITE_HTTP_'.$code,'http_code'=>$code];
            set_transient($cache,$out,60);
            return $out;
        }
        if (stripos(substr($body,0,32),'<!doctype html')!==0) {
            $out=['ok'=>false,'error'=>'CANONICAL_SITE_DOCTYPE_FAIL','http_code'=>$code];
            set_transient($cache,$out,60);
            return $out;
        }
        if (stripos($body,'your domain is expired')!==false || stripos($body,'domain is expired')!==false) {
            $out=['ok'=>false,'error'=>'CANONICAL_SITE_EXPIRED_MARKER','http_code'=>$code];
            set_transient($cache,$out,60);
            return $out;
        }
        $out=['ok'=>true,'http_code'=>$code];
        set_transient($cache,$out,5*MINUTE_IN_SECONDS);
        return $out;
    }

    public static function lead_is_commercial_ready(array $lead): bool {
        $f = $lead['fields'] ?? [];
        return ($f['Build Status'] ?? '') === 'BUILT'
            && ($f['Factory State'] ?? '') === 'FACTORY_COMPLETE'
            && ($f['Public Smoke Status'] ?? '') === 'PASS'
            && filter_var((string)($f['Site URL'] ?? ''), FILTER_VALIDATE_URL);
    }

    /**
     * Validate the per-lead D0 preview binding. The screenshot generator remains
     * upstream (Factory/Cloudflare); Commercial only consumes a READY artifact and
     * fails closed if the lead record does not prove one.
     */
    public static function d0_preview_contract(array $lead): array {
        $f=$lead['fields']??[];
        if (($f['D0 Preview Status']??'')!=='READY') return ['ok'=>false,'error'=>'D0_PREVIEW_NOT_READY'];
        $url=trim((string)($f['D0 Preview Image URL']??''));
        $parts=$url!==''?parse_url($url):false;
        if (!filter_var($url,FILTER_VALIDATE_URL) || !is_array($parts) || strtolower((string)($parts['scheme']??''))!=='https') {
            return ['ok'=>false,'error'=>'D0_PREVIEW_URL_INVALID'];
        }
        $sha=strtolower(trim((string)($f['D0 Preview SHA256']??'')));
        if (!preg_match('/^[a-f0-9]{64}$/',$sha)) return ['ok'=>false,'error'=>'D0_PREVIEW_SHA_INVALID'];
        $generated=trim((string)($f['D0 Preview Generated At']??''));
        $generated_ts=$generated!==''?strtotime($generated):false;
        if ($generated_ts===false) return ['ok'=>false,'error'=>'D0_PREVIEW_GENERATED_AT_INVALID'];
        $factory_at=trim((string)($f['Last Factory At']??''));
        $factory_ts=$factory_at!==''?strtotime($factory_at):false;
        if ($factory_ts!==false && $generated_ts+300<$factory_ts) {
            // A D0 is generated during canonical visual Smoke, while Last Factory At
            // is stamped only when that same completion write finishes. Long Smoke
            // runs can therefore exceed five minutes without making the exact-byte
            // D0 stale. Accept that case only when final Smoke Evidence binds the
            // same lead/run/url/SHA/generated_at and canonical screenshot SHA.
            $lead_id=trim((string)($lead['id']??''));
            $smoke_raw=trim((string)($f['Visual Smoke Evidence']??''));
            if ($smoke_raw==='' && $lead_id!=='') {
                $fresh=self::get_lead($lead_id);
                if (!empty($fresh['ok']) && !empty($fresh['data']['fields'])) {
                    $smoke_raw=trim((string)($fresh['data']['fields']['Visual Smoke Evidence']??''));
                }
            }
            $smoke=$smoke_raw!==''?json_decode($smoke_raw,true):null;
            $d0=is_array($smoke)?($smoke['d0_preview']??null):null;
            $canonical=is_array($smoke)?($smoke['canonical_visual']??null):null;
            $smoke_run=is_array($smoke)?trim((string)($smoke['factory_run_id']??'')):'';
            $d0_run=is_array($d0)?trim((string)($d0['factory_run_id']??'')):'';
            $d0_generated=is_array($d0)?strtotime((string)($d0['generated_at']??'')):false;
            $reviewed=is_array($smoke)?strtotime((string)($smoke['reviewed_at']??'')):false;
            $bound=is_array($d0)
                && is_array($canonical)
                && ($f['Public Smoke Status']??'')==='PASS'
                && $lead_id!==''
                && hash_equals($lead_id,trim((string)($d0['lead_record_id']??'')))
                && $smoke_run!=='' && $d0_run!=='' && hash_equals($smoke_run,$d0_run)
                && ($d0['status']??'')==='READY'
                && hash_equals($url,trim((string)($d0['url']??'')))
                && hash_equals($sha,strtolower(trim((string)($d0['sha256']??''))))
                && hash_equals($sha,strtolower(trim((string)($d0['capture_sha256']??$sha))))
                && hash_equals($sha,strtolower(trim((string)($canonical['screenshot_sha256']??''))))
                && $d0_generated!==false && $d0_generated===$generated_ts
                && $reviewed!==false && abs($reviewed-$factory_ts)<=2;
            if (!$bound) return ['ok'=>false,'error'=>'D0_PREVIEW_STALE_BEFORE_FACTORY'];
        }
        return ['ok'=>true,'url'=>$url,'sha256'=>$sha,'generated_at'=>$generated];
    }

    /**
     * 10.9.24: a D0 preview image that is the host's bot-check page ("Checking your browser...", ~24 KB) instead of the site (700 KB+) went out to clinics on 2026-10-10.
     * Fail closed on size: the raw route must deliver at least `d0_min_preview_bytes` (Airtable WFCA_RULES_V1, default 150000; 0 = off). Result cached per sha (OK 6 h, BAD 1 h).
     */
    public static function d0_preview_bytes_gate(array $media): array {
        if (empty($media['ok'])) return $media;
        $min=(class_exists('WFCA_Util') && method_exists('WFCA_Util','rules'))?(int)(WFCA_Util::rules()['d0_min_preview_bytes']??150000):150000;
        if ($min<=0) return $media;
        $sha=(string)($media['sha256']??'');
        $key='wfca_d0_bytes_'.substr($sha,0,32);
        $c=get_transient($key);
        if ($c==='OK') return $media;
        if ($c==='BAD') return ['ok'=>false,'error'=>'D0_PREVIEW_IMAGE_TOO_SMALL'];
        $r=wp_remote_get((string)$media['url'],['timeout'=>20,'redirection'=>2,'limit_response_size'=>$min+1024,'headers'=>['Accept'=>'image/*']]);
        if (is_wp_error($r) || (int)wp_remote_retrieve_response_code($r)!==200) return ['ok'=>false,'error'=>'D0_PREVIEW_UNREACHABLE'];
        $n=strlen((string)wp_remote_retrieve_body($r));
        if ($n<$min) { set_transient($key,'BAD',HOUR_IN_SECONDS); return ['ok'=>false,'error'=>'D0_PREVIEW_IMAGE_TOO_SMALL','bytes'=>$n]; }
        set_transient($key,'OK',6*HOUR_IN_SECONDS);
        return $media;
    }

    public static function conversation_id(string $phone): string {
        return 'wa:' . ltrim(WFCA_Util::normalize_phone($phone), '+');
    }

    public static function get_commercial_conversation(string $phone): array {
        $cid = self::conversation_id($phone);
        $formula = "{Conversation ID}='" . str_replace("'", "\\'", $cid) . "'";
        $r = self::req('GET','Commercial Conversations','',null,[
            'maxRecords'=>2,'filterByFormula'=>$formula
        ]);
        if (!$r['ok']) return $r;
        $records=$r['data']['records']??[];
        if (count($records)>1) return ['ok'=>false,'error'=>'DUPLICATE_COMMERCIAL_CONVERSATION','count'=>count($records)];
        return ['ok'=>true,'record'=>$records[0]??null];
    }

    /**
     * Batched read-only variant of get_commercial_conversation() for producer loops: one OR() query per
     * 20 phones instead of one GET per phone. Returns [conversation_id => same shape as the single read].
     * A chunk that fails or is not fully paged is simply absent so the caller falls back to the single read.
     */
    public static function get_commercial_conversations_bulk(array $phones): array {
        $ids=[];
        foreach ($phones as $p) { $cid=self::conversation_id((string)$p); if ($cid!=='wa:') $ids[$cid]=true; }
        $out=[];
        foreach (array_chunk(array_keys($ids),20) as $chunk) {
            $parts=[];
            foreach ($chunk as $cid) $parts[]="{Conversation ID}='".str_replace("'","\\'",$cid)."'";
            $formula='OR('.implode(',',$parts).')';
            $found=[];$offset=null;$seen=[];$complete=false;
            for ($page=0;$page<5;$page++) {
                $q=['pageSize'=>100,'filterByFormula'=>$formula];
                if ($offset) $q['offset']=$offset;
                $r=self::req('GET','Commercial Conversations','',null,$q);
                if (empty($r['ok'])) return $out;
                // A 2xx without a records list (proxy/captive page) is a failed chunk, never "20 conversations do not exist".
                if (!isset($r['data']['records']) || !is_array($r['data']['records'])) return $out;
                foreach (($r['data']['records']??[]) as $rec) {
                    $c=(string)($rec['fields']['Conversation ID']??'');
                    if ($c!=='') $found[$c][]=$rec;
                }
                $offset=$r['data']['offset']??null;
                if (!$offset) { $complete=true;break; }
                if (isset($seen[$offset])) break;
                $seen[$offset]=true;
            }
            if (!$complete) return $out;
            foreach ($chunk as $cid) {
                $n=count($found[$cid]??[]);
                $out[$cid]=$n>1?['ok'=>false,'error'=>'DUPLICATE_COMMERCIAL_CONVERSATION','count'=>$n]:['ok'=>true,'record'=>$found[$cid][0]??null];
            }
        }
        return $out;
    }

    /** $known: a get_commercial_conversation() result the caller read moments ago in this same pass with no Commercial Conversations write since. */
    public static function upsert_commercial_conversation(string $phone, string $lead_id, array $fields, ?array $known=null): array {
        $got = ($known !== null && !empty($known['ok'])) ? $known : self::get_commercial_conversation($phone);
        if (!$got['ok']) return $got;
        $cid = self::conversation_id($phone);
        $record = $got['record'] ?? null;
        $base = [
            'Conversation ID'=>$cid,
            'Lead'=>[$lead_id],
            'Phone E164'=>WFCA_Util::normalize_phone($phone),
        ];
        if ($record) {
            $rf=$record['fields']??[];
            if (!empty($rf['Initial Arm'])) unset($fields['Initial Arm']);
        }
        if (isset($fields['Initial Arm'])) {
            $remote_arm=WFCA_Ownership::remote_arm((string)$fields['Initial Arm']);
            if ($remote_arm==='') unset($fields['Initial Arm']);
            else $fields['Initial Arm']=$remote_arm;
        }
        $fields = array_merge($base, $fields);

        if ($record) {
            $version = (int)($record['fields']['Version'] ?? 0);
            $fields['Version'] = $version + 1;
            return self::req('PATCH','Commercial Conversations','',[
                'records'=>[['id'=>$record['id'],'fields'=>$fields]]
            ]);
        }

        $fields['Version'] = 1;
        return self::req('POST','Commercial Conversations','',[
            'records'=>[['fields'=>$fields]]
        ]);
    }

    public static function update_commercial_by_phone(string $phone, array $fields): array {
        $got = self::get_commercial_conversation($phone);
        if (!$got['ok'] || empty($got['record'])) return ['ok'=>false,'error'=>$got['error']??'COMMERCIAL_CONVERSATION_NOT_FOUND'];
        $rec = $got['record'];
        $owner=$rec['fields']['Conversation Owner']??'DANIEL';
        if ($owner!=='LUNA' && isset($fields['State']) && !in_array($fields['State'],['HUMAN_HANDOFF','OPT_OUT','NO_INTEREST'],true)) unset($fields['State']);
        if ($owner!=='LUNA') unset($fields['Human Handoff Reason']);
        $version = (int)($rec['fields']['Version'] ?? 0);
        $fields['Version']=$version+1;
        return self::req('PATCH','Commercial Conversations','',[
            'records'=>[['id'=>$rec['id'],'fields'=>$fields]]
        ]);
    }

    public static function log_touch(string $lead_id, string $direction, string $action, string $summary, string $provider_id='',string $provider='KAPSO',string $actor='LUNA',string $arm=''): array {
        if ($arm==='') {
            $lr=self::get_lead($lead_id);
            $phone=WFCA_Util::normalize_phone((string)($lr['data']['fields']['Telefone']??''));
            $c=$phone!==''?WFCA_DB::get_conversation_by_phone($phone):null;
            $arm=(string)($c['initial_arm']??'');
        }
        if (strtoupper($direction)==='INBOUND' && $actor==='LUNA') $actor=$action==='PAYMENT_VERIFIED'?'INFINITEPAY':'PROSPECT';
        $summary_short=WFCA_Util::short_text($summary,700);
        // Stable key: retries/reconciliation must never duplicate a commercial Touch.
        $identity=$provider_id!=='' ? $provider_id : $summary_short;
        $fingerprint=($provider==='TWILIO'?'':$provider.'|').$lead_id.'|'.strtoupper($direction).'|'.strtoupper($action).'|'.$identity;
        $touch_id='WFCA-'.strtoupper(substr(hash('sha256',$fingerprint),0,24));
        $lock='touch:'.$touch_id;
        if (!WFCA_Ownership::lock($lock)) return ['ok'=>false,'error'=>'TOUCH_BUSY'];
        try {
        $formula="{Touch ID}='".str_replace("'","\'",$touch_id)."'";
        $existing=self::req('GET','Touches','',null,[
            'maxRecords'=>1,'fields'=>['Touch ID'],'filterByFormula'=>$formula
        ]);
        if (empty($existing['ok'])) return $existing;
        $records=$existing['data']['records']??[];
        if (!empty($records)) return ['ok'=>true,'duplicate'=>true,'touch_id'=>$touch_id,'data'=>$existing['data']];

        $notes = [
            'direction'=>$direction,
            'channel'=>'WHATSAPP',
            'provider'=>$provider,
            'provider_message_id'=>$provider_id,
            'tool_action'=>$action,
            'content_summary'=>$summary_short,
            'agent'=>'WFCA/'.WFCA_VERSION,'actor'=>$actor,'initial_arm'=>$arm,
        ];
        $created=self::req('POST','Touches','',[
            'typecast'=>false,
            'records'=>[[
                'fields'=>[
                    'Touch ID'=>$touch_id,
                    'Attempt DateTime'=>WFCA_Util::now_iso(),
                    'Notes'=>WFCA_Util::json($notes),
                    'Lead'=>[$lead_id],
                ]
            ]]
        ]);
        if (!empty($created['ok'])) $created['touch_id']=$touch_id;
        return $created;
        } finally { WFCA_Ownership::unlock($lock); }
    }

    public static function update_lead(string $lead_id, array $fields): array {
        return self::req('PATCH','Leads','',[
            'records'=>[['id'=>$lead_id,'fields'=>$fields]]
        ]);
    }


    /** Commercial-ready Factory inventory, independent of whether a conversation row already exists. */
    public static function commercial_ready_leads(int $max=100): array {
        $max=max(1,min(500,$max));
        $formula="AND({Build Status}='BUILT',{Factory State}='FACTORY_COMPLETE',{Public Smoke Status}='PASS',{Site URL}!='',{Telefone}!='')";
        $fields=['Lead','Telefone','Site URL','Build Status','Factory State','Public Smoke Status','Assigned Arm',
            'Observação Específica','Follow-up Insight','D0 Preview Image URL','D0 Preview Status','D0 Preview Generated At','D0 Preview SHA256','Last Factory At',
            'Cidade','Especialidade / Posicionamento','Notes'];
        $records=[];$offset=null;$seen=[];
        while(count($records)<$max) {
            // Newest factory completions first: with 120+ leads already BUILT, an unordered window of 100 left the newest ones
            // without a conversation, so they never received a D0 (Bela Leal, Harmony on 2026-10-09).
            $q=['pageSize'=>min(100,$max-count($records)),'fields'=>$fields,'filterByFormula'=>$formula,'sort'=>[['field'=>'Last Factory At','direction'=>'desc']]];
            if ($offset) $q['offset']=$offset;
            $r=self::req('GET','Leads','',null,$q);
            if (empty($r['ok'])) return $r;
            foreach(($r['data']['records']??[]) as $rec) { $records[]=$rec; if(count($records)>=$max) break; }
            $offset=$r['data']['offset']??null;
            if (!$offset || isset($seen[$offset])) break;
            $seen[$offset]=true;
        }
        return ['ok'=>true,'data'=>['records'=>$records]];
    }

    /**
     * Rebind an existing canonical Commercial Conversation to a verified Factory
     * lead without deleting the synthetic lead/history that may have been linked
     * previously. Intended only for exact-phone canonical reconciliation.
     */
    public static function rebind_commercial_conversation(string $phone,string $lead_id,array $fields=[]): array {
        $got=self::get_commercial_conversation($phone);
        if (empty($got['ok']) || empty($got['record'])) return ['ok'=>false,'error'=>$got['error']??'COMMERCIAL_CONVERSATION_NOT_FOUND'];
        $rec=$got['record'];
        $base=['Lead'=>[$lead_id],'Phone E164'=>WFCA_Util::normalize_phone($phone),'Version'=>(int)($rec['fields']['Version']??0)+1];
        if (isset($fields['Initial Arm'])) {
            $arm=WFCA_Ownership::remote_arm((string)$fields['Initial Arm']);
            if ($arm==='') unset($fields['Initial Arm']); else $fields['Initial Arm']=$arm;
        }
        return self::req('PATCH','Commercial Conversations','',[
            'records'=>[['id'=>$rec['id'],'fields'=>array_merge($base,$fields)]]
        ]);
    }

    /**
     * Build a short-lived index of real WhatsApp OUTBOUND Touch history. This
     * catches legacy/manual sends that predate the plugin's local MySQL outbox,
     * including old notes that forgot to link the Lead record.
     */
    public static function outbound_touch_index(bool $force=false): array {
        if (!$force) {
            $cached=get_transient('wfca_outbound_touch_index_v1');
            if (is_array($cached)) return $cached;
        }
        $by_lead=[];$by_phone=[];$offset=null;$seen=[];
        $policy=self::phone_policy();
        // 10.9.29: was 20 pages (2000 touches, oldest first => the NEWEST touches fell off silently once the table grew). 60 pages, and a truncation is flagged in health_v1.
        $max_pages=max(20,min(200,(int)self::rule_flag('touch_index_max_pages',60)));$truncated=0;
        for($page=0;$page<$max_pages;$page++) {
            $q=['pageSize'=>100,'fields'=>['Lead','Notes','Attempt DateTime']];
            if ($offset) $q['offset']=$offset;
            $r=self::req('GET','Touches','',null,$q);
            if (empty($r['ok'])) return ['ok'=>false,'by_lead'=>[],'by_phone'=>[],'error'=>$r['error']??'TOUCH_READ_FAIL'];
            foreach(($r['data']['records']??[]) as $rec) {
                $f=$rec['fields']??[];$notes=(string)($f['Notes']??'');
                if ($notes==='') continue;
                $json=json_decode($notes,true);
                $is_wa_out=false;
                if (is_array($json)) {
                    $is_wa_out=strtoupper((string)($json['direction']??''))==='OUTBOUND'
                        && strtoupper((string)($json['channel']??'WHATSAPP'))==='WHATSAPP';
                } else {
                    $n=WFCA_Util::normalize_text($notes);
                    $is_wa_out=str_contains($n,'whatsapp') && WFCA_Util::contains_any($n,['enviad','outbound','mensagem']);
                }
                if (!$is_wa_out) continue;
                foreach((array)($f['Lead']??[]) as $lid) if ((string)$lid!=='') $by_lead[(string)$lid]=true;
                if (preg_match_all('/(?:\\+?55\\s*)?\\(?\\d{2}\\)?[\\s.-]*\\d{4,5}[\\s.-]*\\d{4}/u',$notes,$m)) {
                    foreach(($m[0]??[]) as $candidate) {
                        $p=self::canonical_factory_phone((string)$candidate,$policy);
                        if ($p!=='') $by_phone[$p]=true;
                    }
                }
            }
            $offset=$r['data']['offset']??null;
            if (!$offset || isset($seen[$offset])) break;
            $seen[$offset]=true;
            if ($page===$max_pages-1) $truncated=1;
        }
        update_option('wfca_touch_index_truncated',$truncated,false);
        $out=['ok'=>true,'by_lead'=>$by_lead,'by_phone'=>$by_phone];
        set_transient('wfca_outbound_touch_index_v1',$out,5*MINUTE_IN_SECONDS);
        return $out;
    }

    public static function prior_whatsapp_outbound_touch_status(string $lead_id,string $phone): array {
        $idx=self::outbound_touch_index();
        if (empty($idx['ok'])) return ['ok'=>false,'exists'=>false,'error'=>$idx['error']??'TOUCH_HISTORY_UNAVAILABLE'];
        $phone=WFCA_Util::normalize_phone($phone);
        return ['ok'=>true,'exists'=>!empty($idx['by_lead'][$lead_id]) || ($phone!=='' && !empty($idx['by_phone'][$phone]))];
    }

    public static function has_prior_whatsapp_outbound_touch(string $lead_id,string $phone): bool {
        $s=self::prior_whatsapp_outbound_touch_status($lead_id,$phone);
        return !empty($s['ok']) && !empty($s['exists']);
    }

    public static function eligible_paid_for_nurture(int $max=10): array {
        $now=WFCA_Util::now_iso();
        $formula="AND({Enabled}=1,{Opt Out}=0,{State}='PAID',IS_BEFORE({Next Commercial Action At},'".str_replace("'","\'",$now)."'))";
        return self::req('GET','Commercial Conversations','',null,[
            'pageSize'=>min(100,max(1,$max)),'filterByFormula'=>$formula
        ]);
    }

    public static function eligible_conversations_for_initial(int $max=10): array {
        // Opt Out is enforced below from the returned record. Do not filter
        // it in Airtable: omitted unchecked checkboxes are not stable formula
        // operands, and an explicit truthy value remains a hard stop there.
        $formula = "AND({Enabled}=1,{State}='READY_FOR_CONTACT')";
        return self::req('GET','Commercial Conversations','',null,[
            'pageSize'=>min(100,max(1,$max)),'filterByFormula'=>$formula
        ]);
    }

    public static function eligible_due_followups(int $max=1): array {
        $now=WFCA_Util::now_iso();
        // Do not filter unchecked Opt Out in the Airtable formula: omitted false
        // checkbox values are not a stable formula operand. The runtime gate below
        // re-reads and enforces Opt Out as a hard stop.
        $formula="AND({Enabled}=1,{Conversation Owner}='LUNA',{State}='FOLLOWUP_SCHEDULED',{Next Commercial Action At}!='',IS_BEFORE({Next Commercial Action At},'".str_replace("'","\\'",$now)."'))";
        return self::req('GET','Commercial Conversations','',null,[
            'pageSize'=>min(100,max(1,$max)),'filterByFormula'=>$formula
        ]);
    }


    /** 10.9.28: FOLLOWUP_SCHEDULED rows whose due passed before $older_than_iso (stuck: nothing was queued). */
    public static function stuck_followup_scheduled(string $older_than_iso,int $max=5): array {
        $formula="AND({Enabled}=1,{Conversation Owner}='LUNA',{State}='FOLLOWUP_SCHEDULED',{Next Commercial Action At}!='',IS_BEFORE({Next Commercial Action At},'".str_replace("'","\\'",$older_than_iso)."'))";
        return self::req('GET','Commercial Conversations','',null,[
            'pageSize'=>min(100,max(1,$max)),'filterByFormula'=>$formula
        ]);
    }

    /** 10.9.28: send-time probe of the D0 preview URL (uncached, tiny read) so a 5xx on OUR server is seen before Meta fetches it. */
    public static function d0_preview_probe(string $url): array {
        $r=wp_remote_get($url,['timeout'=>10,'redirection'=>2,'limit_response_size'=>4096,'headers'=>['Accept'=>'image/*']]);
        if (is_wp_error($r)) return ['ok'=>false,'code'=>0];
        $code=(int)wp_remote_retrieve_response_code($r);
        return ['ok'=>$code===200,'code'=>$code];
    }

    /** WAITING_REPLY rows that may need native D0 follow-up due materialization. */
    public static function waiting_followup_candidates(int $max=100,string $after_iso=''): array {
        // 10.9.29: $after_iso = round-robin cursor (see materialize_due_d0_followup): oldest-first + no cursor meant the SAME 100 oldest leads every tick.
        $formula="AND({Enabled}=1,{Conversation Owner}='LUNA',{State}='WAITING_REPLY',{Last Outbound At}!=''".($after_iso!==''?",IS_AFTER({Last Outbound At},'".str_replace("'","\\'",$after_iso)."')":'').")";
        return self::req('GET','Commercial Conversations','',null,[
            'pageSize'=>min(100,max(1,$max)),'filterByFormula'=>$formula,
            'sort[0][field]'=>'Last Outbound At','sort[0][direction]'=>'asc'
        ]);
    }
}
