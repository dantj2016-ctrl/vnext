<?php
if (!defined('ABSPATH')) exit;

final class WFCA_Kapso {
    public static function ready(): bool {
        return WFCA_Util::token_set('WFCA_KAPSO_API_KEY') && preg_match('/^\d{5,32}$/',(string)WFCA_Util::c('WFCA_KAPSO_PHONE_NUMBER_ID',''))===1;
    }

    /**
     * Active template contracts are Config-driven. Candidate/submitted records are
     * intentionally ignored until an explicit *_TEMPLATE_SPEC record is promoted.
     */
    public static function template_spec(string $kind): array {
        $kind=strtoupper(trim($kind));
        $cfg=WFCA_Airtable::config();
        $keys=[];$allowed=[];$legacy=[];
        if ($kind==='INITIAL') {
            $keys=['COMMERCIAL_INITIAL_WHATSAPP_TEMPLATE_SPEC'];
            $allowed=['lead_name','specific_observation','site_url'];
            $legacy=['lead_name','site_url'];
        } elseif ($kind==='FOLLOWUP') {
            $keys=['COMMERCIAL_FOLLOWUP_WHATSAPP_TEMPLATE_SPEC'];
            $allowed=['lead_name','followup_insight','site_url'];
        }

        foreach ($keys as $key) {
            $raw=trim((string)($cfg[$key]??''));
            if ($raw==='') continue;
            $decoded=json_decode($raw,true);
            if (is_array($decoded)) {
                $name=trim((string)($decoded['name']??''));
                $raw_vars=is_array($decoded['variables']??null)?array_values($decoded['variables']):[];
                $vars=array_map(static fn($v):string=>trim((string)$v),$raw_vars);
                $vars_valid=$vars!==[] && count($vars)===count(array_unique($vars));
                foreach ($vars as $v) {
                    if ($v==='' || !in_array($v,$allowed,true)) {$vars_valid=false;break;}
                }
                $header=[];
                if (is_array($decoded['header']??null)) {
                    $type=strtolower(trim((string)($decoded['header']['type']??'')));
                    $source=trim((string)($decoded['header']['source']??''));
                    if ($type==='image' && $source==='d0_preview_image_url') $header=['type'=>'image','source'=>$source];
                    elseif ($type!=='' || $source!=='') $vars_valid=false;
                } elseif (!empty($decoded['header_image']) && $kind==='INITIAL') {
                    $header=['type'=>'image','source'=>'d0_preview_image_url'];
                }
                if ($kind==='INITIAL') {
                    $media_contract=$name==='wf_site_preview_intro_media_v1'
                        && $vars===['lead_name','specific_observation','site_url']
                        && (($header['type']??'')==='image')
                        && (($header['source']??'')==='d0_preview_image_url');
                    $vars_valid=$vars_valid && $media_contract;
                } elseif ($kind==='FOLLOWUP') {
                    $vars_valid=$vars_valid && $vars===['lead_name','followup_insight','site_url'] && $header===[];
                }
                if (preg_match('/^[a-z0-9_]{1,128}$/',$name) && $vars_valid) {
                    return ['name'=>$name,'variables'=>$vars,'header'=>$header,'source'=>'AIRTABLE_SPEC'];
                }
            }
        }

        // Daniel explicitly retired every legacy initial D0 template. Initial
        // outreach fails closed unless the exact media_v1 Airtable spec above is
        // valid; server constants/plain names can never resurrect v1/v2/v3/v4.
        if ($kind==='INITIAL') return ['name'=>'','variables'=>[],'header'=>[],'source'=>'NONE'];

        $v=trim((string)WFCA_Util::c('WFCA_KAPSO_TEMPLATE_'.$kind,''));
        if ($v==='' && $kind==='OWNER_ALERT') $v=trim((string)($cfg['WFCA_KAPSO_TEMPLATE_OWNER_ALERT']??''));
        if (!preg_match('/^[a-z0-9_]{1,128}$/',$v)) return ['name'=>'','variables'=>[],'header'=>[],'source'=>'NONE'];
        return [
            'name'=>$v,
            'variables'=>[],
            'header'=>[],
            'source'=>'SERVER_CONSTANT'
        ];
    }

    public static function template(string $kind): string {
        return (string)(self::template_spec($kind)['name']??'');
    }
    public static function validate_request(WP_REST_Request $request): bool {
        $raw=$request->get_body();$secret=(string)WFCA_Util::c('WFCA_KAPSO_WEBHOOK_SECRET','');
        $sig=(string)$request->get_header('x-webhook-signature');
        $valid=$secret!=='' && strlen($raw)<=1048576 && preg_match('/^[a-fA-F0-9]{64}$/',$sig) && hash_equals(hash_hmac('sha256',$raw,$secret),strtolower($sig));
        update_option('wfca_last_kapso_signature',['at'=>WFCA_Util::now_iso(),'valid'=>(bool)$valid],false);
        return (bool)$valid;
    }
    public static function last_send(): array { $v=get_option('wfca_last_kapso_send',[]);return is_array($v)?$v:[]; }
    public static function last_signature_check(): array { $v=get_option('wfca_last_kapso_signature',[]);return is_array($v)?$v:[]; }

    /** Called only by the transport facade. Guard is evaluated immediately before network I/O. */
    public static function send(string $to,string $body,string $template,array $variables,callable $guard): array {
        if (!self::ready()) return ['ok'=>false,'error'=>'KAPSO_NOT_CONFIGURED'];
        $to=WFCA_Util::normalize_phone($to);
        if ($to==='') return ['ok'=>false,'error'=>'INVALID_DESTINATION'];
        $payload=['messaging_product'=>'whatsapp','to'=>ltrim($to,'+')];
        if ($template!=='') {
            if (!preg_match('/^[a-z0-9_]{1,128}$/',$template)) return ['ok'=>false,'error'=>'INVALID_TEMPLATE_NAME'];

            // Reserved metadata never becomes a body placeholder.
            $header_url=trim((string)($variables['_header_image_url']??''));
            unset($variables['_header_image_url'],$variables['_header_image_sha256'],$variables['_lead_record_id']);
            foreach (array_keys($variables) as $k) {
                if (!preg_match('/^\d+$/',(string)$k)) return ['ok'=>false,'error'=>'TEMPLATE_PAYLOAD_INVALID'];
            }

            $components=[];
            if ($header_url!=='') {
                $hp=parse_url($header_url);
                if (!filter_var($header_url,FILTER_VALIDATE_URL) || strtolower((string)($hp['scheme']??''))!=='https') {
                    return ['ok'=>false,'error'=>'TEMPLATE_HEADER_IMAGE_INVALID'];
                }
                $components[]=['type'=>'header','parameters'=>[['type'=>'image','image'=>['link'=>$header_url]]]];
            }

            $params=[];ksort($variables,SORT_NATURAL);
            foreach ($variables as $v) $params[]=['type'=>'text','text'=>WFCA_Util::short_text((string)$v,1024)];
            if ($params) $components[]=['type'=>'body','parameters'=>$params];
            $payload+=['type'=>'template','template'=>[
                'name'=>$template,
                'language'=>['code'=>(string)WFCA_Util::c('WFCA_KAPSO_TEMPLATE_LANGUAGE','pt_BR')],
                'components'=>$components
            ]];
        } else {
            if (trim($body)==='') return ['ok'=>false,'error'=>'EMPTY_BODY'];
            $payload+=['type'=>'text','text'=>['body'=>WFCA_Util::short_text($body,4000)]];
        }
        $json=WFCA_Util::json($payload);
        $g=$guard();if (empty($g['ok'])) return ['ok'=>false,'blocked'=>true,'error'=>$g['error']??'FENCE_BLOCKED'];
        $post=static function(string $json): array {
            $res=wp_remote_post('https://api.kapso.ai/meta/whatsapp/v24.0/'.WFCA_Util::c('WFCA_KAPSO_PHONE_NUMBER_ID','').'/messages',[
                'timeout'=>20,'redirection'=>0,'headers'=>['X-API-Key'=>(string)WFCA_Util::c('WFCA_KAPSO_API_KEY',''),'Content-Type'=>'application/json'],'body'=>$json]);
            if (is_wp_error($res)) return ['ok'=>false,'error'=>'KAPSO_NETWORK_ERROR','ambiguous'=>true];
            $code=(int)wp_remote_retrieve_response_code($res);$raw=(string)wp_remote_retrieve_body($res);$data=json_decode($raw,true);
            $sid=(string)($data['messages'][0]['id']??'');
            if ($code>=200 && $code<300 && $sid!=='' && strlen($sid)<=191) return ['ok'=>true,'sid'=>$sid,'status'=>'accepted'];
            // The provider's own words make a 4xx diagnosable; digits are masked so no number is stored.
            $detail=preg_replace('/\d{6,}/','#',preg_replace('/\s+/',' ',$raw));
            return ['ok'=>false,'error'=>'KAPSO_HTTP_'.$code,'http_code'=>$code,'ambiguous'=>$code>=500 || ($code>=200 && $code<300),'detail'=>substr((string)$detail,0,240)];
        };
        $out=$post($json);
        // Brazilian mobiles exist in two spellings (with/without the ninth digit). A rejected (4xx, so NOT delivered)
        // send to the 9-digit form is retried once, for the same recipient, in the legacy 8-digit form.
        if (empty($out['ok']) && ($out['http_code']??0)===422 && preg_match('/^55([1-9][0-9])9([6-9][0-9]{7})$/',ltrim($to,'+'),$mm)) {
            $alt=$payload; $alt['to']='55'.$mm[1].$mm[2];
            $out2=$post(WFCA_Util::json($alt));
            if (!empty($out2['ok'])) { $out=$out2+['variant'=>'NO_NINTH_DIGIT']; }
            else { $out['detail']=($out['detail']??'').' | alt8: '.($out2['detail']??($out2['error']??'')); }
        }
        update_option('wfca_last_kapso_send',array_merge(['at'=>WFCA_Util::now_iso(),'to_tail'=>substr($to,-4)],$out),false);
        return $out;
    }
    /** Masks any run of 9+ digits (phones, ids), tolerating spaces/dashes/parens between digits. */
    public static function mask_nums(string $t): string {
        return (string)preg_replace_callback('/\+?\d[\d\s().\/_-]{7,}\d/',fn($x)=>strlen(preg_replace('/\D/','',$x[0]))>=9?'[num]':$x[0],preg_replace('/\+?\d{9,}/','[num]',$t));
    }
    /** Pure: extracts the provider error of a failed-message webhook (Kapso v2 or raw Meta). Never reads message text. */
    public static function failure_detail(array $p): array {
        $m=is_array($p['message']??null)?$p['message']:[];$k=is_array($m['kapso']??null)?$m['kapso']:[];
        $cands=[];
        $st=is_array($k['statuses']??null)?array_values($k['statuses']):[];
        // 10.9.26: tolerate odd shapes (errors as a single object or a string, non-scalar status) without warnings.
        $first=static fn($v)=>is_array($v)?($v[0]??$v):(is_string($v)?$v:null);
        $stt=static fn($s):string=>is_scalar($s['status']??null)?strtolower((string)$s['status']):'';
        foreach ([true,false] as $failedOnly) foreach (array_reverse($st) as $s) {
            if (!is_array($s) || ($failedOnly && $stt($s)!=='failed')) continue;
            if (!$failedOnly && $stt($s)==='failed') continue;
            $cands[]=$first($s['errors']??null)??($s['error']??null);
        }
        $cands[]=$first($m['errors']??null);$cands[]=$first($k['errors']??null);$cands[]=$m['error']??null;$cands[]=$k['error']??null;$cands[]=$k['status_details']??null;
        $cands[]=$first($p['entry'][0]['changes'][0]['value']['statuses'][0]['errors']??null);
        $cands[]=$first($p['statuses'][0]['errors']??null);
        $src=['kapso.statuses[failed]','kapso.statuses[other]','message.errors','kapso.errors','message.error','kapso.error','kapso.status_details','meta.entry','meta.value'];
        $fix=fn($v,int $n)=>mb_substr(trim(self::mask_nums(preg_replace('/\s+/',' ',is_scalar($v)?(string)$v:''))),0,$n);
        // $cands order: failed statuses..., other statuses..., then fixed slots; source label by position.
        $nf=0;$no=0;foreach ($st as $s) if (is_array($s)) { if ($stt($s)==='failed') $nf++; else $no++; }
        foreach ($cands as $i=>$e) {
            if ($e===null||$e===''||$e===[]) continue;
            if (is_string($e)) $e=['title'=>$e];
            if (!is_array($e)) continue;
            $dt=$e['error_data']['details']??($e['details']??'');
            $r=['code'=>$fix($e['code']??'',20),'title'=>$fix($e['title']??'',80),'message'=>$fix($e['message']??($e['detail']??''),160),'details'=>$fix($dt,120)];
            if ($r['title']===''&&$r['message']!==''&&$r['code']==='') { $r['title']=mb_substr($r['message'],0,80);$r['message']=''; }
            if ($r['code']===''&&$r['title']===''&&$r['message']===''&&$r['details']==='') continue;
            $j=$i<$nf?0:($i<$nf+$no?1:$i-$nf-$no+2);
            $r['source']=$src[min($j,count($src)-1)];
            return $r;
        }
        return ['code'=>'','title'=>'','message'=>'','details'=>'','source'=>'none'];
    }
    public static function normalize(array $p,string $event): array {
        $m=$p['message']??[];$k=$m['kapso']??[];$sender=(string)($p['phone_number_id']??'');
        if ($sender==='' || $sender!==(string)WFCA_Util::c('WFCA_KAPSO_PHONE_NUMBER_ID','')) return ['ok'=>false,'error'=>'SENDER_MISMATCH'];
        $origin=(string)($k['origin']??'');$direction=(string)($k['direction']??'');
        $sid=(string)($m['id']??'');$ts=(string)($m['timestamp']??'');
        if ($sid==='' || strlen($sid)>191 || !ctype_digit($ts) || (int)$ts>time()+300) return ['ok'=>false,'error'=>'INVALID_MESSAGE_ID_OR_TIMESTAMP'];
        $phone=WFCA_Util::normalize_phone((string)($p['conversation']['phone_number']??($direction==='inbound'?($m['from']??''):($m['to']??''))));
        $type=(string)($m['type']??'');
        $body=(string)($m['text']['body']??$m['interactive']['button_reply']['title']??$m['interactive']['list_reply']['title']??'');
        $media=(!empty($k['has_media']) || in_array($type,['image','video','audio','document','sticker'],true))?[['type'=>$type,'id'=>(string)($m[$type]['id']??'')]]:[];
        if (!in_array($event,['whatsapp.message.received','whatsapp.message.sent','whatsapp.message.delivered','whatsapp.message.read','whatsapp.message.failed'],true)) return ['ok'=>false,'error'=>'UNSUPPORTED_EVENT'];
        if (($event==='whatsapp.message.received' && $direction!=='inbound') || ($event!=='whatsapp.message.received' && $direction!=='outbound')) return ['ok'=>false,'error'=>'EVENT_DIRECTION_MISMATCH'];
        // 10.9.26: a failed delivery body is ALWAYS the provider error (never the message text). Kapso v2 nests it in kapso.statuses[].errors[].
        if ($event==='whatsapp.message.failed') {
            $d=self::failure_detail($p);
            if ($d['code']!==''||$d['title']!==''||$d['message']!==''||$d['details']!=='') {
                $body='WA_ERR code='.$d['code'].' title='.$d['title'].($d['message']!==''?' msg='.$d['message']:'').($d['details']!==''?' details='.$d['details']:'');
            } else {
                $ls=(isset($k['statuses'])&&is_array($k['statuses'])&&$k['statuses'])?end($k['statuses']):[];
                $keys=fn($a)=>implode(',',array_slice(array_map('strval',array_keys((array)$a)),0,12));
                $body='WA_ERR NO_DETAIL m_keys='.$keys($m).' k_keys='.$keys($k).' s_keys='.$keys($ls);
            }
            $body=self::mask_nums($body);
        }
        $status='RECEIVED';$kind='MESSAGE';
        if ($origin==='history_sync') { $status='IGNORED_HISTORY';$kind='HISTORY'; }
        elseif ($phone==='') { $status='HOLD';$kind='IDENTITY_WITHOUT_PHONE'; }
        elseif ($direction==='outbound') {
            if ($origin==='business_app') {
                // A manual reply is a 'sent' event that carries a human message (text or media). Status events and empty echoes
                // (delivered/read/failed, no body) must NEVER flip the conversation to DANIEL and silence Luna.
                if ($event==='whatsapp.message.sent' && ($body!=='' || $media)) $kind='MANUAL_OUTBOUND';
                else { $status='IGNORED_STATUS_ECHO';$kind='STATUS_ECHO'; }
            } else $kind='DELIVERY_'.strtoupper(substr($event,strrpos($event,'.')+1));
        }
        elseif (!in_array($type,['text','interactive','image','video','audio','document','sticker'],true)) { $status='HOLD';$kind='UNSUPPORTED_MESSAGE'; }
        if (!in_array($origin,['cloud_api','business_app','history_sync'],true)) { $status='HOLD';$kind='UNKNOWN_ORIGIN'; }
        // Message key, not HTTP batch key: retries and batch fallback deduplicate identically.
        $key='KAPSO:'.hash('sha256',$sender.'|'.$event.'|'.$sid.'|'.$origin);
        return ['ok'=>true,'data'=>['event_id'=>$key,'message_sid'=>$sid,'phone'=>$phone,'body'=>WFCA_Util::short_text($body,4000),
            'media'=>$media,'direction'=>strtoupper($direction),'provider'=>'KAPSO','event_type'=>$kind,
            'status'=>$status,'origin'=>$origin,'sender_id'=>$sender,'occurred_at'=>gmdate('Y-m-d H:i:s',(int)$ts),
            'payload_hash'=>hash('sha256',WFCA_Util::json($p)),'signature_status'=>'VALID']];
    }
}
