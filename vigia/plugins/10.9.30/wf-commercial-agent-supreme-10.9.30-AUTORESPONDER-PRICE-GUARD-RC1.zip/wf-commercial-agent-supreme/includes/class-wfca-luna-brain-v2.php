<?php
if (!defined('ABSPATH')) exit;

/**
 * Luna Sales Brain V2 runtime adapter.
 *
 * This is intentionally a compact decision-support layer, not a pasted book corpus.
 * It retrieves a few paraphrased mechanism cards from the packaged V2 library,
 * exposes deterministic hard-risk hints, and records bounded metadata-only telemetry.
 */
final class WFCA_Luna_Brain_V2 {
    public const VERSION = 'LUNA_SALES_BRAIN_V2_CURRENT';
    private const TELEMETRY_OPTION = 'wfca_luna_brain_v2_telemetry';
    private static ?array $tactics = null;
    private static ?array $objections = null;

    private static function norm(string $text): string {
        if (class_exists('WFCA_Util') && method_exists('WFCA_Util','normalize_text')) $text=WFCA_Util::normalize_text($text);
        else {
            $text=strip_tags($text);
            $text=function_exists('mb_strtolower')?mb_strtolower($text,'UTF-8'):strtolower($text);
        }
        $map=['á'=>'a','à'=>'a','ã'=>'a','â'=>'a','ä'=>'a','é'=>'e','è'=>'e','ê'=>'e','ë'=>'e','í'=>'i','ì'=>'i','î'=>'i','ï'=>'i','ó'=>'o','ò'=>'o','õ'=>'o','ô'=>'o','ö'=>'o','ú'=>'u','ù'=>'u','û'=>'u','ü'=>'u','ç'=>'c'];
        $text=strtr($text,$map);
        $text=preg_replace('/\s+/u',' ',trim($text));
        return (string)$text;
    }

    private static function load_json(string $relative): array {
        $base=defined('WFCA_DIR')?WFCA_DIR:dirname(__DIR__).'/';
        $path=$base.'brain/'.$relative;
        if (!is_readable($path)) return [];
        $decoded=json_decode((string)file_get_contents($path),true);
        return is_array($decoded)?$decoded:[];
    }

    private static function tactics(): array {
        if (self::$tactics!==null) return self::$tactics;
        $raw=self::load_json('tactic-library.json');
        $out=[];
        foreach (($raw['cards']??[]) as $card) {
            if (!is_array($card)) continue;
            $id=strtoupper(trim((string)($card['id']??'')));
            if (!preg_match('/^[A-Z]{2,4}-\d{3}$/',$id)) continue;
            $out[$id]=$card;
        }
        return self::$tactics=$out;
    }

    private static function objections(): array {
        if (self::$objections!==null) return self::$objections;
        $raw=self::load_json('objection-matrix.json');
        $out=[];
        foreach (($raw['rows']??[]) as $row) {
            if (!is_array($row)) continue;
            $id=strtoupper(trim((string)($row['id']??'')));
            if (!preg_match('/^OBJ-\d{3}$/',$id)) continue;
            $out[$id]=$row;
        }
        return self::$objections=$out;
    }

    public static function health(): array {
        return [
            'version'=>self::VERSION,
            'tactic_cards'=>count(self::tactics()),
            'objection_rows'=>count(self::objections()),
            'telemetry_mode'=>'bounded_metadata_only',
        ];
    }

    private static function has(string $t,array $needles): bool {
        foreach($needles as $n) if($n!=='' && str_contains($t,self::norm((string)$n))) return true;
        return false;
    }

    private static function regex(string $t,string $pattern): bool {
        return (bool)preg_match($pattern,$t);
    }

    private static function add_tactics(array &$ids,array $more): void {
        foreach($more as $id){
            $id=strtoupper(trim((string)$id));
            if(isset(self::tactics()[$id]) && !in_array($id,$ids,true)) $ids[]=$id;
            if(count($ids)>=4) break;
        }
    }

    /**
     * Conservative message/state analysis used before model generation.
     * It never authorizes sending; existing backend gates remain sovereign.
     */
    public static function analyze(string $message,array $lead=[],array $conversation=[],array $thread=[]): array {
        $t=self::norm($message);
        $actor='unknown';$stage='D0';$intent='unknown';$objection='NONE';$tactics=[];$hard='NONE';$handoff=false;$terminal=false;
        $forbidden=[];

        $is_bot=self::has($t,['sou um bot','resposta automatica','mensagem automatica','assistente virtual automatico','digite 1','opcao 1']);
        $is_gate=self::has($t,['sou a secretaria','sou secretaria','secretaria','recepcao','recepcionista','fale com a doutora','fala com a doutora','fale com o doutor','fala com o doutor','gestor decide','ela decide','ele decide']);
        if($is_bot){$actor='bot';$stage='routing';$intent='routing';$objection='OBJ-009';self::add_tactics($tactics,['GT-001','DF-001','PR-001']);}
        elseif($is_gate){$actor='human_gatekeeper';$stage='routing';$intent='routing';$objection='OBJ-008';self::add_tactics($tactics,['GT-001','FR-001','CQ-001']);}
        else $actor='human_decisor';

        $optout=self::has($t,['pare de me chamar','pare de me mandar','pare de enviar','nao me chame','nao mande mais','nao quero receber mais mensagens','nao quero receber mensagens','quero sair','cancelar contato','stop']);
        if($optout){
            return ['actor'=>$actor,'stage'=>'terminal','intent'=>'opt_out','objection_id'=>'OBJ-001','candidate_tactic_ids'=>['HN-001'],'hard_gate'=>'OPT_OUT','human_handoff'=>false,'terminal'=>true,'forbidden'=>['rebuttal','last_offer','new_channel'],'next_step'=>'stop_all_automated_commercial_contact'];
        }

        $clear_no=self::has($t,['nao tenho interesse','sem interesse','nao quero contratar','nao quero comprar','nao precisamos disso']);
        if($clear_no){$stage='terminal';$intent='clear_no';$objection='OBJ-001';$terminal=true;self::add_tactics($tactics,['HN-001','SW-001']);$forbidden=['rebuttal','guilt','last_offer'];}

        $payment_mismatch=self::has($t,['valor mudou','checkout mudou','cobranca diferente','cobrança diferente','valor do checkout','preco do checkout diferente','preço do checkout diferente']);
        $complaint=self::has($t,['estou irritado','estou irritada','prometeram retorno','ninguem respondeu','ninguém respondeu','reclamacao','reclamação']);
        $safety=self::has($t,['emergencia medica','emergência médica','urgencia medica','urgência médica']);
        if($payment_mismatch){$stage='handoff';$intent='payment_mismatch';$hard='PAYMENT_MISMATCH';$handoff=true;self::add_tactics($tactics,['RR-001','CL-001']);$forbidden=['charge_anyway','pressure'];}
        elseif($complaint){$stage='handoff';$intent='complaint';$hard='COMPLAINT';$handoff=true;self::add_tactics($tactics,['TE-001','SW-001']);$forbidden=['sales_pitch','deflect_blame'];}
        elseif($safety){$stage='handoff';$intent='safety';$hard='SAFETY_OUT_OF_SCOPE';$handoff=true;$forbidden=['sales_pitch','medical_advice'];}

        if($hard==='NONE' && !$terminal){
            if(self::has($t,['diz que voce e paciente','diz que você é paciente','finja ser paciente','se passe por paciente'])){
                $intent='unsafe_instruction';$stage='routing';self::add_tactics($tactics,['GT-001','HN-001']);$forbidden=['deception','patient_pretence'];
            }
            elseif(self::has($t,['quero pagar','manda o checkout','me manda o checkout','manda o pagamento','quero fechar','vamos fechar'])){
                $intent='checkout';$stage='checkout';$objection='OBJ-012';self::add_tactics($tactics,['CL-001','RR-001','DF-001']);
            }
            elseif(self::has($t,['marcar uma conversa','marcar uma reuniao','marcar uma reunião','marcar uma call','agendar uma call','agendar uma reuniao','agendar uma reunião'])){
                $intent='meeting';$stage='diagnosis';$objection='OBJ-011';self::add_tactics($tactics,['CL-001','DG-001','FR-001']);
            }
            elseif(self::has($t,['esta caro','está caro','90% de desconto','desconto','melhor valor'])){
                $intent='price_objection';$stage='pricing';$objection='OBJ-006';self::add_tactics($tactics,self::has($t,['90%','desconto'])?['NG-001','AN-001','PRC-001']:['TE-001','PRC-001','NG-001']);
            }
            elseif(self::regex($t,'/\b(quanto|valor|preco|preço|custa|investimento|parcel|melhor valor)\b/u')){
                $intent='price';$stage='pricing';self::add_tactics($tactics,['PRC-001','DF-001','RR-001']);
            }
            elseif(self::has($t,['ja temos site','já temos site'])){
                $intent='status_quo';$stage='discovery';$objection='OBJ-002';self::add_tactics($tactics,['TE-001','CQ-001','GP-001']);
            }
            elseif(self::has($t,['temos agencia','temos agência','ja tenho fornecedor','já tenho fornecedor','ja temos fornecedor','já temos fornecedor'])){
                $intent='status_quo';$stage='discovery';$objection='OBJ-014';self::add_tactics($tactics,['TE-001','GP-001','CT-001']);
            }
            elseif(self::has($t,['nao e prioridade','não é prioridade'])){
                $intent='timing';$stage='nurture';$objection='OBJ-003';self::add_tactics($tactics,['TE-001','TM-001','SW-001']);
            }
            elseif(self::has($t,['vou pensar'])){
                $intent='objection';$stage='negotiation';$objection='OBJ-004';self::add_tactics($tactics,['TE-001','CQ-001','RR-001','SW-001']);
            }
            elseif(self::has($t,['manda informacoes','manda informações','pode enviar um resumo','me manda todos os cases','manda todos os cases','pdfs, links e precos'])){
                $intent='information';$stage=$is_gate?'routing':'D0';$objection='OBJ-005';self::add_tactics($tactics,['DF-001','GT-001','PF-001','CQ-001']);
            }
            elseif(self::has($t,['quem indicou voces','quem indicou vocês','por que confiar','quem e voce','quem é você'])){
                $intent='trust';$stage='discovery';$objection='OBJ-007';self::add_tactics($tactics,['AU-001','PF-001','FR-001']);
            }
            elseif(self::has($t,['estou sem tempo','to sem tempo','tô sem tempo','estou viajando','depois vejo','agora nao','agora não','fim do mes','fim do mês'])){
                $intent='timing';$stage='nurture';$objection='OBJ-010';self::add_tactics($tactics,['TM-001','SW-001','DF-001']);
            }
            elseif(self::has($t,['nao entendi o que voces fazem','não entendi o que vocês fazem','nao entendi','não entendi'])){
                $intent='information';$stage='D0';$objection='OBJ-015';self::add_tactics($tactics,['DF-001','FR-001','CU-001']);
            }
            elseif(self::has($t,['garantem que vou ter pacientes','garante pacientes','garantem pacientes'])){
                $intent='risk';$stage='negotiation';self::add_tactics($tactics,['RR-001','PF-001','DG-001']);$forbidden=['guarantee_sales','medical_claim'];
            }
            elseif(self::has($t,['nao sei se o problema e o site','não sei se o problema é o site'])){
                $intent='diagnosis';$stage='discovery';self::add_tactics($tactics,['DG-001','GP-001','TE-001']);
            }
            elseif(self::has($t,['nao temos site','não temos site','dependemos so de indicacao','dependemos só de indicação','quase ninguem chama','quase ninguém chama'])){
                $intent='diagnosis';$stage='discovery';self::add_tactics($tactics,['DG-001','GP-001','LA-001']);
            }
            elseif(self::has($t,['inferior porque nao conhece','inferior porque não conhece','nao conhece o nosso mercado','não conhece o nosso mercado'])){
                $intent='trust';$stage='discovery';self::add_tactics($tactics,['TE-001','CQ-001','AU-001']);$forbidden=['counterattack','fake_expertise'];
            }
            elseif(self::has($t,['perder todos os pacientes','vai perder todos os pacientes'])){
                $intent='unsupported_urgency';$stage='negotiation';self::add_tactics($tactics,['LA-001','RR-001','NG-001']);$forbidden=['false_scarcity','catastrophe','pressure'];
            }
            elseif(self::has($t,['concorrente cobra metade','igualem ou acabou'])){
                $intent='negotiation';$stage='negotiation';self::add_tactics($tactics,['NG-001','PRC-001','CT-001']);$forbidden=['attack_competitor','match_without_scope'];
            }
            elseif($intent==='unknown'){
                $intent='information';$stage='D0';self::add_tactics($tactics,['FR-001','DF-001','CQ-001']);
            }
        }

        if(!$tactics) self::add_tactics($tactics,['FR-001','DF-001']);
        return ['actor'=>$actor,'stage'=>$stage,'intent'=>$intent,'objection_id'=>$objection,'candidate_tactic_ids'=>$tactics,'hard_gate'=>$hard,'human_handoff'=>$handoff,'terminal'=>$terminal,'forbidden'=>$forbidden,'next_step'=>'one_proportionate_next_step'];
    }

    public static function prompt_context(string $message,array $lead=[],array $conversation=[],array $thread=[]): array {
        $analysis=self::analyze($message,$lead,$conversation,$thread);
        $cards=[];
        foreach(($analysis['candidate_tactic_ids']??[]) as $id){
            $card=self::tactics()[$id]??null;
            if(!$card) continue;
            $cards[]=[
                'id'=>$id,
                'mechanism'=>(string)($card['name']??''),
                'use'=>(string)($card['description']??''),
                'contraindications'=>array_slice(array_values((array)($card['contraindications']??[])),0,3),
                'exit_conditions'=>array_slice(array_values((array)($card['exit_conditions']??[])),0,2),
            ];
        }
        return ['brain_version'=>self::VERSION,'analysis'=>$analysis,'retrieved_tactics'=>$cards];
    }

    public static function validate_tactics(array $ids,array $candidate_ids): array {
        $allowed=[];foreach($candidate_ids as $id)$allowed[strtoupper((string)$id)]=true;
        $out=[];foreach($ids as $id){$id=strtoupper(trim((string)$id));if(isset($allowed[$id])&&isset(self::tactics()[$id])&&!in_array($id,$out,true))$out[]=$id;if(count($out)>=4)break;}
        if(!$out){foreach($candidate_ids as $id){if(isset(self::tactics()[$id]))$out[]=$id;if(count($out)>=2)break;}}
        return $out;
    }

    public static function record_decision(array $lead,array $conversation,string $message,array $decision,array $brain): void {
        if(!function_exists('get_option')||!function_exists('update_option')) return;
        $ring=get_option(self::TELEMETRY_OPTION,[]);if(!is_array($ring))$ring=[];
        $analysis=$brain['analysis']??[];
        $ring[]=[
            'at'=>gmdate('c'),
            'lead_id'=>(string)($lead['id']??''),
            'conversation_id'=>(int)($conversation['id']??0),
            'message_sha256'=>hash('sha256',$message),
            'actor'=>(string)($decision['actor']??($analysis['actor']??'unknown')),
            'stage'=>(string)($decision['stage']??($analysis['stage']??'D0')),
            'intent'=>(string)($decision['intent']??($analysis['intent']??'unknown')),
            'objection_id'=>(string)($decision['objection_id']??($analysis['objection_id']??'NONE')),
            'tactics'=>array_values((array)($decision['selected_tactic_ids']??($analysis['candidate_tactic_ids']??[]))),
            'action'=>(string)($decision['action']??'HANDOFF'),
            'confidence'=>(float)($decision['confidence']??0),
            'human_handoff'=>!empty($decision['human_handoff']) || (($decision['action']??'')==='HANDOFF'),
        ];
        if(count($ring)>100)$ring=array_slice($ring,-100);
        update_option(self::TELEMETRY_OPTION,$ring,false);
    }

    public static function last_telemetry(): array {
        if(!function_exists('get_option')) return [];
        $ring=get_option(self::TELEMETRY_OPTION,[]);if(!is_array($ring)||!$ring)return [];
        $last=end($ring);return is_array($last)?$last:[];
    }
}
