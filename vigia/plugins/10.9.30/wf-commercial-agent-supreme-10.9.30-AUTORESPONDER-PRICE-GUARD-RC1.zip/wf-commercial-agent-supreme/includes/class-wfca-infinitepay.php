<?php
if (!defined('ABSPATH')) exit;

final class WFCA_InfinitePay {
    public static function ready(): bool {
        $handle=trim((string)WFCA_Util::c('WFCA_INFINITEPAY_HANDLE',''));
        return $handle!=='' && strlen($handle)<=120;
    }

    public static function webhook_url(): string {
        $override=trim((string)WFCA_Util::c('WFCA_INFINITEPAY_WEBHOOK_URL',''));
        return $override!==''?$override:rest_url(WFCA_NS.'/commercial/infinitepay-webhook');
    }

    public static function last_transport(): array {
        $v=get_option('wfca_last_infinitepay_transport',[]);
        return is_array($v)?$v:[];
    }

    public static function create_link(string $order_nsu, string $description, int $amount_cents, string $phone=''): array {
        if (!self::ready()) return ['ok'=>false,'error'=>'INFINITEPAY_HANDLE_MISSING'];
        if ($order_nsu==='' || strlen($order_nsu)>191) return ['ok'=>false,'error'=>'INVALID_ORDER_NSU'];
        if ($amount_cents<=0) return ['ok'=>false,'error'=>'INVALID_AMOUNT'];

        $payload = [
            'handle'=>(string)WFCA_Util::c('WFCA_INFINITEPAY_HANDLE',''),
            'order_nsu'=>$order_nsu,
            'webhook_url'=>self::webhook_url(),
            'items'=>[[
                'quantity'=>1,
                'price'=>$amount_cents,
                'description'=>WFCA_Util::short_text($description,180),
            ]]
        ];
        $redirect = trim((string)WFCA_Util::c('WFCA_INFINITEPAY_REDIRECT_URL',''));
        if ($redirect !== '' && filter_var($redirect,FILTER_VALIDATE_URL)) $payload['redirect_url']=$redirect;
        $normalized=WFCA_Util::normalize_phone($phone);
        if ($normalized !== '') $payload['customer']=['phone_number'=>$normalized];

        $res=wp_remote_post('https://api.checkout.infinitepay.io/links',[
            'timeout'=>20,
            'redirection'=>3,
            'headers'=>['Content-Type'=>'application/json'],
            'body'=>WFCA_Util::json($payload),
        ]);
        if (is_wp_error($res)) {
            $err=WFCA_Util::redact_error($res->get_error_message());
            self::record(false,'CREATE_LINK',0,$err);
            return ['ok'=>false,'error'=>$err];
        }
        $code=wp_remote_retrieve_response_code($res);
        $data=json_decode(wp_remote_retrieve_body($res),true);
        $url=(string)($data['url']??'');
        if ($code<200 || $code>=300 || !filter_var($url,FILTER_VALIDATE_URL)) {
            $err='INFINITEPAY_HTTP_'.$code.($url===''?':MISSING_URL':'');
            self::record(false,'CREATE_LINK',$code,$err);
            return ['ok'=>false,'error'=>$err,'http_code'=>$code];
        }
        self::record(true,'CREATE_LINK',$code,'');
        return ['ok'=>true,'url'=>$url];
    }

    public static function payment_check(string $order_nsu, string $transaction_nsu, string $slug): array {
        if (!self::ready()) return ['ok'=>false,'error'=>'INFINITEPAY_HANDLE_MISSING'];
        if ($order_nsu==='' || $transaction_nsu==='' || $slug==='') return ['ok'=>false,'error'=>'PAYMENT_CHECK_IDENTIFIERS_MISSING'];
        $payload=[
            'handle'=>(string)WFCA_Util::c('WFCA_INFINITEPAY_HANDLE',''),
            'order_nsu'=>$order_nsu,
            'transaction_nsu'=>$transaction_nsu,
            'slug'=>$slug,
        ];
        $res=wp_remote_post('https://api.checkout.infinitepay.io/payment_check',[
            'timeout'=>20,
            'redirection'=>3,
            'headers'=>['Content-Type'=>'application/json'],
            'body'=>WFCA_Util::json($payload),
        ]);
        if (is_wp_error($res)) {
            $err=WFCA_Util::redact_error($res->get_error_message());
            self::record(false,'PAYMENT_CHECK',0,$err);
            return ['ok'=>false,'error'=>$err];
        }
        $code=wp_remote_retrieve_response_code($res);
        $data=json_decode(wp_remote_retrieve_body($res),true);
        if ($code<200 || $code>=300 || !is_array($data)) {
            $err='INFINITEPAY_HTTP_'.$code;
            self::record(false,'PAYMENT_CHECK',$code,$err);
            return ['ok'=>false,'error'=>$err,'http_code'=>$code];
        }
        if (array_key_exists('success',$data) && !$data['success']) {
            $err='INFINITEPAY_PAYMENT_CHECK_SUCCESS_FALSE';
            self::record(false,'PAYMENT_CHECK',$code,$err);
            return ['ok'=>false,'error'=>$err,'data'=>$data];
        }
        self::record(true,'PAYMENT_CHECK',$code,'');
        return ['ok'=>true,'data'=>$data];
    }

    private static function record(bool $ok,string $operation,int $http_code,string $error): void {
        update_option('wfca_last_infinitepay_transport',[
            'at'=>WFCA_Util::now_iso(),
            'ok'=>$ok,
            'operation'=>$operation,
            'http_code'=>$http_code,
            'error'=>$error!==''?WFCA_Util::redact_error($error):'',
        ],false);
    }
}
