SYSTEM GREEN CANDIDATE — COMMERCIAL 10.9.0-MEDIA-FOLLOWUP

Built from 10.8.0-WEEKLY-POLICY with a deliberately narrow change surface.

UNCHANGED CORE
- Transactional outbox and lifetime D0 idempotency.
- Canonical +55 identity and owner-revision fencing.
- Opt-out, payment-terminal and human-handoff fences.
- Weekly commercial policy, windows and strict spacing.
- Ambiguous-send no-retry behavior.
- Kapso webhook verification and InfinitePay truth.

NEW, DORMANT-BY-DEFAULT CAPABILITIES
- Dynamic per-lead IMAGE header for INITIAL template.
- Same-lead media URL + SHA binding checked again immediately before provider send.
- Provider-approved D0 follow-up template using Lead + Follow-up Insight + Site URL.
- New inbound cancels the pending no-inbound follow-up.

This plugin does NOT generate screenshots. Factory/Cloudflare remains the upstream screenshot producer and Airtable remains the business-state source of truth.
