Website Factory — Commercial Agent 10.9.4-AUTONOMY-DELIVERY-RC1
STATUS: OFFLINE VALIDATED CANDIDATE; NOT DEPLOYED; LIVE ACCEPTANCE REQUIRED.
Exact parent: 10.9.3-IDEMPOTENT-REDRIVE-RC1.
Schema remains 10.4.0.

This release is a scoped Gate19 repair only:
- sanitizes technical Factory observation telemetry into a grounded commercial observation for media_v1 without modifying source evidence;
- adds native WAITING_REPLY -> due FOLLOWUP_SCHEDULED materialization with one-at-a-time safety/idempotency fences;
- distinguishes sent-stage from recipient DELIVERED/READ truth.

Read PATCH-NOTES-10.9.4.txt and QA-REPORT-10.9.4.txt.
Prior release notes/reports remain bundled as historical parent evidence.
