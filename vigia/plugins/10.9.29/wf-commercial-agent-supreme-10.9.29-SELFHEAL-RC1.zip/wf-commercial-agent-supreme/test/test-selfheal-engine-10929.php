<?php
// 10.9.29: stall diagnosis (item 2), ambiguous Kapso result (item 4), hardened reconciler (item 5), D0 scheduler hygiene (item 6).
// Offline: real WFCA_Util + WFCA_Engine, in-memory stubs for DB/Airtable/Alerts/Ownership/Kapso.
define('ABSPATH', __DIR__.'/');
define('ARRAY_A','ARRAY_A');
$GLOBALS['opts']=[];
foreach (['wp_strip_all_tags','sanitize_email','is_email','apply_filters','wp_json_encode','home_url','esc_url_raw'] as $fn) { if(!function_exists($fn)) { eval('function '.$fn.'(...$a){return $a[0]??"";}'); } }
function get_option($k,$d=false){return $GLOBALS['opts'][$k]??$d;}
function update_option($k,$v,$a=null){$GLOBALS['opts'][$k]=$v;return true;}
final class WFCA_Alerts { public static $raised=[]; public static $resolved=[]; public static function raise(...$a){self::$raised[]=$a;return 1;} public static function resolve_source($k){self::$resolved[]=$k;} public static function ring_tail($n=10){return [];} }
final class WFCA_Kapso { public static function template_spec($k){return ['name'=>'d0_media_v1','variables'=>['lead_name']];} }
final class WFCA_Airtable {
  public static $cfg=[]; public static $updates=[]; public static $touches=[]; public static $stuck=['ok'=>true,'data'=>['records'=>[]]];
  public static $draining=false; public static $mode='LIVE'; public static $eligible=['ok'=>true,'data'=>['records'=>[]]]; public static $eligible_arg=null; public static $cc=['ok'=>true,'record'=>['fields'=>[]]];
  public static function config(bool $f=false): array {return self::$cfg;}
  public static function draining(): bool {return self::$draining;} public static function base_mode(): string {return self::$mode;}
  public static function eligible_conversations_for_initial(int $m): array {self::$eligible_arg=$m;return self::$eligible;}
  public static function get_commercial_conversation(string $p): array {return self::$cc;}
  public static function update_commercial_by_phone(string $p,array $f): array {self::$updates[]=[$p,$f];return ['ok'=>true];}
  public static function log_touch(...$a): array {self::$touches[]=$a;return ['ok'=>true];}
  public static function stuck_followup_scheduled(string $c,int $m=5): array {return self::$stuck;}
  public static function get_lead(string $id): array {return ['ok'=>false];}
  public static $waiting=[]; public static $waiting_args=[];
  public static function waiting_followup_candidates(int $m=100,string $after=''): array {self::$waiting_args[]=$after;return ['ok'=>true,'data'=>['records'=>self::$waiting]];}
}
final class WFCA_Ownership {
  public static $changes=[]; public static $syncs=[]; public static $change_ok=true;
  public static function arm(string $a): string {return $a;} public static function remote_arm(string $a): string {return $a;} public static function is_only_daniel(string $a): bool {return $a==='DANIEL_CALL';}
  public static function queue_status(): string {return 'PENDING';}
  public static function change(int $id,string $owner,string $reason,int $exp,bool $explicit=false){ self::$changes[]=[$id,$owner,$reason,$exp,$explicit]; if(!self::$change_ok) return ['ok'=>false,'error'=>'REMOTE_RESUME_BLOCKED']; WFCA_DB::$convs[$id]['conversation_owner']=$owner; WFCA_DB::$convs[$id]['owner_revision']=$exp+1; return ['ok'=>true,'revision'=>$exp+1]; }
  public static function sync(int $id){ self::$syncs[]=$id; return true; }
}
final class WFCA_DB {
  public static $convs=[]; public static $out=[]; public static $queued=[]; public static $failed_by=[]; public static $resets=[]; public static $payment=[]; public static $last_d0=0; public static $latest_initial=null; public static $used=0;
  public static function t($n){return 'wp_wfca_'.$n;}
  public static function get_conversation(int $id): ?array {return self::$convs[$id]??null;}
  public static function get_conversation_by_phone(string $p): ?array {foreach(self::$convs as $c) if($c['phone_e164']===$p) return $c; return null;}
  public static function get_outbox_by_idempotency_key(string $k): ?array {return self::$out[$k]??null;}
  public static function get_outbox(int $id): ?array {foreach(self::$out as $r) if((int)$r['id']===$id) return $r; return null;}
  public static function queue(array $i): int {$id=count(self::$out)+100;$i['id']=$id;self::$out[$i['idempotency_key']]=$i;self::$queued[]=$i;return $id;}
  public static function upsert_conversation(string $p,array $f): array {foreach(self::$convs as $id=>$c) if($c['phone_e164']===$p){self::$convs[$id]=array_merge($c,$f);return self::$convs[$id];} return [];}
  // the real query: handoffs still waiting (owner HANDOFF_PENDING) => a restored conversation is NOT a candidate any more
  public static function transient_handoff_candidates(int $l): array {return array_values(array_filter(self::$convs,fn($c)=>($c['conversation_owner']??'')==='HANDOFF_PENDING'&&($c['state']??'')==='HUMAN_HANDOFF'&&str_starts_with((string)($c['owner_reason']??''),'OUTBOX_FAILED:')));}
  public static function has_terminal_payment(int $c): bool {return !empty(self::$payment[$c]);}
  public static function latest_failed_outbox(int $c): ?array {return self::$failed_by[$c]??null;}
  public static function reset_failed_outbox(int $id,int $rev,string $st,string $note): bool {foreach(self::$failed_by as $c=>&$r) if($r['id']===$id && $r['status']==='FAILED'){$r['status']='PENDING';self::$resets[]=[$id,$rev,$st,$note];return true;} return false;}
  public static function last_proactive_sent_ts(string $a): int {return self::$last_d0;}
  public static function latest_initial_contact_at(): ?string {return self::$latest_initial;}
  public static function count_initial_queued_in_range(string $a,string $b): int {return self::$used;}
  // ambiguous D0 helpers (same predicates as the SQL)
  public static function ambiguous_d0_candidates(int $older,int $limit): array {$o=[];foreach(self::$out as $r){$c=self::$convs[$r['conversation_id']]??null;if($c&&$r['status']==='UNCERTAIN'&&$r['action_type']==='TEMPLATE_INITIAL'&&empty($r['provider_message_id'])&&str_starts_with((string)$r['last_error'],'AMBIGUOUS_')&&strtotime($r['updated_at'].' UTC')<$older&&!$c['human_hold']&&!$c['opt_out']&&$c['conversation_owner']==='LUNA')$o[]=$r;}return $o;}
  public static function ambiguous_d0_for_status(string $phone,int $ts,int $w=7200): ?array {$o=[];foreach(self::$out as $r){$c=self::$convs[$r['conversation_id']]??null;$st=strtotime($r['send_started_at'].' UTC');if($c&&$c['phone_e164']===$phone&&$r['status']==='UNCERTAIN'&&empty($r['provider_message_id'])&&$st<=$ts+120&&$st>=$ts-max(300,$w))$o[]=$r;}return count($o)===1?$o[0]:null;}
  public static function resolve_uncertain_outbox(int $id,string $sid): bool {foreach(self::$out as $k=>&$r) if($r['id']===$id&&$r['status']==='UNCERTAIN'&&empty($r['provider_message_id'])){$r['status']='SENT';$r['provider_message_id']=$sid;$r['sent_at']=$r['send_started_at'];$r['sync_pending']=1;return true;} return false;}
  public static function release_uncertain_outbox(int $id,string $note): bool {foreach(self::$out as $k=>&$r) if($r['id']===$id&&$r['status']==='UNCERTAIN'&&str_starts_with((string)$r['last_error'],'AMBIGUOUS_')){$r['last_error']=$note;return true;} return false;}
}
require_once __DIR__.'/../includes/class-wfca-util.php';
require_once __DIR__.'/../includes/class-wfca-engine.php';
$pass=0;$fail=0;function t($n,$c){global $pass,$fail;if($c){echo "PASS $n\n";$pass++;}else{echo "FAIL $n\n";$fail++;}}
function E($name){$m=(new ReflectionClass('WFCA_Engine'))->getMethod($name);$m->setAccessible(true);return $m;}
function stall_set(array $a){$p=(new ReflectionClass('WFCA_Engine'))->getProperty('stall');$p->setAccessible(true);$p->setValue(null,$a+['d0'=>'','fu'=>'','d0_out'=>'','fu_out'=>'','in_window'=>false,'d0_stock'=>0]);}
function reset_all(){$GLOBALS['opts']=[];WFCA_Alerts::$raised=[];WFCA_Alerts::$resolved=[];WFCA_Airtable::$updates=[];WFCA_Airtable::$touches=[];WFCA_Airtable::$cfg=[];WFCA_Airtable::$draining=false;WFCA_Airtable::$mode='LIVE';WFCA_Airtable::$eligible=['ok'=>true,'data'=>['records'=>[]]];WFCA_Airtable::$eligible_arg=null;WFCA_Airtable::$cc=['ok'=>true,'record'=>['fields'=>[]]];WFCA_Ownership::$changes=[];WFCA_Ownership::$syncs=[];WFCA_Ownership::$change_ok=true;WFCA_DB::$convs=[];WFCA_DB::$out=[];WFCA_DB::$queued=[];WFCA_DB::$failed_by=[];WFCA_DB::$resets=[];WFCA_DB::$payment=[];WFCA_DB::$last_d0=0;WFCA_DB::$latest_initial=null;WFCA_DB::$used=0;stall_set([]);}
final class FakeWpdb { public $rows=[]; public function prepare($q,...$a){return $q;} public function get_results($q,$t=null){return $this->rows;} }
$wpdb=new FakeWpdb();
$LEAD='recLEAD1';$PH='+5511999990000';
$src=file_get_contents(__DIR__.'/../includes/class-wfca-engine.php');

// ================= ITEM 2: which gate blocks the next D0
function day($on,$sp=300){return ['proactive'=>$on,'windows'=>$on?['00:00-23:59']:[],'spacing_seconds'=>$sp];}
function d0cfg($on=true,$extra=[]){$d=[];foreach(['mon','tue','wed','thu','fri','sat','sun'] as $k)$d[$k]=day($on);return $extra+['COMMERCIAL_D0_WEEKLY_SCHEDULE_V1'=>json_encode(['version'=>'COMMERCIAL_CLASS_SCHEDULE_V1','timezone'=>'America/Sao_Paulo','days'=>$d]),'COMMERCIAL_MAX_NEW_CONTACTS_DAY'=>'100'];}
$sched=E('schedule_initial_contacts');
$why=function() use ($sched){stall_set([]);$sched->invoke(null);$p=(new ReflectionClass('WFCA_Engine'))->getProperty('stall');$p->setAccessible(true);return $p->getValue()['d0'];};
reset_all();WFCA_Airtable::$draining=true;WFCA_Airtable::$cfg=d0cfg();t('stall reason DRAINING',$why()==='DRAINING');
reset_all();WFCA_Airtable::$mode='SHADOW';WFCA_Airtable::$cfg=d0cfg();t('stall reason MODE_NOT_ACTIVE',$why()==='MODE_NOT_ACTIVE');
reset_all();WFCA_Airtable::$cfg=['COMMERCIAL_D0_WEEKLY_SCHEDULE_V1'=>'{broken'];t('stall reason POLICY_INVALID (no last-known-good yet)',$why()==='POLICY_INVALID');
reset_all();WFCA_Airtable::$cfg=d0cfg(false);t('stall reason OUTSIDE_WINDOW (not a proactive day)',$why()==='OUTSIDE_WINDOW');
reset_all();WFCA_Airtable::$cfg=d0cfg();WFCA_DB::$latest_initial=gmdate('Y-m-d H:i:s',time()-5);t('stall reason SPACING_WAIT',$why()==='SPACING_WAIT');
reset_all();WFCA_Airtable::$cfg=d0cfg();$GLOBALS['opts']['wfca_d0_brake_until']=time()+600;t('stall reason BRAKE_ACTIVE',$why()==='BRAKE_ACTIVE');
reset_all();WFCA_Airtable::$cfg=d0cfg();$GLOBALS['opts']['wfca_provider_hold_until']=time()+600;t('stall reason PROVIDER_HOLD',$why()==='PROVIDER_HOLD');
reset_all();WFCA_Airtable::$cfg=d0cfg(true,['COMMERCIAL_MAX_NEW_CONTACTS_DAY'=>'5']);WFCA_DB::$used=5;t('stall reason DAILY_CAP',$why()==='DAILY_CAP');
reset_all();WFCA_Airtable::$cfg=d0cfg();t('stall reason NO_ELIGIBLE_CONVERSATION (empty stock)',$why()==='NO_ELIGIBLE_CONVERSATION'&&(int)get_option('wfca_d0_stock_seen')[0]===0);
reset_all();WFCA_Airtable::$cfg=d0cfg();WFCA_Airtable::$eligible=['ok'=>true,'data'=>['records'=>[['id'=>'recC','fields'=>['WhatsApp Permission Status'=>'OPTED_IN','Lead'=>['recL'],'Phone E164'=>$PH]]]]];
t('stall reason CANDIDATES_REJECTED (stock exists, nothing passes) and the stock is recorded',$why()==='CANDIDATES_REJECTED'&&(int)get_option('wfca_d0_stock_seen')[0]===1);
reset_all();WFCA_Airtable::$cfg=d0cfg(true,['COMMERCIAL_MAX_NEW_CONTACTS_DAY'=>'4']);$why();
t('eligible page is never smaller than d0_eligible_page_size (50): 3 permanently-rejected records can not starve the rest near the daily cap',WFCA_Airtable::$eligible_arg===50);
reset_all();WFCA_Airtable::$cfg=d0cfg(true,['COMMERCIAL_MAX_NEW_CONTACTS_DAY'=>'4','WFCA_RULES_V1'=>'{"d0_eligible_page_size":80}']);$why();
t('page size is configurable',WFCA_Airtable::$eligible_arg===80);
t('pre-existing hold gate text kept (10.9.28 test anchor)',str_contains($src,'if (WFCA_Util::provider_hold_remaining()>0) return; // 10.9.28'));

// ---- stall_diag: age, window clock, CRITICAL once, resolution
$sd=E('stall_diag');$now=time();
reset_all();WFCA_DB::$last_d0=$now-120;stall_set(['d0'=>'SPACING_WAIT','in_window'=>true,'d0_stock'=>5]);update_option('wfca_d0_stock_seen',[5,$now]);
$o=$sd->invoke(null,WFCA_Util::rules(),$now);
t('d0_age_s = seconds since the last D0 (120) and the reason is exposed',$o['d0_age_s']===120&&$o['d0_stall_reason']==='SPACING_WAIT'&&!WFCA_Alerts::$raised);
reset_all();WFCA_DB::$last_d0=0;$o=$sd->invoke(null,WFCA_Util::rules(),$now);
t('never sent => d0_age_s -1; value cached in an option (no table scan every tick)',$o['d0_age_s']===-1&&get_option('wfca_last_d0_sent_ts')===0);
// window opens at 08:00 with yesterday's last D0: no false alarm
reset_all();WFCA_DB::$last_d0=$now-14*3600;update_option('wfca_d0_stock_seen',[8,$now]);
stall_set(['d0'=>'CANDIDATES_REJECTED','in_window'=>true,'d0_stock'=>8]);
$o=$sd->invoke(null,WFCA_Util::rules(),$now);
t('first tick of the window: 14 h since last D0 but the clock starts at window open => no alert',$o['d0_stall_age_s']<5&&!WFCA_Alerts::$raised);
$later=$now+901;$o=$sd->invoke(null,WFCA_Util::rules(),$later);
t('15 min inside the window, stock, nothing sent, reason not legitimate => ONE CRITICAL',count(WFCA_Alerts::$raised)===1&&WFCA_Alerts::$raised[0][1]==='CRITICAL'&&str_contains((string)WFCA_Alerts::$raised[0][0],'D0_STALL:CANDIDATES_REJECTED')&&$o['d0_stalled']===true);
$sd->invoke(null,WFCA_Util::rules(),$later+60);$sd->invoke(null,WFCA_Util::rules(),$later+120);
t('not repeated every tick',count(WFCA_Alerts::$raised)===1);
WFCA_DB::$last_d0=$later+130;update_option('wfca_last_d0_sent_ts',$later+130);
$o=$sd->invoke(null,WFCA_Util::rules(),$later+140);
t('a D0 goes out => episode resolved',$o['d0_stalled']===false&&count(WFCA_Alerts::$resolved)===1&&str_starts_with(WFCA_Alerts::$resolved[0],'d0-stall:'));
foreach (['OUTSIDE_WINDOW','BRAKE_ACTIVE','PROVIDER_HOLD','DRAINING','MODE_NOT_ACTIVE','DAILY_CAP','NO_ELIGIBLE_CONVERSATION'] as $legit) {
  reset_all();WFCA_DB::$last_d0=$now-5000;update_option('wfca_d0_stock_seen',[8,$now]);update_option('wfca_d0_window_since',$now-5000);
  stall_set(['d0'=>$legit,'in_window'=>true,'d0_stock'=>8]);$sd->invoke(null,WFCA_Util::rules(),$now);
  t("legitimate reason $legit never alerts",!WFCA_Alerts::$raised);
}
reset_all();WFCA_DB::$last_d0=$now-5000;update_option('wfca_d0_stock_seen',[0,$now]);update_option('wfca_d0_window_since',$now-5000);
stall_set(['d0'=>'CANDIDATES_REJECTED','in_window'=>true]);$sd->invoke(null,WFCA_Util::rules(),$now);
t('no stock => no alert',!WFCA_Alerts::$raised);
reset_all();WFCA_DB::$last_d0=$now-5000;update_option('wfca_d0_stock_seen',[8,$now]);
stall_set(['d0'=>'OUTSIDE_WINDOW','in_window'=>false]);$sd->invoke(null,WFCA_Util::rules(),$now);
t('outside the window => no alert and the window clock is reset',!WFCA_Alerts::$raised&&(int)get_option('wfca_d0_window_since')===0);
reset_all();WFCA_DB::$last_d0=$now-1500;update_option('wfca_d0_stock_seen',[8,$now]);update_option('wfca_d0_window_since',$now-1500);stall_set(['d0'=>'SPACING_WAIT','in_window'=>true]);
$sd->invoke(null,WFCA_Util::rules(),$now);t('SPACING_WAIT tolerates the policy spacing_max (30 min) before alerting',!WFCA_Alerts::$raised);
WFCA_DB::$last_d0=$now-2500;update_option('wfca_last_d0_sent_ts',$now-2500);update_option('wfca_d0_window_since',$now-2500);$sd->invoke(null,WFCA_Util::rules(),$now);
t('...but 40+ min of SPACING_WAIT does alert',count(WFCA_Alerts::$raised)===1);
reset_all();WFCA_DB::$last_d0=$now-5000;update_option('wfca_d0_stock_seen',[8,$now]);update_option('wfca_d0_window_since',$now-5000);stall_set(['d0'=>'CANDIDATES_REJECTED','in_window'=>true]);
WFCA_Airtable::$cfg=['WFCA_RULES_V1'=>'{"stall_diag_enabled":false}'];$o=$sd->invoke(null,WFCA_Util::rules(),$now);
t('stall_diag_enabled=false: fields stay, alert is off',!WFCA_Alerts::$raised&&$o['d0_stall_reason']==='CANDIDATES_REJECTED');
// reserved row blocked in the outbox beats SPACING_WAIT; follow-up mapping
reset_all();stall_set(['d0'=>'SPACING_WAIT','d0_out'=>'PROBE_DEFERRED','fu'=>'FOLLOWUP_DAILY_CAP','in_window'=>true]);$o=$sd->invoke(null,WFCA_Util::rules(),$now);
t('a D0 row deferred in the outbox (probe) is named instead of SPACING_WAIT; follow-up reason is normalised',$o['d0_stall_reason']==='PROBE_DEFERRED'&&$o['fu_stall_reason']==='DAILY_CAP');
reset_all();stall_set(['d0'=>'CROSS'.'_X','d0_out'=>'']);$GLOBALS['opts']['wfca_config_error']=['at'=>$now-400,'err'=>'DUPLICATE_CURRENT_KEY:WFCA_RULES_V1'];stall_set(['d0'=>'MODE_NOT_ACTIVE','fu'=>'MODE_NOT_ACTIVE']);
$o=$sd->invoke(null,WFCA_Util::rules(),$now);
t('Config unreadable/duplicated shows CONFIG_UNAVAILABLE instead of a bare SHADOW',$o['d0_stall_reason']==='CONFIG_UNAVAILABLE'&&$o['fu_stall_reason']==='CONFIG_UNAVAILABLE');
t('outbox gates note their reason (probe, cross-class floor, window, policy)',substr_count($src,"d0_out")>=6&&str_contains($src,"'CROSS_CLASS_FLOOR'")&&str_contains($src,"'PROBE_DEFERRED'"));
// health snapshot carries the new fields
$hw=E('health_write');reset_all();WFCA_DB::$last_d0=$now-60;stall_set(['d0'=>'SPACING_WAIT','in_window'=>true]);
$GLOBALS['opts']['wfca_policy_state_v1']=['K'=>['since'=>$now-10,'error'=>'CLASS_POLICY_INVALID','source'=>'COMMERCIAL_D0_WEEKLY_SCHEDULE_V1','lkg'=>true,'lkg_age_s'=>77,'last'=>$now]];
$hw->invoke(null,'COMPLETED','DONE','');$h=get_option('wfca_health_v1');
t('health_v1 has d0_age_s, d0_stall_reason, fu_stall_reason, policy_error/source/using_lkg',$h['d0_age_s']===60&&$h['d0_stall_reason']==='SPACING_WAIT'&&array_key_exists('fu_stall_reason',$h)&&$h['policy_error']==='CLASS_POLICY_INVALID'&&$h['policy_source']==='COMMERCIAL_D0_WEEKLY_SCHEDULE_V1'&&$h['policy_using_lkg']===true&&$h['policy_lkg_age_s']===77&&$h['v']===1&&$h['v2']===1);
t('health_v1 still has every 10.9.28 field',isset($h['brake_active'],$h['provider_hold_active'],$h['fail_by_code_1h'],$h['reconcile_recovered_total'],$h['tick_overlap_skip_count']));

// ================= ITEM 4: ambiguous Kapso result
function conv($over=[]){global $PH;return array_merge(['id'=>7,'phone_e164'=>$PH,'conversation_owner'=>'LUNA','human_hold'=>0,'opt_out'=>0,'last_inbound_at'=>null,'owner_revision'=>3,'state'=>'READY_FOR_CONTACT'],$over);}
function amb($over=[]){global $LEAD;return array_merge(['id'=>50,'idempotency_key'=>'k50','lead_record_id'=>$LEAD,'conversation_id'=>7,'action_type'=>'TEMPLATE_INITIAL','status'=>'UNCERTAIN','provider_message_id'=>null,'sent_at'=>null,'send_started_at'=>gmdate('Y-m-d H:i:s',time()-600),'updated_at'=>gmdate('Y-m-d H:i:s',time()-600),'last_error'=>'AMBIGUOUS_TRANSPORT_SEND:KAPSO_HTTP_503','initial_arm'=>'LUNA_COLD_WHATSAPP','state_after'=>'WAITING_REPLY'],$over);}
$soft=E('ambiguous_is_soft');
reset_all();
t('only the D0 gets the soft path; replies/checkout/follow-up keep the 10.9.28 handoff',$soft->invoke(null,'TEMPLATE_INITIAL')===true&&!$soft->invoke(null,'FOLLOWUP')&&!$soft->invoke(null,'CHECKOUT')&&!$soft->invoke(null,'REPLY')&&!$soft->invoke(null,'HANDOFF_ACK'));
WFCA_Airtable::$cfg=['WFCA_RULES_V1'=>'{"ambiguous_soft_enabled":false}'];t('ambiguous_soft_enabled=false restores the old handoff for the D0 too',$soft->invoke(null,'TEMPLATE_INITIAL')===false);
$ex=substr($src,strpos($src,'$reason=\'AMBIGUOUS_TRANSPORT_SEND:\''),1800);
t('execute_outbox: UNCERTAIN + CRITICAL alert stay; soft branch comes BEFORE the legacy HUMAN_HANDOFF/human_hold write',str_contains($ex,"'status'=>'UNCERTAIN'")&&str_contains($ex,"WFCA_Alerts::raise(\$reason,'CRITICAL'")&&strpos($ex,'ambiguous_is_soft')<strpos($ex,"'human_hold'=>1"));
reset_all();WFCA_DB::$convs[7]=conv(['state'=>'CONTACT_QUEUED']);WFCA_DB::$out['k50']=amb();
E('ambiguous_soft_mark')->invoke(null,WFCA_DB::$convs[7],50);
$u=WFCA_Airtable::$updates[0][1]??[];
t('soft mark: NO HUMAN_HANDOFF, no human_hold, owner untouched; only an informational Commercial Error',!isset($u['State'])&&!isset($u['Human Handoff Reason'])&&$u['Commercial Error']==='D0_SEND_AMBIGUOUS_AWAITING_STATUS'&&(int)WFCA_DB::$convs[7]['human_hold']===0&&WFCA_DB::$convs[7]['conversation_owner']==='LUNA'&&empty(WFCA_DB::$queued));

// (b) status webhook resolves the row
$res=E('resolve_ambiguous_by_status');
function ev($type='DELIVERY_DELIVERED',$over=[]){global $PH;return array_merge(['event_type'=>$type,'phone_e164'=>$PH,'provider_message_id'=>'wamid.LATE1','occurred_at'=>gmdate('Y-m-d H:i:s',time()-300)],$over);}
reset_all();WFCA_DB::$convs[7]=conv(['state'=>'CONTACT_QUEUED']);WFCA_DB::$out['k50']=amb();
$row=$res->invoke(null,ev());
t('delivered status binds the provider id to the UNCERTAIN D0 => SENT (sync_pending so the funnel sync runs)',$row&&$row['status']==='SENT'&&$row['provider_message_id']==='wamid.LATE1'&&(int)$row['sync_pending']===1&&$row['sent_at']===$row['send_started_at']);
t('uncertain alert resolved and Commercial Error cleared',in_array('outbox:50:uncertain',WFCA_Alerts::$resolved,true)&&WFCA_Airtable::$updates&&WFCA_Airtable::$updates[0][1]===['Commercial Error'=>'']);
t('no resend: nothing queued',empty(WFCA_DB::$queued));
t('second delivery of the same status finds nothing to resolve (idempotent)',$res->invoke(null,ev())===null);
foreach (['DELIVERY_SENT','DELIVERY_READ','DELIVERY_FAILED'] as $et) { reset_all();WFCA_DB::$convs[7]=conv();WFCA_DB::$out['k50']=amb();t("$et also resolves",($res->invoke(null,ev($et))['status']??'')==='SENT'); }
reset_all();WFCA_DB::$convs[7]=conv();WFCA_DB::$out['k50']=amb();
t('status of ANOTHER phone does not match',$res->invoke(null,ev('DELIVERY_DELIVERED',['phone_e164'=>'+5511888880000']))===null);
t('a status far from the send window does not match',$res->invoke(null,ev('DELIVERY_DELIVERED',['occurred_at'=>gmdate('Y-m-d H:i:s',time()-86400*2)]))===null);
t('non-delivery events (inbound, manual) never resolve',$res->invoke(null,ev('MESSAGE'))===null&&$res->invoke(null,ev('MANUAL_OUTBOUND'))===null);
WFCA_DB::$out['k51']=amb(['id'=>51,'idempotency_key'=>'k51']);
t('two candidates for the same phone => ambiguous mapping refused',$res->invoke(null,ev())===null);
reset_all();WFCA_DB::$convs[7]=conv(['opt_out'=>1]);WFCA_DB::$out['k50']=amb();t('opted-out conversation is never touched',$res->invoke(null,ev())===null);
reset_all();WFCA_DB::$convs[7]=conv();WFCA_DB::$out['k50']=amb();WFCA_Airtable::$cfg=['WFCA_RULES_V1'=>'{"ambiguous_resolve_by_status":false}'];t('ambiguous_resolve_by_status=false switches (b) off',$res->invoke(null,ev())===null);
t('process_transport_event tries the resolution only when the provider id is unmatched, before the UNMATCHED requeue',strpos($src,'resolve_ambiguous_by_status($e)')<strpos($src,"'UNMATCHED_OUTBOUND_ECHO'")&&str_contains($src,'if (!$row) $row=self::resolve_ambiguous_by_status($e);'));

// (c) timed release without resend
$rel=E('reconcile_ambiguous_d0');
reset_all();WFCA_DB::$convs[7]=conv(['state'=>'CONTACT_QUEUED']);WFCA_DB::$out['k50']=amb(['updated_at'=>gmdate('Y-m-d H:i:s',time()-7*3600)]);WFCA_Airtable::$cc=['ok'=>true,'record'=>['fields'=>['State'=>'CONTACT_QUEUED','Conversation Owner'=>'LUNA']]];
$o=$rel->invoke(null);
t('after 6 h without status: released (1), D0 recorded as ATTEMPTED (Touch), funnel state WAITING_REPLY',$o['released']===1&&count(WFCA_Airtable::$touches)===1&&WFCA_Airtable::$touches[0][2]==='D0_AMBIGUOUS_NO_STATUS'&&WFCA_Airtable::$updates[0][1]['State']==='WAITING_REPLY'&&WFCA_DB::$convs[7]['state']==='WAITING_REPLY');
t('NO resend: no outbox row queued, original row stays UNCERTAIN with its key consumed',empty(WFCA_DB::$queued)&&WFCA_DB::$out['k50']['status']==='UNCERTAIN'&&WFCA_DB::$out['k50']['last_error']==='RELEASED_AMBIGUOUS_NO_STATUS'&&count(WFCA_DB::$out)===1);
$o=$rel->invoke(null);
t('running it again releases nothing and writes nothing more (idempotent)',$o['released']===0&&count(WFCA_Airtable::$touches)===1&&count(WFCA_Airtable::$updates)===1);
t('an INFO-level WARN alert tells Daniel',count(array_filter(WFCA_Alerts::$raised,fn($a)=>str_contains((string)$a[0],'AMBIGUOUS_D0_RELEASED_NO_RESEND')))===1);
reset_all();WFCA_DB::$convs[7]=conv();WFCA_DB::$out['k50']=amb();t('before the timeout nothing is released',$rel->invoke(null)['released']===0&&!WFCA_Airtable::$touches);
reset_all();WFCA_DB::$convs[7]=conv(['human_hold'=>1,'state'=>'HUMAN_HANDOFF','conversation_owner'=>'HANDOFF_PENDING']);WFCA_DB::$out['k50']=amb(['updated_at'=>gmdate('Y-m-d H:i:s',time()-9*3600)]);
t('legacy 10.9.28 ambiguous rows already in a human handoff are left to Daniel',$rel->invoke(null)['released']===0&&!WFCA_Airtable::$updates);
reset_all();WFCA_DB::$convs[7]=conv();WFCA_DB::$out['k50']=amb(['updated_at'=>gmdate('Y-m-d H:i:s',time()-9*3600)]);WFCA_Airtable::$cc=['ok'=>true,'record'=>['fields'=>['State'=>'ENGAGED','Conversation Owner'=>'LUNA']]];
$rel->invoke(null);
t('prospect already moved the state (ENGAGED): row released and D0 marked attempted, state NOT rewritten',count(WFCA_Airtable::$touches)===1&&!WFCA_Airtable::$updates);
reset_all();WFCA_DB::$convs[7]=conv();WFCA_DB::$out['k50']=amb(['updated_at'=>gmdate('Y-m-d H:i:s',time()-9*3600)]);WFCA_Airtable::$cc=['ok'=>true,'record'=>['fields'=>['State'=>'CONTACT_QUEUED','Conversation Owner'=>'LUNA','Opt Out'=>true]]];
$rel->invoke(null);t('remote opt-out: state never rewritten',!WFCA_Airtable::$updates);
reset_all();WFCA_DB::$convs[7]=conv();WFCA_DB::$out['k50']=amb(['updated_at'=>gmdate('Y-m-d H:i:s',time()-9*3600)]);WFCA_Airtable::$cfg=['WFCA_RULES_V1'=>'{"ambiguous_release_enabled":false}'];
t('ambiguous_release_enabled=false switches (c) off',$rel->invoke(null)['released']===0);
reset_all();WFCA_DB::$convs[7]=conv();WFCA_DB::$out['k50']=amb(['updated_at'=>gmdate('Y-m-d H:i:s',time()-9*3600)]);$GLOBALS['opts']['wfca_provider_hold_until']=time()+300;
t('not while the provider is on hold',$rel->invoke(null)['released']===0);
t('tick runs the release after the reconciler, guarded by the tick budget',str_contains($src,'self::reconcile_ambiguous_d0();')&&strpos($src,'self::reconcile_transient();')<strpos($src,'self::reconcile_ambiguous_d0();'));

// ================= ITEM 5: reconciler
function cand($over=[]){return conv(array_merge(['conversation_owner'=>'HANDOFF_PENDING','human_hold'=>1,'state'=>'HUMAN_HANDOFF','owner_reason'=>'OUTBOX_FAILED:KAPSO_HTTP_503','lead_record_id'=>'recLEAD1'],$over));}
function failed($id=60,$over=[]){return array_merge(['id'=>$id,'action_type'=>'TEMPLATE_INITIAL','status'=>'FAILED','last_error'=>'KAPSO_HTTP_503','provider_message_id'=>null,'sent_at'=>null,'lead_record_id'=>'recLEAD1','scheduled_action_at'=>null],$over);}
$run=E('reconcile_transient');
function fresh_run(){$GLOBALS['opts']['wfca_reconcile_last_at']=0;}
reset_all();WFCA_DB::$convs[7]=cand();WFCA_DB::$failed_by[7]=failed();
$o1=$run->invoke(null);fresh_run();$o2=$run->invoke(null);fresh_run();$o3=$run->invoke(null);
t('IDEMPOTENT: 1st run restores, 2nd and 3rd runs change NOTHING (1 ownership change, 1 reset, 1 Airtable update)',$o1['recovered']===1&&$o2['recovered']===0&&$o3['recovered']===0&&count(WFCA_Ownership::$changes)===1&&count(WFCA_DB::$resets)===1&&count(WFCA_Airtable::$updates)===1&&empty(WFCA_DB::$queued));
t('audit trail: conversation, action, reason, time',(function(){$a=get_option('wfca_reconcile_audit');return count($a)===1&&$a[0][1]===7&&$a[0][2]==='RESTORED'&&str_contains($a[0][3],'KAPSO_HTTP_503')&&$a[0][0]>=time()-5;})());
t('counters: restored total',(get_option('wfca_selfheal_totals')['reconcile_restored']??0)===1);
$neg=[
 ['SKIP_INBOUND',cand(['last_inbound_at'=>'2026-10-10 12:00:00'])],
 ['SKIP_OPT_OUT',cand(['opt_out'=>1])],
 ['SKIP_MANUAL',cand(['last_manual_at'=>'2026-10-10 12:00:00'])],
 ['SKIP_PAYMENT',cand()],
];
foreach ($neg as [$cause,$c]) {
  reset_all();WFCA_DB::$convs[7]=$c;WFCA_DB::$failed_by[7]=failed();if($cause==='SKIP_PAYMENT')WFCA_DB::$payment[7]=true;
  $o=$run->invoke(null);fresh_run();$run->invoke(null);
  $a=get_option('wfca_reconcile_audit',[]);
  t("never restores ($cause): untouched, recorded once with the cause",$o['recovered']===0&&!WFCA_Ownership::$changes&&!WFCA_DB::$resets&&!WFCA_Airtable::$updates&&count($a)===1&&$a[0][2]===$cause&&(get_option('wfca_selfheal_totals')['reconcile_'.strtolower($cause)]??0)===1);
}
// breaker: hourly cap
reset_all();WFCA_DB::$failed_by=[];for($i=1;$i<=30;$i++){WFCA_DB::$convs[$i]=cand(['id'=>$i,'phone_e164'=>'+55119999'.str_pad((string)$i,5,'0',STR_PAD_LEFT)]);WFCA_DB::$failed_by[$i]=failed(200+$i);}
$tot=0;for($r=0;$r<8;$r++){fresh_run();$o=$run->invoke(null);$tot+=$o['recovered'];if($o['skipped']==='CIRCUIT_OPEN')break;}
t('CIRCUIT BREAKER: never more than reconcile_max_per_hour (10) restorations per hour; then CIRCUIT_OPEN',$tot===10&&$o['skipped']==='CIRCUIT_OPEN');
t('breaker pause is loud (one WARN alert for the hour) and counted',count(array_filter(WFCA_Alerts::$raised,fn($a)=>str_contains((string)$a[0],'RECONCILER_PAUSED:CIRCUIT_OPEN')))===1);
fresh_run();$run->invoke(null);
t('...and stays ONE alert per hour (same alert key => the alerts table de-duplicates)',count(array_unique(array_map(fn($a)=>$a[6],array_filter(WFCA_Alerts::$raised,fn($a)=>str_contains((string)$a[0],'RECONCILER_PAUSED')))))===1);
reset_all();WFCA_DB::$convs[7]=cand();WFCA_DB::$failed_by[7]=failed();$GLOBALS['opts']['wfca_d0_brake_until']=time()+900;
$o=$run->invoke(null);
t('brake active => reconciler pauses and alerts, restores nothing',$o['skipped']==='BRAKE_ACTIVE'&&!WFCA_DB::$resets&&count(WFCA_Alerts::$raised)===1);
reset_all();WFCA_DB::$convs[7]=cand();WFCA_DB::$failed_by[7]=failed();$GLOBALS['opts']['wfca_provider_hold_until']=time()+900;
$o=$run->invoke(null);t('provider hold => pauses and alerts',$o['skipped']==='PROVIDER_HOLD'&&!WFCA_DB::$resets&&count(WFCA_Alerts::$raised)===1);
reset_all();WFCA_Airtable::$cfg=['WFCA_RULES_V1'=>'{"reconcile_breaker_enabled":false,"reconcile_max_per_run":20}'];WFCA_DB::$failed_by=[];for($i=1;$i<=15;$i++){WFCA_DB::$convs[$i]=cand(['id'=>$i,'phone_e164'=>'+55119999'.str_pad((string)$i,5,'0',STR_PAD_LEFT)]);WFCA_DB::$failed_by[$i]=failed(300+$i);}
t('reconcile_breaker_enabled=false => old behaviour (only the per-run cap)',$run->invoke(null)['recovered']===15);
reset_all();WFCA_Airtable::$cfg=['WFCA_RULES_V1'=>'{"reconcile_max_per_run":3}'];WFCA_DB::$failed_by=[];for($i=1;$i<=9;$i++){WFCA_DB::$convs[$i]=cand(['id'=>$i,'phone_e164'=>'+55119999'.str_pad((string)$i,5,'0',STR_PAD_LEFT)]);WFCA_DB::$failed_by[$i]=failed(400+$i);}
t('per-run ceiling is configurable in WFCA_RULES_V1 (3)',$run->invoke(null)['recovered']===3);
$ma=E('health_write');reset_all();WFCA_DB::$convs[7]=cand();WFCA_DB::$failed_by[7]=failed();$run->invoke(null);$ma->invoke(null,'COMPLETED','DONE','');$h=get_option('wfca_health_v1');
t('health_v1: reconcile_restored_1h, selfheal_totals, audit tail',$h['reconcile_restored_1h']===1&&$h['selfheal_totals']['reconcile_restored']===1&&count($h['reconcile_audit_tail'])===1);

// ================= ITEM 6 hygiene
$mat=E('materialize_due_d0_followup');
function wrecs($n,$from=0){$r=[];for($i=$from;$i<$from+$n;$i++)$r[]=['id'=>'rec'.$i,'fields'=>['Last Outbound At'=>gmdate('c',1760000000+$i*60)]];return $r;}
reset_all();WFCA_Airtable::$cfg=['COMMERCIAL_MAX_FOLLOWUPS_DAY'=>'10','COMMERCIAL_D0_FOLLOWUP_DELAY_MINUTES'=>'60'];WFCA_Airtable::$waiting_args=[];
WFCA_Airtable::$waiting=wrecs(100);$mat->invoke(null,1);
t('follow-up materializer: full page => cursor = Last Outbound At of the last record examined',get_option('wfca_fu_mat_cursor')===gmdate('c',1760000000+99*60)&&WFCA_Airtable::$waiting_args===['']);
WFCA_Airtable::$waiting=wrecs(100,100);$mat->invoke(null,1);
t('next tick asks for records AFTER the cursor (a different 100 leads, no more head-of-line)',WFCA_Airtable::$waiting_args[1]===gmdate('c',1760000000+99*60)&&get_option('wfca_fu_mat_cursor')===gmdate('c',1760000000+199*60));
WFCA_Airtable::$waiting=wrecs(40,200);$mat->invoke(null,1);
t('short page = end of queue => cursor wraps to the start',get_option('wfca_fu_mat_cursor')==='');
$GLOBALS['opts']['wfca_fu_mat_cursor']='x';WFCA_Airtable::$waiting=wrecs(100);WFCA_Airtable::$waiting_args=[];WFCA_Airtable::$cfg['WFCA_RULES_V1']='{"fu_materialize_rotate":false}';$mat->invoke(null,1);
t('fu_materialize_rotate=false restores the 10.9.28 query (no cursor)',WFCA_Airtable::$waiting_args===[''] );


t('G5/noncanonical/variable-missing errors are not re-PATCHed when the record already carries them (Airtable 429 flood guard)',substr_count($src,"(\$f['Commercial Error']??'')!==")>=3);
t('tick: time limit + send budget, optional stages skipped over budget',str_contains($src,'@set_time_limit($tl)')&&str_contains($src,'self::tick_over_budget()')&&str_contains($src,"if (\$i>0 && self::tick_over_budget()) break;"));
t('version is 10.9.29-SELFHEAL-RC1',str_contains(file_get_contents(__DIR__.'/../wf-commercial-agent.php'),"define('WFCA_VERSION', '10.9.29-SELFHEAL-RC1')")&&str_contains(file_get_contents(__DIR__.'/../wf-commercial-agent.php'),'Version: 10.9.29-SELFHEAL-RC1'));
echo "TOTAL PASS=$pass FAIL=$fail\n";exit($fail?1:0);
