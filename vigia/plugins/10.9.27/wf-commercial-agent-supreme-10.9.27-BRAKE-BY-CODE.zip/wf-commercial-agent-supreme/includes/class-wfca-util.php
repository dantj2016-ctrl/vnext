<?php
if (!defined('ABSPATH')) exit;

final class WFCA_Util {
    public static function c(string $name, $default = null) {
        return defined($name) ? constant($name) : $default;
    }

    public static function now_iso(): string {
        return gmdate('c');
    }

    public static function now_mysql(): string {
        return gmdate('Y-m-d H:i:s');
    }

    public static function normalize_phone(string $value): string {
        $value = preg_replace('/^whatsapp:/i', '', trim($value));
        $digits = preg_replace('/\D+/', '', (string)$value);
        if (!$digits || strlen($digits) < 8 || strlen($digits) > 15) return '';
        // 10.9.14: Brazilian mobile numbers may arrive from WhatsApp without the ninth digit (55 + DDD + 8 digits starting 6-9).
        // Canonicalize to the 13-digit form so inbound replies match the conversation the D0 was sent to (otherwise the reply
        // becomes an organic 'WhatsApp Prospect' owned by DANIEL and Luna never answers). Landlines (first local digit 2-5) are untouched.
        if (strlen($digits) === 12 && strncmp($digits, '55', 2) === 0 && preg_match('/^55[1-9][0-9][6-9]/', $digits)) {
            $digits = substr($digits, 0, 4) . '9' . substr($digits, 4);
        }
        return '+' . $digits;
    }

    /** Resolve a Factory lead phone field without concatenating multiple numbers.
     * Prefer an explicitly labelled WhatsApp number. Otherwise accept one unique
     * candidate, or one unique Brazilian mobile candidate; ambiguous fields fail closed. */
    public static function extract_factory_phone(string $value,string $default_country_code='55',array $local_nsn_lengths=[10,11]): string {
        $value=trim($value); if($value==='') return '';
        $canon=static function(string $raw) use($default_country_code,$local_nsn_lengths): string {
            $d=preg_replace('/\D+/','',$raw); if($d==='') return '';
            if(in_array(strlen($d),$local_nsn_lengths,true)) $d=$default_country_code.$d;
            if(strlen($d)<8 || strlen($d)>15) return '';
            return '+'.$d;
        };
        if(preg_match('/(?:whats(?:app)?|wa)\s*[:\-]?\s*([+()0-9][0-9\s().\-]{6,25})/iu',$value,$m)) {
            $p=$canon((string)$m[1]); if($p!=='') return $p;
        }
        preg_match_all('/\+?\d[\d\s().\-]{6,22}\d/u',$value,$m);
        $candidates=[];
        foreach(($m[0]??[]) as $raw){$p=$canon((string)$raw);if($p!=='')$candidates[$p]=true;}
        $phones=array_keys($candidates);
        if(count($phones)===1) return $phones[0];
        if(count($phones)>1 && $default_country_code==='55') {
            $mobiles=[];
            foreach($phones as $p){$d=preg_replace('/\D+/','',$p);$nsn=str_starts_with($d,'55')?substr($d,2):$d;if(strlen($nsn)===11 && ($nsn[2]??'')==='9')$mobiles[]=$p;}
            $mobiles=array_values(array_unique($mobiles)); if(count($mobiles)===1) return $mobiles[0];
        }
        return '';
    }

    /**
     * Compare phone numbers without mutating the canonical E.164 storage format.
     * Website Factory lead rows historically contain Brazilian local DDD+number
     * values, while Kapso events arrive as +55 E.164. Treat those as equivalent
     * so a known Factory lead is never duplicated as an organic WhatsApp lead.
     */
    public static function phone_equivalent(string $a, string $b): bool {
        $ad=preg_replace('/\D+/','',$a);
        $bd=preg_replace('/\D+/','',$b);
        if ($ad==='' || $bd==='') return false;
        if (hash_equals($ad,$bd)) return true;
        if (str_starts_with($ad,'55') && in_array(strlen($bd),[10,11],true) && hash_equals(substr($ad,2),$bd)) return true;
        if (str_starts_with($bd,'55') && in_array(strlen($ad),[10,11],true) && hash_equals(substr($bd,2),$ad)) return true;
        return false;
    }

    /** Read-only diagnostic counters of delivery failures by provider error code. Never read by any send decision or gate. */
    /** Numeric provider error code of a failed-delivery body ('WA_ERR code=131049 ...' -> '131049'), '' when absent. Used by the D0 brake only to IGNORE recipient-side codes. */
    public static function delivery_fail_code_digits(string $body): string {
        return preg_match('/^WA_ERR code=(\d{3,8})(?!\d)/',$body,$m)?$m[1]:'';
    }

    public static function delivery_fail_code(string $body): string {
        if (preg_match('/^WA_ERR code=([A-Za-z0-9_.\-]{1,12})/',$body,$m)) return 'code_'.$m[1];
        return 'NO_DETAIL';
    }

    public static function record_delivery_failure(string $body,string $phone='',?int $now=null): void {
        try {
            $now=$now??time();
            $key=self::delivery_fail_code($body);
            $o=get_option('wfca_delivery_fail_counters',[]);
            if (!is_array($o)) $o=[];
            $codes=is_array($o['codes']??null)?$o['codes']:[];
            $days=is_array($o['days']??null)?$o['days']:[];
            if (!isset($codes[$key]) && count($codes)>=40) $key='code_OTHER';
            $prev=is_array($codes[$key]??null)?$codes[$key]:[];
            $codes[$key]=['count'=>(int)($prev['count']??0)+1,'last_at'=>gmdate('Y-m-d\TH:i:s\Z',$now),'last_tail4'=>substr(preg_replace('/\D+/','',$phone),-4)];
            $day=gmdate('Y-m-d',$now);
            $days[$day][$key]=(int)($days[$day][$key]??0)+1;
            ksort($days);
            $days=array_slice($days,-7,null,true);
            update_option('wfca_delivery_fail_counters',['codes'=>$codes,'days'=>$days],false);
        } catch (\Throwable $e) {}
    }

    public static function delivery_fail_counters(): array {
        try {
            $o=get_option('wfca_delivery_fail_counters',[]);
            return is_array($o)?['codes'=>(array)($o['codes']??[]),'days'=>(array)($o['days']??[])]:['codes'=>[],'days'=>[]];
        } catch (\Throwable $e) { return ['codes'=>[],'days'=>[]]; }
    }

    public static function short_text(string $text, int $max = 1200): string {
        $text = wp_strip_all_tags($text);
        $text = preg_replace('/\s+/u', ' ', $text);
        $text = trim((string)$text);
        if (function_exists('mb_substr')) return mb_substr($text, 0, $max, 'UTF-8');
        return substr($text, 0, $max);
    }

    public static function json($value): string {
        $json = wp_json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        return is_string($json) ? $json : '{}';
    }

    /**
     * Legacy helper. Do not use this for Twilio webhook signature validation when
     * an exact canonical callback URL is known.
     */
    public static function effective_request_url(): string {
        $scheme = is_ssl() ? 'https://' : 'http://';
        $host = isset($_SERVER['HTTP_HOST']) ? (string)$_SERVER['HTTP_HOST'] : (string)parse_url(home_url(), PHP_URL_HOST);
        $uri = isset($_SERVER['REQUEST_URI']) ? (string)$_SERVER['REQUEST_URI'] : '';
        return $scheme . $host . $uri;
    }

    public static function local_mode(): string {
        $mode = strtoupper((string)get_option('wfca_local_mode', 'SHADOW'));
        return in_array($mode, ['OFF','SHADOW','ASSISTED','LIVE','DRAINING'], true) ? $mode : 'OFF';
    }

    public static function set_local_mode(string $mode): void {
        $mode = strtoupper($mode);
        if (!in_array($mode, ['OFF','SHADOW','ASSISTED','LIVE','DRAINING'], true)) $mode = 'OFF';
        update_option('wfca_local_mode', $mode, false);
    }

    public static function token_set(string $constant): bool {
        return defined($constant) && trim((string)constant($constant)) !== '';
    }

    public static function hash_event(array $payload): string {
        return hash('sha256', self::json($payload));
    }

    public static function lower(string $text): string {
        return function_exists('mb_strtolower') ? mb_strtolower($text, 'UTF-8') : strtolower($text);
    }

    public static function normalize_text(string $text): string {
        $text = self::lower(self::short_text($text, 5000));
        $text = str_replace(["\r", "\n", "\t"], ' ', $text);
        $text = preg_replace('/\s+/u', ' ', $text);
        return trim((string)$text);
    }

    public static function contains_any(string $haystack, array $needles): bool {
        $h = self::lower($haystack);
        foreach ($needles as $n) {
            $n = self::lower((string)$n);
            if ($n !== '' && str_contains($h, $n)) return true;
        }
        return false;
    }

    /** Kept for backwards compatibility with v1 code. */
    public static function starts_with_any(string $haystack, array $needles): bool {
        return self::contains_any($haystack, $needles);
    }

    /** Stable (per seed) upward jitter so D0 cadence is never a fixed, robot-like interval; the real send fence keeps the configured floor. */
    public static function jitter_up(int $seconds,int $seed,float $max=0.25): int {
        $max=max(0.0,min(0.5,$max));
        $f=(crc32((string)$seed)%1001)/1000*$max;
        return (int)round($seconds*(1+$f));
    }

    /** Technical-stack words never belong in text a clinic owner reads. */
    public static function has_tech_jargon(string $text): bool {
        return (bool)preg_match('/\b(gsap|three\.?js|webgl|framework|cms|motion)\b/iu',$text);
    }

    /** Last-mile guard for the D0 personalised line: swap jargon for a benefit sentence naming the clinic's own verified services. */
    public static function customer_safe_observation(string $line,string $raw_observation=''): string {
        if ($line!=='' && !self::has_tech_jargon($line)) return $line;
        if ($line==='') return $line;
        $titles=[];
        if (preg_match('/SERVI[CÇ]OS VERIFICADOS:\s*(.+?)(?:\s+VNEXT_|\r?\n|$)/iu',$raw_observation,$m)) {
            foreach (explode(';',(string)$m[1]) as $t) { $t=trim(preg_replace('/\s+/u',' ',$t)); if ($t!=='' && !self::has_tech_jargon($t) && (function_exists('mb_strlen')?mb_strlen($t,'UTF-8'):strlen($t))<=60) $titles[]=$t; }
        }
        $titles=array_slice($titles,0,3);
        if (count($titles)>=2) {
            $joined=count($titles)===2?implode(' e ',$titles):implode(', ',array_slice($titles,0,-1)).' e '.end($titles);
            return 'Apresentar '.$joined.' com mais clareza e deixar o caminho até o agendamento mais direto.';
        }
        return 'Apresentar os tratamentos com mais clareza e deixar o caminho até o agendamento mais direto.';
    }

    /** Daniel's alert number: server constant first, then Airtable Config key WFCA_OWNER_WHATSAPP (no wp-config edit needed). */
    public static function owner_whatsapp(): string {
        $v=trim((string)self::c('WFCA_OWNER_WHATSAPP',''));
        if ($v==='' && class_exists('WFCA_Airtable')) { $cfg=WFCA_Airtable::config(); $v=trim((string)($cfg['WFCA_OWNER_WHATSAPP']??'')); }
        return self::normalize_phone($v);
    }

    /**
     * Operating rules editable in Airtable Config key WFCA_RULES_V1 (JSON, cached 60 s by config()).
     * Safety floors stay in code: Airtable can only add blocked states / hostile words, never remove them,
     * and the auto-resume delay can never go below 10 minutes.
     */
    public static function rules(): array {
        $d=['auto_resume_enabled'=>true,'auto_resume_after_seconds'=>1800,'auto_resume_extra_blocked_states'=>[],
            'gatekeeper_email_redirect_enabled'=>true,'gatekeeper_extra_hostile_words'=>[],
            'd0_jitter_max'=>0.25,'d0_delivery_brake_enabled'=>true,'d0_delivery_brake_failure_ratio'=>0.30,'d0_min_preview_bytes'=>150000,
            // 10.9.27: Meta errors that say nothing about OUR sender quality (130472 user is in a Meta experiment, 131026 recipient cannot receive).
            // They no longer count toward the delivery brake. Set [] in WFCA_RULES_V1 to restore the old behaviour.
            'd0_delivery_brake_ignore_codes'=>['130472','131026']];
        if (!class_exists('WFCA_Airtable')) return $d;
        $cfg=WFCA_Airtable::config();
        $j=json_decode(trim((string)($cfg['WFCA_RULES_V1']??'')),true);
        if (!is_array($j)) return $d;
        if (array_key_exists('auto_resume_enabled',$j)) $d['auto_resume_enabled']=filter_var($j['auto_resume_enabled'],FILTER_VALIDATE_BOOLEAN);
        if (isset($j['auto_resume_after_seconds']) && is_numeric($j['auto_resume_after_seconds'])) $d['auto_resume_after_seconds']=max(600,min(86400,(int)$j['auto_resume_after_seconds']));
        if (isset($j['d0_min_preview_bytes']) && is_numeric($j['d0_min_preview_bytes'])) $d['d0_min_preview_bytes']=max(0,min(1000000,(int)$j['d0_min_preview_bytes']));
        if (isset($j['d0_jitter_max']) && is_numeric($j['d0_jitter_max'])) $d['d0_jitter_max']=max(0.0,min(0.5,(float)$j['d0_jitter_max']));
        if (array_key_exists('d0_delivery_brake_enabled',$j)) $d['d0_delivery_brake_enabled']=filter_var($j['d0_delivery_brake_enabled'],FILTER_VALIDATE_BOOLEAN);
        if (isset($j['d0_delivery_brake_failure_ratio']) && is_numeric($j['d0_delivery_brake_failure_ratio'])) $d['d0_delivery_brake_failure_ratio']=max(0.1,min(0.9,(float)$j['d0_delivery_brake_failure_ratio']));
        if (array_key_exists('gatekeeper_email_redirect_enabled',$j)) $d['gatekeeper_email_redirect_enabled']=filter_var($j['gatekeeper_email_redirect_enabled'],FILTER_VALIDATE_BOOLEAN);
        if (array_key_exists('d0_delivery_brake_ignore_codes',$j) && is_array($j['d0_delivery_brake_ignore_codes'])) {
            $codes=[];
            foreach (array_slice($j['d0_delivery_brake_ignore_codes'],0,10) as $x) { if (is_scalar($x) && preg_match('/^\d{3,8}$/',trim((string)$x))) $codes[]=trim((string)$x); }
            $d['d0_delivery_brake_ignore_codes']=array_values(array_unique($codes));
        }
        foreach (['auto_resume_extra_blocked_states'=>'/^[A-Z_]{3,40}$/','gatekeeper_extra_hostile_words'=>'/^.{2,30}$/u'] as $k=>$re) {
            if (!is_array($j[$k]??null)) continue;
            foreach (array_slice($j[$k],0,40) as $x) { $x=trim((string)$x); if ($x!=='' && preg_match($re,$x)) $d[$k][]=$k==='gatekeeper_extra_hostile_words'?self::lower($x):$x; }
        }
        return $d;
    }

    /**
     * Conversation "arms" editable in Airtable Config key WFCA_ARMS_V1 (JSON). An arm routes a NEW inbound (unknown number)
     * to its own owner/prompt/offer rules without a plugin release. Code keeps the safety floors (opt-out, media, handoff).
     * Example: {"arms":[{"id":"SITES_INBOUND","tag_regex":"-\\s*([A-Za-z0-9])\\s*$","owner":"LUNA","untagged_inbound":false,
     *   "prompt_key":"WFCA_ARM_PROMPT_SITES_INBOUND","checkout_without_site":true,"blocked_actions":["SEND_SITE"],
     *   "allow_deterministic":[...],"static_checkout":{"LANDING_PAGE_PREMIUM":"https://..."}}]}
     */
    public static function arms(): array {
        if (!class_exists('WFCA_Airtable') || !method_exists('WFCA_Airtable','config')) return [];
        $cfg=WFCA_Airtable::config();
        $j=json_decode(trim((string)($cfg['WFCA_ARMS_V1']??'')),true);
        if (!is_array($j) || !is_array($j['arms']??null)) return [];
        $out=[];
        foreach (array_slice($j['arms'],0,8) as $a) {
            if (!is_array($a)) continue;
            $id=strtoupper(trim((string)($a['id']??'')));
            if (array_key_exists('enabled',$a) && !filter_var($a['enabled'],FILTER_VALIDATE_BOOLEAN)) continue; // master switch per arm in Airtable
            if (!preg_match('/^[A-Z][A-Z0-9_]{2,30}$/',$id) || in_array($id,['CALL_FIRST','ASYNC_FIRST','DANIEL_CALL','DANIEL_ASYNC','LUNA_COLD_WHATSAPP'],true)) continue;
            $re=(string)($a['tag_regex']??'');
            if ($re!=='' && @preg_match('~'.str_replace('~','\\~',$re).'~u','')===false) $re='';
            $owner=strtoupper((string)($a['owner']??'LUNA'));
            $static=[];
            if (is_array($a['static_checkout']??null)) foreach ($a['static_checkout'] as $k=>$u) {
                $u=trim((string)$u);
                if (preg_match('/^[A-Z0-9_]{3,48}$/',(string)$k) && preg_match('~^https://(link|invoice|checkout)\.infinitepay\.io/~',$u) && filter_var($u,FILTER_VALIDATE_URL)) $static[(string)$k]=$u;
            }
            $out[$id]=[
                'id'=>$id,'tag_regex'=>$re,'owner'=>in_array($owner,['LUNA','DANIEL'],true)?$owner:'LUNA',
                'untagged_inbound'=>filter_var($a['untagged_inbound']??false,FILTER_VALIDATE_BOOLEAN),
                'default_tag'=>substr(preg_replace('/[^A-Za-z0-9_\-]/','',(string)($a['default_tag']??'organico')),0,20)?:'organico',
                'prompt_key'=>preg_match('/^WFCA_ARM_PROMPT_[A-Z0-9_]{2,40}$/',(string)($a['prompt_key']??''))?(string)$a['prompt_key']:'',
                'checkout_without_site'=>filter_var($a['checkout_without_site']??false,FILTER_VALIDATE_BOOLEAN),
                'blocked_actions'=>array_values(array_filter(array_map('strtoupper',array_map('strval',(array)($a['blocked_actions']??['SEND_SITE','PRICE','OFFER_STRATEGY_EXPRESS','ROUTE_SOCIAL_MEDIA','ROUTE_VIDEO_EDITING']))),fn($x)=>preg_match('/^[A-Z_]{3,40}$/',$x))),
                'allow_deterministic'=>array_values(array_filter(array_map('strval',(array)($a['allow_deterministic']??['EXPLICIT_OPT_OUT','MEDIA_PRESENT','CLEAR_REJECTION','DANIEL_PERSONAL_TOUCH','LUNA_IDENTITY_QUESTION','GUARANTEE_QUESTION','COURTESY_CLOSING'])),fn($x)=>preg_match('/^[A-Z_]{3,40}$/',$x))),
                'static_checkout'=>$static,
            ];
        }
        return $out;
    }

    public static function arm_by_id(string $id): ?array {
        if ($id==='' || in_array($id,['CALL_FIRST','ASYNC_FIRST','DANIEL_CALL','DANIEL_ASYNC','LUNA_COLD_WHATSAPP'],true)) return null;
        $arms=self::arms();
        return $arms[strtoupper($id)]??null;
    }

    /** First arm whose tag matches the first message of an unknown number; untagged arms only when explicitly enabled in Airtable. */
    public static function arm_for_inbound(string $body): ?array {
        $body=trim($body);
        foreach (self::arms() as $a) {
            if ($a['tag_regex']!=='' && preg_match('~'.str_replace('~','\\~',$a['tag_regex']).'~u',$body,$m)) {
                $tag=strtoupper(substr(preg_replace('/[^A-Za-z0-9_\-]/','',(string)($m[1]??$a['default_tag'])),0,20));
                return $a+['tag'=>$tag!==''?$tag:$a['default_tag']];
            }
        }
        foreach (self::arms() as $a) if ($a['untagged_inbound']) return $a+['tag'=>$a['default_tag']];
        return null;
    }

    public static function owner_email(): string {
        $override = sanitize_email((string)self::c('WFCA_OWNER_EMAIL', ''));
        if ($override !== '' && is_email($override)) return $override;
        $admin = sanitize_email((string)get_option('admin_email', ''));
        return is_email($admin) ? $admin : '';
    }

    public static function handoff_ack_text(): string {
        $custom = trim((string)self::c('WFCA_HANDOFF_ACK_TEXT', ''));
        if ($custom !== '') return self::short_text($custom, 500);
        return 'Recebi sua mensagem. Vou conferir isso e te respondo por aqui.';
    }

    /**
     * Parse "10:00-11:30,14:00-15:30 America/Sao_Paulo" safely.
     * Returns [ranges, timezone].
     */
    public static function parse_windows(string $windows): array {
        $windows = str_replace("\xC2\xA0", " ", trim($windows));
        $tz_name = 'America/Sao_Paulo';
        $ranges_text = $windows;

        if (preg_match('/^(.+?)\s+([A-Za-z_]+\/[A-Za-z_\-+]+)$/', $windows, $m)) {
            $ranges_text = trim($m[1]);
            $tz_name = trim($m[2]);
        }

        try {
            new DateTimeZone($tz_name);
        } catch (Throwable $e) {
            $tz_name = 'America/Sao_Paulo';
        }

        $ranges = [];
        foreach (explode(',', $ranges_text) as $range) {
            $parts = array_map('trim', explode('-', trim($range)));
            if (count($parts) !== 2) continue;
            if (!preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/', $parts[0])) continue;
            if (!preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/', $parts[1])) continue;
            if ($parts[1] < $parts[0]) continue;
            $ranges[] = [$parts[0], $parts[1]];
        }
        return [$ranges, $tz_name];
    }

    /**
     * Resolve one sovereign weekly commercial schedule from Airtable CURRENT.
     * JSON shape (COMMERCIAL_WEEKLY_SCHEDULE_V1):
     * {"version":"COMMERCIAL_WEEKLY_SCHEDULE_V1","timezone":"America/Sao_Paulo","days":{"mon":{"proactive":true,"windows":["09:00-12:00","13:00-18:00"],"spacing_seconds":600},...}}
     * Legacy COMMERCIAL_WINDOWS + COMMERCIAL_LUNA_NEW_CONTACT_INTERVAL_V1 remains
     * a safe fallback so deploy does not broaden sending before the JSON policy exists.
     */
    public static function weekly_commercial_policy(array $cfg, ?DateTimeImmutable $now=null): array {
        $legacy_windows=trim((string)($cfg['COMMERCIAL_WINDOWS']??'09:00-18:00 America/Sao_Paulo'));
        $legacy_spacing=max(600,(int)($cfg['COMMERCIAL_LUNA_NEW_CONTACT_INTERVAL_V1']??600));
        $fallback=['valid'=>true,'source'=>'LEGACY_FALLBACK','version'=>'LEGACY','proactive'=>true,'windows'=>$legacy_windows,'spacing_seconds'=>$legacy_spacing,'timezone'=>self::parse_windows($legacy_windows)[1],'day_key'=>''];
        $raw=trim((string)($cfg['COMMERCIAL_WEEKLY_SCHEDULE_V1']??''));
        if ($raw==='') return $fallback;
        $policy=json_decode($raw,true);
        /* Once a weekly policy exists it is sovereign. Malformed/partial JSON
         * must fail closed rather than silently broaden sending through legacy
         * weekday windows. Legacy is fallback only when the record is absent. */
        if (!is_array($policy) || ($policy['version']??'')!=='COMMERCIAL_WEEKLY_SCHEDULE_V1' || !is_array($policy['days']??null))
            return ['valid'=>false,'source'=>'WEEKLY_POLICY','version'=>'COMMERCIAL_WEEKLY_SCHEDULE_V1','proactive'=>false,'windows'=>'','spacing_seconds'=>86400,'timezone'=>'America/Sao_Paulo','day_key'=>'','error'=>'WEEKLY_POLICY_INVALID'];
        $tz_name=trim((string)($policy['timezone']??'America/Sao_Paulo'));
        try { $tz=new DateTimeZone($tz_name); $local=$now?$now->setTimezone($tz):new DateTimeImmutable('now',$tz); }
        catch (Throwable $e) { return ['valid'=>false,'source'=>'WEEKLY_POLICY','version'=>'COMMERCIAL_WEEKLY_SCHEDULE_V1','proactive'=>false,'windows'=>'','spacing_seconds'=>86400,'timezone'=>$tz_name,'day_key'=>'','error'=>'WEEKLY_TIMEZONE_INVALID']; }
        $keys=[1=>'mon',2=>'tue',3=>'wed',4=>'thu',5=>'fri',6=>'sat',7=>'sun'];
        /* Validate the whole week up front. Friday health must already catch a
         * broken Saturday policy instead of discovering it while sending. */
        foreach(array_values($keys) as $required_key){
            $candidate=is_array($policy['days'][$required_key]??null)?$policy['days'][$required_key]:null;
            if(!$candidate) return ['valid'=>false,'source'=>'WEEKLY_POLICY','version'=>'COMMERCIAL_WEEKLY_SCHEDULE_V1','proactive'=>false,'windows'=>'','spacing_seconds'=>86400,'timezone'=>$tz_name,'day_key'=>$required_key,'error'=>'DAY_POLICY_MISSING'];
            $candidate_proactive=!empty($candidate['proactive']);
            if($candidate_proactive){
                $candidate_spacing=(int)($candidate['spacing_seconds']??0);$candidate_ranges=0;
                foreach((array)($candidate['windows']??[]) as $candidate_range){
                    $candidate_range=trim((string)$candidate_range);
                    if(preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d-(?:[01]\d|2[0-3]):[0-5]\d$/',$candidate_range)){[$ca,$cb]=explode('-',$candidate_range,2);if($cb>$ca)$candidate_ranges++;}
                }
                if($candidate_spacing<300||$candidate_ranges<1) return ['valid'=>false,'source'=>'WEEKLY_POLICY','version'=>'COMMERCIAL_WEEKLY_SCHEDULE_V1','proactive'=>false,'windows'=>'','spacing_seconds'=>86400,'timezone'=>$tz_name,'day_key'=>$required_key,'error'=>'DAY_POLICY_INVALID'];
            }
        }
        $day_key=$keys[(int)$local->format('N')]??'';
        $day=is_array($policy['days'][$day_key]??null)?$policy['days'][$day_key]:null;
        $proactive=!empty($day['proactive']);
        $ranges=[];
        foreach((array)($day['windows']??[]) as $range){
            $range=trim((string)$range);
            if(preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d-(?:[01]\d|2[0-3]):[0-5]\d$/',$range)){
                [$a,$b]=explode('-',$range,2); if($b>$a)$ranges[]=$range;
            }
        }
        $spacing=(int)($day['spacing_seconds']??0);
        /* 300 seconds is the absolute code fence. Current Saturday policy uses
         * 350s; weekdays use 600s. Anything faster fails closed. */
        if($proactive && ($spacing<300 || !$ranges)) return ['valid'=>false,'source'=>'WEEKLY_POLICY','version'=>'COMMERCIAL_WEEKLY_SCHEDULE_V1','proactive'=>false,'windows'=>'','spacing_seconds'=>86400,'timezone'=>$tz_name,'day_key'=>$day_key,'error'=>'DAY_POLICY_INVALID'];
        if(!$proactive) return ['valid'=>true,'source'=>'WEEKLY_POLICY','version'=>'COMMERCIAL_WEEKLY_SCHEDULE_V1','proactive'=>false,'windows'=>'','spacing_seconds'=>86400,'timezone'=>$tz_name,'day_key'=>$day_key];
        return ['valid'=>true,'source'=>'WEEKLY_POLICY','version'=>'COMMERCIAL_WEEKLY_SCHEDULE_V1','proactive'=>true,'windows'=>implode(',',$ranges).' '.$tz_name,'spacing_seconds'=>$spacing,'spacing_max_seconds'=>self::spacing_max($spacing,(int)($day['spacing_max_seconds']??0)),'timezone'=>$tz_name,'day_key'=>$day_key];
    }

    /** Optional upper bound for the random gap between D0s (Airtable: spacing_max_seconds). Never below the base, never above 30 min; 0 = off. */
    public static function spacing_max(int $base,int $max): int {
        if ($max<=$base) return 0;
        return min($max,1800);
    }

    /** Stable (per seed) gap in [base, max]: lets the cadence vary 4..10 min instead of a fixed robot-like interval. The real send fence still keeps the base floor. */
    public static function spread_gap(int $base,int $max,int $seed): int {
        if ($max<=$base) return $base;
        return $base+(int)round((crc32((string)$seed)%1001)/1000*($max-$base));
    }

    /**
     * Resolve a class-specific proactive schedule while retaining the proven
     * weekly-policy validator. Missing class policy inherits the shared policy;
     * a present-but-malformed class policy fails closed.
     */
    public static function class_min_spacing_seconds(string $action): int {
        $action=strtoupper(trim($action));
        // D0 has an explicitly approved 240s Saturday floor. Follow-up/nurture
        // keep the older 300s code floor; the live policy itself remains 600s.
        return $action==='TEMPLATE_INITIAL'?240:300;
    }

    public static function class_commercial_policy(array $cfg,string $action,?DateTimeImmutable $now=null): array {
        $action=strtoupper(trim($action));
        $key=$action==='TEMPLATE_INITIAL'?'COMMERCIAL_D0_WEEKLY_SCHEDULE_V1':
            (in_array($action,['FOLLOWUP','TEMPLATE_NURTURE'],true)?'COMMERCIAL_FOLLOWUP_WEEKLY_SCHEDULE_V1':'');
        if($key==='') return self::weekly_commercial_policy($cfg,$now);
        $raw=trim((string)($cfg[$key]??''));
        if($raw==='') return self::weekly_commercial_policy($cfg,$now);
        $decoded=json_decode($raw,true);
        if(!is_array($decoded) || ($decoded['version']??'')!=='COMMERCIAL_CLASS_SCHEDULE_V1' || !is_array($decoded['days']??null)) {
            return ['valid'=>false,'source'=>$key,'version'=>'COMMERCIAL_CLASS_SCHEDULE_V1','proactive'=>false,'windows'=>'','spacing_seconds'=>86400,'timezone'=>'America/Sao_Paulo','day_key'=>'','error'=>'CLASS_POLICY_INVALID'];
        }
        $tz_name=trim((string)($decoded['timezone']??'America/Sao_Paulo'));
        try{$tz=new DateTimeZone($tz_name);$local=$now?$now->setTimezone($tz):new DateTimeImmutable('now',$tz);}catch(Throwable $e){
            return ['valid'=>false,'source'=>$key,'version'=>'COMMERCIAL_CLASS_SCHEDULE_V1','proactive'=>false,'windows'=>'','spacing_seconds'=>86400,'timezone'=>$tz_name,'day_key'=>'','error'=>'CLASS_TIMEZONE_INVALID'];
        }
        $keys=[1=>'mon',2=>'tue',3=>'wed',4=>'thu',5=>'fri',6=>'sat',7=>'sun'];
        $floor=self::class_min_spacing_seconds($action);
        // Validate the entire class week so a future-day invalid policy is visible
        // before it can strand the commercial runtime at the next day boundary.
        foreach(array_values($keys) as $required_key){
            $candidate=is_array($decoded['days'][$required_key]??null)?$decoded['days'][$required_key]:null;
            if(!$candidate) return ['valid'=>false,'source'=>$key,'version'=>'COMMERCIAL_CLASS_SCHEDULE_V1','proactive'=>false,'windows'=>'','spacing_seconds'=>86400,'timezone'=>$tz_name,'day_key'=>$required_key,'error'=>'CLASS_DAY_POLICY_MISSING'];
            if(!empty($candidate['proactive'])){
                $candidate_spacing=(int)($candidate['spacing_seconds']??0);$candidate_ranges=0;
                foreach((array)($candidate['windows']??[]) as $candidate_range){
                    $candidate_range=trim((string)$candidate_range);
                    if(preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d-(?:[01]\d|2[0-3]):[0-5]\d$/',$candidate_range)){[$ca,$cb]=explode('-',$candidate_range,2);if($cb>$ca)$candidate_ranges++;}
                }
                if($candidate_spacing<$floor || $candidate_ranges<1) return ['valid'=>false,'source'=>$key,'version'=>'COMMERCIAL_CLASS_SCHEDULE_V1','proactive'=>false,'windows'=>'','spacing_seconds'=>86400,'timezone'=>$tz_name,'day_key'=>$required_key,'error'=>'CLASS_DAY_POLICY_INVALID'];
            }
        }
        $day_key=$keys[(int)$local->format('N')]??'';
        $day=is_array($decoded['days'][$day_key]??null)?$decoded['days'][$day_key]:null;
        $proactive=!empty($day['proactive']);$ranges=[];
        foreach((array)($day['windows']??[]) as $range){
            $range=trim((string)$range);
            if(preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d-(?:[01]\d|2[0-3]):[0-5]\d$/',$range)){[$a,$b]=explode('-',$range,2);if($b>$a)$ranges[]=$range;}
        }
        $spacing=(int)($day['spacing_seconds']??0);
        if($proactive && ($spacing<$floor || !$ranges)) return ['valid'=>false,'source'=>$key,'version'=>'COMMERCIAL_CLASS_SCHEDULE_V1','proactive'=>false,'windows'=>'','spacing_seconds'=>86400,'timezone'=>$tz_name,'day_key'=>$day_key,'error'=>'CLASS_DAY_POLICY_INVALID'];
        if(!$proactive) return ['valid'=>true,'source'=>$key,'version'=>'COMMERCIAL_CLASS_SCHEDULE_V1','proactive'=>false,'windows'=>'','spacing_seconds'=>86400,'timezone'=>$tz_name,'day_key'=>$day_key];
        return ['valid'=>true,'source'=>$key,'version'=>'COMMERCIAL_CLASS_SCHEDULE_V1','proactive'=>true,'windows'=>implode(',',$ranges).' '.$tz_name,'spacing_seconds'=>$spacing,'timezone'=>$tz_name,'day_key'=>$day_key];
    }

    /**
     * Aggregate transport floor across proactive classes.
     * 10.9.9 adds an explicit weekly aggregate policy so Saturday can use a
     * different aggregate floor without weakening weekday behavior. A weekly
     * policy is fail-closed when malformed. If absent, the proven scalar/legacy
     * path remains unchanged and never goes below 300s.
     */
    public static function global_proactive_min_seconds(array $cfg,?DateTimeImmutable $now=null): int {
        $weekly_raw=trim((string)($cfg['COMMERCIAL_GLOBAL_PROACTIVE_WEEKLY_POLICY_V1']??''));
        if($weekly_raw!=='') {
            $policy=json_decode($weekly_raw,true);
            if(!is_array($policy) || ($policy['version']??'')!=='COMMERCIAL_GLOBAL_PROACTIVE_WEEKLY_POLICY_V1' || !is_array($policy['days']??null)) return 86400;
            $tz_name=trim((string)($policy['timezone']??'America/Sao_Paulo'));
            try{$tz=new DateTimeZone($tz_name);$local=$now?$now->setTimezone($tz):new DateTimeImmutable('now',$tz);}catch(Throwable $e){return 86400;}
            $keys=[1=>'mon',2=>'tue',3=>'wed',4=>'thu',5=>'fri',6=>'sat',7=>'sun'];
            foreach(array_values($keys) as $required_key){
                $day=is_array($policy['days'][$required_key]??null)?$policy['days'][$required_key]:null;
                if(!$day) return 86400;
                $n=(int)($day['min_seconds']??0);
                if($n<120 || $n>3600) return 86400;
            }
            $day_key=$keys[(int)$local->format('N')]??'';
            return (int)($policy['days'][$day_key]['min_seconds']??86400);
        }
        $raw=trim((string)($cfg['COMMERCIAL_GLOBAL_PROACTIVE_MIN_SECONDS_V1']??''));
        if($raw==='') {
            $shared=self::weekly_commercial_policy($cfg,$now);
            return max(300,(int)($shared['spacing_seconds']??600));
        }
        if(!preg_match('/^\d{3,4}$/',$raw)) return 86400;
        $n=(int)$raw;
        return ($n>=300 && $n<=3600)?$n:86400;
    }

    /** Next opening for a class-specific schedule; malformed policy stays fail-closed. */
    public static function seconds_until_next_class_window(array $cfg,string $action,?DateTimeImmutable $now=null): int {
        $action=strtoupper(trim($action));
        $key=$action==='TEMPLATE_INITIAL'?'COMMERCIAL_D0_WEEKLY_SCHEDULE_V1':
            (in_array($action,['FOLLOWUP','TEMPLATE_NURTURE'],true)?'COMMERCIAL_FOLLOWUP_WEEKLY_SCHEDULE_V1':'');
        if($key==='' || trim((string)($cfg[$key]??''))==='') return self::seconds_until_next_weekly_window($cfg,$now);
        $decoded=json_decode((string)$cfg[$key],true);
        if(!is_array($decoded) || ($decoded['version']??'')!=='COMMERCIAL_CLASS_SCHEDULE_V1' || !is_array($decoded['days']??null)) return 3600;
        $decoded['version']='COMMERCIAL_WEEKLY_SCHEDULE_V1';
        $shadow=$cfg;$shadow['COMMERCIAL_WEEKLY_SCHEDULE_V1']=self::json($decoded);
        return self::seconds_until_next_weekly_window($shadow,$now);
    }

    public static function inside_window(string $windows, ?DateTimeImmutable $now=null): bool {
        [$ranges, $tz_name] = self::parse_windows($windows);
        if (!$ranges) return false;
        try {
            $tz=new DateTimeZone($tz_name);
            $now=$now?$now->setTimezone($tz):new DateTimeImmutable('now',$tz);
        } catch (Throwable $e) {
            return false;
        }
        $hm = $now->format('H:i');
        foreach ($ranges as [$start, $end]) {
            /* End-exclusive: 09:00-12:00 means the lunch pause starts at 12:00. */
            if ($hm >= $start && $hm < $end) return true;
        }
        return false;
    }

    /** Next active weekly window, respecting proactive=false days. */
    public static function seconds_until_next_weekly_window(array $cfg, ?DateTimeImmutable $now=null): int {
        $raw=trim((string)($cfg['COMMERCIAL_WEEKLY_SCHEDULE_V1']??''));
        if($raw==='') return self::seconds_until_next_window((string)($cfg['COMMERCIAL_WINDOWS']??'09:00-18:00 America/Sao_Paulo'));
        $policy=json_decode($raw,true);
        if(!is_array($policy)||($policy['version']??'')!=='COMMERCIAL_WEEKLY_SCHEDULE_V1'||!is_array($policy['days']??null)) return 3600;
        $tz_name=trim((string)($policy['timezone']??'America/Sao_Paulo'));
        try{$tz=new DateTimeZone($tz_name);$local=$now?$now->setTimezone($tz):new DateTimeImmutable('now',$tz);}catch(Throwable $e){return 3600;}
        $keys=[1=>'mon',2=>'tue',3=>'wed',4=>'thu',5=>'fri',6=>'sat',7=>'sun'];$candidates=[];
        for($offset=0;$offset<=7;$offset++){
            $date_obj=$local->modify('+'.$offset.' day');$key=$keys[(int)$date_obj->format('N')]??'';$day=$policy['days'][$key]??null;
            if(!is_array($day)||empty($day['proactive']))continue;
            foreach((array)($day['windows']??[]) as $range){
                $range=trim((string)$range);if(!preg_match('/^((?:[01]\d|2[0-3]):[0-5]\d)-((?:[01]\d|2[0-3]):[0-5]\d)$/',$range,$m))continue;
                try{$candidate=new DateTimeImmutable($date_obj->format('Y-m-d').' '.$m[1].':00',$tz);}catch(Throwable $e){continue;}
                if($candidate>$local)$candidates[]=$candidate;
            }
            if($candidates)break;
        }
        if(!$candidates)return 3600;usort($candidates,static fn(DateTimeImmutable $a,DateTimeImmutable $b):int=>$a<=>$b);
        return max(60,$candidates[0]->getTimestamp()-$local->getTimestamp());
    }

    /**
     * Seconds until the next configured commercial window starts. Used for
     * deferral without burning retry attempts.
     */
    public static function seconds_until_next_window(string $windows): int {
        [$ranges, $tz_name] = self::parse_windows($windows);
        if (!$ranges) return 3600;
        try {
            $tz = new DateTimeZone($tz_name);
            $now = new DateTimeImmutable('now', $tz);
        } catch (Throwable $e) {
            return 3600;
        }

        $candidates = [];
        for ($day = 0; $day <= 7; $day++) {
            $date = $now->modify('+' . $day . ' day')->format('Y-m-d');
            foreach ($ranges as [$start, $end]) {
                try {
                    $candidate = new DateTimeImmutable($date . ' ' . $start . ':00', $tz);
                } catch (Throwable $e) {
                    continue;
                }
                if ($candidate > $now) $candidates[] = $candidate;
            }
            if ($candidates) break;
        }
        if (!$candidates) return 3600;
        usort($candidates, static fn(DateTimeImmutable $a, DateTimeImmutable $b): int => $a <=> $b);
        return max(60, $candidates[0]->getTimestamp() - $now->getTimestamp());
    }

    /** Number of fixed initiation slots in the configured windows. */
    public static function initial_slot_count(string $windows,int $interval): int {
        [$ranges,]=self::parse_windows($windows);
        if (!$ranges || $interval<=0) return 0;
        $total=0;
        foreach($ranges as [$start,$end]) {
            [$sh,$sm]=array_map('intval',explode(':',$start));[$eh,$em]=array_map('intval',explode(':',$end));
            $seconds=(($eh*60+$em)-($sh*60+$sm))*60;
            if ($seconds>0) $total+=(int)floor($seconds/$interval);
        }
        return $total;
    }

    /**
     * Return the current wall-clock initiation slot for a commercial window.
     * Slot boundaries are anchored to each configured window start, so a late
     * cron wake never shifts the rest of the day's cadence. Window ends are
     * exclusive for slot creation (09:00-12:00 with 600s => 09:00..11:50).
     */
    public static function current_initial_slot(string $windows, int $interval, ?DateTimeImmutable $now=null): array {
        [$ranges, $tz_name] = self::parse_windows($windows);
        if (!$ranges || $interval <= 0) return ['ok'=>false,'reason'=>'NO_SLOT_GRID','timezone'=>$tz_name];
        try {
            $tz = new DateTimeZone($tz_name);
            $now = $now ? $now->setTimezone($tz) : new DateTimeImmutable('now', $tz);
        } catch (Throwable $e) {
            return ['ok'=>false,'reason'=>'INVALID_TIMEZONE','timezone'=>$tz_name];
        }
        $date=$now->format('Y-m-d');
        $now_ts=$now->getTimestamp();
        foreach ($ranges as $range_index => [$start_hm,$end_hm]) {
            try {
                $start=new DateTimeImmutable($date.' '.$start_hm.':00',$tz);
                $end=new DateTimeImmutable($date.' '.$end_hm.':00',$tz);
            } catch (Throwable $e) { continue; }
            $start_ts=$start->getTimestamp();$end_ts=$end->getTimestamp();
            if ($end_ts <= $start_ts || $now_ts < $start_ts || $now_ts >= $end_ts) continue;
            $slot_index=(int)floor(($now_ts-$start_ts)/$interval);
            $slot_ts=$start_ts+($slot_index*$interval);
            if ($slot_ts >= $end_ts) continue;
            $slot=(new DateTimeImmutable('@'.$slot_ts))->setTimezone($tz);
            return [
                'ok'=>true,'timezone'=>$tz_name,'local_date'=>$date,'range_index'=>$range_index,
                'slot_index'=>$slot_index,'slot_ts'=>$slot_ts,'slot_local'=>$slot->format('Y-m-d H:i:s'),
                'slot_key'=>$date.'|'.$range_index.'|'.$slot_index.'|'.$interval,
            ];
        }
        return ['ok'=>false,'reason'=>'OUTSIDE_WINDOW','timezone'=>$tz_name,'local_date'=>$date];
    }

    /**
     * First configured business-window instant at or after a UTC timestamp.
     * Used for contextual follow-up scheduling; returns 0 if config is invalid.
     */
    public static function next_window_time_at_or_after(int $after_ts, string $windows): int {
        [$ranges,$tz_name]=self::parse_windows($windows);
        if (!$ranges || $after_ts<=0) return 0;
        try { $tz=new DateTimeZone($tz_name); }
        catch (Throwable $e) { return 0; }
        $cursor=(new DateTimeImmutable('@'.$after_ts))->setTimezone($tz);
        for($day=0;$day<=3;$day++) {
            $date=$cursor->modify('+'.$day.' day')->format('Y-m-d');
            foreach($ranges as [$start_hm,$end_hm]) {
                try {
                    $start=new DateTimeImmutable($date.' '.$start_hm.':00',$tz);
                    $end=new DateTimeImmutable($date.' '.$end_hm.':00',$tz);
                } catch(Throwable $e){ continue; }
                if ($end <= $start) continue;
                $candidate=$after_ts <= $start->getTimestamp() ? $start->getTimestamp() : $after_ts;
                if ($candidate < $end->getTimestamp()) return $candidate;
            }
        }
        return 0;
    }

    /** UTC bounds for today's calendar date in a given timezone. */
    public static function utc_bounds_for_local_day(string $tz_name): array {
        try {
            $tz = new DateTimeZone($tz_name);
            $local_now = new DateTimeImmutable('now', $tz);
            $start_local = new DateTimeImmutable($local_now->format('Y-m-d') . ' 00:00:00', $tz);
            $end_local = $start_local->modify('+1 day');
            $utc = new DateTimeZone('UTC');
            return [
                $start_local->setTimezone($utc)->format('Y-m-d H:i:s'),
                $end_local->setTimezone($utc)->format('Y-m-d H:i:s'),
            ];
        } catch (Throwable $e) {
            $start = gmdate('Y-m-d 00:00:00');
            return [$start, gmdate('Y-m-d H:i:s', strtotime($start . ' +1 day'))];
        }
    }

    public static function redact_error(string $message, int $max = 260): string {
        $message = self::short_text($message, $max * 2);
        // Avoid accidentally persisting obvious bearer/API secrets if an upstream
        // library ever includes them in an error string.
        $message = preg_replace('/(Bearer\s+)[A-Za-z0-9._\-]+/i', '$1[REDACTED]', $message);
        $message = preg_replace('/\b(sk-[A-Za-z0-9_\-]{10,}|pat[A-Za-z0-9_\-]{10,})\b/i', '[REDACTED]', (string)$message);
        if (function_exists('mb_substr')) return mb_substr((string)$message, 0, $max, 'UTF-8');
        return substr((string)$message, 0, $max);
    }
}
