<?php
define('ABSPATH', __DIR__.'/');
define('ARRAY_A','ARRAY_A');
$GLOBALS['opts']=[];$GLOBALS['autoload']=[];
foreach (['wp_strip_all_tags','sanitize_email','is_email','apply_filters','wp_json_encode','home_url','esc_url_raw'] as $fn) { if(!function_exists($fn)) { eval('function '.$fn.'(...$a){return $a[0]??"";}'); } }
function get_option($k,$d=false){return $GLOBALS['opts'][$k]??$d;}
function update_option($k,$v,$a=null){$GLOBALS['opts'][$k]=$v;$GLOBALS['autoload'][$k]=$a;return true;}
final class WFCA_DB { public static function t($n){return 'wp_wfca_'.$n;} }
final class WFCA_Alerts { public static $raised=[]; public static function raise(...$a){self::$raised[]=$a;return 1;} }
final class WFCA_Ownership { public static function arm(string $a): string {return $a;} public static function remote_arm(string $a): string {return $a;} }
final class FakeWpdb { public $rows=[]; public function prepare($q,...$a){return $q;} public function get_results($q,$t=null){return $this->rows;} }
$wpdb=new FakeWpdb();
require_once __DIR__.'/../includes/class-wfca-util.php';
require_once __DIR__.'/../includes/class-wfca-engine.php';
$pass=0;$fail=0;function t($n,$c){global $pass,$fail;if($c){echo "PASS $n\n";$pass++;}else{echo "FAIL $n\n";$fail++;}}
$K='wfca_delivery_fail_counters';
t('parse code',WFCA_Util::delivery_fail_code('WA_ERR code=131026 title=Message undeliverable')==='code_131026');
t('parse NO_DETAIL',WFCA_Util::delivery_fail_code('WA_ERR NO_DETAIL m_keys=a,b k_keys=c')==='NO_DETAIL');
t('code= inside free text is ignored (anchored at WA_ERR code=)',WFCA_Util::delivery_fail_code('WA_ERR code= title=Foo msg=see code=9999 here')==='NO_DETAIL');
t('empty code is NO_DETAIL',WFCA_Util::delivery_fail_code('WA_ERR code= title=x')==='NO_DETAIL');
$t0=gmmktime(12,0,0,3,10,2026);
WFCA_Util::record_delivery_failure('WA_ERR code=131026 title=X','+5511987654321',$t0);
WFCA_Util::record_delivery_failure('WA_ERR code=131026 title=X','+5511999990000',$t0+5);
WFCA_Util::record_delivery_failure('WA_ERR NO_DETAIL m_keys=a','+5511987651111',$t0+9);
$c=WFCA_Util::delivery_fail_counters();
t('increments per code',$c['codes']['code_131026']['count']===2&&$c['codes']['NO_DETAIL']['count']===1);
t('last_tail4 and last_at stored',$c['codes']['code_131026']['last_tail4']==='0000'&&$c['codes']['code_131026']['last_at']==='2026-03-10T12:00:05Z');
t('not autoloaded',$GLOBALS['autoload'][$K]===false);
$raw=json_encode($GLOBALS['opts'][$K]);
t('no full phone / no message text in storage',!str_contains($raw,'5511987654321')&&!str_contains($raw,'987654321')&&!str_contains($raw,'Message undeliverable')&&!str_contains($raw,'title'));
// key cap
$GLOBALS['opts']=[];
for($i=0;$i<60;$i++) WFCA_Util::record_delivery_failure("WA_ERR code=$i title=x",'1234',$t0);
$c=WFCA_Util::delivery_fail_counters();
t('key cap 40 + overflow bucket',count($c['codes'])===41&&$c['codes']['code_OTHER']['count']===20);
t('existing key still increments at cap',(function(){WFCA_Util::record_delivery_failure('WA_ERR code=3 title=x','1234',1773144000);return WFCA_Util::delivery_fail_counters()['codes']['code_3']['count']===2;})());
// 7 day buckets
$GLOBALS['opts']=[];
for($d=0;$d<10;$d++) WFCA_Util::record_delivery_failure('WA_ERR code=1 title=x','9999',$t0+$d*86400);
$c=WFCA_Util::delivery_fail_counters();$ks=array_keys($c['days']);
t('only last 7 UTC days kept',count($ks)===7&&$ks[0]==='2026-03-13'&&$ks[6]==='2026-03-19');
WFCA_Util::record_delivery_failure('WA_ERR code=1 title=x','9999',$t0+9*86400+60);
t('day bucket counts',WFCA_Util::delivery_fail_counters()['days']['2026-03-19']['code_1']===2);
// never throws
$GLOBALS['opts'][$K]='garbage';
$ok=true;try{WFCA_Util::record_delivery_failure('WA_ERR code=7 title=x','1');$ok=WFCA_Util::delivery_fail_counters()['codes']['code_7']['count']===1;}catch(\Throwable $e){$ok=false;}
t('tolerates corrupt option, never throws',$ok);
// brake isolation
$m=(new ReflectionClass('WFCA_Engine'))->getMethod('d0_delivery_brake_active');$m->setAccessible(true);
$rules=['d0_delivery_brake_enabled'=>true,'d0_delivery_brake_failure_ratio'=>0.30];
function rows($d,$f){$r=[];for($i=0;$i<$d;$i++)$r[]=['delivery_status'=>'delivered'];for($i=0;$i<$f;$i++)$r[]=['delivery_status'=>'failed'];return $r;}
$res=[];
foreach ([true,false] as $with) foreach ([[8,2],[6,4]] as [$d,$f]) {
  $GLOBALS['opts']=[];WFCA_Alerts::$raised=[];$wpdb->rows=rows($d,$f);
  if($with) for($i=0;$i<500;$i++) WFCA_Util::record_delivery_failure('WA_ERR code=1 title=x','1111',$t0);
  $r=$m->invoke(null,$rules);$o=$GLOBALS['opts'];unset($o[$K]);
  $res[$with?'with':'without'][]=[$r,$o,count(WFCA_Alerts::$raised)];
}
t('brake result, options and alerts identical with and without counters',$res['with']===$res['without']&&$res['with'][0][0]===false&&$res['with'][1][0]===true);
$eng=file_get_contents(__DIR__.'/../includes/class-wfca-engine.php');
$brake=substr($eng,strpos($eng,'function d0_delivery_brake_active'),1500);
t('brake source never references counters',!str_contains($brake,'delivery_fail_counters')&&!str_contains($brake,'record_delivery_failure'));
$n=0;foreach(glob(__DIR__.'/../includes/*.php') as $f){$n+=substr_count(file_get_contents($f),'delivery_fail_counters');}
t('counters read only by rest health + admin + util',$n>=4);
echo "TOTAL PASS=$pass FAIL=$fail\n";exit($fail?1:0);
