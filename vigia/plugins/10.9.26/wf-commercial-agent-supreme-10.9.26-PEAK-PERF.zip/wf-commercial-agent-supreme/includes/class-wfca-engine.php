<?php
if (!defined('ABSPATH')) exit;

final class WFCA_Engine {
    public static function tick(): void {
        $entered=WFCA_Util::now_iso();

        // Whole-tick single-flight. Individual send/conversation mutexes protect
        // effects, but they do not prevent two 60s cron callbacks from racing
        // through the expensive producer/reconciliation phases at the same time.
        // A skipped overlapping callback must not overwrite the active tick's
        // canonical telemetry; it writes only side telemetry and returns.
        if (!WFCA_Ownership::lock('minute-tick')) {
            update_option('wfca_tick_overlap_skipped_at',$entered,false);
            update_option('wfca_tick_overlap_skip_count',max(0,(int)get_option('wfca_tick_overlap_skip_count',0))+1,false);
            return;
        }

        $run_id='WFCA-TICK-'.gmdate('YmdHis').'-'.substr(hash('sha256',$entered.'|'.wp_generate_password(12,false,false)),0,8);
        $stage='BOOT';
        $started=microtime(true);
        $result='COMPLETED';
        $skip='';
        update_option('wfca_tick_run_id',$run_id,false);
        update_option('wfca_tick_stage',$stage,false);
        update_option('wfca_tick_exception','',false);
        // Compatibility marker: this remains the first persistent marker after
        // the single-flight admission fence.
        update_option('wfca_last_tick_at',$entered,false);

        try {
            $due=(string)get_option('wfca_tick_due_at','');
            if ($due==='') {
                $next=wp_next_scheduled('wfca_minute_tick');
                $due=$next?gmdate('c',(int)$next):'';
            }
            update_option('wfca_tick_entered_at',$entered,false);
            update_option('wfca_tick_due_at',$due,false);

            $stage='OWNERSHIP_RECOVER'; update_option('wfca_tick_stage',$stage,false);
            WFCA_Ownership::recover();
            $stage='ALERTS_PRE'; update_option('wfca_tick_stage',$stage,false);
            WFCA_Alerts::process_queue(4);
            $stage='MODE_STATE'; update_option('wfca_tick_stage',$stage,false);
            $mode_state=WFCA_Airtable::mode_state();
            $mode=(string)$mode_state['base_mode'];
            $draining=(bool)$mode_state['draining'];
            if ($mode==='OFF') {
                $result='SKIPPED';
                $skip='MODE_OFF';
                return;
            }

            $stage='RECOVER_LOCAL'; update_option('wfca_tick_stage',$stage,false);
            self::fail_exhausted_stale_events();
            WFCA_DB::recover_stale_events(300);
            WFCA_DB::recover_stale_outbox(600);
            self::surface_uncertain_outbox(6);

            // Process fresh inbound before any outbound so opt-out/handoff/reply
            // truth wins. Then drain already-durable outbox effects BEFORE the
            // expensive inventory/follow-up producer phases. A producer defect
            // can no longer starve previously reserved D0s.
            $stage='INBOUND_RECOVERY'; update_option('wfca_tick_stage',$stage,false);
            self::recover_pending_inbound(6);
            $stage='OUTBOX_DRAIN'; update_option('wfca_tick_stage',$stage,false);
            self::process_outbox(8,$mode_state);
            $stage='POST_SEND_RECONCILE'; update_option('wfca_tick_stage',$stage,false);
            self::reconcile_sent_outbox(4);
            self::verify_pending_orders(4);
            self::reconcile_paid_orders(3);

            $stage='INVENTORY_MATERIALIZE'; update_option('wfca_tick_stage',$stage,false);
            if (!$draining) self::materialize_commercial_ready_inventory(250);

            // D0 production remains before follow-up production. New reservations
            // intentionally wait for the next natural tick; the durable outbox is
            // the boundary and real provider spacing remains sovereign.
            $stage='D0_SCHEDULE'; update_option('wfca_tick_stage',$stage,false);
            if (!$draining) self::schedule_initial_contacts();

            $stage='FOLLOWUP_MATERIALIZE'; update_option('wfca_tick_stage',$stage,false);
            if (!$draining) self::materialize_due_d0_followup(1);
            $stage='FOLLOWUP_SCHEDULE'; update_option('wfca_tick_stage',$stage,false);
            $followup_state=$draining?['reserved'=>0,'skip_reason'=>'DRAINING_NO_NEW_PROACTIVE']:self::schedule_due_followups(1);
            $skip=(string)($followup_state['skip_reason']??'');

            $stage='NURTURE_SCHEDULE'; update_option('wfca_tick_stage',$stage,false);
            if (!$draining) self::schedule_paid_nurture();
            $stage='ALERTS_POST'; update_option('wfca_tick_stage',$stage,false);
            WFCA_Alerts::process_queue(4);
            $stage='DONE'; update_option('wfca_tick_stage',$stage,false);
        } catch (Throwable $e) {
            $result='ERROR';
            $skip='EXCEPTION_'.get_class($e);
            $detail=$stage.'|'.get_class($e).'|'.WFCA_Util::redact_error($e->getMessage(),320);
            update_option('wfca_tick_exception',WFCA_Util::short_text($detail,420),false);
            // Do not rethrow from WP-Cron. The error remains durable/observable,
            // the single-flight lock is released in finally, and the next natural
            // tick gets a clean chance to recover instead of crashing the cron request.
        } finally {
            $exited=WFCA_Util::now_iso();
            $next=wp_next_scheduled('wfca_minute_tick');
            update_option('wfca_tick_due_at',$next?gmdate('c',(int)$next):'',false);
            update_option('wfca_tick_exited_at',$exited,false);
            update_option('wfca_tick_duration_ms',max(0,(int)round((microtime(true)-$started)*1000)),false);
            update_option('wfca_tick_result',WFCA_Util::short_text($result,64),false);
            update_option('wfca_tick_skip_reason',WFCA_Util::short_text($skip,191),false);
            WFCA_Ownership::unlock('minute-tick');
        }
    }

    private static function recover_pending_inbound(int $limit=6): void {
        foreach (WFCA_DB::pending_event_ids($limit) as $id) self::process_inbound($id);
    }

    private static function fail_exhausted_stale_events(): void {
        foreach (WFCA_DB::exhausted_stale_events(300,10) as $event) {
            $id=(int)$event['id'];
            $reason='EVENT_PROCESSING_EXHAUSTED';
            WFCA_DB::finish_event($id,'ERROR',$reason);
            $phone=(string)($event['phone_e164']??'');
            $conv=$phone!==''?WFCA_DB::get_conversation_by_phone($phone):null;
            $lead_id=(string)($conv['lead_record_id']??'');
            WFCA_Alerts::raise($reason,'CRITICAL',$lead_id,(int)($conv['id']??0),$id,(string)($event['body']??''),'event:'.$id.':exhausted');
        }
    }

    public static function process_inbound(int $event_id): void {
        $event=WFCA_DB::claim_event($event_id);
        if (!$event) return;
        $lock='conversation:'.(string)$event['phone_e164'];
        if (!WFCA_Ownership::lock($lock)) { WFCA_DB::requeue_event($event_id,'CONVERSATION_BUSY');return; }
        try {
            if (self::process_transport_event($event_id,$event)) return;
            self::process_claimed_inbound($event_id,$event);
        } catch (Throwable $e) {
            $reason='UNEXPECTED_PROCESSING_ERROR:'.get_class($e).':'.$e->getMessage();
            $safe_reason=WFCA_Util::redact_error($reason,400);
            if ((int)($event['attempts']??0)<3) {
                WFCA_DB::requeue_event($event_id,$safe_reason);
                return;
            }
            WFCA_DB::finish_event($event_id,'ERROR',$safe_reason);
            $phone=(string)($event['phone_e164']??'');
            $conv=$phone!==''?WFCA_DB::get_conversation_by_phone($phone):null;
            $lead_id=(string)($conv['lead_record_id']??'');
            WFCA_Alerts::raise('UNEXPECTED_PROCESSING_ERROR','CRITICAL',$lead_id,(int)($conv['id']??0),$event_id,(string)($event['body']??''),'event:'.$event_id.':unexpected');
            if ($phone!=='' && $conv && $lead_id!=='' && !empty($event['provider_message_id'])) {
                $mode=WFCA_Airtable::mode();
                $status=WFCA_Ownership::queue_status();
                try {
                    self::handoff($phone,'UNEXPECTED_PROCESSING_ERROR',$lead_id,(int)$conv['id'],$event_id,(string)($event['body']??''),(string)$event['provider_message_id'],$status,true);
                } catch (Throwable $ignored) {
                    // The durable alert/event error above is the final safety net.
                }
            }
        } finally { WFCA_Ownership::unlock($lock); }
    }

    public static function manual_receipt(array $data): bool {
        $phone=(string)($data['phone']??$data['phone_e164']??'');
        if ($phone==='') return false;
        $c=WFCA_DB::upsert_conversation($phone,[]);
        if (!$c) return false;
        // "eu assumo" in Daniel's own message keeps Luna out until an explicit resume.
        $reason=preg_match('/\beu\s+assumo\b/iu',(string)($data['body']??''))?'WHATSAPP_BUSINESS_MANUAL_TAKEOVER':'WHATSAPP_BUSINESS_MANUAL';
        $r=WFCA_Ownership::change((int)$c['id'],'DANIEL',$reason,
            (int)$c['owner_revision'],false,(string)$data['occurred_at']);
        return !empty($r['ok']);
    }

    public const AUTO_RESUME_AFTER_SECONDS=1800;
    private const AUTO_RESUME_BLOCKED_STATES=['HUMAN_HANDOFF','ERROR_HOLD','PRICE_STATE','HIGH_INTENT','CHECKOUT_READY','CHECKOUT_SENT','PAYMENT_PENDING','PAID','OPT_OUT','NO_INTEREST'];

    /** A plain manual reply from Daniel does not silence Luna forever: 30 min later the next inbound resumes her. */
    private static function maybe_auto_resume(array $conv,array $remote_fields): array {
        if (($conv['conversation_owner']??'')!=='DANIEL' || ($conv['owner_reason']??'')!=='WHATSAPP_BUSINESS_MANUAL') return $conv;
        if (!empty($conv['opt_out']) || !empty($remote_fields['Opt Out']) || ($remote_fields['WhatsApp Permission Status']??'')==='OPT_OUT') return $conv;
        $rules=WFCA_Util::rules();
        if (empty($rules['auto_resume_enabled'])) return $conv;
        $blocked=array_merge(self::AUTO_RESUME_BLOCKED_STATES,$rules['auto_resume_extra_blocked_states']);
        if (in_array((string)($conv['state']??''),$blocked,true)) return $conv;
        if (in_array((string)($remote_fields['State']??''),$blocked,true)) return $conv;
        if (($remote_fields['Conversation Owner']??'')!=='DANIEL') return $conv;
        $manual=strtotime((string)($conv['last_manual_at']??'').' UTC');
        if (!$manual || time()-$manual<(int)$rules['auto_resume_after_seconds']) return $conv;
        $r=WFCA_Ownership::change((int)$conv['id'],'LUNA','AUTO_RESUME_AFTER_MANUAL_30M',(int)$conv['owner_revision'],true);
        if (empty($r['ok'])) return $conv;
        WFCA_Ownership::sync((int)$conv['id']);
        return WFCA_DB::get_conversation((int)$conv['id'])?:$conv;
    }

    private static function process_transport_event(int $id,array $e): bool {
        if (($e['provider']??'')!=='KAPSO' || ($e['origin']??'')==='history_sync') {
            WFCA_DB::finish_event($id,'HOLD','HISTORY_OR_LEGACY_TRANSPORT');return true;
        }
        if ($e['event_type']==='MANUAL_OUTBOUND') {
            if (!self::manual_receipt($e)) { WFCA_DB::requeue_event($id,'MANUAL_FENCE_RETRY');return true; }
            $c=WFCA_DB::get_conversation_by_phone($e['phone_e164']);
            if (empty($c['lead_record_id'])) {
                $match=WFCA_Airtable::find_lead_by_phone($e['phone_e164']);
                if (empty($match['ok'])) { WFCA_DB::finish_event($id,'HOLD','MANUAL_LEAD_NOT_IDENTIFIED');return true; }
                $c=WFCA_DB::upsert_conversation($e['phone_e164'],['lead_record_id'=>$match['lead']['id'],
                    'initial_arm'=>WFCA_Ownership::arm((string)($match['lead']['fields']['Assigned Arm']??''))]);
            }
            if (!WFCA_Ownership::sync((int)$c['id'])) { WFCA_DB::requeue_event($id,'MANUAL_OWNER_SYNC');return true; }
            $clear=WFCA_Airtable::update_commercial_by_phone($e['phone_e164'],['Next Commercial Action At'=>null]);
            if (empty($clear['ok'])) { WFCA_DB::requeue_event($id,'MANUAL_FOLLOWUP_CLEAR_SYNC');return true; }
            $touch=WFCA_Airtable::log_touch($c['lead_record_id'],'OUTBOUND','MANUAL_MESSAGE',$e['body'],$e['provider_message_id'],'KAPSO','DANIEL',(string)($c['initial_arm']??''));
            if (empty($touch['ok'])) { WFCA_DB::requeue_event($id,'MANUAL_TOUCH_SYNC');return true; }
            WFCA_DB::finish_event($id,'PROCESSED');return true;
        }
        if (str_starts_with((string)$e['event_type'],'DELIVERY_')) {
            $row=WFCA_DB::get_outbox_by_provider_sid((string)$e['provider_message_id']);
            if (!$row) {
                if ((int)$e['attempts']<5) WFCA_DB::requeue_event($id,'UNMATCHED_OUTBOUND_ECHO');
                else WFCA_DB::finish_event($id,'HOLD','UNMATCHED_API_SENDER_REVIEW_REQUIRED');
                return true;
            }
            $status=strtolower(substr($e['event_type'],9));
            $rank=['accepted'=>0,'sent'=>1,'delivered'=>2,'read'=>3,'failed'=>4];
            $previous=$row['delivery_status']??'accepted';
            if (isset($rank[$status]) && $rank[$status]>=($rank[$previous]??0)) {
                WFCA_DB::update_outbox((int)$row['id'],['delivery_status'=>$status,'delivery_at'=>$e['occurred_at']]);
                if (in_array($status,['delivered','read'],true)) {
                    $conv=WFCA_DB::get_conversation((int)$row['conversation_id']);
                    if ($conv && !empty($conv['phone_e164'])) {
                        $label=((string)($row['action_type']??'')==='FOLLOWUP')?'Follow-up':'WhatsApp initial';
                        WFCA_Airtable::update_commercial_by_phone((string)$conv['phone_e164'],['Conversation Summary'=>$label.' delivered to recipient; awaiting reply.']);
                    }
                }
                if ($status==='failed') {
                    $why=WFCA_Util::short_text((string)($e['body']??''),300);
                    $cv=WFCA_DB::get_conversation((int)$row['conversation_id']);
                    if ($why!=='' && $cv && !empty($cv['phone_e164'])) {
                        $tail=substr((string)$cv['phone_e164'],-4);
                        WFCA_Airtable::update_commercial_by_phone((string)$cv['phone_e164'],['Commercial Error'=>'WA_DELIVERY_FAILED '.$why.' tail='.$tail]);
                        if (!empty($row['lead_record_id'])) WFCA_Airtable::log_touch((string)$row['lead_record_id'],'OUTBOUND','DELIVERY_FAILED','WA_DELIVERY_FAILED '.$why.' tail='.$tail,(string)$e['provider_message_id'],'KAPSO','LUNA',(string)($cv['initial_arm']??''));
                    }
                }
                if ($status==='failed') { try { $fc=WFCA_DB::get_conversation((int)$row['conversation_id']); WFCA_Util::record_delivery_failure((string)($e['body']??''),(string)($fc['phone_e164']??'')); } catch (\Throwable $ex) {} }
                if ($status==='failed') WFCA_Alerts::raise('KAPSO_DELIVERY_FAILED','CRITICAL',$row['lead_record_id'],(int)$row['conversation_id'],$id,'','delivery:'.$e['provider_message_id']);
            }
            WFCA_DB::finish_event($id,'PROCESSED');return true;
        }
        if ($e['direction']!=='INBOUND' || $e['event_type']!=='MESSAGE') { WFCA_DB::finish_event($id,'HOLD','UNSUPPORTED_EVENT');return true; }
        return false;
    }

    private static function execute_alert(array $row): void {
        $variables=json_decode((string)($row['content_variables']??''),true)?:[];
        $sent=WFCA_Transport::send($row,(string)$row['body'],(string)($row['content_sid']??''),$variables);
        $id=(int)$row['id'];
        if (!empty($sent['ok'])) {
            WFCA_DB::mark_outbox_sent($id,(string)$sent['sid']);
        } elseif (!empty($sent['blocked'])) {
            WFCA_DB::set_outbox_status($id,'CANCELLED',(string)$sent['error']);
        } elseif (!empty($sent['ambiguous'])) {
            WFCA_DB::update_outbox($id,['status'=>'UNCERTAIN','last_error'=>$sent['error'],'uncertain_alerted'=>1]);
        } else WFCA_DB::retry_outbox($row,$sent['error']??'ALERT_SEND_FAILED');
        WFCA_Alerts::sync_outbox(WFCA_DB::get_outbox($id)?:$row);
    }

    private static function process_claimed_inbound(int $event_id,array $event): void {
        if (WFCA_Airtable::mode(true)==='OFF') {
            WFCA_DB::finish_event($event_id,'IGNORED_OFF');
            return;
        }

        $phone=(string)$event['phone_e164'];
        $body=(string)$event['body'];
        $media=json_decode((string)$event['media_json'],true) ?: [];
        $auto_reply=self::is_likely_autoresponder($body);
        $existing=WFCA_DB::get_conversation_by_phone($phone);

        if ($existing && (int)$existing['opt_out']===1) {
            if (!empty($existing['lead_record_id'])) {
                WFCA_Airtable::log_touch((string)$existing['lead_record_id'],'INBOUND','BLOCKED_OPT_OUT',$body,(string)$event['provider_message_id']);
            }
            WFCA_DB::finish_event($event_id,'HOLD','OPT_OUT_HARD_STOP');
            return;
        }

        if (!WFCA_Airtable::available()) {
            $conv=WFCA_DB::upsert_conversation($phone,['state'=>'ERROR_HOLD','human_hold'=>1,'summary'=>'Airtable unavailable']);
            WFCA_Alerts::raise('AIRTABLE_UNAVAILABLE','CRITICAL','',(int)($conv['id']??0),$event_id,$body,'event:'.$event_id.':airtable');
            WFCA_DB::finish_event($event_id,'ERROR','AIRTABLE_UNAVAILABLE');
            return;
        }

        $match=WFCA_Airtable::find_lead_by_phone($phone);
        if (!$match['ok'] && (($match['error']??'')==='LEAD_NOT_FOUND')) {
            // Do not manufacture an organic prospect from a clinic autoresponder.
            // These messages are transport noise, not a human sales interaction.
            if ($auto_reply) {
                WFCA_DB::upsert_conversation($phone,['state'=>'WAITING_REPLY','human_hold'=>1,'summary'=>'AUTO_REPLY_UNMATCHED']);
                WFCA_DB::finish_event($event_id,'HOLD','AUTO_REPLY_UNMATCHED');
                return;
            }
            $match=WFCA_Airtable::create_organic_inbound_lead($phone,$body);
        }
        if (!$match['ok']) {
            $reason=(string)($match['error']??'LEAD_MATCH_FAIL');
            $conv=WFCA_DB::upsert_conversation($phone,['state'=>'HUMAN_HANDOFF','human_hold'=>1,'summary'=>$reason]);
            WFCA_Alerts::raise('LEAD_MATCH_FAIL:'.$reason,'WARN','',(int)($conv['id']??0),$event_id,$body,'event:'.$event_id.':lead-match');
            WFCA_DB::finish_event($event_id,'HOLD',$reason);
            return;
        }

        $lead=$match['lead'];
        $lead_id=(string)$lead['id'];
        if ($existing && !empty($existing['lead_record_id']) && (string)$existing['lead_record_id']!==$lead_id && !WFCA_Airtable::lead_is_organic_intake($lead)) {
            $rebind=self::reconcile_canonical_lead_binding($phone,$lead,$existing);
            if (empty($rebind['ok'])) {
                $reason='CANONICAL_LEAD_REBIND_BLOCKED:'.(string)($rebind['error']??'UNKNOWN');
                WFCA_Alerts::raise($reason,'WARN',$lead_id,(int)($existing['id']??0),$event_id,$body,'event:'.$event_id.':canonical-rebind');
                WFCA_DB::finish_event($event_id,'HOLD',$reason);
                return;
            }
            $existing=$rebind['conversation']??$existing;
        }
        $organic=WFCA_Airtable::lead_is_organic_intake($lead);
        if (!WFCA_Airtable::lead_is_commercial_ready($lead) && !$organic) {
            $conv=WFCA_DB::upsert_conversation($phone,['lead_record_id'=>$lead_id,'state'=>'COMMERCIAL_NOT_ELIGIBLE','human_hold'=>1,'summary'=>'Factory not commercial-ready']);
            WFCA_Airtable::upsert_commercial_conversation($phone,$lead_id,[
                'State'=>'COMMERCIAL_NOT_ELIGIBLE','Enabled'=>false,'Last Inbound At'=>WFCA_Util::now_iso(),
                'Commercial Error'=>'Inbound arrived before BUILT + FACTORY_COMPLETE + Public Smoke PASS.'
            ]);
            WFCA_Airtable::log_touch($lead_id,'INBOUND','BLOCKED_NOT_READY',$body,(string)$event['provider_message_id']);
            WFCA_Alerts::raise('FACTORY_NOT_COMMERCIAL_READY','WARN',$lead_id,(int)($conv['id']??0),$event_id,$body,'event:'.$event_id.':not-ready');
            WFCA_DB::finish_event($event_id,'HOLD','FACTORY_NOT_COMMERCIAL_READY');
            return;
        }

        $existing=WFCA_DB::get_conversation_by_phone($phone);
        $arm=(string)($existing['initial_arm']??'');
        if ($arm==='') $arm=WFCA_Ownership::arm((string)($lead['fields']['Assigned Arm']??''));
        // Config-driven arms (WFCA_ARMS_V1): a NEW unknown number whose first message matches an arm tag (e.g. "... - A")
        // is routed to that arm's owner/prompt. Existing conversations keep the arm they were created with.
        $arm_cfg=null;$arm_new_tag='';
        if ($arm!=='') $arm_cfg=WFCA_Util::arm_by_id($arm);
        elseif ($organic && !$existing) {
            $hit=WFCA_Util::arm_for_inbound($body);
            if ($hit) { $arm=(string)$hit['id']; $arm_cfg=$hit; $arm_new_tag=(string)$hit['tag']; }
        }
        $event_ts=strtotime((string)($event['occurred_at']?:$event['received_at']).' UTC');
        $last=$existing && !empty($existing['last_inbound_at'])?strtotime($existing['last_inbound_at'].' UTC'):0;
        $inbound_ts=max($last,$event_ts?:0);
        $window_iso=gmdate('c',$inbound_ts+DAY_IN_SECONDS);

        if ($auto_reply) {
            $auto_owner=$existing['conversation_owner']??($arm==='LUNA_COLD_WHATSAPP'?'LUNA':'DANIEL');
            $conv=WFCA_DB::upsert_conversation($phone,[
                'lead_record_id'=>$lead_id,'initial_arm'=>$arm,'conversation_owner'=>$auto_owner,
                'service_window_until'=>gmdate('Y-m-d H:i:s',$inbound_ts+DAY_IN_SECONDS),
                'last_inbound_at'=>gmdate('Y-m-d H:i:s',$inbound_ts),'summary'=>'AUTO_REPLY_DETECTED'
            ]);
            if (!$conv) { WFCA_DB::finish_event($event_id,'ERROR','LOCAL_CONVERSATION_WRITE_FAIL');return; }
            $got=WFCA_Airtable::get_commercial_conversation($phone);
            if (!empty($got['ok'])) {
                $fields=['Last Inbound At'=>gmdate('c',$inbound_ts),'WhatsApp 24h Window Until'=>$window_iso,
                    'Conversation Summary'=>'Automated clinic responder detected; still awaiting a human reply.'];
                if (empty($got['record'])) {
                    $fields += ['State'=>'WAITING_REPLY','Enabled'=>$auto_owner==='LUNA','Conversation Owner'=>$auto_owner,
                        'Owner Revision'=>(int)$conv['owner_revision']];
                    if ($arm!=='') $fields['Initial Arm']=$arm;
                }
                WFCA_Airtable::upsert_commercial_conversation($phone,$lead_id,$fields,$got);
            }
            WFCA_Airtable::log_touch($lead_id,'INBOUND','AUTO_REPLY',$body,(string)$event['provider_message_id'],'KAPSO','PROSPECT',$arm);
            // Silent now: never answer an automated clinic questionnaire/menu as if it
            // were a person. If Luna owns this Factory lead, use the service window
            // opened by the inbound only for one delayed, contextual gatekeeper
            // follow-up. Any newer inbound cancels/supersedes it.
            $fresh_auto=WFCA_DB::get_conversation((int)$conv['id'])?:$conv;
            self::schedule_autoresponder_followup($fresh_auto,$lead);
            WFCA_DB::finish_event($event_id,'PROCESSED','AUTO_REPLY_DETECTED_SILENT');
            return;
        }

        $conv_fields=['lead_record_id'=>$lead_id,'initial_arm'=>$arm,
            'permission_status'=>'USER_INITIATED','service_window_until'=>gmdate('Y-m-d H:i:s',$inbound_ts+DAY_IN_SECONDS),
            'last_inbound_at'=>gmdate('Y-m-d H:i:s',$inbound_ts)];
        if (!$existing && in_array(WFCA_Airtable::base_mode(),['ASSISTED','LIVE'],true)) {
            if ($arm==='LUNA_COLD_WHATSAPP' || ($arm_cfg && ($arm_cfg['owner']??'LUNA')==='LUNA')) $conv_fields += ['conversation_owner'=>'LUNA','human_hold'=>0,'state'=>'ENGAGED'];
            else $conv_fields += ['conversation_owner'=>'DANIEL','human_hold'=>1,'state'=>'ENGAGED'];
        }
        $conv=WFCA_DB::upsert_conversation($phone,$conv_fields);
        if (!$conv) { WFCA_DB::finish_event($event_id,'ERROR','LOCAL_CONVERSATION_WRITE_FAIL');return; }
        if ($arm_new_tag!=='') {
            // Measure which ad converts: tag on the Lead + one INFO alert for Daniel. Failure here never blocks the reply.
            $u=WFCA_Airtable::update_lead($lead_id,['Ad Tag'=>$arm_new_tag,'Notes'=>(string)($lead['fields']['Notes']??'')."\nWFCA_ARM:".$arm.' TAG:'.$arm_new_tag]);
            if (empty($u['ok'])) WFCA_Airtable::log_touch($lead_id,'INBOUND','AD_TAG_WRITE_FAIL',$arm_new_tag,(string)$event['provider_message_id']);
            WFCA_Alerts::raise('NEW_INBOUND_LEAD:'.$arm.':'.$arm_new_tag,'INFO',$lead_id,(int)$conv['id'],$event_id,$body,'arm-new:'.$phone);
        }
        WFCA_DB::cancel_pending_followups((int)$conv['id'],'FOLLOWUP_SUPERSEDED_BY_INBOUND');
        WFCA_DB::cancel_pending_action((int)$conv['id'],'AUTO_REPLY_GATEKEEPER','AUTO_REPLY_GATEKEEPER_SUPERSEDED_BY_INBOUND');
        $got=WFCA_Airtable::get_commercial_conversation($phone);
        if (empty($got['ok'])) { WFCA_DB::requeue_event($event_id,'COMMERCIAL_STATE_READ_FAIL');return; }
        $cf=$got['record']['fields']??[];
        $sync_fields=['WhatsApp 24h Window Until'=>$window_iso,'Last Inbound At'=>gmdate('c',$inbound_ts),'Next Commercial Action At'=>null];
        if (($conv['conversation_owner']??'')==='LUNA' && ($conv['state']??'')==='FOLLOWUP_SCHEDULED') {
            WFCA_DB::upsert_conversation($phone,['state'=>'ENGAGED']);
            $conv=WFCA_DB::get_conversation((int)$conv['id'])?:$conv;
            $sync_fields['State']='ENGAGED';
        }
        if (empty($cf['Opt Out']) && ($cf['WhatsApp Permission Status']??'')!=='OPT_OUT') {
            $sync_fields['WhatsApp Permission Status']='USER_INITIATED';
            $sync_fields['WhatsApp Permission Evidence']='Kapso inbound '.(string)$event['provider_message_id'];
        }
        if (empty($got['record'])) {
            $default_owner=(string)($conv['conversation_owner']??'DANIEL');
            $sync_fields += ['State'=>'ENGAGED','Enabled'=>$default_owner==='LUNA',
                'Conversation Owner'=>$default_owner,'Owner Revision'=>(int)$conv['owner_revision']];
            // Airtable singleSelect rejects an empty string. Organic inbound
            // may have no Assigned Arm; preserve omission until an arm exists.
            if ($arm !== '') $sync_fields['Initial Arm'] = $arm;
        }
        $sync=WFCA_Airtable::upsert_commercial_conversation($phone,$lead_id,$sync_fields,$got);
        if (empty($sync['ok'])) { WFCA_DB::requeue_event($event_id,'AIRTABLE_CONVERSATION_WRITE_FAIL');return; }
        WFCA_Ownership::sync((int)$conv['id']);
        // STOP is interpreted even when Daniel owns the conversation, before media routing.
        if (self::is_explicit_opt_out($body)) {
            $d=['action'=>'OPT_OUT'];self::apply_decision($d,$lead,$conv,$event);WFCA_DB::finish_event($event_id,'PROCESSED');return;
        }
        $conv=self::maybe_auto_resume($conv,$cf);
        $gate=WFCA_Ownership::fence((int)$conv['id'],'REPLY',(int)$conv['owner_revision']);
        if (empty($gate['ok'])) {
            WFCA_Airtable::log_touch($lead_id,'INBOUND','OWNER_HOLD',$body,(string)$event['provider_message_id'],'KAPSO','PROSPECT',$arm);
            WFCA_DB::finish_event($event_id,'HOLD',(string)$gate['error']);return;
        }
        $conv=$gate['conversation'];

        $touch=WFCA_Airtable::log_touch($lead_id,'INBOUND','MESSAGE',$body,(string)$event['provider_message_id']);
        if (empty($touch['ok'])) {
            WFCA_Alerts::raise('AIRTABLE_TOUCH_WRITE_FAIL','WARN',$lead_id,(int)$conv['id'],$event_id,$body,'event:'.$event_id.':touch');
        }

        $decision=self::deterministic_decision($body,$lead,$media);
        // Arms with their own offer must not receive canned clinic-D0 replies ("já deixei essa versão pronta..."): only safety/identity rules stay deterministic.
        if ($decision && $arm_cfg && !in_array((string)($decision['reason']??''),$arm_cfg['allow_deterministic'],true)) $decision=null;
        if (!$decision) $decision=WFCA_OpenAI::decide($lead,$conv,WFCA_DB::recent_thread($phone,8),$body);

        self::apply_decision($decision,$lead,$conv,$event);
        WFCA_DB::finish_event($event_id,'PROCESSED');
     }

    /**
     * Exact-phone canonical Factory lead wins over a synthetic organic placeholder,
     * but never across a conflicting non-organic lead or a different initial arm.
     */
    private static function reconcile_canonical_lead_binding(string $phone,array $lead,array $existing): array {
        $lead_id=(string)($lead['id']??'');
        if ($lead_id==='' || empty($existing['id'])) return ['ok'=>false,'error'=>'REBIND_INPUT_INVALID'];
        $old_id=(string)($existing['lead_record_id']??'');
        if ($old_id==='' || $old_id===$lead_id) return ['ok'=>true,'conversation'=>$existing];
        $old=WFCA_Airtable::get_lead($old_id);
        if (empty($old['ok']) || empty($old['data'])) return ['ok'=>false,'error'=>'OLD_LEAD_READ_FAIL'];
        if (!WFCA_Airtable::lead_is_organic_intake($old['data'])) return ['ok'=>false,'error'=>'NON_ORGANIC_LEAD_CONFLICT'];
        $raw_arm=(string)($lead['fields']['Assigned Arm']??'');
        if ($raw_arm==='') {
            $raw_arm=WFCA_Ownership::route_for_lead($lead_id);
            $write=WFCA_Airtable::update_lead($lead_id,['Assigned Arm'=>$raw_arm]);
            if (empty($write['ok'])) return ['ok'=>false,'error'=>'CANONICAL_ARM_WRITE_FAIL'];
        }
        $arm=WFCA_Ownership::arm($raw_arm);
        if ($arm==='') return ['ok'=>false,'error'=>'CANONICAL_ARM_INVALID'];
        $old_arm=(string)($existing['initial_arm']??'');
        if ($old_arm!=='' && $old_arm!==$arm) return ['ok'=>false,'error'=>'INITIAL_ARM_CONFLICT'];
        $remote=WFCA_Airtable::rebind_commercial_conversation($phone,$lead_id,['Initial Arm'=>$raw_arm]);
        if (empty($remote['ok'])) return ['ok'=>false,'error'=>'AIRTABLE_REBIND_FAIL'];
        $local=WFCA_DB::rebind_conversation((int)$existing['id'],$lead_id,$arm);
        if (!$local) return ['ok'=>false,'error'=>'LOCAL_REBIND_FAIL'];
        return ['ok'=>true,'conversation'=>$local];
    }

    /** Pure pleasantry (thanks/wishes) with no question, no request and no negative or stop wording. */
    private static function is_courtesy_closing(string $t): bool {
        $t=trim(preg_replace('/^\*[^*]{1,40}:\*\s*/u','',$t));
        if ($t==='' || (function_exists('mb_strlen')?mb_strlen($t,'UTF-8'):strlen($t))>140 || str_contains($t,'?')) return false;
        if (WFCA_Util::contains_any($t,['não','nao','jamais','pare ','parar','spam','incomod','preço','preco','valor','quanto','proposta','link','site','orçamento','orcamento','contrato','pagamento','reunião','reuniao','agendar','whatsapp do','telefone','email','e-mail'])) return false;
        return WFCA_Util::contains_any($t,['desejo um','excelente dia','excelente tarde','ótimo dia','otimo dia','tudo de bom','igualmente','tenha um','fique bem','um abraço','um abraco','muito obrigad','obrigad','valeu','agradeço','agradeco','disponha','imagina','por nada','de nada']);
    }

    private static function deterministic_decision(string $body,array $lead,array $media): ?array {
        $t=WFCA_Util::normalize_text($body);
        $f=$lead['fields']??[];

        // The text-only language layer must never pretend it saw/heard media.
        if ($media) return ['action'=>'HANDOFF','message'=>'','offer_code'=>'NONE','reason'=>'MEDIA_PRESENT','confidence'=>1];

        if (self::is_explicit_opt_out($body)) return ['action'=>'OPT_OUT','message'=>'','offer_code'=>'NONE','reason'=>'EXPLICIT_OPT_OUT','confidence'=>1];

        $reject=(bool)preg_match('/\b(não|nao)\s+(tenho|temos)\s+interesse\b/u',$t)
            || str_contains($t,'sem interesse')
            || (bool)preg_match('/\b(não|nao)\s+quero\s+(contratar|comprar|o site|esse site|essa proposta|o serviço|o servico)\b/u',$t)
            || str_contains($t,'não precisamos disso') || str_contains($t,'nao precisamos disso');
        if ($reject) return ['action'=>'NO_INTEREST','message'=>'Sem problema. Obrigado por responder.','offer_code'=>'NONE','reason'=>'CLEAR_REJECTION','confidence'=>1];

        $wants_daniel=WFCA_Util::contains_any($t,[
            'quero falar com o daniel','queria falar com o daniel','posso falar com o daniel','pode chamar o daniel',
            'chama o daniel','chame o daniel','manda um áudio do daniel','manda um audio do daniel','áudio do daniel','audio do daniel'
        ]);
        if ($wants_daniel) {
            return ['action'=>'HANDOFF','message'=>'Claro. Vou chamar o Daniel e deixar o contexto certinho pra ele te responder por aqui.','offer_code'=>'NONE','reason'=>'DANIEL_PERSONAL_TOUCH','confidence'=>1];
        }

        // Charisma (Carnegie): a warm closing pleasantry deserves a short warm answer, once per conversation per day, never a loop.
        if (self::is_courtesy_closing($t)) {
            $key='wfca_courtesy_'.substr(hash('sha256',(string)($lead['id']??'').'|'.gmdate('Y-m-d')),0,24);
            if (!get_option($key,false)) {
                update_option($key,time(),false);
                $variants=['Igualmente! 😊 Muito obrigada pela atenção. Qualquer coisa, estou por aqui.','Obrigada, igualmente! 😊 Fico à disposição por aqui.','Que bom! Igualmente 😊 Qualquer coisa é só chamar.'];
                return ['action'=>'REPLY','message'=>$variants[crc32($t)%count($variants)],'offer_code'=>'NONE','reason'=>'COURTESY_CLOSING','confidence'=>1];
            }
        }

        if (WFCA_Util::contains_any($t,[
            'quero marcar uma call','quero marcar uma reunião','quero marcar uma reuniao','quero agendar uma call','quero agendar uma reunião','quero agendar uma reuniao',
            'diagnóstico','diagnostico','agendar diagnóstico','agendar diagnostico','marcar diagnóstico','marcar diagnostico','agenda do daniel','link da agenda',
            'quero conversar numa call','podemos fazer uma call','podemos marcar uma reunião','podemos marcar uma reuniao'
        ])) {
            return ['action'=>'SEND_DIAGNOSTIC','message'=>'','offer_code'=>'NONE','reason'=>'DIAGNOSTIC_OR_CALL_REQUEST','confidence'=>1];
        }

        // A gatekeeper who redirects us to an e-mail address gets the site link right here in the chat;
        // Luna cannot send e-mail, so she must never promise it and must not go silent either.
        $mentions_mail=str_contains($t,'@') || str_contains($t,'e-mail') || preg_match('/\bemail\b/u',$t);
        $mentions_send=WFCA_Util::contains_any($t,['apresenta','proposta','material','contato comercial','enviar','envie','mande','manda ','mandar']);
        $rules=WFCA_Util::rules();
        $hostile=WFCA_Util::contains_any($t,array_merge($rules['gatekeeper_extra_hostile_words'],['pare ','parar','chega','spam','incomod','descadastr','remov','sair da lista','não me ','nao me ','não quero','nao quero','não envie','nao envie','não mande','nao mande','denunci','bloque','processo','procon']));
        if (!empty($rules['gatekeeper_email_redirect_enabled']) && $mentions_mail && $mentions_send && !$hostile) {
            return ['action'=>'SEND_SITE','message'=>'','offer_code'=>'NONE','reason'=>'GATEKEEPER_EMAIL_REDIRECT','confidence'=>1];
        }

        if (WFCA_Util::contains_any($t,[
            'social media','gestão de instagram','gestao de instagram','gerenciamento de instagram','gerenciar instagram','conteúdo recorrente','conteudo recorrente',
            'gestão de redes sociais','gestao de redes sociais','gerenciar redes sociais'
        ])) {
            return ['action'=>'ROUTE_SOCIAL_MEDIA','message'=>'','offer_code'=>'NONE','reason'=>'SOCIAL_MEDIA_DEMAND','confidence'=>1];
        }

        if (WFCA_Util::contains_any($t,[
            'edição de vídeo','edicao de video','editar vídeo','editar video','reels','shorts','youtube','vsl','criativo em vídeo','criativo em video'
        ])) {
            return ['action'=>'ROUTE_VIDEO_EDITING','message'=>'','offer_code'=>'NONE','reason'=>'VIDEO_EDITING_DEMAND','confidence'=>1];
        }

        if (WFCA_Util::contains_any($t,[
            'consultoria estratégica','consultoria estrategica','estratégia de marketing','estrategia de marketing','posicionamento','aquisição de clientes','aquisicao de clientes',
            'quero ajuda com estratégia','quero ajuda com estrategia','estratégia 360','estrategia 360'
        ])) {
            return ['action'=>'ROUTE_STRATEGY','message'=>'','offer_code'=>'NONE','reason'=>'BROADER_STRATEGY_DEMAND','confidence'=>1];
        }

        if (WFCA_Util::contains_any($t,[
            'sou amigo do daniel','sou amiga do daniel','sou parente do daniel','sou primo do daniel','sou prima do daniel','sou colega do daniel',
            'faculdade','trabalho da faculdade','atividade da faculdade'
        ])) {
            return ['action'=>'HANDOFF','message'=>'Vou encaminhar sua mensagem para o Daniel.','offer_code'=>'NONE','reason'=>'PERSONAL_OR_NONCOMMERCIAL_CONTACT','confidence'=>1];
        }

        $wants_strategy=WFCA_Util::contains_any($t,[
            'strategy express','sessão estratégica','sessao estrategica','sessão com o daniel','sessao com o daniel',
            'consultoria com o daniel','estratégia com o daniel','estrategia com o daniel','hora com o daniel'
        ]);
        $attach_strategy=$wants_strategy && WFCA_Util::contains_any($t,[
            'quero incluir','quero adicionar','pode incluir','pode adicionar','inclui pra mim','inclua pra mim','adiciona pra mim','adicione pra mim',
            'quero fechar','vamos fechar','quero comprar','quero contratar','manda o pagamento','me manda o pagamento','checkout'
        ]);
        if ($attach_strategy) {
            return ['action'=>'CREATE_CHECKOUT_WITH_STRATEGY','message'=>'','offer_code'=>'ENTRY_STRATEGY','reason'=>'BUY_INTENT_WITH_STRATEGY','confidence'=>1];
        }
        if (preg_match('/\b(quero fechar|vamos fechar|quero comprar|fechado|pode mandar o pagamento|manda o pagamento|me manda o pagamento|checkout|quero contratar)\b/u',$t)) {
            return ['action'=>'CREATE_CHECKOUT','message'=>'','offer_code'=>'ENTRY','reason'=>'BUY_INTENT','confidence'=>1];
        }
        if ($wants_strategy) {
            return ['action'=>'OFFER_STRATEGY_EXPRESS','message'=>'','offer_code'=>'NONE','reason'=>'STRATEGY_EXPRESS_INTEREST','confidence'=>1];
        }
        if (WFCA_Util::contains_any($t,['quais os planos','quais planos','quais as opções','quais as opcoes','opções de site','opcoes de site','tem outros planos','outros valores'])) {
            return ['action'=>'PRICE_OPTIONS','message'=>'','offer_code'=>'NONE','reason'=>'PRICE_OPTIONS_ASK','confidence'=>1];
        }
        if (preg_match('/\b(quanto|valor|preço|preco|custa|investimento|parcel|qual o valor)\b/u',$t)) {
            return ['action'=>'PRICE','message'=>'','offer_code'=>'ENTRY','reason'=>'PRICE_ASK','confidence'=>1];
        }
        if (preg_match('/\b(manda o site|mande o site|ver o site|mostrar o site|link do site|cadê o site|cade o site)\b/u',$t)) {
            return ['action'=>'SEND_SITE','message'=>'','offer_code'=>'NONE','reason'=>'SITE_REQUEST','confidence'=>1];
        }

        if (WFCA_Util::contains_any($t,['você é ia','voce e ia','você é uma ia','voce e uma ia','você é inteligência artificial','voce e inteligencia artificial'])) {
            return ['action'=>'REPLY','message'=>'Sim. Sou a Luna, assistente virtual da equipe do Daniel. Uso IA para agilizar o atendimento, e o Daniel entra pessoalmente quando faz sentido.','offer_code'=>'NONE','reason'=>'LUNA_IDENTITY_QUESTION','confidence'=>1];
        }
        if (WFCA_Util::contains_any($t,['foi feito por ia','foi ia','usou ia','isso é ia','isso e ia'])) {
            return ['action'=>'REPLY','message'=>'Não é um site genérico gerado em um clique por IA. Essa versão foi construída especificamente para vocês, com direção de design, código e experiência próprios — incluindo recursos avançados de motion/imersão quando fazem sentido. IA pode entrar como ferramenta de apoio no processo, mas o que vocês estão avaliando é um projeto montado e revisado para o negócio.','offer_code'=>'NONE','reason'=>'AI_QUESTION','confidence'=>1];
        }
        if (WFCA_Util::contains_any($t,['garante pacientes','garante resultado','garantia de pacientes','garante vendas'])) {
            return ['action'=>'REPLY','message'=>"Não. Eu não consigo prometer um resultado comercial que depende de várias variáveis.\n\nO que eu consigo te entregar é o site e o escopo que estou te mostrando.",'offer_code'=>'NONE','reason'=>'GUARANTEE_QUESTION','confidence'=>1];
        }
        if (WFCA_Util::contains_any($t,['como funciona','como seria'])) {
            return ['action'=>'REPLY','message'=>'Eu já deixei essa versão pronta para vocês avaliarem. Se fizer sentido, a gente ajusta o que precisar dentro do escopo, acerta o pagamento e eu deixo a entrega/publicação final organizada com vocês.','offer_code'=>'NONE','reason'=>'HOW_IT_WORKS','confidence'=>1];
        }
        if (WFCA_Util::contains_any($t,['quem te passou meu número','quem te passou meu numero','de onde pegou meu número','de onde pegou meu numero','onde achou meu contato'])) {
            $src='em um canal público do negócio';
            if (!empty($f['Google Maps'])) $src='no Google';
            elseif (!empty($f['Instagram'])) $src='no Instagram';
            return ['action'=>'REPLY','message'=>'Encontrei o contato público '.$src.'.','offer_code'=>'NONE','reason'=>'SOURCE_QUESTION','confidence'=>1];
        }
        if (WFCA_Util::contains_any($t,['estou ocupada','estou ocupado','sem tempo agora','agora não posso','agora nao posso'])) {
            return ['action'=>'REPLY','message'=>'Sem problema. Posso te mandar o link e você vê quando puder?','offer_code'=>'NONE','reason'=>'BUSY','confidence'=>1];
        }
        if (WFCA_Util::contains_any($t,['vou encaminhar','vou repassar','vou mandar pra ela','vou mandar para ela'])) {
            return ['action'=>'REPLY','message'=>'Perfeito, obrigado.','offer_code'=>'NONE','reason'=>'GATEKEEPER_FORWARD','confidence'=>1];
        }
        if (WFCA_Util::contains_any($t,['já temos site','ja temos site','já tenho site','ja tenho site'])) {
            return ['action'=>'REPLY','message'=>'Sim, eu vi. Vocês estão satisfeitos com ele hoje?','offer_code'=>'NONE','reason'=>'ALREADY_HAS_SITE','confidence'=>1];
        }
        if (WFCA_Util::contains_any($t,['forma de pagamento','formas de pagamento','pode pagar no pix','aceita pix','aceita cartão','aceita cartao'])) {
            return ['action'=>'REPLY','message'=>'Pix ou cartão em até 12x sem juros pela rota de pagamento atual.','offer_code'=>'NONE','reason'=>'PAYMENT_METHODS','confidence'=>1];
        }
        if (WFCA_Util::contains_any($t,['do que se trata','sobre o que é','sobre o que e'])) {
            return ['action'=>'REPLY','message'=>'É uma proposta comercial de site. Eu montei uma versão específica antes de entrar em contato. Se você quiser, eu te envio para avaliar.','offer_code'=>'NONE','reason'=>'WHAT_IS_THIS','confidence'=>1];
        }
        return null;
    }

    /** Conservative classifier for automated clinic greetings/menus. */
    private static function is_likely_autoresponder(string $body): bool {
        $t=WFCA_Util::normalize_text($body);
        if ($t==='') return false;
        // 10.9.13: an explicit stop or clear rejection is never transport noise, even when the
        // same message also carries a greeter phrase. The autoresponder branch returns before
        // the opt-out handling in process_claimed_inbound(), so swallowing it here would ignore a hard stop.
        if (self::is_explicit_opt_out($body)) return false;
        // Tolerant stop-intent net: is_explicit_opt_out() is a deliberately strict allowlist for the irreversible OPT_OUT,
        // so wordings such as "pare de me enviar" are not in it. Here a false negative only sends the message down the
        // pre-10.9.13 path (language model -> handoff), which is safe; a false positive would silently ignore a request to stop.
        if (preg_match('/\b(?:pare|parem|para|deixe|deixem)\s+de\s+(?:me\s+|nos\s+)?(?:mandar|enviar|chamar|ligar|contatar|incomodar|escrever|insistir)\b/u',$t)
            || preg_match('/\b(?:não|nao)\s+(?:me\s+|nos\s+)?(?:mande|mandem|envie|enviem|chame|chamem|ligue|liguem|incomode|incomodem|escreva|escrevam|contate)\b/u',$t)
            || preg_match('/\b(?:descadastr|exclu[ai]\s+(?:meu|nosso)\s+n[úu]mero|remov[ae]\s+(?:meu|nosso)\s+(?:n[úu]mero|contato)|tire\s+(?:meu|nosso)\s+(?:n[úu]mero|contato)|sair\s+da\s+lista|vou\s+bloquear)/u',$t)) return false;
        if (preg_match('/\b(não|nao)\s+(tenho|temos)\s+interesse\b/u',$t)
            || str_contains($t,'sem interesse')
            || preg_match('/\b(não|nao)\s+quero\s+(contratar|comprar|o site|esse site|essa proposta|o serviço|o servico)\b/u',$t)
            || str_contains($t,'não precisamos disso') || str_contains($t,'nao precisamos disso')) return false;
        // 10.9.13: unmistakable human commercial intent (buy / price / call / Daniel) outranks any greeter phrase,
        // so "obrigado pelo contato, quero fechar" is processed by deterministic_decision() instead of dropped.
        if (WFCA_Util::contains_any($t,[
            'quero fechar','vamos fechar','quero comprar','quero contratar','manda o pagamento','me manda o pagamento','pode mandar o pagamento',
            'checkout','quanto custa','qual o valor','qual é o valor','qual e o valor',
            'quero marcar uma call','quero agendar uma call','podemos fazer uma call','quero falar com o daniel','posso falar com o daniel'
        ])) return false;
        $strong=[
            'seja bem vindo','seja bem-vindo','seja bem-vinda','agradece seu contato','agradecemos seu contato',
            'mensagens são respondidas por ordem de chegada','mensagens sao respondidas por ordem de chegada',
            'iremos te retornar o mais breve possível','iremos te retornar o mais breve possivel',
            'para agilizarmos nosso atendimento','para tornar o seu atendimento mais ágil','para tornar o seu atendimento mais agil',
            'gostaríamos de algumas informações','gostariamos de algumas informacoes','mensagem automática','mensagem automatica',
            'obrigada por entrar em contato','obrigado por entrar em contato','obrigado pelo contato','obrigada pelo contato',
            'assim que possível, retornaremos','assim que possivel, retornaremos','assim que possível retornaremos','assim que possivel retornaremos',
            'assim que possível, retornaremos a sua mensagem','assim que possivel, retornaremos a sua mensagem',
            'nosso horário de atendimento','nosso horario de atendimento',
            // 10.9.13: variants observed in real EMPTY_MODEL_REPLY handoffs (clinic greeters/away messages).
            'seja muito bem-vinda','seja muito bem-vindo','seja muito bem vinda','seja muito bem vindo',
            'agradecemos sua mensagem','agradecemos a sua mensagem',
            'não estamos disponíveis no momento','nao estamos disponiveis no momento',
            'responderemos assim que possível','responderemos assim que possivel'
        ];
        if (WFCA_Util::contains_any($t,$strong)) return true;
        $markers=0;
        foreach (['como podemos ajudar','informe seu nome','nome e sobrenome','nome completo','data de nascimento','plano de saúde','plano de saude','qual procedimento','esta é a sua primeira vez','esta e a sua primeira vez','razão da sua consulta','razao da sua consulta','data de sua preferência','data de sua preferencia','horário de sua preferência','horario de sua preferencia','retornaremos em breve','responderemos em breve','estarei responsável pelo seu atendimento','estarei responsavel pelo seu atendimento','como posso te ajudar','como posso estar te ajudando','como posso ajudar','sou da equipe','sou secretária da','sou secretaria da','que bom receber sua mensagem','ficamos felizes em receber o seu contato'] as $m) {
            if (str_contains($t,$m)) $markers++;
        }
        return $markers>=2;
    }

    /**
     * Only an explicit, user-authored opt-out phrase may trigger the irreversible
     * hard stop. Model output is advisory and must not widen this allowlist.
     */
    private static function is_explicit_opt_out(string $body): bool {
        $t=WFCA_Util::normalize_text($body);
        return WFCA_Util::contains_any($t,[
            'pare de me mandar','pare de enviar','não me chame','nao me chame','não mande mais','nao mande mais',
            'remova meu número','remova meu numero','tire meu número','tire meu numero','não entre mais em contato','nao entre mais em contato',
            'quero sair','cancelar contato','não quero mais receber mensagens','nao quero mais receber mensagens',
            'não quero receber mensagens','nao quero receber mensagens','stop'
        ]);
    }

    private static function apply_decision(array $d,array $lead,array $conv,array $event): void {
        $action=strtoupper((string)($d['action']??'HANDOFF'));
        if ($action==='OPT_OUT' && !self::is_explicit_opt_out((string)($event['body']??''))) {
            // A model cannot manufacture an irreversible opt-out from ambiguous text.
            // Route the ambiguity to the existing human-handoff path instead.
            $action='HANDOFF';
            $d['action']='HANDOFF';
            $d['message']='';
            $d['reason']='OPT_OUT_WITHOUT_EXPLICIT_REQUEST';
        }
        $lead_id=(string)$lead['id'];
        $phone=(string)$event['phone_e164'];
        $mode=WFCA_Airtable::mode();
        $status=WFCA_Ownership::queue_status();
        $f=$lead['fields']??[];
        $site=(string)($f['Site URL']??'');
        $source_sid=(string)$event['provider_message_id'];

        $arm_cfg=WFCA_Util::arm_by_id((string)($conv['initial_arm']??''));
        if ($arm_cfg && in_array($action,$arm_cfg['blocked_actions'],true)) {
            $d['reason']='ARM_BLOCKED_ACTION:'.$action;$action='HANDOFF';$d['action']='HANDOFF';$d['message']='';
        }
        if ($action!=='OPT_OUT' && empty(WFCA_Ownership::fence((int)$conv['id'],'REPLY',(int)$conv['owner_revision'])['ok'])) return;
        if ($action==='OPT_OUT') {
            WFCA_DB::upsert_conversation($phone,['opt_out'=>1]);
            $owner=WFCA_DB::get_conversation((int)$conv['id']);
            WFCA_Ownership::change((int)$conv['id'],'STOPPED','EXPLICIT_OPT_OUT',(int)$owner['owner_revision']);
            WFCA_Ownership::sync((int)$conv['id']);
            WFCA_DB::upsert_conversation($phone,['state'=>'OPT_OUT','opt_out'=>1,'human_hold'=>1,'summary'=>'Explicit opt-out']);
            WFCA_Airtable::update_commercial_by_phone($phone,[
                'State'=>'OPT_OUT','Enabled'=>false,'WhatsApp Permission Status'=>'OPT_OUT','Opt Out'=>true,'Opt Out At'=>WFCA_Util::now_iso(),
                'Conversation Summary'=>'Explicit opt-out. Hard stop.'
            ]);
            WFCA_Airtable::log_touch($lead_id,'INBOUND','OPT_OUT',(string)$event['body'],$source_sid);
            return;
        }

        if ($action==='HANDOFF') {
            $handoff_message=WFCA_Util::short_text((string)($d['message']??''),700);
            self::handoff(
                $phone,(string)($d['reason']??'Model/policy handoff'),$lead_id,(int)$conv['id'],(int)$event['id'],
                (string)$event['body'],$source_sid,$status,$handoff_message!=='',$handoff_message
            );
            return;
        }

        if ($action==='NO_INTEREST') {
            $owner=WFCA_DB::get_conversation((int)$conv['id']);
            WFCA_Ownership::change((int)$conv['id'],'STOPPED','NO_INTEREST',(int)$owner['owner_revision']);
            WFCA_Ownership::sync((int)$conv['id']);
            WFCA_DB::upsert_conversation($phone,['state'=>'NO_INTEREST','summary'=>'Clear rejection']);
            WFCA_Airtable::update_commercial_by_phone($phone,['State'=>'NO_INTEREST','Enabled'=>false,'Conversation Summary'=>'Clear rejection; final courtesy reply only.']);
            // STOPPED has no courtesy-send exception.
            return;
        }

        if ($action==='PRICE') {
            $offer=self::offer('ENTRY');
            if (!$offer) { self::handoff($phone,'OFFER_CATALOG_UNAVAILABLE',$lead_id,(int)$conv['id'],(int)$event['id'],(string)$event['body'],$source_sid,$status,true); return; }
            $price='R$'.number_format($offer['amount']/100,0,',','.').' na opção de entrada.';
            self::queue_message($conv,$lead_id,'PRICE',$price,'PRICE_STATE',$status,'ENTRY',$source_sid);
            return;
        }

        if ($action==='PRICE_OPTIONS') {
            $entry=self::offer('LANDING_PAGE_PREMIUM');
            $pro=self::offer('SITE_PROFISSIONAL');
            $auth=self::offer('SITE_AUTORIDADE');
            if (!$entry || !$pro || !$auth) { self::handoff($phone,'OFFER_CATALOG_UNAVAILABLE',$lead_id,(int)$conv['id'],(int)$event['id'],(string)$event['body'],$source_sid,$status,true); return; }
            $reply="Hoje tenho três níveis:
"
                ."• ".$entry['name'].': R$'.number_format($entry['amount']/100,0,',','.')."
"
                ."• ".$pro['name'].': R$'.number_format($pro['amount']/100,0,',','.')."
"
                ."• ".$auth['name'].': R$'.number_format($auth['amount']/100,0,',','.')."

"
                ."Se me disser o que você quer que o site faça, eu te digo qual faz mais sentido — sem empurrar escopo desnecessário.";
            self::queue_message($conv,$lead_id,'PRICE',$reply,'PRICE_STATE',$status,'NONE',$source_sid);
            return;
        }

        if ($action==='SEND_DIAGNOSTIC') {
            $cfg=WFCA_Airtable::config();
            $url=WFCA_Commercial_Context::diagnostic_url($cfg);
            if (!filter_var($url,FILTER_VALIDATE_URL)) { self::handoff($phone,'DIAGNOSTIC_URL_INVALID',$lead_id,(int)$conv['id'],(int)$event['id'],(string)$event['body'],$source_sid,$status,true); return; }
            $reply="Claro. Se você prefere conversar antes de decidir, pode escolher um horário direto na agenda do Daniel:
".$url."

O diagnóstico é justamente para entender o cenário e indicar o caminho que faz mais sentido, sem empurrar escopo desnecessário.";
            self::queue_message($conv,$lead_id,'REPLY',$reply,'DIAGNOSTIC_OFFERED',$status,'NONE',$source_sid);
            return;
        }

        if ($action==='ROUTE_SOCIAL_MEDIA') {
            $cfg=WFCA_Airtable::config();
            $url=WFCA_Commercial_Context::social_media_url($cfg);
            if (!filter_var($url,FILTER_VALIDATE_URL)) { self::handoff($phone,'SOCIAL_MEDIA_URL_INVALID',$lead_id,(int)$conv['id'],(int)$event['id'],(string)$event['body'],$source_sid,$status,true); return; }
            $reply="Sim — o Daniel também tem uma frente específica de Social Media, com estratégia, copy, design, edição e operação recorrente. Os planos e escopos estão aqui:
".$url."

Se quiser, eu também posso te passar o diagnóstico para entender antes qual intensidade faz sentido.";
            self::queue_message($conv,$lead_id,'REPLY',$reply,'SERVICE_ROUTED',$status,'NONE',$source_sid);
            return;
        }

        if ($action==='ROUTE_VIDEO_EDITING') {
            $cfg=WFCA_Airtable::config();
            $url=WFCA_Commercial_Context::video_editing_url($cfg);
            if (!filter_var($url,FILTER_VALIDATE_URL)) { self::handoff($phone,'VIDEO_EDITING_URL_INVALID',$lead_id,(int)$conv['id'],(int)$event['id'],(string)$event['body'],$source_sid,$status,true); return; }
            $reply="Sim — edição de vídeo também faz parte do trabalho do Daniel, incluindo Reels/Shorts, criativos, YouTube e VSL. Você pode ver a frente audiovisual aqui:
".$url."

Se me disser o tipo de vídeo e a frequência, eu te direciono sem misturar escopo.";
            self::queue_message($conv,$lead_id,'REPLY',$reply,'SERVICE_ROUTED',$status,'NONE',$source_sid);
            return;
        }

        if ($action==='ROUTE_STRATEGY') {
            $cfg=WFCA_Airtable::config();
            $url=WFCA_Commercial_Context::diagnostic_url($cfg);
            if (!filter_var($url,FILTER_VALIDATE_URL)) { self::handoff($phone,'DIAGNOSTIC_URL_INVALID',$lead_id,(int)$conv['id'],(int)$event['id'],(string)$event['body'],$source_sid,$status,true); return; }
            $reply="Faz sentido. Estratégia é justamente a frente central do Daniel — posicionamento, oferta, aquisição, comunicação e prioridade antes de escolher ferramenta. O melhor primeiro passo aqui é o diagnóstico:
".$url;
            self::queue_message($conv,$lead_id,'REPLY',$reply,'DIAGNOSTIC_OFFERED',$status,'NONE',$source_sid);
            return;
        }

        if ($action==='OFFER_STRATEGY_EXPRESS') {
            $cfg=WFCA_Airtable::config();
            $label=WFCA_Commercial_Context::strategy_price_label($cfg);
            $reply='Tem sim. O Strategy Express é uma sessão estratégica 1:1 de até 1h com o Daniel, a partir de '.$label.'. É opcional e pode ser adicionada junto à compra do site. Se quiser incluir, eu preparo o pagamento com ela.';
            self::queue_message($conv,$lead_id,'REPLY',$reply,'HIGH_INTENT',$status,'NONE',$source_sid);
            return;
        }

        if ($action==='SEND_SITE') {
            $canonical=WFCA_Airtable::canonical_site_url($lead_id,$lead,true);
            if (empty($canonical['ok'])) {
                self::handoff($phone,'CANONICAL_SITE_PREFLIGHT:'.(string)($canonical['error']??'UNKNOWN'),$lead_id,(int)$conv['id'],(int)$event['id'],(string)$event['body'],$source_sid,$status,true);
                return;
            }
            $site=(string)$canonical['url'];
            $reply="Esse é o site que preparei:
".$site."

Depois me diz o que você manteria ou mudaria.";
            if ((string)($d['reason']??'')==='GATEKEEPER_EMAIL_REDIRECT') {
                $reply="Obrigada! Como é algo bem visual, deixo o link direto por aqui pra você ver rapidinho:
".$site."

Se fizer sentido pra equipe, é só repassar pra quem decide.";
            }
            self::queue_message($conv,$lead_id,'SITE',$reply,'SITE_SENT',$status,'NONE',$source_sid);
            return;
        }

        if (in_array($action,['CREATE_CHECKOUT','CREATE_CHECKOUT_WITH_STRATEGY'],true)) {
            if (WFCA_Airtable::lead_is_organic_intake($lead) && !filter_var($site,FILTER_VALIDATE_URL) && empty($arm_cfg['checkout_without_site'])) {
                self::handoff($phone,'ORGANIC_SITE_CHECKOUT_REQUIRES_DANIEL_OR_BUILD',$lead_id,(int)$conv['id'],(int)$event['id'],(string)$event['body'],$source_sid,$status,true);
                return;
            }
            $offer_code=(string)($d['offer_code']??'ENTRY');
            if ($action==='CREATE_CHECKOUT_WITH_STRATEGY') {
                $base=preg_replace('/_STRATEGY$/','',strtoupper($offer_code));
                $offer_code=(in_array($base,['','NONE','ENTRY'],true)?'ENTRY':$base).'_STRATEGY';
            }
            // Arms may carry Daniel's own InfinitePay links (exact products/bumps from his pages). These are sent as-is;
            // payment truth then needs Daniel (no webhook), so a WARN alert follows.
            $static=$arm_cfg['static_checkout'][strtoupper($offer_code)]??'';
            if ($static!=='') {
                self::queue_message($conv,$lead_id,'REPLY',"Perfeito. Esse é o link seguro para concluir:\n".$static."\n\nAssim que você pagar, me avisa por aqui que eu confirmo com o Daniel.",'CHECKOUT_SENT',$status,strtoupper($offer_code),$source_sid);
                WFCA_Airtable::update_commercial_by_phone($phone,['State'=>'CHECKOUT_SENT','Checkout URL'=>$static]);
                WFCA_Alerts::raise('STATIC_CHECKOUT_SENT:'.strtoupper($offer_code),'WARN',$lead_id,(int)$conv['id'],(int)$event['id'],(string)$event['body'],'static-checkout:'.$source_sid);
                return;
            }
            if (!WFCA_InfinitePay::ready()) {
                self::handoff($phone,'INFINITEPAY_NOT_CONFIGURED',$lead_id,(int)$conv['id'],(int)$event['id'],(string)$event['body'],$source_sid,$status,true);
                return;
            }
            self::queue_message($conv,$lead_id,'CHECKOUT','', 'CHECKOUT_SENT',$status,$offer_code,$source_sid);
            WFCA_Airtable::update_commercial_by_phone($phone,['State'=>'HIGH_INTENT']);
            return;
        }

        $message=WFCA_Util::short_text((string)($d['message']??''),700);
        if ($message==='') { self::handoff($phone,'EMPTY_REPLY',$lead_id,(int)$conv['id'],(int)$event['id'],(string)$event['body'],$source_sid,$status,false); return; }
        self::queue_message($conv,$lead_id,'REPLY',$message,'QUESTION_STATE',$status,'NONE',$source_sid);
    }

    private static function queue_message(array $conv,string $lead_id,string $type,string $body,string $state_after,string $status,string $offer,string $source_sid): int {
        $id=WFCA_DB::queue([
            'idempotency_key'=>hash('sha256',$source_sid.'|'.$type.'|'.$lead_id),
            'lead_record_id'=>$lead_id,'conversation_id'=>(int)$conv['id'],'action_type'=>$type,'body'=>$body,
            'offer_code'=>$offer,'state_after'=>$state_after,'status'=>$status,'owner_revision'=>(int)($conv['owner_revision']??0),'initial_arm'=>$conv['initial_arm']??''
        ]);
        if ($id<=0) {
            WFCA_Alerts::raise('OUTBOX_QUEUE_FAIL','CRITICAL',$lead_id,(int)$conv['id'],0,$body,'outbox:'.$source_sid.':'.$type);
        }
        return $id;
    }

    private static function handoff(string $phone,string $reason,string $lead_id='',int $conversation_id=0,int $event_id=0,string $prospect_message='',string $source_sid='',string $reply_status='PENDING',bool $send_ack=false,string $ack_message=''): void {
        $reason=WFCA_Util::redact_error($reason,220);
        $conv=WFCA_DB::upsert_conversation($phone,['state'=>'HUMAN_HANDOFF','human_hold'=>1,'summary'=>$reason]);
        if (!$conversation_id) $conversation_id=(int)($conv['id']??0);
        if ($conv) {
            WFCA_Ownership::change($conversation_id,'HANDOFF_PENDING',$reason,(int)$conv['owner_revision']);
            WFCA_Ownership::sync($conversation_id);
            $conv=WFCA_DB::get_conversation($conversation_id);
        }
        if ($lead_id!=='') {
            WFCA_Airtable::update_commercial_by_phone($phone,[
                'State'=>'HUMAN_HANDOFF','Human Handoff Reason'=>$reason,
                'Conversation Summary'=>WFCA_Util::short_text($prospect_message,700)
            ]);
        }
        WFCA_Alerts::raise($reason,'WARN',$lead_id,$conversation_id,$event_id,$prospect_message,'handoff:'.($event_id?:$source_sid).':'.$reason);

        if ($send_ack && $lead_id!=='' && $source_sid!=='' && $conversation_id>0) {
            $ack=WFCA_Util::short_text($ack_message,700);
            if ($ack==='') {
                $ack=$reason==='DANIEL_PERSONAL_TOUCH'
                    ? 'Claro. Vou chamar o Daniel e deixar o contexto certinho pra ele te responder por aqui.'
                    : WFCA_Util::handoff_ack_text();
            }
            self::queue_message($conv ?: ['id'=>$conversation_id],$lead_id,'HANDOFF_ACK',$ack,'HUMAN_HANDOFF',$reply_status,'NONE',$source_sid);
        }
    }

    private static function surface_uncertain_outbox(int $limit=6): void {
        foreach (WFCA_DB::uncertain_outbox($limit) as $row) {
            $id=(int)$row['id'];
            if (str_starts_with((string)$row['action_type'],'ALERT_')) { WFCA_Alerts::sync_outbox($row);WFCA_DB::update_outbox($id,['sync_pending'=>0,'uncertain_alerted'=>1]);continue; }
            $conv=WFCA_DB::get_conversation((int)$row['conversation_id']);
            $reason='AMBIGUOUS_TRANSPORT_SEND_DO_NOT_AUTO_RETRY';
            WFCA_Alerts::raise($reason,'CRITICAL',(string)$row['lead_record_id'],(int)($conv['id']??0),0,(string)$row['body'],'outbox:'.$id.':uncertain');
            WFCA_DB::update_outbox($id,['uncertain_alerted'=>1]);
            if ($conv && (string)$row['action_type']!=='HANDOFF_ACK') {
                WFCA_DB::upsert_conversation((string)$conv['phone_e164'],['state'=>'HUMAN_HANDOFF','human_hold'=>1,'summary'=>$reason]);
                WFCA_Airtable::update_commercial_by_phone((string)$conv['phone_e164'],[
                    'State'=>'HUMAN_HANDOFF','Human Handoff Reason'=>$reason,'Commercial Error'=>$reason
                ]);
            }
        }
    }

    public static function process_outbox(int $limit=5,?array $mode_state=null): void {
        $mode_state=$mode_state?:WFCA_Airtable::mode_state();
        $mode=(string)($mode_state['base_mode']??'OFF');
        $draining=(bool)($mode_state['draining']??false);
        if (!in_array($mode,['ASSISTED','LIVE'],true)) return;
        $worker='WFCA-'.wp_generate_password(8,false,false);
        $followup_done=false;

        for($i=0;$i<$limit;$i++) {
            $row=WFCA_DB::claim_outbox($worker,$mode,$draining);
            if (!$row) break;
            if (($row['action_type']??'')==='FOLLOWUP' && trim((string)($row['content_sid']??''))==='') {
                WFCA_DB::set_outbox_status((int)$row['id'],'CANCELLED','FOLLOWUP_TEMPLATE_REQUIRED');
                continue;
            }
            if (($row['action_type']??'')==='FOLLOWUP' && $followup_done) {
                WFCA_DB::defer_outbox($row,'FOLLOWUP_ONE_PER_TICK',60);
                continue;
            }
            $conv=WFCA_DB::get_conversation((int)$row['conversation_id']);
            $lock='conversation:'.($conv['phone_e164']??'');
            if (!WFCA_Ownership::lock($lock)) { WFCA_DB::defer_outbox($row,'CONVERSATION_BUSY',60);continue; }
            $proactive=in_array((string)($row['action_type']??''),['TEMPLATE_INITIAL','FOLLOWUP','TEMPLATE_NURTURE'],true);
            $proactive_locked=false;
            if ($proactive) {
                $proactive_locked=WFCA_Ownership::lock('proactive-send');
                if (!$proactive_locked) {
                    WFCA_DB::defer_outbox($row,'PROACTIVE_SEND_BUSY',60);
                    WFCA_Ownership::unlock($lock);
                    continue;
                }
            }
            try {
                if (str_starts_with($row['action_type'],'ALERT_')) self::execute_alert($row);
                else self::execute_outbox($row,$mode);
                if (($row['action_type']??'')==='FOLLOWUP') $followup_done=true;
            } catch (Throwable $e) {
                $fresh=WFCA_DB::get_outbox((int)$row['id']);
                if (($fresh['status']??'')==='SENT') WFCA_DB::update_outbox((int)$row['id'],['sync_pending'=>1,'last_error'=>'POST_SEND_EXCEPTION:'.WFCA_Util::redact_error($e->getMessage())]);
                elseif (!empty($fresh['send_started_at'])) WFCA_DB::update_outbox((int)$row['id'],['status'=>'UNCERTAIN','last_error'=>'SEND_EXCEPTION','uncertain_alerted'=>0]);
                else self::retry_or_alert($fresh?:$row,'WORKER_EXCEPTION');
                if (($row['action_type']??'')==='FOLLOWUP') $followup_done=true;
            } finally {
                if ($proactive_locked) WFCA_Ownership::unlock('proactive-send');
                WFCA_Ownership::unlock($lock);
            }
        }
    }

    private static function execute_outbox(array $row,string $mode): void {
        $id=(int)$row['id'];
        $action=(string)$row['action_type'];
        $is_followup=$action==='FOLLOWUP';
        $conv=WFCA_DB::get_conversation((int)$row['conversation_id']);
        if (!$conv) { self::retry_or_alert($row,'CONVERSATION_MISSING','CRITICAL'); return; }
        $gate=WFCA_Ownership::fence((int)$conv['id'],$action,(int)$row['owner_revision']);
        if (empty($gate['ok'])) { WFCA_DB::set_outbox_status($id,'CANCELLED',(string)$gate['error']);return; }
        if ((int)$conv['opt_out']===1) { WFCA_DB::set_outbox_status($id,'CANCELLED','OPT_OUT_HARD_STOP'); return; }
        if ((int)$conv['human_hold']===1 && $action!=='HANDOFF_ACK') { WFCA_DB::set_outbox_status($id,'CANCELLED','HUMAN_HOLD'); return; }
        if ($is_followup && WFCA_DB::has_terminal_payment((int)$conv['id'])) { WFCA_DB::set_outbox_status($id,'CANCELLED','PAYMENT_TERMINAL'); return; }

        $lead_r=WFCA_Airtable::get_lead((string)$row['lead_record_id']);
        if (!$lead_r['ok'] || empty($lead_r['data']['fields'])) { self::retry_or_alert($row,'AIRTABLE_LEAD_READ_FAIL','WARN'); return; }
        $lead=$lead_r['data']; $lead['id']=(string)$row['lead_record_id'];
        if (!WFCA_Airtable::lead_is_commercial_ready($lead) && !WFCA_Airtable::lead_is_organic_intake($lead)) {
            WFCA_DB::set_outbox_status($id,'CANCELLED','LEAD_NOT_COMMERCIAL_READY');
            WFCA_Alerts::raise('LEAD_NOT_COMMERCIAL_READY','WARN',(string)$row['lead_record_id'],(int)$conv['id'],0,(string)$row['body'],'outbox:'.$id.':not-ready');
            return;
        }

        $cc=WFCA_Airtable::get_commercial_conversation((string)$conv['phone_e164']);
        if (!$cc['ok'] || empty($cc['record'])) { self::retry_or_alert($row,'COMMERCIAL_STATE_READ_FAIL','WARN'); return; }
        $cf=$cc['record']['fields']??[];
        if (!empty($cf['Opt Out']) || ($cf['State']??'')==='OPT_OUT') {
            WFCA_DB::set_outbox_status($id,'CANCELLED','AIRTABLE_OPT_OUT'); return;
        }
        if (($cf['State']??'')==='HUMAN_HANDOFF' && $action!=='HANDOFF_ACK') {
            WFCA_DB::set_outbox_status($id,'CANCELLED','AIRTABLE_HUMAN_HANDOFF'); return;
        }

        $is_initial_template=$action==='TEMPLATE_INITIAL';
        $is_nurture_template=$action==='TEMPLATE_NURTURE';
        $is_followup_template=$is_followup && trim((string)($row['content_sid']??''))!=='';
        $is_template=$is_initial_template || $is_nurture_template || $is_followup_template;

        if ($is_followup) {
            $scheduled=(string)($row['scheduled_action_at']??'');
            $due_ts=$scheduled!==''?strtotime($scheduled.' UTC'):0;
            $reason=$due_ts?self::followup_gate_reason($conv,$cf,$due_ts,$is_followup_template):'FOLLOWUP_DUE_MISSING';
            if ($reason!=='') {
                WFCA_DB::set_outbox_status($id,'CANCELLED',$reason);
                if ($reason==='FOLLOWUP_SUPERSEDED_BY_INBOUND') self::clear_followup_schedule((string)$conv['phone_e164']);
                return;
            }
        }

        $window_ts=!empty($cf['WhatsApp 24h Window Until'])?strtotime((string)$cf['WhatsApp 24h Window Until']):0;

        if ($action==='AUTO_REPLY_GATEKEEPER') {
            $scheduled=(string)($row['scheduled_action_at']??'');
            $due_ts=$scheduled!==''?strtotime($scheduled.' UTC'):0;
            if (!$due_ts) { WFCA_DB::set_outbox_status($id,'CANCELLED','AUTO_REPLY_GATEKEEPER_DUE_MISSING'); return; }
            if ($due_ts>time()) { WFCA_DB::defer_outbox($row,'AUTO_REPLY_GATEKEEPER_NOT_DUE',max(60,$due_ts-time())); return; }
            $created_ts=!empty($row['created_at'])?strtotime((string)$row['created_at'].' UTC'):0;
            $last_inbound=!empty($conv['last_inbound_at'])?strtotime((string)$conv['last_inbound_at'].' UTC'):0;
            if ($created_ts && $last_inbound>$created_ts) {
                WFCA_DB::set_outbox_status($id,'CANCELLED','AUTO_REPLY_GATEKEEPER_SUPERSEDED_BY_INBOUND');
                return;
            }
            if (($conv['conversation_owner']??'')!=='LUNA' || !empty($conv['human_hold']) || !empty($conv['opt_out'])) {
                WFCA_DB::set_outbox_status($id,'CANCELLED','AUTO_REPLY_GATEKEEPER_OWNER_OR_HOLD');
                return;
            }
        }

        if ($is_initial_template) {
            $perm=(string)($cf['WhatsApp Permission Status']??'UNKNOWN');
            if (!in_array($perm,['OPTED_IN','LIVE_HANDOFF'],true)) {
                WFCA_DB::set_outbox_status($id,'CANCELLED','INITIAL_PERMISSION_NOT_PRESENT');
                return;
            }
            $cfg=WFCA_Airtable::config();
            $policy=WFCA_Util::class_commercial_policy($cfg,'TEMPLATE_INITIAL');
            $windows=(string)($policy['windows']??'');
            if (empty($policy['valid']) || empty($policy['proactive']) || $windows==='' || !WFCA_Util::inside_window($windows)) {
                $delay=WFCA_Util::seconds_until_next_class_window($cfg,'TEMPLATE_INITIAL');
                WFCA_DB::defer_outbox($row,'OUTSIDE_D0_WINDOW',$delay);
                return;
            }
            $arm=(string)($conv['initial_arm']??'');
            if ($arm!=='LUNA_COLD_WHATSAPP') {
                WFCA_DB::set_outbox_status($id,'CANCELLED','CALL_FIRST_REQUIRES_LIVE_HANDOFF');
                return;
            }
            $active_initial=WFCA_Kapso::template_spec('INITIAL');
            if (empty($active_initial['name']) || !hash_equals((string)$active_initial['name'],(string)($row['content_sid']??''))) {
                WFCA_DB::set_outbox_status($id,'CANCELLED','INITIAL_TEMPLATE_NOT_ACTIVE');
                return;
            }
            $canonical=WFCA_Airtable::canonical_site_url((string)$row['lead_record_id'],$lead,true);
            if (empty($canonical['ok'])) {
                $err='CANONICAL_SITE_PREFLIGHT:'.(string)($canonical['error']??'UNKNOWN');
                WFCA_DB::set_outbox_status($id,'CANCELLED',$err);
                WFCA_Alerts::raise($err,'WARN',(string)$row['lead_record_id'],(int)$conv['id'],0,'','outbox:'.$id.':canonical-site');
                return;
            }
            $queued_vars=json_decode((string)$row['content_variables'],true);
            if (is_array($queued_vars)) {
                $needs_media=is_array($active_initial['header']??null) && (($active_initial['header']['type']??'')==='image');
                if ($needs_media) {
                    $live_media=WFCA_Airtable::d0_preview_contract($lead);
                    $size_gate=WFCA_Airtable::d0_preview_bytes_gate($live_media);
                    if (!empty($live_media['ok']) && empty($size_gate['ok']) && ($size_gate['error']??'')==='D0_PREVIEW_IMAGE_TOO_SMALL') $live_media=$size_gate; // unreachable at send time stays fail-open: the queue-time gate already checked it
                    $queued_lead=(string)($queued_vars['_lead_record_id']??'');
                    $queued_url=(string)($queued_vars['_header_image_url']??'');
                    $queued_sha=strtolower((string)($queued_vars['_header_image_sha256']??''));
                    $live_sha=strtolower((string)($live_media['sha256']??''));
                    if (empty($live_media['ok']) || $queued_lead==='' || !hash_equals((string)$row['lead_record_id'],$queued_lead)
                        || $queued_url==='' || !hash_equals((string)$live_media['url'],$queued_url)
                        || $queued_sha==='' || $live_sha==='' || !hash_equals($live_sha,$queued_sha)) {
                        WFCA_DB::set_outbox_status($id,'CANCELLED','D0_MEDIA_BINDING_MISMATCH');
                        WFCA_Alerts::raise('D0_MEDIA_BINDING_MISMATCH','CRITICAL',(string)$row['lead_record_id'],(int)$conv['id'],0,'','outbox:'.$id.':media-binding');
                        return;
                    }
                }
                $changed=false;
                foreach ($queued_vars as $k=>$v) {
                    if (!preg_match('/^\d+$/',(string)$k)) continue;
                    $vh=strtolower((string)parse_url((string)$v,PHP_URL_HOST));
                    if (in_array($vh,['auracorp.online','www.auracorp.online','danielfreireditor.online','www.danielfreireditor.online'],true)) {
                        $queued_vars[$k]=(string)$canonical['url'];
                        $changed=true;
                    }
                }
                if ($changed) {
                    $row['content_variables']=WFCA_Util::json($queued_vars);
                    WFCA_DB::update_outbox($id,['content_variables'=>$row['content_variables']]);
                }
            }
        } elseif ($is_nurture_template || $is_followup_template) {
            $perm=(string)($cf['WhatsApp Permission Status']??'UNKNOWN');
            if (!in_array($perm,['OPTED_IN','LIVE_HANDOFF'],true)) {
                WFCA_DB::set_outbox_status($id,'CANCELLED',$is_nurture_template?'NURTURE_PERMISSION_NOT_PRESENT':'FOLLOWUP_PERMISSION_NOT_PRESENT');
                return;
            }
            if ($is_nurture_template && ($cf['State']??'')!=='PAID') {
                WFCA_DB::set_outbox_status($id,'CANCELLED','NURTURE_STATE_NOT_PRESENT');
                return;
            }
            $cfg=WFCA_Airtable::config();
            $window_action=$is_nurture_template?'TEMPLATE_NURTURE':'FOLLOWUP';
            $policy=WFCA_Util::class_commercial_policy($cfg,$window_action);
            $windows=(string)($policy['windows']??'');
            if (empty($policy['valid']) || empty($policy['proactive']) || $windows==='' || !WFCA_Util::inside_window($windows)) {
                $delay=WFCA_Util::seconds_until_next_class_window($cfg,$window_action);
                WFCA_DB::defer_outbox($row,'OUTSIDE_FOLLOWUP_WINDOW',$delay);
                return;
            }
        } elseif ($window_ts<=time()) {
            WFCA_DB::set_outbox_status($id,'CANCELLED','24H_SERVICE_WINDOW_CLOSED');
            WFCA_Alerts::raise('24H_SERVICE_WINDOW_CLOSED','WARN',(string)$row['lead_record_id'],(int)$conv['id'],0,(string)$row['body'],'outbox:'.$id.':window');
            return;
        }

        $body=(string)$row['body'];
        if ($action==='CHECKOUT') {
            $prepared=self::prepare_checkout($row,$conv);
            if (!$prepared['ok']) {
                if (!empty($prepared['terminal'])) {
                    WFCA_DB::set_outbox_status($id,'FAILED',(string)$prepared['error']);
                    self::handoff((string)$conv['phone_e164'],(string)$prepared['error'],(string)$row['lead_record_id'],(int)$conv['id'],0,'','outbox-'.$id,'PENDING',false);
                } else {
                    self::retry_or_alert($row,(string)$prepared['error'],'CRITICAL');
                }
                return;
            }
            $body=(string)$prepared['body'];
        }

        WFCA_DB::update_outbox($id,['body'=>$body]);

        // FINAL dual-class real-spacing fence. D0 and follow-up keep independent
        // class floors while a separate aggregate transport floor prevents D0/FU from
        // colliding when their clocks interleave. Missing new knobs inherit the
        // former single shared spacing, so deployment cannot silently accelerate.
        if (in_array($action,['TEMPLATE_INITIAL','FOLLOWUP','TEMPLATE_NURTURE'],true)) {
            $spacing_cfg=WFCA_Airtable::config();
            $class=$action==='TEMPLATE_INITIAL'?'D0':'FOLLOWUP';
            $class_policy=WFCA_Util::class_commercial_policy($spacing_cfg,$action);
            if (empty($class_policy['valid'])) {
                WFCA_DB::defer_outbox($row,'CLASS_SPACING_POLICY_INVALID',3600);
                return;
            }
            $class_spacing=max(WFCA_Util::class_min_spacing_seconds($action),(int)($class_policy['spacing_seconds']??600));
            $global_spacing=WFCA_Util::global_proactive_min_seconds($spacing_cfg);
            if ($global_spacing>3600) {
                WFCA_DB::defer_outbox($row,'GLOBAL_SPACING_POLICY_INVALID',3600);
                return;
            }
            $wait=0;
            $last_class=WFCA_DB::latest_proactive_class_boundary_except_lead($class,(string)$row['lead_record_id'],$id);
            if ($last_class && !empty($last_class['boundary_at'])) {
                $ts=strtotime((string)$last_class['boundary_at'].' UTC');
                if ($ts && time()<($ts+$class_spacing)) $wait=max($wait,($ts+$class_spacing)-time()+1);
            }
            $last_global=WFCA_DB::latest_proactive_boundary_except_lead((string)$row['lead_record_id'],$id);
            if ($last_global && !empty($last_global['boundary_at'])) {
                $ts=strtotime((string)$last_global['boundary_at'].' UTC');
                if ($ts && time()<($ts+$global_spacing)) $wait=max($wait,($ts+$global_spacing)-time()+1);
            }
            if ($wait>0) {
                WFCA_DB::defer_outbox($row,'STRICT_DUAL_CLASS_SPACING_PRE_SEND',max(60,$wait));
                return;
            }
        }
        // Final owner/mode fence and durable send boundary live in the transport facade.
        if ($is_template) {
            $content_sid=trim((string)$row['content_sid']);
            $variables=json_decode((string)$row['content_variables'],true);
            if ($content_sid==='' || !is_array($variables)) {
                self::retry_or_alert($row,'TEMPLATE_PAYLOAD_INVALID','CRITICAL');
                return;
            }
            $sent=WFCA_Transport::send($row,'',$content_sid,$variables);
            if ($is_initial_template) {
                $touch_body='Approved WhatsApp initial template sent with server-side variables.';
                $event_body='[Approved initial template sent]';
            } elseif ($is_followup_template) {
                $touch_body='Approved WhatsApp follow-up template sent with server-side variables.';
                $event_body='[Approved follow-up template sent]';
            } else {
                $touch_body='Approved WhatsApp paid-client nurture template sent with server-side variables.';
                $event_body='[Approved nurture template sent]';
            }
        } else {
            $sent=WFCA_Transport::send($row,$body);
            $touch_body=$body;
            $event_body=$body;
        }
        if (!$sent['ok'] || empty($sent['sid'])) {
            if (!empty($sent['blocked'])) {
                $blocked_error=(string)($sent['error']??'TRANSPORT_BLOCKED');
                WFCA_DB::set_outbox_status($id,'CANCELLED',$blocked_error);
                if ($is_followup && $blocked_error==='FOLLOWUP_SUPERSEDED_BY_INBOUND') self::clear_followup_schedule((string)$conv['phone_e164']);
                return;
            }
            if (!empty($sent['ambiguous'])) {
                $reason='AMBIGUOUS_TRANSPORT_SEND:'.(string)($sent['error']??'UNKNOWN');
                WFCA_DB::update_outbox($id,[
                    'status'=>'UNCERTAIN','lease_owner'=>null,'lease_until'=>null,
                    'last_error'=>WFCA_Util::redact_error($reason,500),'uncertain_alerted'=>1
                ]);
                WFCA_Alerts::raise($reason,'CRITICAL',(string)$row['lead_record_id'],(int)$conv['id'],0,(string)$row['body'],'outbox:'.$id.':uncertain');
                if ($action!=='HANDOFF_ACK') {
                    WFCA_DB::upsert_conversation((string)$conv['phone_e164'],['state'=>'HUMAN_HANDOFF','human_hold'=>1,'summary'=>'Ambiguous provider send']);
                    WFCA_Airtable::update_commercial_by_phone((string)$conv['phone_e164'],[
                        'State'=>'HUMAN_HANDOFF','Human Handoff Reason'=>'AMBIGUOUS_TRANSPORT_SEND','Commercial Error'=>'AMBIGUOUS_TRANSPORT_SEND'
                    ]);
                }
                return;
            }
            $error=(string)($sent['error']??'TRANSPORT_SEND_FAIL');
            if ($is_followup && self::followup_permanent_error($error)) self::fail_followup_fast(WFCA_DB::get_outbox($id)?:$row,$error);
            else self::retry_or_alert(WFCA_DB::get_outbox($id)?:$row,$error,'CRITICAL');
            return;
        }

        // Mark SENT before any post-send sync. A downstream Airtable outage must
        // never cause the same WhatsApp message to be sent twice.
        if (!WFCA_DB::mark_outbox_sent($id,(string)$sent['sid'])) {
            // Kapso/Meta accepted the message but local commit failed. Do not retry.
            // send_started_at remains durable when possible; stale recovery will
            // surface UNCERTAIN rather than sending a duplicate.
            WFCA_Alerts::raise('POST_SEND_LOCAL_COMMIT_FAIL','CRITICAL',(string)$row['lead_record_id'],(int)$conv['id'],0,$event_body,'outbox:'.$id.':local-commit');
            return;
        }
        WFCA_DB::insert_outbound_event((string)$sent['sid'],(string)$conv['phone_e164'],$event_body,$action);
        $current_owner=WFCA_DB::get_conversation((int)$conv['id']);
        if (!$current_owner || (int)$current_owner['owner_revision']!==(int)$row['owner_revision']) return;
        $current_owner=WFCA_DB::get_conversation((int)$conv['id']);
        if (!$current_owner || (int)$current_owner['owner_revision']!==(int)$row['owner_revision']) return;
        WFCA_DB::upsert_conversation((string)$conv['phone_e164'],[
            'state'=>(string)($row['state_after']?:$conv['state']),'last_outbound_at'=>WFCA_Util::now_mysql()
        ]);

        $sync_fields=[
            'State'=>(string)($row['state_after']?:($cf['State']??'ENGAGED')),'Last Outbound At'=>WFCA_Util::now_iso()
        ];
        if ($is_followup) {
            // Consume the due timestamp only after the provider acceptance and
            // local SENT commit. Future follow-up scheduling must be explicit.
            $sync_fields['Next Commercial Action At']=null;
            $sync_fields['Conversation Summary']='Commercial follow-up accepted by provider; recipient delivery pending.';
        }
        $sync=WFCA_Airtable::update_commercial_by_phone((string)$conv['phone_e164'],$sync_fields);
        $sync_ok=!empty($sync['ok']);
        if (!$sync_ok) {
            WFCA_Alerts::raise('POST_SEND_AIRTABLE_SYNC_FAIL','CRITICAL',(string)$row['lead_record_id'],(int)$conv['id'],0,$event_body,'outbox:'.$id.':post-send-sync');
        }
        if ($is_followup && $sync_ok) {
            $readback=WFCA_Airtable::get_commercial_conversation((string)$conv['phone_e164']);
            $rf=$readback['record']['fields']??[];
            if (empty($readback['ok']) || ($rf['State']??'')!=='WAITING_REPLY' || !empty($rf['Next Commercial Action At'])) {
                $sync_ok=false;
                WFCA_Alerts::raise('FOLLOWUP_POST_SEND_READBACK_FAIL','CRITICAL',(string)$row['lead_record_id'],(int)$conv['id'],0,$event_body,'outbox:'.$id.':followup-readback');
            }
        }

        $price_ok=true;
        if ($action==='PRICE') {
            $price_sync=WFCA_Airtable::update_lead((string)$row['lead_record_id'],['Price Presented'=>true]);
            $price_ok=!empty($price_sync['ok']);
            if (!$price_ok) WFCA_Alerts::raise('POST_SEND_PRICE_SYNC_FAIL','WARN',(string)$row['lead_record_id'],(int)$conv['id'],0,$event_body,'outbox:'.$id.':price-sync');
        }

        $touch=WFCA_Airtable::log_touch((string)$row['lead_record_id'],'OUTBOUND',$action,$touch_body,(string)$sent['sid']);
        $touch_ok=!empty($touch['ok']);
        if (!$touch_ok) {
            WFCA_Alerts::raise('POST_SEND_TOUCH_LOG_FAIL','WARN',(string)$row['lead_record_id'],(int)$conv['id'],0,$event_body,'outbox:'.$id.':touch');
        }

        $all_synced=$sync_ok && $price_ok && $touch_ok;
        WFCA_DB::update_outbox($id,['sync_pending'=>$all_synced?0:1]);
        if ($all_synced && $is_initial_template) self::schedule_d0_followup_after_initial($conv,$lead);
        if ($all_synced && $is_followup) self::schedule_next_followup_after_followup($conv,$lead,WFCA_DB::get_outbox($id)?:$row);
        if ($all_synced && !$is_template && !$is_followup && !in_array($action,['HANDOFF_ACK','CHECKOUT'],true)) {
            $fresh_conv=WFCA_DB::get_conversation((int)$conv['id']);
            if ($fresh_conv) self::schedule_contextual_followup($fresh_conv);
        }
        if ($all_synced) {
            WFCA_Alerts::resolve_source('outbox:'.$id.':post-send-sync');
            WFCA_Alerts::resolve_source('outbox:'.$id.':price-sync');
            WFCA_Alerts::resolve_source('outbox:'.$id.':touch');
        }
    }

    public static function reconcile_sent_outbox(int $limit=4): void {
        foreach (WFCA_DB::sent_sync_pending($limit) as $row) {
            $id=(int)$row['id'];
            if (str_starts_with((string)$row['action_type'],'ALERT_')) { WFCA_Alerts::sync_outbox($row);WFCA_DB::update_outbox($id,['sync_pending'=>0]);continue; }
            $conv=WFCA_DB::get_conversation((int)$row['conversation_id']);
            if (!$conv || empty($row['lead_record_id']) || empty($row['provider_message_id'])) continue;

            $cc=WFCA_Airtable::get_commercial_conversation((string)$conv['phone_e164']);
            if (empty($cc['ok']) || empty($cc['record'])) continue;
            $cf=$cc['record']['fields']??[];
            $current_state=(string)($cf['State']??'');
            $state_after=trim((string)($row['state_after']??''));
            $is_followup=(string)$row['action_type']==='FOLLOWUP';
            $advanced=['PAYMENT_PENDING','HIGH_INTENT','PAID','HUMAN_HANDOFF','OPT_OUT','NO_INTEREST'];

            $sent_ts=!empty($row['sent_at'])?strtotime((string)$row['sent_at'].' UTC'):false;
            WFCA_DB::insert_outbound_event((string)$row['provider_message_id'],(string)$conv['phone_e164'],(string)$row['body'],(string)$row['action_type'],(string)$row['provider']);
            $fields=['Last Outbound At'=>$sent_ts?gmdate('c',$sent_ts):WFCA_Util::now_iso()];
            // Never let a delayed reconciliation regress an advanced business state.
            if ($state_after!=='' && !in_array($current_state,$advanced,true)) $fields['State']=$state_after;
            if ($is_followup) {
                $fields['Next Commercial Action At']=null;
                $fields['Conversation Summary']='Commercial follow-up accepted by provider; recipient delivery pending.';
            }
            $sync=WFCA_Airtable::update_commercial_by_phone((string)$conv['phone_e164'],$fields);
            $sync_ok=!empty($sync['ok']);
            if ($is_followup && $sync_ok) {
                $readback=WFCA_Airtable::get_commercial_conversation((string)$conv['phone_e164']);
                $rf=$readback['record']['fields']??[];
                if (empty($readback['ok']) || ($rf['State']??'')!=='WAITING_REPLY' || !empty($rf['Next Commercial Action At'])) $sync_ok=false;
            }

            $price_ok=true;
            if ((string)$row['action_type']==='PRICE') {
                $price_sync=WFCA_Airtable::update_lead((string)$row['lead_record_id'],['Price Presented'=>true]);
                $price_ok=!empty($price_sync['ok']);
            }

            $touch_body=(string)$row['body'];
            if ((string)$row['action_type']==='TEMPLATE_INITIAL') $touch_body='Approved WhatsApp initial template sent with server-side variables.';
            if ((string)$row['action_type']==='FOLLOWUP' && trim((string)($row['content_sid']??''))!=='') $touch_body='Approved WhatsApp follow-up template sent with server-side variables.';
            if ((string)$row['action_type']==='TEMPLATE_NURTURE') $touch_body='Approved WhatsApp paid-client nurture template sent with server-side variables.';
            if ((string)$row['action_type']==='CHECKOUT' && $touch_body==='') $touch_body='Checkout InfinitePay sent.';
            $touch=WFCA_Airtable::log_touch((string)$row['lead_record_id'],'OUTBOUND',(string)$row['action_type'],$touch_body,(string)$row['provider_message_id'],(string)$row['provider'],'LUNA',(string)($row['initial_arm']??''));
            $touch_ok=!empty($touch['ok']);

            if ($sync_ok && $price_ok && $touch_ok) {
                WFCA_DB::update_outbox($id,['sync_pending'=>0]);
                if (in_array((string)$row['action_type'],['TEMPLATE_INITIAL','FOLLOWUP'],true)) {
                    $lead_r=WFCA_Airtable::get_lead((string)$row['lead_record_id']);
                    if (!empty($lead_r['ok']) && !empty($lead_r['data']['fields'])) {
                        $lead=$lead_r['data'];$lead['id']=(string)$row['lead_record_id'];
                        if ((string)$row['action_type']==='TEMPLATE_INITIAL') self::schedule_d0_followup_after_initial($conv,$lead);
                        else self::schedule_next_followup_after_followup($conv,$lead,$row);
                    }
                }
                WFCA_Alerts::resolve_source('outbox:'.$id.':post-send-sync');
                WFCA_Alerts::resolve_source('outbox:'.$id.':price-sync');
                WFCA_Alerts::resolve_source('outbox:'.$id.':touch');
            }
        }
    }

    private static function prepare_checkout(array $row,array $conv): array {
        $offer=self::offer((string)$row['offer_code']);
        if (!$offer) return ['ok'=>false,'error'=>'OFFER_NOT_FOUND','terminal'=>true];
        if (!WFCA_InfinitePay::ready()) return ['ok'=>false,'error'=>'INFINITEPAY_NOT_CONFIGURED','terminal'=>true];

        $order=WFCA_DB::get_order_by_outbox_id((int)$row['id']);
        if (!$order) {
            $order_nsu='WFCA-'.substr((string)$row['lead_record_id'],-8).'-'.gmdate('YmdHis').'-'.wp_generate_password(5,false,false);
            $oid=WFCA_DB::create_order([
                'order_nsu'=>$order_nsu,'outbox_id'=>(int)$row['id'],'lead_record_id'=>(string)$row['lead_record_id'],
                'conversation_id'=>(int)$conv['id'],'offer_code'=>$offer['code'],'expected_amount_cents'=>$offer['amount']
            ]);
            if ($oid<=0) return ['ok'=>false,'error'=>'ORDER_CREATE_FAIL','terminal'=>false];
            WFCA_DB::update_outbox((int)$row['id'],['related_order_id'=>$oid]);
            $order=WFCA_DB::get_order($oid);
        }
        if (!$order) return ['ok'=>false,'error'=>'ORDER_READ_FAIL','terminal'=>false];
        if (($order['state']??'')==='PAID') return ['ok'=>false,'error'=>'ORDER_ALREADY_PAID','terminal'=>true];

        $checkout_url=(string)($order['checkout_url']??'');
        if (!filter_var($checkout_url,FILTER_VALIDATE_URL)) {
            $checkout=WFCA_InfinitePay::create_link((string)$order['order_nsu'],$offer['name'],$offer['amount'],(string)$conv['phone_e164']);
            if (!$checkout['ok']) {
                WFCA_DB::update_order((int)$order['id'],['state'=>'ERROR','error'=>$checkout['error']??'CREATE_LINK_FAIL']);
                return ['ok'=>false,'error'=>'CHECKOUT_CREATE_FAIL:'.($checkout['error']??''),'terminal'=>false];
            }
            $checkout_url=(string)$checkout['url'];
            WFCA_DB::update_order((int)$order['id'],['checkout_url'=>$checkout_url,'state'=>'PENDING','error'=>null]);
        }

        $sync=WFCA_Airtable::update_commercial_by_phone((string)$conv['phone_e164'],[
            'State'=>'PAYMENT_PENDING','Checkout URL'=>$checkout_url,'Payment State'=>'PENDING','Payment Order NSU'=>(string)$order['order_nsu']
        ]);
        if (empty($sync['ok'])) return ['ok'=>false,'error'=>'AIRTABLE_PAYMENT_STATE_WRITE_FAIL','terminal'=>false];

        $body="Perfeito. Esse é o link seguro para concluir:\n".$checkout_url;
        if (str_ends_with((string)$offer['code'],'_STRATEGY')) {
            $body.="\n\nEsse link já inclui o site + Strategy Express com o Daniel.";
        } elseif (in_array((string)$offer['code'],['ENTRY','LANDING_PAGE_PREMIUM','SITE_PROFISSIONAL','SITE_AUTORIDADE'],true)) {
            $cfg=WFCA_Airtable::config();
            $body.="\n\nSe quiser adicionar a sessão Strategy Express com o Daniel (a partir de ".WFCA_Commercial_Context::strategy_price_label($cfg)."), me avisa antes de pagar que eu ajusto o link.";
        }
        $body.="\n\nQuando o pagamento for aprovado, eu confirmo por aqui.";

        return [
            'ok'=>true,
            'body'=>$body,
            'order_id'=>(int)$order['id']
        ];
    }

    private static function retry_or_alert(array $row,string $error,string $severity='WARN'): void {
        $terminal=WFCA_DB::retry_outbox($row,$error,5);
        if (!$terminal) return;
        $conv=WFCA_DB::get_conversation((int)$row['conversation_id']);
        WFCA_Alerts::raise('OUTBOX_FAILED:'.$error,$severity,(string)$row['lead_record_id'],(int)($conv['id']??0),0,(string)$row['body'],'outbox:'.(int)$row['id'].':failed');
        if ($conv && $row['action_type']!=='HANDOFF_ACK') {
            self::handoff((string)$conv['phone_e164'],'OUTBOX_FAILED:'.$error,(string)$row['lead_record_id'],(int)$conv['id'],0,'','outbox-'.(int)$row['id'],'PENDING',false);
        }
    }

    /**
     * Bridge Factory PASS inventory into Commercial Conversations. RC5 only
     * consumed pre-existing conversation rows, which made throughput depend on a
     * one-off migration. This materializer is bounded, idempotent and preserves
     * every existing touched conversation/owner/opt-out state.
     */
    private static function materialize_commercial_ready_inventory(int $max=250): array {
        $mode=WFCA_Airtable::base_mode();
        if (WFCA_Airtable::draining() || !in_array($mode,['ASSISTED','LIVE'],true)) return ['ok'=>false,'reason'=>WFCA_Airtable::draining()?'DRAINING':'MODE_NOT_ACTIVE'];
        $last=(int)get_option('wfca_inventory_materialized_at',0);
        if ($last>0 && time()-$last<120) return ['ok'=>true,'skipped'=>'THROTTLED'];
        update_option('wfca_inventory_materialized_at',time(),false);
        $list=WFCA_Airtable::commercial_ready_leads(max(1,min(100,$max)));
        if (empty($list['ok'])) return ['ok'=>false,'reason'=>'READY_INVENTORY_READ_FAIL'];
        $touch_index=WFCA_Airtable::outbound_touch_index();
        if (empty($touch_index['ok'])) return ['ok'=>false,'reason'=>'TOUCH_HISTORY_READ_FAIL'];
        $created=0;$preserved=0;$rebound=0;
        // One phone-policy snapshot and one batched conversation read for the whole pass. Each prefetched row is
        // consumed once (a later lead with the same phone re-reads live, after any write the first one made).
        $policy=WFCA_Airtable::phone_policy();$ready_phones=[];
        foreach(($list['data']['records']??[]) as $lead) {
            if (!WFCA_Airtable::lead_is_commercial_ready($lead)) continue;
            $ph=WFCA_Airtable::canonical_factory_phone((string)($lead['fields']['Telefone']??''),$policy);
            if ($ph!=='') $ready_phones[]=$ph;
        }
        $prefetch=WFCA_Airtable::get_commercial_conversations_bulk($ready_phones);$pf_at=microtime(true);
        foreach(($list['data']['records']??[]) as $lead) {
            $lead_id=(string)($lead['id']??'');$f=$lead['fields']??[];
            if ($lead_id==='' || !WFCA_Airtable::lead_is_commercial_ready($lead)) continue;
            $phone=WFCA_Airtable::canonical_factory_phone((string)($f['Telefone']??''),$policy);
            if ($phone==='') continue;
            $raw_arm=(string)($f['Assigned Arm']??'');
            if ($raw_arm==='') {
                $raw_arm=WFCA_Ownership::route_for_lead($lead_id);
                $arm_write=WFCA_Airtable::update_lead($lead_id,['Assigned Arm'=>$raw_arm]);
                if (empty($arm_write['ok'])) continue;
                $f['Assigned Arm']=$raw_arm;$lead['fields']=$f;
            }
            $arm=WFCA_Ownership::arm($raw_arm);
            if ($arm==='') continue;
            $pf_key=WFCA_Airtable::conversation_id($phone);
            // 10.9.26 (adversarial review): trust the batch row only when it EXISTS and is fresh (<2 s). An "absent" row, or any
            // row older than that, is re-read live exactly like 10.9.25, so an inbound/STOP/owner change landing mid-pass is never overwritten.
            if (!empty($prefetch[$pf_key]['record']) && (microtime(true)-$pf_at)<2.0) { $remote=$prefetch[$pf_key];unset($prefetch[$pf_key]); }
            else $remote=WFCA_Airtable::get_commercial_conversation($phone);
            if (empty($remote['ok'])) continue;
            $rf=$remote['record']['fields']??[];
            $local=WFCA_DB::get_conversation_by_phone($phone);
            if (!empty($remote['record'])) {
                $linked=array_values(array_filter((array)($rf['Lead']??[]),'is_string'));
                if (in_array($lead_id,$linked,true)) {
                    if (!$local) $local=WFCA_DB::upsert_conversation($phone,['lead_record_id'=>$lead_id,'airtable_record_id'=>$remote['record']['id'],'initial_arm'=>$arm]);
                    if ($local) WFCA_DB::materialize_remote_snapshot((int)$local['id'],$rf);
                    $preserved++;continue;
                }
                if (count($linked)===1) {
                    $old=WFCA_Airtable::get_lead((string)$linked[0]);
                    if (!empty($old['ok']) && !empty($old['data']) && WFCA_Airtable::lead_is_organic_intake($old['data'])) {
                        if (!$local) {
                            $local=WFCA_DB::upsert_conversation($phone,['lead_record_id'=>(string)$linked[0],'airtable_record_id'=>$remote['record']['id'],'initial_arm'=>WFCA_Ownership::arm((string)($rf['Initial Arm']??''))]);
                            if ($local) WFCA_DB::materialize_remote_snapshot((int)$local['id'],$rf);
                        }
                        if ($local) {
                            $reb=self::reconcile_canonical_lead_binding($phone,$lead,$local);
                            if (!empty($reb['ok'])) {$rebound++;continue;}
                        }
                    }
                }
                // Existing non-organic or ambiguous conversation is sovereign.
                $preserved++;continue;
            }

            $prior_local=WFCA_DB::initial_outreach_exists($lead_id,$phone);
            $prior_touch=!empty($touch_index['by_lead'][$lead_id]) || !empty($touch_index['by_phone'][$phone]);
            $prior=$prior_local || $prior_touch;
            $owner=$arm==='LUNA_COLD_WHATSAPP'?'LUNA':'DANIEL';
            $state=$prior?'WAITING_REPLY':'READY_FOR_CONTACT';
            $fields=[
                'State'=>$state,'Enabled'=>$owner==='LUNA','Conversation Owner'=>$owner,'Owner Revision'=>1,
                'Initial Arm'=>$raw_arm,'WhatsApp Permission Status'=>'LIVE_HANDOFF',
                'WhatsApp Permission Evidence'=>'Factory PASS under CURRENT upstream phone-approval invariant.',
                'Conversation Summary'=>$prior?'Prior WhatsApp outbound detected; do not create a second D0.':'Factory PASS inventory materialized for the assigned arm.'
            ];
            $write=WFCA_Airtable::upsert_commercial_conversation($phone,$lead_id,$fields);
            if (empty($write['ok'])) continue;
            $got=WFCA_Airtable::get_commercial_conversation($phone);$remote_f=$got['record']['fields']??$fields;
            $local=WFCA_DB::upsert_conversation($phone,[
                'lead_record_id'=>$lead_id,'airtable_record_id'=>$got['record']['id']??null,'state'=>$state,
                'permission_status'=>'LIVE_HANDOFF','initial_arm'=>$arm,'conversation_owner'=>$owner,
                'owner_revision'=>1,'human_hold'=>$owner==='LUNA'?0:1
            ]);
            if ($local && !empty($got['record'])) WFCA_DB::materialize_remote_snapshot((int)$local['id'],$remote_f);
            $created++;
        }
        return ['ok'=>true,'created'=>$created,'preserved'=>$preserved,'rebound'=>$rebound];
    }

    /** True/false/null: null means history read failed and D0 must fail closed. */
    private static function prior_initial_outreach_exists(string $lead_id,string $phone): ?bool {
        if (WFCA_DB::initial_outreach_exists($lead_id,$phone)) return true;
        $remote=WFCA_Airtable::prior_whatsapp_outbound_touch_status($lead_id,$phone);
        if (empty($remote['ok'])) return null;
        return !empty($remote['exists']);
    }

    /**
     * After a detected clinic autoresponder, stay silent for ~30 minutes, then ask
     * one low-friction routing question inside the already-open 24h service window.
     * This is inbound-triggered service-window traffic, not a cold/proactive
     * follow-up. It is lifetime-idempotent per lead/phone and any newer human
     * inbound cancels it before send.
     */
    private static function schedule_autoresponder_followup(array $conv,array $lead): void {
        $conv_id=(int)($conv['id']??0);
        $lead_id=(string)($lead['id']??'');
        $phone=WFCA_Util::normalize_phone((string)($conv['phone_e164']??''));
        if ($conv_id<=0 || $lead_id==='' || $phone==='') return;
        $fresh=WFCA_DB::get_conversation($conv_id)?:$conv;
        if (($fresh['conversation_owner']??'')!=='LUNA' || !empty($fresh['human_hold']) || !empty($fresh['opt_out'])) return;
        if (!WFCA_Airtable::lead_is_commercial_ready($lead)) return;
        $window=!empty($fresh['service_window_until'])?strtotime((string)$fresh['service_window_until'].' UTC'):0;
        $due=time()+(30*MINUTE_IN_SECONDS);
        if (!$window || $window<=$due+60) return;
        $key=hash('sha256','AUTO_REPLY_GATEKEEPER|'.$lead_id.'|'.$phone);
        if (WFCA_DB::get_outbox_by_idempotency_key($key)) return;
        $lead_name=trim((string)($lead['fields']['Lead']??''));
        $body=$lead_name!==''
            ? 'Só pra eu falar com a pessoa certa: quem cuida do site/marketing da '.$lead_name.' por aí?'
            : 'Só pra eu falar com a pessoa certa: quem cuida do site/marketing por aí?';
        WFCA_DB::queue([
            'idempotency_key'=>$key,'lead_record_id'=>$lead_id,'conversation_id'=>$conv_id,
            'action_type'=>'AUTO_REPLY_GATEKEEPER','body'=>$body,'state_after'=>'WAITING_REPLY',
            'status'=>WFCA_Ownership::queue_status(),'next_attempt_at'=>gmdate('Y-m-d H:i:s',$due),
            'scheduled_action_at'=>gmdate('Y-m-d H:i:s',$due),'followup_step'=>'AUTO_REPLY_GATEKEEPER_1'
        ]);
    }

    private static function schedule_contextual_followup(array $conv): void {
        return;
    }

    private static function followup_permanent_error(string $error): bool {
        $u=strtoupper($error);
        foreach (['KAPSO_HTTP_4','KAPSO_NOT_CONFIGURED','INVALID_DESTINATION','EMPTY_BODY','TEMPLATE_PAYLOAD_INVALID','TEMPLATE_HEADER_IMAGE_INVALID'] as $needle) {
            if (str_contains($u,$needle)) return true;
        }
        return false;
    }

    private static function fail_followup_fast(array $row,string $error): void {
        $safe=WFCA_Util::redact_error($error,500);
        WFCA_DB::set_outbox_status((int)$row['id'],'FAILED',$safe);
        WFCA_Alerts::raise('FOLLOWUP_PERMANENT_FAILURE:'.$safe,'CRITICAL',(string)($row['lead_record_id']??''),(int)($row['conversation_id']??0),0,(string)($row['body']??''),'outbox:'.(int)$row['id'].':followup-permanent');
    }

    /**
     * Optional multi-stage no-inbound ladder. Absent config preserves the
     * 10.9.9 single-FU behavior. The current approved provider template is
     * reused for later stages; only the safe variable insight changes.
     */
    private static function followup_ladder_policy(array $cfg): array {
        $raw=trim((string)($cfg['COMMERCIAL_FOLLOWUP_LADDER_POLICY_V2']??($cfg['COMMERCIAL_FOLLOWUP_LADDER_V1']??'')));
        if ($raw==='') return ['present'=>false,'valid'=>true,'enabled'=>false];
        $j=json_decode($raw,true);
        if (!is_array($j) || (string)($j['version']??'')!=='COMMERCIAL_FOLLOWUP_LADDER_POLICY_V2') return ['present'=>true,'valid'=>false,'enabled'=>false];
        $enabled=!empty($j['enabled']);
        $fu2=(int)($j['fu2_due_from_initial_minutes']??4320);
        $fu2_min=(int)($j['fu2_min_after_fu1_minutes']??1440);
        $fu3=(int)($j['fu3_due_from_initial_minutes']??10080);
        $fu3_min=(int)($j['fu3_min_after_fu2_minutes']??4320);
        if ($fu2<1440 || $fu2>20160 || $fu2_min<600 || $fu2_min>10080 || $fu3<= $fu2 || $fu3>43200 || $fu3_min<1440 || $fu3_min>20160) {
            return ['present'=>true,'valid'=>false,'enabled'=>false];
        }
        return [
            'present'=>true,'valid'=>true,'enabled'=>$enabled,
            'fu2_due_from_initial_minutes'=>$fu2,'fu2_min_after_fu1_minutes'=>$fu2_min,
            'fu3_due_from_initial_minutes'=>$fu3,'fu3_min_after_fu2_minutes'=>$fu3_min,
        ];
    }

    private static function followup_outbox_for_stage(string $lead_id,string $phone,int $stage): ?array {
        if ($stage<1 || $stage>3) return null;
        $key=hash('sha256','FOLLOWUP|D0_'.$stage.'|'.$lead_id.'|'.$phone);
        return WFCA_DB::get_outbox_by_idempotency_key($key);
    }

    /** Determine the one next legal follow-up stage from durable provider history. */
    private static function next_followup_stage(string $lead_id,string $phone,array $cfg): array {
        $initial_key=hash('sha256','INITIAL|'.$lead_id.'|'.$phone);
        $initial=WFCA_DB::get_outbox_by_idempotency_key($initial_key);
        if (!$initial || (string)($initial['action_type']??'')!=='TEMPLATE_INITIAL' || (string)($initial['status']??'')!=='SENT' || empty($initial['provider_message_id']) || empty($initial['sent_at'])) return [];
        $initial_sent=strtotime((string)$initial['sent_at'].' UTC');
        if (!$initial_sent) return [];
        $fu1=self::followup_outbox_for_stage($lead_id,$phone,1);
        $delay=(int)($cfg['COMMERCIAL_D0_FOLLOWUP_DELAY_MINUTES']??0);
        if (!$fu1) {
            if ($delay<10 || $delay>10080) return [];
            return ['stage'=>1,'step'=>'D0_FOLLOWUP_1','key'=>hash('sha256','FOLLOWUP|D0_1|'.$lead_id.'|'.$phone),'due_ts'=>$initial_sent+($delay*60),'previous_sent_ts'=>$initial_sent];
        }
        if ((string)($fu1['status']??'')!=='SENT' || empty($fu1['provider_message_id']) || empty($fu1['sent_at'])) return [];
        $p=self::followup_ladder_policy($cfg);
        if (empty($p['valid']) || empty($p['enabled'])) return [];
        $fu1_sent=strtotime((string)$fu1['sent_at'].' UTC');
        if (!$fu1_sent) return [];
        $fu2=self::followup_outbox_for_stage($lead_id,$phone,2);
        if (!$fu2) {
            $due=max($initial_sent+((int)$p['fu2_due_from_initial_minutes']*60),$fu1_sent+((int)$p['fu2_min_after_fu1_minutes']*60));
            return ['stage'=>2,'step'=>'D0_FOLLOWUP_2','key'=>hash('sha256','FOLLOWUP|D0_2|'.$lead_id.'|'.$phone),'due_ts'=>$due,'previous_sent_ts'=>$fu1_sent];
        }
        if ((string)($fu2['status']??'')!=='SENT' || empty($fu2['provider_message_id']) || empty($fu2['sent_at'])) return [];
        $fu2_sent=strtotime((string)$fu2['sent_at'].' UTC');
        if (!$fu2_sent) return [];
        $fu3=self::followup_outbox_for_stage($lead_id,$phone,3);
        if (!$fu3) {
            $due=max($initial_sent+((int)$p['fu3_due_from_initial_minutes']*60),$fu2_sent+((int)$p['fu3_min_after_fu2_minutes']*60));
            return ['stage'=>3,'step'=>'D0_FOLLOWUP_3','key'=>hash('sha256','FOLLOWUP|D0_3|'.$lead_id.'|'.$phone),'due_ts'=>$due,'previous_sent_ts'=>$fu2_sent];
        }
        return [];
    }

    private static function followup_stage_insight(array $lead,string $step): string {
        if ($step==='D0_FOLLOWUP_2') {
            return self::prospect_sentence_text('Além da apresentação, a página já deixa uma base pronta para ajustar textos, contato e domínio sem precisar recomeçar o projeto.',220,true);
        }
        if ($step==='D0_FOLLOWUP_3') {
            return self::prospect_sentence_text('A página continua guardada como uma base pronta; se o projeto entrar na prioridade de vocês, dá para retomar exatamente daqui sem reconstruir o trabalho.',220,true);
        }
        return self::commercial_followup_insight($lead);
    }

    /** After FU1/FU2 provider acceptance, persist only the next future due. */
    private static function schedule_next_followup_after_followup(array $conv,array $lead,array $sent_row): void {
        $step=(string)($sent_row['followup_step']??'');
        if (!in_array($step,['D0_FOLLOWUP_1','D0_FOLLOWUP_2'],true)) return;
        $cfg=WFCA_Airtable::config();
        $p=self::followup_ladder_policy($cfg);
        if (empty($p['valid']) || empty($p['enabled'])) return;
        $phone=(string)($conv['phone_e164']??'');
        $lead_id=(string)($lead['id']??($conv['lead_record_id']??''));
        if ($phone==='' || $lead_id==='') return;
        $next=self::next_followup_stage($lead_id,$phone,$cfg);
        if (!$next) return;
        $expected=$step==='D0_FOLLOWUP_1'?'D0_FOLLOWUP_2':'D0_FOLLOWUP_3';
        if ((string)$next['step']!==$expected) return;
        WFCA_Airtable::update_commercial_by_phone($phone,[
            'State'=>'WAITING_REPLY','Next Commercial Action At'=>gmdate('c',(int)$next['due_ts']),
            'Conversation Summary'=>$expected==='D0_FOLLOWUP_2'?'FU1 accepted; FU2 D3 due persisted subject to all stop fences.':'FU2 accepted; FU3 D7/final-touch due persisted subject to all stop fences.'
        ]);
    }

    /**
     * Reserve at most one due provider-approved template follow-up per tick. No
     * provider-approved active spec, zero daily cap, missing insight, stale owner,
     * payment/opt-out or missing D0 proof => fail closed.
     */
    private static function schedule_due_followups(int $limit=1): array {
        if (WFCA_Airtable::draining()) return ['reserved'=>0,'skip_reason'=>'DRAINING_NO_NEW_PROACTIVE'];
        $mode=WFCA_Airtable::base_mode();
        if (!in_array($mode,['ASSISTED','LIVE'],true)) return ['reserved'=>0,'skip_reason'=>'MODE_NOT_ACTIVE'];
        $cfg=WFCA_Airtable::config();
        $max=max(0,(int)($cfg['COMMERCIAL_MAX_FOLLOWUPS_DAY']??0));
        if ($max<=0) return ['reserved'=>0,'skip_reason'=>'FOLLOWUP_DISABLED_BY_CONFIG'];
        $spec=WFCA_Kapso::template_spec('FOLLOWUP');
        $sid=(string)($spec['name']??'');
        if ($sid==='' || empty($spec['variables'])) return ['reserved'=>0,'skip_reason'=>'FOLLOWUP_TEMPLATE_NOT_ACTIVE'];
        $policy=WFCA_Util::class_commercial_policy($cfg,'FOLLOWUP');
        if (empty($policy['valid'])) return ['reserved'=>0,'skip_reason'=>'FOLLOWUP_POLICY_INVALID'];
        $tz=(string)($policy['timezone']??'America/Sao_Paulo');
        [$start_utc,$end_utc]=WFCA_Util::utc_bounds_for_local_day($tz);
        $used=WFCA_DB::count_followups_in_range($start_utc,$end_utc);
        $remaining=max(0,$max-$used);
        if ($remaining<=0) return ['reserved'=>0,'skip_reason'=>'FOLLOWUP_DAILY_CAP'];

        $list=WFCA_Airtable::eligible_due_followups(min(max(1,$limit),$remaining));
        if (empty($list['ok'])) return ['reserved'=>0,'skip_reason'=>'FOLLOWUP_AIRTABLE_READ_FAIL'];
        $reserved=0;
        foreach (($list['data']['records']??[]) as $rec) {
            if ($reserved>=$limit || $remaining<=0) break;
            $cf=$rec['fields']??[];
            $lead_ids=(array)($cf['Lead']??[]);
            if (count($lead_ids)!==1) continue;
            $lead_id=(string)$lead_ids[0];
            $phone=WFCA_Util::normalize_phone((string)($cf['Phone E164']??''));
            if ($lead_id==='' || $phone==='') continue;
            $lead_r=WFCA_Airtable::get_lead($lead_id);
            if (empty($lead_r['ok']) || empty($lead_r['data']['fields'])) continue;
            $lead=$lead_r['data'];$lead['id']=$lead_id;
            if (!WFCA_Airtable::lead_is_commercial_ready($lead)) continue;
            $canonical=WFCA_Airtable::canonical_site_url($lead_id,$lead,true);
            if (empty($canonical['ok'])) continue;
            $lead['fields']['Site URL']=(string)$canonical['url'];
            $conv=WFCA_DB::get_conversation_by_phone($phone);
            if (!$conv || (string)($conv['lead_record_id']??'')!==$lead_id) continue;
            $due_ts=strtotime((string)($cf['Next Commercial Action At']??''));
            if (!$due_ts) continue;
            $reason=self::followup_gate_reason($conv,$cf,$due_ts,true);
            if ($reason!=='') {
                if ($reason==='FOLLOWUP_SUPERSEDED_BY_INBOUND') self::clear_followup_schedule($phone,true);
                continue;
            }
            $history=self::prior_initial_outreach_exists($lead_id,$phone);
            if ($history!==true) continue;
            $next=self::next_followup_stage($lead_id,$phone,$cfg);
            if (!$next || (int)$next['due_ts']!==$due_ts) continue;
            $step=(string)$next['step'];
            if ($step==='D0_FOLLOWUP_1' && self::commercial_followup_insight($lead)==='') continue;
            $key=(string)$next['key'];
            if (WFCA_DB::get_outbox_by_idempotency_key($key)) continue;
            $vars=self::followup_template_variables($spec,$lead,(string)$canonical['url'],$step);
            if (!$vars) continue;
            $oid=WFCA_DB::queue([
                'idempotency_key'=>$key,
                'lead_record_id'=>$lead_id,'conversation_id'=>(int)$conv['id'],'action_type'=>'FOLLOWUP',
                'content_sid'=>$sid,'content_variables'=>$vars,'state_after'=>'WAITING_REPLY','status'=>WFCA_Ownership::queue_status(),
                'scheduled_action_at'=>gmdate('Y-m-d H:i:s',$due_ts),'followup_step'=>$step
            ]);
            if ($oid>0) {$reserved++;$remaining--;}
        }
        return ['reserved'=>$reserved,'skip_reason'=>$reserved>0?'':'NO_DUE_SAFE_FOLLOWUP'];
    }

    private static function followup_gate_reason(array $conv,array $cf,int $due_ts,bool $template_followup=false): string {
        $owner=(string)($cf['Conversation Owner']??'');
        $state=strtoupper((string)($cf['State']??''));
        $payment=strtoupper((string)($cf['Payment State']??''));
        if (($conv['conversation_owner']??'')!=='LUNA' || $owner!=='LUNA') return 'OWNER_NOT_LUNA';
        if (WFCA_Ownership::is_only_daniel((string)($conv['initial_arm']??'')) && empty($conv['luna_resumed_at'])) return 'ONLY_DANIEL_REQUIRES_EXPLICIT_HANDOFF';
        if (!empty($conv['owner_sync_pending'])) return 'OWNER_SYNC_PENDING';
        if ((int)($conv['human_hold']??0)===1 || $state==='HUMAN_HANDOFF') return 'HUMAN_HANDOFF';
        if ((int)($conv['opt_out']??0)===1 || !empty($cf['Opt Out']) || ($cf['WhatsApp Permission Status']??'')==='OPT_OUT' || $state==='OPT_OUT') return 'OPT_OUT_HARD_STOP';
        if (empty($cf['Enabled'])) return 'CONVERSATION_DISABLED';
        if (in_array($state,['PAID','PAYMENT_PENDING','CHECKOUT','COMPLETED','SETTLED'],true) || in_array($payment,['PAID','SETTLED','COMPLETED','TERMINAL'],true)) return 'PAYMENT_TERMINAL';
        if (WFCA_DB::has_terminal_payment((int)$conv['id'])) return 'PAYMENT_TERMINAL';
        if ($state!=='FOLLOWUP_SCHEDULED') return 'FOLLOWUP_STATE_CHANGED';
        if (!$template_followup) {
            $window=!empty($cf['WhatsApp 24h Window Until'])?strtotime((string)$cf['WhatsApp 24h Window Until']):0;
            if (!$window || $window<=time()+30) return 'FOLLOWUP_SERVICE_WINDOW_CLOSED';
        }
        $remote_due=strtotime((string)($cf['Next Commercial Action At']??''));
        if (!$remote_due || $remote_due!==$due_ts) return 'FOLLOWUP_SCHEDULE_CHANGED';
        $last_inbound=!empty($conv['last_inbound_at'])?strtotime((string)$conv['last_inbound_at'].' UTC'):0;
        if ($last_inbound && $last_inbound>$due_ts) return 'FOLLOWUP_SUPERSEDED_BY_INBOUND';
        return '';
    }

    /** Persist the future due timestamp after an accepted D0 while remaining WAITING_REPLY. */
    private static function schedule_d0_followup_after_initial(array $conv,array $lead): void {
        $cfg=WFCA_Airtable::config();
        $delay=(int)($cfg['COMMERCIAL_D0_FOLLOWUP_DELAY_MINUTES']??0);
        if ($delay<10 || $delay>10080) return;
        $fresh=WFCA_DB::get_conversation((int)($conv['id']??0));
        if (!$fresh || ($fresh['conversation_owner']??'')!=='LUNA' || !empty($fresh['opt_out']) || !empty($fresh['human_hold'])) return;
        $phone=(string)$fresh['phone_e164'];
        $key=hash('sha256','INITIAL|'.(string)($fresh['lead_record_id']??'').'|'.$phone);
        $initial=WFCA_DB::get_outbox_by_idempotency_key($key);
        if (!$initial || (string)($initial['action_type']??'')!=='TEMPLATE_INITIAL' || (string)($initial['status']??'')!=='SENT' || empty($initial['provider_message_id']) || empty($initial['sent_at'])) return;
        $base=strtotime((string)$initial['sent_at'].' UTC');
        if (!$base) return;
        $due=$base+($delay*60);
        $remote=WFCA_Airtable::update_commercial_by_phone($phone,[
            'State'=>'WAITING_REPLY','Next Commercial Action At'=>gmdate('c',$due),
            'Conversation Summary'=>'D0 accepted; follow-up due recorded and will be materialized natively only if still safe at due time.'
        ]);
        if (empty($remote['ok'])) {
            WFCA_Alerts::raise('FOLLOWUP_DUE_SYNC_FAIL','WARN',(string)($fresh['lead_record_id']??''),(int)$fresh['id'],0,'','followup-due:'.(int)$fresh['id']);
        }
    }

    /** Backfill/materialize at most one due safe WAITING_REPLY D0 follow-up per tick. */
    private static function materialize_due_d0_followup(int $limit=1): array {
        $cfg=WFCA_Airtable::config();
        $max=max(0,(int)($cfg['COMMERCIAL_MAX_FOLLOWUPS_DAY']??0));
        if ($max<=0) return ['materialized'=>0,'skip_reason'=>'FOLLOWUP_DISABLED_BY_CONFIG'];
        $delay=(int)($cfg['COMMERCIAL_D0_FOLLOWUP_DELAY_MINUTES']??0);
        if ($delay<10 || $delay>10080) return ['materialized'=>0,'skip_reason'=>'FOLLOWUP_DELAY_INVALID'];
        $list=WFCA_Airtable::waiting_followup_candidates(100);
        if (empty($list['ok'])) return ['materialized'=>0,'skip_reason'=>'FOLLOWUP_WAITING_READ_FAIL'];
        $materialized=0;
        foreach (($list['data']['records']??[]) as $rec) {
            if ($materialized>=$limit) break;
            $cf=$rec['fields']??[];
            $lead_ids=(array)($cf['Lead']??[]);
            if (count($lead_ids)!==1) continue;
            $lead_id=(string)$lead_ids[0];
            $phone=WFCA_Util::normalize_phone((string)($cf['Phone E164']??''));
            if ($lead_id==='' || $phone==='') continue;
            $conv=WFCA_DB::get_conversation_by_phone($phone);
            if (!$conv || (string)($conv['lead_record_id']??'')!==$lead_id) continue;
            if (($conv['conversation_owner']??'')!=='LUNA' || !empty($conv['human_hold']) || !empty($conv['opt_out']) || !empty($conv['owner_sync_pending'])) continue;
            if (!empty($cf['Opt Out']) || ($cf['WhatsApp Permission Status']??'')==='OPT_OUT') continue;
            $payment=strtoupper((string)($cf['Payment State']??''));
            if (in_array($payment,['PAID','SETTLED','COMPLETED','TERMINAL'],true) || WFCA_DB::has_terminal_payment((int)$conv['id'])) continue;
            $last_inbound=!empty($conv['last_inbound_at'])?strtotime((string)$conv['last_inbound_at'].' UTC'):0;
            $remote_last_inbound=!empty($cf['Last Inbound At'])?strtotime((string)$cf['Last Inbound At']):0;
            $initial_key=hash('sha256','INITIAL|'.$lead_id.'|'.$phone);
            $initial=WFCA_DB::get_outbox_by_idempotency_key($initial_key);
            if (!$initial || (string)($initial['action_type']??'')!=='TEMPLATE_INITIAL' || (string)($initial['status']??'')!=='SENT' || empty($initial['provider_message_id']) || empty($initial['sent_at'])) continue;
            $initial_sent=strtotime((string)$initial['sent_at'].' UTC');
            if (!$initial_sent) continue;
            if (($last_inbound && $last_inbound>$initial_sent) || ($remote_last_inbound && $remote_last_inbound>$initial_sent)) continue;
            $next=self::next_followup_stage($lead_id,$phone,$cfg);
            if (!$next) continue;
            $due=(int)$next['due_ts'];
            $step=(string)$next['step'];
            $remote_due=strtotime((string)($cf['Next Commercial Action At']??''));
            if (!$remote_due || abs($remote_due-$due)>5) {
                $sync=WFCA_Airtable::update_commercial_by_phone($phone,[
                    'Next Commercial Action At'=>gmdate('c',$due),
                    'Conversation Summary'=>$step.' due reconciled from provider-confirmed ladder history; awaiting native due materialization.'
                ]);
                if (empty($sync['ok'])) continue;
                $remote_due=$due;
            }
            if (time()<$due) continue;
            $lead_r=WFCA_Airtable::get_lead($lead_id);
            if (empty($lead_r['ok']) || empty($lead_r['data']['fields'])) continue;
            $lead=$lead_r['data'];$lead['id']=$lead_id;
            if (!WFCA_Airtable::lead_is_commercial_ready($lead)) continue;
            if ($step==='D0_FOLLOWUP_1') {
                $insight=self::commercial_followup_insight($lead);
                if ($insight==='') {
                    $raw_insight=trim((string)(($lead['fields']??[])['Follow-up Insight']??''));
                    if ($raw_insight==='') self::materialize_safe_followup_insight($lead);
                    // Persist first, schedule only on a later tick after Airtable reread.
                    continue;
                }
            }
            $write=WFCA_Airtable::update_commercial_by_phone($phone,[
                'State'=>'FOLLOWUP_SCHEDULED','Next Commercial Action At'=>gmdate('c',$due),
                'Conversation Summary'=>$step.' is due and has been materialized by the native Commercial ladder runtime.'
            ]);
            if (empty($write['ok'])) continue;
            $local=WFCA_DB::upsert_conversation($phone,['state'=>'FOLLOWUP_SCHEDULED']);
            if (!$local) {
                WFCA_Airtable::update_commercial_by_phone($phone,['State'=>'WAITING_REPLY']);
                continue;
            }
            $materialized++;
        }
        return ['materialized'=>$materialized,'skip_reason'=>$materialized?'':'NO_DUE_SAFE_WAITING_FOLLOWUP'];
    }

    private static function clear_followup_schedule(string $phone,bool $waiting=false): void {
        $fields=['Next Commercial Action At'=>null];
        if ($waiting) $fields['State']='WAITING_REPLY';
        WFCA_Airtable::update_commercial_by_phone($phone,$fields);
        if ($waiting) WFCA_DB::upsert_conversation($phone,['state'=>'WAITING_REPLY']);
    }

    private static function commercial_text_is_technical(string $text): bool {
        if ($text==='') return false;
        return preg_match('/(?:CERTIFICATION_CANDIDATE_V1|CLOUDFLARE_SUPPLY_V1|LEAD_INTELLIGENCE_V4|CURRENT\s+feeder\s+proof|feeder\s+proof|LEAD_OPPORTUNITY_CLASS=|BUILDABLE_OPPORTUNITY_PREFILTER_V1|material_delta=|gap_codes=|run=WF-|verified=\d{4}-\d{2}-\d{2}|discovery=|FINAL\s+DEDUPE|economic\s+plausibility=|public\s+phone\s+\+?\d|current\s+hours|exact\s+Google\s+Business\s+listing)/iu',$text)===1;
    }

    private static function prospect_sentence_text(string $text,int $max=220,bool $strip_openers=false): string {
        $text=WFCA_Util::short_text($text,2000);
        if ($text==='') return '';
        if ($strip_openers) {
            for ($i=0;$i<3;$i++) {
                $next=preg_replace('/^(?:só\s+queria\s+deixar\s+um\s+ponto\s+mais\s+claro|outro\s+ponto\s+concreto|um\s+ponto\s+concreto|outro\s+ponto|só\s+um\s+ponto(?:\s+mais)?\s+concreto)\s*:\s*/iu','',$text,1);
                $next=trim((string)$next);
                if ($next===$text) break;
                $text=$next;
            }
        }
        if ($text==='' || self::commercial_text_is_technical($text)) return '';
        $len=function_exists('mb_strlen')?mb_strlen($text,'UTF-8'):strlen($text);
        if ($len<=$max) return rtrim($text," \t\n\r\0\x0B,;:-");
        $prefix=function_exists('mb_substr')?mb_substr($text,0,$max,'UTF-8'):substr($text,0,$max);
        if (preg_match_all('/[.!?](?=\s|$)/u',$prefix,$m,PREG_OFFSET_CAPTURE) && !empty($m[0])) {
            $last=end($m[0]);
            $byte_end=(int)$last[1]+strlen((string)$last[0]);
            $candidate=trim(substr($prefix,0,$byte_end));
            return $candidate;
        }
        // No complete sentence fits the provider-safe bound: fail closed instead
        // of exposing a dangling clause or invented continuation.
        return '';
    }

    /** Dedicated prospect-safe follow-up copy. Raw Observação Específica is never a fallback. */
    private static function commercial_followup_insight(array $lead): string {
        $f=$lead['fields']??[];
        $raw=trim((string)($f['Follow-up Insight']??''));
        if ($raw==='') return '';
        $raw=preg_replace('/https?:\/\/\S+/iu','',$raw);
        $candidate=self::prospect_sentence_text((string)$raw,220,true);
        if ($candidate==='' || self::commercial_text_is_technical($candidate)) return '';
        return $candidate;
    }

    /** Build a bounded insight only from safe persisted metadata; never from research telemetry. */
    private static function build_safe_followup_insight(array $lead): string {
        $f=$lead['fields']??[];
        $specialty=WFCA_Util::short_text(trim((string)($f['Especialidade / Posicionamento']??'')),90);
        $city=WFCA_Util::short_text(trim((string)($f['Cidade']??'')),60);
        if ($specialty==='') return '';
        $specialty=trim((string)preg_split('/[;|]/u',$specialty,2)[0]);
        if ($specialty==='' || self::commercial_text_is_technical($specialty) || preg_match('/https?:\/\//iu',$specialty)) return '';
        if ($city!=='' && (self::commercial_text_is_technical($city) || preg_match('/https?:\/\//iu',$city))) $city='';
        $copy=$city!==''
            ? 'A página pode reunir '.$specialty.' em '.$city.', apresentar os serviços com mais clareza e deixar o caminho até o agendamento mais direto.'
            : 'A página pode reunir '.$specialty.', apresentar os serviços com mais clareza e deixar o caminho até o agendamento mais direto.';
        return self::prospect_sentence_text($copy,220,false);
    }

    /** Persist first; scheduling may consume the dedicated field only on a later reread/tick. */
    private static function materialize_safe_followup_insight(array $lead): bool {
        $lead_id=(string)($lead['id']??'');
        $f=$lead['fields']??[];
        if ($lead_id==='' || trim((string)($f['Follow-up Insight']??''))!=='') return false;
        $copy=self::build_safe_followup_insight($lead);
        if ($copy==='') return false;
        $write=WFCA_Airtable::update_lead($lead_id,['Follow-up Insight'=>$copy]);
        return !empty($write['ok']);
    }

    private static function commercial_display_name(array $lead): string {
        $f=$lead['fields']??[];
        $raw=WFCA_Util::short_text(trim((string)($f['Lead']??'')),180);
        if ($raw==='') return '';
        if (!str_contains($raw,'—')) return $raw;
        // Factory Lead names use an em-dash suffix as internal taxonomy/context
        // (city, specialty, clinic/person qualifier). Prospect-facing salutations
        // must never expose that CRM suffix. Keep only the canonical left label.
        $parts=array_map('trim',explode('—',$raw,2));
        $clean=trim((string)($parts[0]??''));
        return $clean!==''?$clean:$raw;
    }

    private static function commercial_observation(array $lead): string {
        // WFCA_COMMERCIAL_OBSERVATION_SAFE_PIPE_V4_20261005
        $f=$lead['fields']??[];
        $raw=trim((string)($f['Observação Específica']??''));

        if ($raw==='') return '';

        // 1. Contrato explícito legado continua soberano.
        if (
            preg_match(
                '/(?:^|\\|\\s*)improvement_thesis=([^|]+)/iu',
                $raw,
                $m
            )
        ) {
            $candidate=trim((string)$m[1]);

            $candidate=preg_replace(
                '/https?:\\/\\/\\S+/iu',
                '',
                $candidate
            );

            $candidate=self::prospect_sentence_text(
                $candidate,
                220,
                false
            );

            if (
                $candidate==='' ||
                self::commercial_text_is_technical($candidate)
            ) return '';

            return $candidate;
        }

        // 2. Novo formato Factory:
        // TELEMETRIA | ... | frase comercial grounded.
        // Procura primeiro um tail seguro, SEM depender
        // da classificação técnica do campo inteiro.
        if (str_contains($raw,'|')) {

            $segments=array_reverse(
                array_map('trim',explode('|',$raw))
            );

            foreach ($segments as $segment) {

                if ($segment==='') continue;

                // Nunca transformar telemetria em copy.
                if (str_contains($segment,'=')) continue;

                if (
                    preg_match('/https?:\\/\\//iu',$segment) ||
                    preg_match('/[{}\\[\\]]/u',$segment) ||
                    preg_match('/\\b[a-f0-9]{32,}\\b/i',$segment)
                ) continue;

                if (
                    preg_match(
                        '/(?:SERVIÇOS?\\s+VERIFICADOS|VNEXT|BUILDABILITY|CERTIFIED|PRODUCTION_AUTHORITY|FACTORY|D0_|SHA(?:256)?|slot_contract|treatment_digest|card_sha|exact_core_compile|source_url_sha|asset_sha|receipt|release|run\\b|cards\\b|services\\b)/iu',
                        $segment
                    )
                ) continue;

                $candidate=self::prospect_sentence_text(
                    $segment,
                    220,
                    false
                );

                // Factory tails can be one long grounded sentence. If no full
                // sentence fits the provider-safe bound, allow a clause-boundary
                // clamp only inside this already-denylists-cleared tail branch.
                if ($candidate==='') {
                    $prefix=function_exists('mb_substr')?mb_substr($segment,0,219,'UTF-8'):substr($segment,0,219);
                    if (preg_match_all('/[,;](?=\s|$)/u',$prefix,$cm,PREG_OFFSET_CAPTURE) && !empty($cm[0])) {
                        $last=end($cm[0]);
                        $byte_end=(int)$last[1];
                        $clause=rtrim(trim(substr($prefix,0,$byte_end))," \t\n\r\0\x0B,;:-");
                        if ($clause!=='' && !self::commercial_text_is_technical($clause)) $candidate=$clause.'.';
                    }
                }

                if ($candidate==='') continue;

                $candidate_len=function_exists('mb_strlen')?mb_strlen($candidate,'UTF-8'):strlen($candidate);
                if ($candidate_len<24) continue;

                // Este ramo já passou por denylist estrutural.
                // Não reaplicar o classificador amplo,
                // que gera falso positivo para palavras
                // legítimas como "site" e "digital".
                return $candidate;
            }
        }

        // 3. Fallback legado para observações simples.
        if (self::commercial_text_is_technical($raw))
            return '';

        $candidate=preg_replace(
            '/https?:\\/\\/\\S+/iu',
            '',
            $raw
        );

        $candidate=self::prospect_sentence_text(
            $candidate,
            220,
            false
        );

        if (
            $candidate==='' ||
            self::commercial_text_is_technical($candidate)
        ) return '';

        return $candidate;
    }

    private static function initial_template_variables(array $spec,array $lead,string $canonical_url): array {
        $values=[];$f=$lead['fields']??[];
        foreach (($spec['variables']??[]) as $token) {
            if ($token==='lead_name') $value=self::commercial_display_name($lead);
            elseif ($token==='specific_observation') $value=WFCA_Util::customer_safe_observation(self::commercial_observation($lead),(string)($f['Observação Específica']??''));
            elseif ($token==='site_url') $value=$canonical_url;
            else return [];
            if ($value==='') return [];
            $values[]=$value;
        }
        $out=[];foreach ($values as $i=>$value) $out[(string)($i+1)]=$value;
        $header=$spec['header']??[];
        if (is_array($header) && ($header['type']??'')==='image') {
            $media=WFCA_Airtable::d0_preview_bytes_gate(WFCA_Airtable::d0_preview_contract($lead));
            if (empty($media['ok'])) return [];
            $out['_header_image_url']=(string)$media['url'];
            $out['_header_image_sha256']=(string)($media['sha256']??'');
            $out['_lead_record_id']=(string)($lead['id']??'');
        }
        return $out;
    }

    private static function followup_template_variables(array $spec,array $lead,string $canonical_url,string $step='D0_FOLLOWUP_1'): array {
        $values=[];$f=$lead['fields']??[];
        foreach (($spec['variables']??[]) as $token) {
            if ($token==='lead_name') $value=self::commercial_display_name($lead);
            elseif ($token==='followup_insight') $value=self::followup_stage_insight($lead,$step);
            elseif ($token==='site_url') $value=$canonical_url;
            else return [];
            if ($value==='') return [];
            $values[]=$value;
        }
        $out=[];foreach ($values as $i=>$value) $out[(string)($i+1)]=$value;
        return $out;
    }

    private static function initial_arm_decision(array $conversation_fields,array $lead_fields,bool $prior_history): array {
        $remote_raw=trim((string)($conversation_fields['Initial Arm']??''));
        $lead_raw=trim((string)($lead_fields['Assigned Arm']??''));
        $fallback=$remote_raw!==''?$remote_raw:$lead_raw;
        $remote_arm=WFCA_Ownership::arm($remote_raw);
        $lead_arm=WFCA_Ownership::arm($lead_raw);
        $untouched=!$prior_history
            && empty($conversation_fields['Last Inbound At'])
            && empty($conversation_fields['Last Outbound At']);
        $legacy_remote=in_array($remote_arm,['DANIEL_CALL','DANIEL_ASYNC'],true);
        if ($untouched && $legacy_remote && $lead_arm==='LUNA_COLD_WHATSAPP') {
            return ['raw_arm'=>$lead_raw,'reconcile_remote'=>true,'reason'=>'UNTOUCHED_LEGACY_ARM_TO_CURRENT_LUNA'];
        }
        return ['raw_arm'=>$fallback,'reconcile_remote'=>false,'reason'=>'PRESERVE_REMOTE_OR_CURRENT'];
    }

    /**
     * Pause new D0 when too many recent sends failed to deliver (numbers without WhatsApp hurt the sender's quality).
     * Only sends made after the last release count, so a pause can never lock itself.
     */
    private static function d0_delivery_brake_active(array $rules): bool {
        if (empty($rules['d0_delivery_brake_enabled'])) return false;
        $until=(int)get_option('wfca_d0_brake_until',0);
        if ($until>time()) return true;
        $since=(int)get_option('wfca_d0_brake_released_at',0);
        global $wpdb;
        $rows=$wpdb->get_results($wpdb->prepare("SELECT delivery_status FROM ".WFCA_DB::t('outbox')." WHERE action_type='TEMPLATE_INITIAL' AND status='SENT' AND sent_at>%s ORDER BY id DESC LIMIT 10",gmdate('Y-m-d H:i:s',$since)),ARRAY_A)?:[];
        $resolved=0;$failed=0;
        foreach ($rows as $r) {
            $st=strtolower((string)($r['delivery_status']??''));
            if (in_array($st,['delivered','read','failed'],true)) { $resolved++; if ($st==='failed') $failed++; }
        }
        if ($resolved<6) return false;
        if ($failed/$resolved<=(float)$rules['d0_delivery_brake_failure_ratio']) return false;
        update_option('wfca_d0_brake_until',time()+3600,false);
        update_option('wfca_d0_brake_released_at',time()+3600,false);
        WFCA_Alerts::raise('D0_DELIVERY_BRAKE:'.$failed.'/'.$resolved.'_FAILED','CRITICAL','',0,0,'','d0brake:'.gmdate('YmdH'));
        return true;
    }

    public static function schedule_initial_contacts(): void {
        if (WFCA_Airtable::draining()) return;
        $mode=WFCA_Airtable::base_mode();
        if (!in_array($mode,['ASSISTED','LIVE'],true)) return;
        $cfg=WFCA_Airtable::config();
        $policy=WFCA_Util::class_commercial_policy($cfg,'TEMPLATE_INITIAL');
        if (empty($policy['valid']) || empty($policy['proactive'])) return;
        $windows=(string)($policy['windows']??'');
        if ($windows==='' || !WFCA_Util::inside_window($windows)) return;

        $template_spec=WFCA_Kapso::template_spec('INITIAL');
        $sid=(string)($template_spec['name']??'');
        if ($sid==='' || empty($template_spec['variables'])) return;

        // Cadence is reservation-based, not wall-clock-slot based. This is stricter
        // than provider-accepted spacing because a queued/uncertain D0 also blocks
        // the next reservation, preventing bursts during provider/network latency.
        $interval=max(WFCA_Util::class_min_spacing_seconds('TEMPLATE_INITIAL'),(int)($policy['spacing_seconds']??600));
        $rules=WFCA_Util::rules();
        $latest=WFCA_DB::latest_initial_contact_at();
        if ($latest) {
            $latest_ts=strtotime($latest.' UTC');
            // Upward-only jitter keyed to the previous reservation: stable across ticks, never below the configured floor.
            $spacing_max=(int)($policy['spacing_max_seconds']??0);
            $jittered=$latest_ts?($spacing_max>$interval?WFCA_Util::spread_gap($interval,$spacing_max,(int)$latest_ts):WFCA_Util::jitter_up($interval,(int)$latest_ts,(float)$rules['d0_jitter_max'])):$interval;
            if ($latest_ts && time() < ($latest_ts+$jittered)) return;
        }
        if (self::d0_delivery_brake_active($rules)) return;

        $max=max(0,(int)($cfg['COMMERCIAL_MAX_NEW_CONTACTS_DAY']??15));
        if ($max===0) return;
        [, $tz_name]=WFCA_Util::parse_windows($windows);
        [$start_utc,$end_utc]=WFCA_Util::utc_bounds_for_local_day($tz_name);
        $used=WFCA_DB::count_initial_queued_in_range($start_utc,$end_utc);
        $remaining=max(0,$max-$used);
        if ($remaining===0) return;

        $list=WFCA_Airtable::eligible_conversations_for_initial(min(100,$remaining*3));
        if (!$list['ok']) return;

        foreach (($list['data']['records']??[]) as $rec) {
            if ($remaining<=0) break;
            $f=$rec['fields']??[];
            $perm=$f['WhatsApp Permission Status']??'UNKNOWN';
            if (!in_array($perm,['OPTED_IN','LIVE_HANDOFF'],true)) continue;
            if (!empty($f['Opt Out'])) continue;
            $lead_ids=$f['Lead']??[];
            if (count($lead_ids)!==1) continue;
            $lead_id=(string)$lead_ids[0];
            $lead_r=WFCA_Airtable::get_lead($lead_id);
            if (!$lead_r['ok']) continue;
            $lead=$lead_r['data']; $lead['id']=$lead_id;
            if (!WFCA_Airtable::lead_is_commercial_ready($lead)) continue;

            // WFCA_STRICT_G5_LAST_MILE_GATE_20261005
            // Final send gate must match CURRENT G5 consumer contract.
            // Never reserve a D0 merely because legacy commercial_ready passes.
            $lf=$lead['fields']??[];

            $readiness=trim(
                (string)($lf['Commercial Readiness Status']??'')
            );

            $d0_status=trim(
                (string)($lf['D0 Preview Status']??'')
            );

            $d0_url=trim(
                (string)($lf['D0 Preview Image URL']??'')
            );

            $d0_sha=strtolower(trim(
                (string)($lf['D0 Preview SHA256']??'')
            ));

            $d0_generated=trim(
                (string)($lf['D0 Preview Generated At']??'')
            );

            $site_url=trim(
                (string)($lf['Site URL']??'')
            );

            $assigned_arm=trim(
                (string)($lf['Assigned Arm']??'')
            );

            $expected_d0=
                preg_match('/^[a-f0-9]{64}$/',$d0_sha)
                ? 'https://auracorp.online/wf-d0-preview/'.
                  $lead_id.'/'.$d0_sha.'/raw'
                : '';

            $strict_g5_ready=
                $readiness==='PASS' &&
                $d0_status==='READY' &&
                $expected_d0!=='' &&
                hash_equals($expected_d0,$d0_url) &&
                $d0_generated!=='' &&
                $assigned_arm==='LUNA_COLD_WHATSAPP' &&
                preg_match(
                    '#^https://auracorp\\.online/[^?]+/?$#',
                    $site_url
                );

            if (!$strict_g5_ready) {
                WFCA_Airtable::update_commercial_by_phone(
                    (string)($f['Phone E164']??''),
                    [
                        'Commercial Error'=>
                            'STRICT_G5_LAST_MILE_CONTRACT_FAIL'
                    ]
                );

                continue;
            }
            $phone=WFCA_Util::normalize_phone((string)($f['Phone E164']??''));
            $lead_phone=WFCA_Airtable::canonical_factory_phone((string)($lead['fields']['Telefone']??''));
            if ($phone==='' || $lead_phone==='') continue;
            if (!hash_equals($lead_phone,$phone)) {
                WFCA_Airtable::update_commercial_by_phone($phone,[
                    'Commercial Error'=>'NONCANONICAL_FACTORY_LEAD_PHONE_SUPPRESSED',
                    'Conversation Summary'=>'Noncanonical commercial phone differs from the linked Factory lead canonical E164; outbound suppressed. Canonical materializer will use the lead phone policy.'
                ]);
                continue;
            }
            $phone=$lead_phone;
            $history=self::prior_initial_outreach_exists($lead_id,$phone);
            if ($history===null) {
                WFCA_Alerts::raise('INITIAL_HISTORY_UNAVAILABLE','WARN',$lead_id,0,0,'','lead:'.$lead_id.':initial-history');
                continue;
            }
            if ($history===true) {
                WFCA_Airtable::update_commercial_by_phone($phone,[
                    'State'=>'WAITING_REPLY','Conversation Summary'=>'Prior WhatsApp outbound detected; fresh D0 suppressed by lifetime idempotency fence.'
                ]);
                $existing_local=WFCA_DB::get_conversation_by_phone($phone);
                if ($existing_local && ($existing_local['conversation_owner']??'')==='LUNA') WFCA_DB::upsert_conversation($phone,['state'=>'WAITING_REPLY']);
                continue;
            }
            $arm_decision=self::initial_arm_decision($f,$lead['fields'],false);
            $raw_arm=(string)($arm_decision['raw_arm']??'');
            if (!empty($arm_decision['reconcile_remote'])) {
                // Untouched Factory conversations may carry a legacy CALL_FIRST/ASYNC_FIRST
                // residue from the retired routing era. If CURRENT Lead routing is LUNA and
                // there is provably no prior inbound/outbound/initial history, reconcile the
                // stale Initial Arm before reserving. History-bearing rows are immutable here.
                $remote_arm=WFCA_Ownership::remote_arm($raw_arm);
                if ($remote_arm==='') continue;
                $arm_write=WFCA_Airtable::update_commercial_by_phone($phone,[
                    'Initial Arm'=>$remote_arm,
                    'Commercial Error'=>'',
                    'Conversation Summary'=>'Untouched legacy Initial Arm reconciled to CURRENT Factory routing before first outbound.'
                ]);
                if (empty($arm_write['ok'])) continue;
                $f['Initial Arm']=$remote_arm;
            }
            if ($raw_arm==='') {
                // Fail-safe router for newly commercial-ready records that have not
                // yet been assigned by the Factory. Existing/touched arms are never
                // overwritten here.
                $raw_arm=WFCA_Ownership::route_for_lead($lead_id);
                $arm_write=WFCA_Airtable::update_lead($lead_id,['Assigned Arm'=>$raw_arm]);
                if (empty($arm_write['ok'])) continue;
                WFCA_Airtable::upsert_commercial_conversation($phone,$lead_id,['Initial Arm'=>$raw_arm]);
                $lead['fields']['Assigned Arm']=$raw_arm;
            }
            $initial=WFCA_Ownership::arm($raw_arm);
            if ($initial!=='LUNA_COLD_WHATSAPP') continue;
            if (empty($f['Initial Arm']) && $raw_arm!=='') $f['Initial Arm']=$raw_arm;

            $conv=WFCA_DB::upsert_conversation($phone,[
                'lead_record_id'=>$lead_id,'airtable_record_id'=>$rec['id'],'state'=>(string)($f['State']??'READY_FOR_CONTACT'),'permission_status'=>$perm,'initial_arm'=>$initial
            ]);
            if ($conv) {
                WFCA_DB::materialize_remote_snapshot((int)$conv['id'],$f);
                $conv=WFCA_DB::get_conversation((int)$conv['id'])?:$conv;
            }
            if (!$conv || ($conv['initial_arm']??'')!=='LUNA_COLD_WHATSAPP' || empty(WFCA_Ownership::fence((int)$conv['id'],'TEMPLATE_INITIAL')['ok'])) continue;
            $canonical=WFCA_Airtable::canonical_site_url($lead_id,$lead,true);
            if (empty($canonical['ok'])) {
                WFCA_Airtable::update_commercial_by_phone($phone,['Commercial Error'=>'CANONICAL_SITE_PREFLIGHT:'.(string)($canonical['error']??'UNKNOWN')]);
                WFCA_Alerts::raise('CANONICAL_SITE_PREFLIGHT','WARN',$lead_id,(int)$conv['id'],0,'','lead:'.$lead_id.':canonical-site');
                continue;
            }
            $lead['fields']['Site URL']=(string)$canonical['url'];
            $vars=self::initial_template_variables($template_spec,$lead,(string)$canonical['url']);
            if (!$vars) {
                $requires_media=is_array($template_spec['header']??null) && (($template_spec['header']['type']??'')==='image');
                WFCA_Airtable::update_commercial_by_phone($phone,[
                    'Commercial Error'=>$requires_media?'D0_MEDIA_OR_REQUIRED_VARIABLE_MISSING':'INITIAL_TEMPLATE_REQUIRED_VARIABLE_MISSING'
                ]);
                continue;
            }
            $reservation=WFCA_DB::queue_initial_idempotent([
                'idempotency_key'=>hash('sha256','INITIAL|'.$lead_id.'|'.$phone),
                'lead_record_id'=>$lead_id,'conversation_id'=>(int)$conv['id'],'action_type'=>'TEMPLATE_INITIAL',
                'content_sid'=>$sid,'content_variables'=>$vars,'state_after'=>'WAITING_REPLY','status'=>WFCA_Ownership::queue_status()
            ]);
            if (!empty($reservation['queued'])) {
                WFCA_Airtable::update_commercial_by_phone($phone,['State'=>'CONTACT_QUEUED','Commercial Error'=>'']);
                update_option('wfca_last_initial_reservation_at',WFCA_Util::now_iso(),false);
                $remaining--;
                // Exactly one fresh/safely-redriven D0 reservation per tick. The durable
                // reservation timestamp above becomes the cadence fence for subsequent ticks.
                break;
            }
            if (($reservation['disposition']??'')==='CONSUMED') {
                WFCA_Airtable::update_commercial_by_phone($phone,[
                    'State'=>'WAITING_REPLY','Commercial Error'=>'',
                    'Conversation Summary'=>'Initial WhatsApp outbox already consumed; duplicate D0 suppressed by lifetime idempotency fence.'
                ]);
                continue;
            }
            $reserve_error=(string)($reservation['error']??'INITIAL_OUTBOX_RESERVATION_FAILED');
            WFCA_Airtable::update_commercial_by_phone($phone,['Commercial Error'=>$reserve_error]);
            WFCA_Alerts::raise($reserve_error,'WARN',$lead_id,(int)$conv['id'],(int)($reservation['id']??0),'','lead:'.$lead_id.':initial-reservation');
        }
    }

    public static function schedule_paid_nurture(): void {
        if (WFCA_Airtable::draining() || WFCA_Airtable::base_mode()!=='LIVE') return;
        $sid=WFCA_Kapso::template('NURTURE');
        if ($sid==='') return;
        $list=WFCA_Airtable::eligible_paid_for_nurture(10);
        if (empty($list['ok'])) return;
        foreach (($list['data']['records']??[]) as $rec) {
            $f=$rec['fields']??[];
            if (!empty($f['Opt Out'])) continue;
            $perm=(string)($f['WhatsApp Permission Status']??'UNKNOWN');
            if (!in_array($perm,['OPTED_IN','LIVE_HANDOFF'],true)) continue;
            $lead_ids=$f['Lead']??[];
            if (count($lead_ids)!==1) continue;
            $lead_id=(string)$lead_ids[0];
            $phone=WFCA_Util::normalize_phone((string)($f['Phone E164']??''));
            if ($phone==='') continue;
            $lead_r=WFCA_Airtable::get_lead($lead_id);
            if (empty($lead_r['ok'])) continue;
            $lead=$lead_r['data']; $lead['id']=$lead_id;
            $conv=WFCA_DB::upsert_conversation($phone,[
                'lead_record_id'=>$lead_id,'airtable_record_id'=>$rec['id'],'state'=>'PAID','permission_status'=>$perm
            ]);
            if (!$conv || (int)($conv['opt_out']??0)===1 || empty(WFCA_Ownership::fence((int)$conv['id'],'TEMPLATE_NURTURE')['ok'])) continue;
            $vars=['1'=>(string)($lead['fields']['Lead']??'')];
            $bucket=(new DateTimeImmutable('now',new DateTimeZone('America/Sao_Paulo')))->format('Y-m');
            $oid=WFCA_DB::queue([
                'idempotency_key'=>hash('sha256','NURTURE|'.$lead_id.'|'.$bucket),
                'lead_record_id'=>$lead_id,'conversation_id'=>(int)$conv['id'],'action_type'=>'TEMPLATE_NURTURE',
                'content_sid'=>$sid,'content_variables'=>$vars,'state_after'=>'PAID','status'=>'PENDING'
            ]);
            if ($oid>0) {
                WFCA_Airtable::update_commercial_by_phone($phone,[
                    'Next Commercial Action At'=>gmdate('c',time()+90*DAY_IN_SECONDS),
                    'Conversation Summary'=>'Paid-client nurture queued from approved template; opt-out/permission gates remain authoritative.'
                ]);
            }
        }
    }

    private static function offer(string $code): ?array {
        $cfg=WFCA_Airtable::config();
        $raw=(string)($cfg['COMMERCIAL_OFFER_CATALOG']??'');
        $offers=[];
        foreach (explode(';',$raw) as $part) {
            $p=explode('|',$part,3);
            if (count($p)!==3) continue;
            $key=strtoupper(str_replace(' ','_',trim($p[0])));
            $offers[$key]=['code'=>$key,'name'=>trim($p[0]),'amount'=>(int)$p[1],'terms'=>trim($p[2])];
        }
        $fallbacks=[
            'LANDING_PAGE_PREMIUM'=>['code'=>'LANDING_PAGE_PREMIUM','name'=>'Landing Page Premium','amount'=>70000,'terms'=>'R$700'],
            'SITE_PROFISSIONAL'=>['code'=>'SITE_PROFISSIONAL','name'=>'Site Profissional','amount'=>90000,'terms'=>'R$900'],
            'SITE_AUTORIDADE'=>['code'=>'SITE_AUTORIDADE','name'=>'Site Autoridade','amount'=>150000,'terms'=>'R$1.500'],
        ];
        $entry=$offers['LANDING_PAGE_PREMIUM']??$fallbacks['LANDING_PAGE_PREMIUM'];
        if ($code==='ENTRY' || $code==='LANDING_PAGE_PREMIUM') return $entry;
        if ($code==='ENTRY_STRATEGY') {
            $strategy=WFCA_Commercial_Context::strategy_price_cents($cfg);
            return [
                'code'=>'ENTRY_STRATEGY',
                'name'=>'Landing Page Premium + Strategy Express',
                'amount'=>(int)$entry['amount']+$strategy,
                'terms'=>'Entry site + Strategy Express'
            ];
        }
        $key=strtoupper($code);
        if (str_ends_with($key,'_STRATEGY') && $key!=='ENTRY_STRATEGY') {
            $base=$offers[substr($key,0,-9)]??($fallbacks[substr($key,0,-9)]??null);
            if (!$base) return null;
            return ['code'=>$key,'name'=>$base['name'].' + Strategy Express','amount'=>(int)$base['amount']+WFCA_Commercial_Context::strategy_price_cents($cfg),'terms'=>$base['name'].' + Strategy Express'];
        }
        return $offers[$key]??($fallbacks[$key]??null);
    }

    public static function verify_pending_orders(int $limit=3): void {
        foreach(WFCA_DB::due_order_ids($limit) as $id) self::verify_order($id);
    }

    public static function reconcile_paid_orders(int $limit=3): void {
        foreach (WFCA_DB::paid_unsynced_order_ids($limit) as $id) {
            $o=WFCA_DB::get_order($id);
            if (!$o) continue;
            self::sync_paid_order_to_airtable($o,true);
        }
    }

    public static function verify_order(int $order_id): void {
        if (!WFCA_Ownership::lock('order:'.$order_id)) return;
        try { self::verify_order_locked($order_id); } finally { WFCA_Ownership::unlock('order:'.$order_id); }
    }

    private static function verify_order_locked(int $order_id): void {
        $o=WFCA_DB::get_order($order_id);
        if (!$o || ($o['state']??'')==='PAID') return;
        if (empty($o['pending_transaction_nsu']) || empty($o['pending_invoice_slug'])) return;

        $candidate_tx=(string)$o['pending_transaction_nsu'];
        $candidate_slug=(string)$o['pending_invoice_slug'];
        $check=WFCA_InfinitePay::payment_check((string)$o['order_nsu'],$candidate_tx,$candidate_slug);
        if (!$check['ok']) {
            $terminal=WFCA_DB::retry_order_verification($o,$check['error']??'CHECK_FAIL',8);
            if ($terminal) self::payment_handoff($o,'PAYMENT_VERIFY_EXHAUSTED:'.($check['error']??'CHECK_FAIL'));
            return;
        }
        $d=$check['data']??[];
        $paid=!empty($d['paid']);
        $amount=(int)($d['amount']??0);
        if (!$paid) {
            $terminal=WFCA_DB::retry_order_verification($o,'PAYMENT_NOT_PAID_YET',8);
            if ($terminal) self::payment_handoff($o,'PAYMENT_NOT_CONFIRMED_AFTER_RETRIES');
            return;
        }
        if ($amount!==(int)$o['expected_amount_cents']) {
            WFCA_DB::update_order($order_id,['state'=>'VERIFY_FAILED','error'=>'AMOUNT_MISMATCH','next_verify_at'=>null]);
            self::payment_handoff($o,'PAYMENT_AMOUNT_MISMATCH','CRITICAL');
            return;
        }

        $paid_amount=(int)($d['paid_amount']??$amount);
        WFCA_DB::update_order($order_id,[
            'state'=>'PAID','transaction_nsu'=>$candidate_tx,'invoice_slug'=>$candidate_slug,
            'paid_amount_cents'=>$paid_amount,'verify_attempts'=>(int)($o['verify_attempts']??0),
            'next_verify_at'=>null,'verified_at'=>WFCA_Util::now_mysql(),'paid_at'=>WFCA_Util::now_mysql(),'airtable_synced_at'=>null,'error'=>null
        ]);
        $o=WFCA_DB::get_order($order_id) ?: $o;
        if (($o['state']??'')!=='PAID' || ($o['transaction_nsu']??'')!==$candidate_tx || ($o['invoice_slug']??'')!==$candidate_slug) { self::payment_handoff($o,'PAID_COMMIT_FAILED','CRITICAL');return; }
        $conv=WFCA_DB::get_conversation((int)$o['conversation_id']);
        if ($conv) WFCA_DB::upsert_conversation((string)$conv['phone_e164'],['state'=>'PAID']);

        self::sync_paid_order_to_airtable($o,false);
        WFCA_Airtable::log_touch((string)$o['lead_record_id'],'INBOUND','PAYMENT_VERIFIED','InfinitePay payment verified',(string)$o['transaction_nsu']);

        if ($conv && (int)$conv['opt_out']===0 && !empty($conv['service_window_until']) && strtotime((string)$conv['service_window_until'])>time()) {
            $mode=WFCA_Airtable::mode();
            $status=WFCA_Ownership::queue_status();
            self::queue_message($conv,(string)$o['lead_record_id'],'PAYMENT_CONFIRMATION','Pagamento confirmado ✅ Obrigado. Vou seguir com a próxima etapa da entrega por aqui.','PAID',$status,'NONE','PAYMENT-'.(string)$o['transaction_nsu']);
        }
    }

    private static function sync_paid_order_to_airtable(array $o,bool $is_reconcile): bool {
        $conv=WFCA_DB::get_conversation((int)$o['conversation_id']);
        $paid_ts=!empty($o['paid_at'])?strtotime((string)$o['paid_at'].' UTC'):false;
        $paid_iso=$paid_ts?gmdate('c',$paid_ts):WFCA_Util::now_iso();
        $conv_ok=false;
        if ($conv) {
            $sync=WFCA_Airtable::update_commercial_by_phone((string)$conv['phone_e164'],[
                'State'=>'PAID','Payment State'=>'PAID','Payment Order NSU'=>(string)$o['order_nsu'],
                'Payment Transaction NSU'=>(string)$o['transaction_nsu'],'Paid At'=>$paid_iso,
                'Next Commercial Action At'=>gmdate('c',time()+30*DAY_IN_SECONDS),
                'Conversation Summary'=>'Paid client. Preserve relationship; future cross-sell only from real need/permission.',
                'Commercial Error'=>''
            ]);
            $conv_ok=!empty($sync['ok']);
        }
        $lead_sync=WFCA_Airtable::update_lead((string)$o['lead_record_id'],[
            'Paid'=>true,'Amount Received'=>((int)($o['paid_amount_cents']??0))/100
        ]);
        $lead_ok=!empty($lead_sync['ok']);

        if ($conv_ok && $lead_ok) {
            WFCA_DB::update_order((int)$o['id'],['airtable_synced_at'=>WFCA_Util::now_mysql(),'error'=>null]);
            WFCA_Alerts::resolve_source('order:'.(int)$o['id'].':paid-conv-sync');
            WFCA_Alerts::resolve_source('order:'.(int)$o['id'].':paid-lead-sync');
            return true;
        }

        $prefix=$is_reconcile?'PAID_RECONCILE':'PAID_INITIAL';
        if (!$conv_ok) WFCA_Alerts::raise($prefix.'_AIRTABLE_CONVERSATION_SYNC_FAIL','CRITICAL',(string)$o['lead_record_id'],(int)($conv['id']??0),0,'','order:'.(int)$o['id'].':paid-conv-sync');
        if (!$lead_ok) WFCA_Alerts::raise($prefix.'_AIRTABLE_LEAD_SYNC_FAIL','CRITICAL',(string)$o['lead_record_id'],(int)($conv['id']??0),0,'','order:'.(int)$o['id'].':paid-lead-sync');
        return false;
    }

    private static function payment_handoff(array $order,string $reason,string $severity='WARN'): void {
        $conv=WFCA_DB::get_conversation((int)$order['conversation_id']);
        WFCA_Alerts::raise($reason,$severity,(string)$order['lead_record_id'],(int)($conv['id']??0),0,'','order:'.(int)$order['id'].':'.$reason);
        if ($conv) {
            WFCA_DB::upsert_conversation((string)$conv['phone_e164'],['state'=>'HUMAN_HANDOFF','human_hold'=>1,'summary'=>$reason]);
            WFCA_Airtable::update_commercial_by_phone((string)$conv['phone_e164'],[
                'State'=>'HUMAN_HANDOFF','Human Handoff Reason'=>$reason,'Commercial Error'=>$reason
            ]);
        }
    }
}
