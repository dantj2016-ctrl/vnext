<?php
if (!defined('ABSPATH')) exit;

final class WFCA_Alerts {
    public static function raise(string $reason,string $severity='WARN',string $lead_id='',int $conversation_id=0,int $event_id=0,string $prospect_message='',string $source_key=''): int {
        $source_key=$source_key!==''?$source_key:implode('|',[$event_id,$conversation_id,$lead_id,$reason]);
        $id=WFCA_DB::create_alert(['alert_key'=>hash('sha256','WFCA_ALERT|'.$source_key),
            'lead_record_id'=>$lead_id,'conversation_id'=>$conversation_id,'event_id'=>$event_id,
            'severity'=>in_array($severity,['INFO','WARN','CRITICAL'],true)?$severity:'WARN',
            'reason'=>WFCA_Util::redact_error($reason,191),'prospect_message'=>WFCA_Util::short_text($prospect_message,2000),
            'email_status'=>WFCA_Util::owner_email()!==''?'PENDING':'NOT_CONFIGURED',
            'whatsapp_status'=>WFCA_Kapso::template('OWNER_ALERT')!=='' && WFCA_Util::owner_whatsapp()!==''?'PENDING':'NOT_CONFIGURED']);
        if ($id>0 && !wp_next_scheduled('wfca_deliver_alert',[$id])) wp_schedule_single_event(time()+1,'wfca_deliver_alert',[$id]);
        return $id;
    }
    public static function deliver_one(int $id): void { self::enqueue($id); }
    public static function process_queue(int $limit=4): void {
        foreach (WFCA_DB::due_alerts($limit) as $r) self::enqueue((int)$r['id']);
    }
    private static function enqueue(int $id): void {
        $a=WFCA_DB::get_alert($id);if (!$a || $a['status']!=='OPEN') return;
        $c=WFCA_DB::get_conversation((int)$a['conversation_id']);
        // Unidentified-source alerts stay durable in the protected admin panel.
        if (!$c) { WFCA_DB::update_alert($id,['last_error'=>'NO_SOURCE_CONVERSATION_LOCAL_ALERT_ONLY','attempts'=>4]);return; }
        $body='Lead: '.$a['lead_record_id'].' | Reason: '.$a['reason'].' | Message: '.WFCA_Util::short_text($a['prospect_message'],1000);
        foreach (['EMAIL','WHATSAPP'] as $channel) {
            $field=strtolower($channel).'_status';
            if (!in_array($a[$field]??'',['PENDING','FAILED'],true)) continue;
            $to=$channel==='EMAIL'?WFCA_Util::owner_email():WFCA_Util::owner_whatsapp();
            if ($to==='') continue;
            $oid=WFCA_DB::queue(['idempotency_key'=>hash('sha256','ALERT|'.$id.'|'.$channel),
                'conversation_id'=>(int)$c['id'],'lead_record_id'=>$a['lead_record_id'],'alert_id'=>$id,
                'action_type'=>'ALERT_'.$channel,'destination'=>$to,'body'=>$body,
                'content_sid'=>$channel==='WHATSAPP'?WFCA_Kapso::template('OWNER_ALERT'):'',
                'content_variables'=>['1'=>$a['lead_record_id']?:'Lead não identificado','2'=>$a['reason'],'3'=>WFCA_Util::short_text($a['prospect_message'],220)]]);
            if ($oid) WFCA_DB::update_alert($id,[$field=>'QUEUED']);
        }
    }
    public static function sync_outbox(array $row): void {
        $field=$row['action_type']==='ALERT_EMAIL'?'email_status':'whatsapp_status';
        WFCA_DB::update_alert((int)$row['alert_id'],[$field=>$row['status'],'last_error'=>$row['last_error']??null]);
    }
    public static function resolve(int $id): void { WFCA_DB::update_alert($id,['status'=>'RESOLVED','next_attempt_at'=>null]); }
    public static function acknowledge(int $id): void { WFCA_DB::update_alert($id,['status'=>'ACKED','next_attempt_at'=>null]); }
    public static function resolve_source(string $key): void { WFCA_DB::resolve_alert_by_key(hash('sha256','WFCA_ALERT|'.$key)); }
}
