<?php
if (!defined('ABSPATH')) exit;

final class WFCA_REST {
    public static function register(): void {
        register_rest_route(WFCA_NS,'/commercial/health',[
            'methods'=>'GET','callback'=>[__CLASS__,'health'],'permission_callback'=>'__return_true'
        ]);
        register_rest_route(WFCA_NS,'/commercial/kapso-webhook',[
            'methods'=>'POST','callback'=>[__CLASS__,'kapso_webhook'],'permission_callback'=>'__return_true'
        ]);
        register_rest_route(WFCA_NS,'/commercial/owner',[
            'methods'=>'POST','callback'=>[__CLASS__,'owner'],'permission_callback'=>[__CLASS__,'owner_permission']
        ]);
        register_rest_route(WFCA_NS,'/commercial/infinitepay-webhook',[
            'methods'=>'POST','callback'=>[__CLASS__,'infinitepay_webhook'],'permission_callback'=>'__return_true'
        ]);
        register_rest_route(WFCA_NS,'/commercial/run',[
            'methods'=>'POST','callback'=>[__CLASS__,'run'],'permission_callback'=>[__CLASS__,'run_permission']
        ]);

    }

    private static function capabilities(): array {
        return [
            'transactional_outbox'=>true,
            'lifetime_d0_idempotency_v2'=>true,
            'canonical_e164_identity'=>true,
            'owner_revision_fence'=>true,
            'conversation_mutex'=>true,
            'proactive_send_mutex'=>true,
            'tick_single_flight_v1'=>true,
            'outbox_drain_before_producers_v1'=>true,
            'strict_spacing_reservation_and_presend'=>true,
            'ambiguous_send_uncertain_no_retry'=>true,
            'graceful_drain_mode'=>true,
            'd0_dynamic_image_header'=>true,
            'followup_template_capability'=>true,
            'native_followup_materializer_v1'=>true,
            'followup_ladder_d3_d7_v2'=>true,
            'followup_template_reuse_stage_insight_v1'=>true,
            'followup_safe_insight_materializer_v2'=>true,
            'followup_raw_observation_fallback'=>false,
            'commercial_observation_sanitizer_v1'=>true,
            'delivery_truth_v1'=>true,
            'followup_freeform_autonomy'=>false,
            'kapso_hmac_webhook'=>true,
            'infinitepay_verified_payment_truth'=>true,
            'config_driven_routing'=>true,
            'dual_class_proactive_pacing_v1'=>true,
            'd0_240s_class_floor_v1'=>true,
            'luna_sales_brain_v2'=>true,
        ];
    }

    private static function build_manifest_sha256(): string {
        $path=WFCA_DIR.'BUILD-MANIFEST.json';
        return is_readable($path)?(string)hash_file('sha256',$path):'';
    }

    public static function health(WP_REST_Request $request): WP_REST_Response {
        $schema=(string)get_option('wfca_schema_version');
        $cached_target=trim((string)get_option('wfca_target_version_observed',''));
        $base=[
            'ok'=>true,
            'plugin'=>'Website Factory — Commercial Agent',
            'observed_version'=>WFCA_VERSION,
            'target_version'=>$cached_target!==''?$cached_target:null,
            'target_match'=>$cached_target!==''?hash_equals(WFCA_VERSION,$cached_target):null,
            'schema'=>$schema,
            'build_manifest_sha256'=>self::build_manifest_sha256(),
            'capabilities'=>self::capabilities(),
            'local_mode'=>WFCA_Util::local_mode(),
        ];
        if (!self::health_details_allowed($request)) {
            $base['details']='protected';
            return new WP_REST_Response($base,200);
        }

        $cfg=WFCA_Airtable::config(true);
        $mode_state=WFCA_Airtable::mode_state(true);
        $mode=(string)$mode_state['mode'];
        $base_mode=(string)$mode_state['base_mode'];
        $draining=(bool)$mode_state['draining'];
        $target=trim((string)($cfg['COMMERCIAL_AGENT_TARGET_VERSION']??''));
        if ($target!=='') update_option('wfca_target_version_observed',$target,false);
        $base['target_version']=$target!==''?$target:null;
        $base['target_match']=$target!==''?hash_equals(WFCA_VERSION,$target):false;
        $probe=WFCA_Airtable::probe(true);
        $initial_spec=WFCA_Kapso::template_spec('INITIAL');
        $followup_spec=WFCA_Kapso::template_spec('FOLLOWUP');
        $routing=WFCA_Ownership::routing_split();
        $policy=WFCA_Util::weekly_commercial_policy($cfg);
        $d0_policy=WFCA_Util::class_commercial_policy($cfg,'TEMPLATE_INITIAL');
        $followup_policy=WFCA_Util::class_commercial_policy($cfg,'FOLLOWUP');
        $spacing=(int)($policy['spacing_seconds']??600);
        $global_spacing=WFCA_Util::global_proactive_min_seconds($cfg);
        $followups=(int)($cfg['COMMERCIAL_MAX_FOLLOWUPS_DAY']??0);
        $followup_delay=(int)($cfg['COMMERCIAL_D0_FOLLOWUP_DELAY_MINUTES']??0);
        $followup_enabled=$followups>0;
        $followup_contract_ok=!$followup_enabled || (!empty($followup_spec['name']) && !empty($followup_spec['variables']) && $followup_delay>=10 && $followup_delay<=10080);
        $ladder_raw=trim((string)($cfg['COMMERCIAL_FOLLOWUP_LADDER_POLICY_V2']??($cfg['COMMERCIAL_FOLLOWUP_LADDER_V1']??'')));
        $ladder_json=$ladder_raw!==''?json_decode($ladder_raw,true):null;
        $ladder_valid=$ladder_raw==='' || (is_array($ladder_json) && (string)($ladder_json['version']??'')==='COMMERCIAL_FOLLOWUP_LADDER_POLICY_V2');
        $windows=trim((string)($policy['windows']??''));
        $proactive=!empty($policy['proactive']);
        $valid_mode=in_array($base_mode,['OFF','SHADOW','ASSISTED','LIVE'],true);
        $policy_valid=!empty($policy['valid']) && (!$proactive || ($spacing>=300 && $windows!==''));
        $config_contract=[
            'mode_valid'=>$valid_mode,
            'weekly_policy_version'=>(string)($policy['version']??''),
            'weekly_policy_source'=>(string)($policy['source']??''),
            'weekly_policy_day'=>(string)($policy['day_key']??''),
            'proactive_today'=>$proactive,
            'strict_spacing_seconds'=>$spacing,
            'strict_spacing_valid'=>$policy_valid,
            'global_proactive_min_seconds'=>$global_spacing,
            'd0_class_policy_source'=>(string)($d0_policy['source']??''),
            'd0_class_windows'=>(string)($d0_policy['windows']??''),
            'd0_class_spacing_seconds'=>(int)($d0_policy['spacing_seconds']??0),
            'followup_class_policy_source'=>(string)($followup_policy['source']??''),
            'followup_class_windows'=>(string)($followup_policy['windows']??''),
            'followup_class_spacing_seconds'=>(int)($followup_policy['spacing_seconds']??0),
            'dual_class_policy_valid'=>!empty($d0_policy['valid']) && !empty($followup_policy['valid']) && $global_spacing>=120 && $global_spacing<=3600,
            'weekly_aggregate_policy_v1'=>true,
            'followups_per_day'=>$followups,
            'followup_enabled'=>$followup_enabled,
            'followup_template_name'=>$followup_spec['name']??'',
            'followup_template_source'=>$followup_spec['source']??'',
            'd0_followup_delay_minutes'=>$followup_delay,
            'followup_contract_valid'=>$followup_contract_ok,
            'followup_ladder_policy_present'=>$ladder_raw!=='',
            'followup_ladder_policy_valid'=>$ladder_valid,
            'followup_ladder_enabled'=>is_array($ladder_json) && !empty($ladder_json['enabled']),
            'commercial_windows'=>$windows,
            'commercial_windows_present'=>$windows!=='',
        ];
        $d0_spacing=(int)($d0_policy['spacing_seconds']??0);
        $followup_spacing=(int)($followup_policy['spacing_seconds']??0);
        $dual_class_ok=!empty($d0_policy['valid']) && !empty($followup_policy['valid']) && $d0_spacing>=WFCA_Util::class_min_spacing_seconds('TEMPLATE_INITIAL') && $followup_spacing>=WFCA_Util::class_min_spacing_seconds('FOLLOWUP') && $global_spacing>=120 && $global_spacing<=3600;
        $config_contract['dual_class_policy_valid']=$dual_class_ok;
        $config_ok=$valid_mode && $policy_valid && $followup_contract_ok && $ladder_valid && $dual_class_ok;
        $airtable_ok=(bool)($probe['ok']??false);
        $schema_ok=hash_equals(WFCA_SCHEMA_VERSION,$schema);
        $provider_required=$base_mode==='LIVE' && !$draining;
        $provider_ok=!$provider_required || (WFCA_Kapso::ready() && !empty($initial_spec['name']));
        $readiness=$schema_ok && $airtable_ok && $config_ok && $provider_ok;

        $base=array_merge($base,[
            'liveness'=>$schema_ok,
            'readiness'=>$readiness,
            'effective_mode'=>$mode,
            'base_mode'=>$base_mode,
            'draining'=>$draining,
            'maintenance'=>WFCA_DB::maintenance_state(),
            'config_contract'=>$config_contract,
            'airtable_configured'=>WFCA_Airtable::available(),
            'airtable_reachable'=>$airtable_ok,
            'airtable_transport'=>WFCA_Airtable::last_transport(),
            'kapso'=>WFCA_Kapso::ready(),
            'kapso_signature_check'=>WFCA_Kapso::last_signature_check(),
            'kapso_last_send'=>WFCA_Kapso::last_send(),
            'delivery_fail_counters'=>WFCA_Util::delivery_fail_counters(),
            'openai'=>WFCA_OpenAI::ready(),
            'openai_model'=>WFCA_OpenAI::model(),
            'openai_telemetry'=>WFCA_OpenAI::telemetry(),
            'openai_usage'=>WFCA_OpenAI::usage(),
            'commercial_context_version'=>WFCA_Commercial_Context::VERSION,
            'luna_sales_brain'=>WFCA_Luna_Brain_V2::health(),
            'luna_sales_brain_last_telemetry'=>WFCA_Luna_Brain_V2::last_telemetry(),
            'strategy_express_price'=>WFCA_Commercial_Context::strategy_price_label($cfg),
            'infinitepay'=>WFCA_InfinitePay::ready(),
            'infinitepay_transport'=>WFCA_InfinitePay::last_transport(),
            'initial_template'=>!empty($initial_spec['name']),
            'initial_template_name'=>$initial_spec['name']??'',
            'initial_template_source'=>$initial_spec['source']??'',
            'initial_template_header_type'=>$initial_spec['header']['type']??'',
            'followup_template'=>!empty($followup_spec['name']),
            'followup_template_name'=>$followup_spec['name']??'',
            'followup_template_source'=>$followup_spec['source']??'',
            'routing_split'=>$routing,
            'owner_email_configured'=>WFCA_Util::owner_email()!=='',
            'owner_whatsapp_alert_configured'=>WFCA_Util::owner_whatsapp()!=='' && WFCA_Kapso::template('OWNER_ALERT')!=='',
            'stats'=>WFCA_DB::stats(),
            'backlog'=>WFCA_DB::backlog(),
            'last_tick_at'=>get_option('wfca_last_tick_at'),
            'tick_due_at'=>get_option('wfca_tick_due_at'),
            'tick_entered_at'=>get_option('wfca_tick_entered_at'),
            'tick_exited_at'=>get_option('wfca_tick_exited_at'),
            'tick_duration_ms'=>get_option('wfca_tick_duration_ms'),
            'tick_result'=>get_option('wfca_tick_result'),
            'tick_skip_reason'=>get_option('wfca_tick_skip_reason'),
            'tick_run_id'=>get_option('wfca_tick_run_id'),
            'tick_stage'=>get_option('wfca_tick_stage'),
            'tick_exception'=>get_option('wfca_tick_exception'),
            'tick_overlap_skipped_at'=>get_option('wfca_tick_overlap_skipped_at'),
            'tick_overlap_skip_count'=>(int)get_option('wfca_tick_overlap_skip_count',0),
            'next_tick'=>wp_next_scheduled('wfca_minute_tick')?:null,
            'commercial_windows'=>$windows!==''?$windows:null,
            'autonomous_outbound_active'=>$base_mode==='LIVE' && !$draining && $readiness && $proactive && $windows!=='' && WFCA_Util::inside_window($windows),
        ]);
        return new WP_REST_Response($base,200);
    }

    private static function health_details_allowed(WP_REST_Request $request): bool {
        if (current_user_can('manage_options')) return true;
        $secret=(string)WFCA_Util::c('WFCA_HEALTH_SECRET','');
        if ($secret==='') return false;
        $given=(string)$request->get_header('x-wfca-health-secret');
        return $given!=='' && hash_equals($secret,$given);
    }

    public static function kapso_webhook(WP_REST_Request $request): WP_REST_Response {
        if (!WFCA_Kapso::validate_request($request)) return new WP_REST_Response(['error'=>'invalid_signature_or_size'],403);
        if ((string)$request->get_header('x-webhook-payload-version')!=='v2') return new WP_REST_Response(['error'=>'v2_required'],400);
        $p=json_decode($request->get_body(),true);
        if (!is_array($p)) return new WP_REST_Response(['error'=>'invalid_json'],400);
        $event=(string)$request->get_header('x-webhook-event');
        $items=!empty($p['batch'])?($p['data']??[]):[$p];
        if (!is_array($items) || !$items || count($items)>100) return new WP_REST_Response(['error'=>'invalid_batch'],400);
        $normalized=[];
        foreach ($items as $item) {
            if (!is_array($item)) return new WP_REST_Response(['error'=>'invalid_item'],400);
            $n=WFCA_Kapso::normalize($item,$event);
            if (empty($n['ok'])) return new WP_REST_Response(['error'=>$n['error']],400);
            $normalized[]=$n['data'];
        }
        foreach ($normalized as $data) {
            $r=WFCA_DB::insert_event($data);
            if (!empty($r['error']) || empty($r['id'])) return new WP_REST_Response(['error'=>'event_persistence_failed'],500);
            // Apply the local manual fence before ACK, including retry after partial persistence.
            if ($data['event_type']==='MANUAL_OUTBOUND' && !WFCA_Engine::manual_receipt($data)) return new WP_REST_Response(['error'=>'owner_persistence_failed'],500);
            if ($data['status']==='RECEIVED') wp_schedule_single_event(time()+1,'wfca_process_inbound',[(int)$r['id']]);
        }
        return new WP_REST_Response(['ok'=>true],200);
    }

    public static function owner_permission(): bool { return current_user_can('manage_options'); }
    public static function owner(WP_REST_Request $request): WP_REST_Response {
        $r=WFCA_Ownership::change((int)$request->get_param('conversation_id'),
            strtoupper((string)$request->get_param('owner')),'EXPLICIT_ADMIN_CHANGE',
            (int)$request->get_param('expected_revision'),true);
        if (!empty($r['ok'])) $r['airtable_synced']=WFCA_Ownership::sync((int)$request->get_param('conversation_id'));
        return new WP_REST_Response($r,!empty($r['ok'])?200:409);
    }

    public static function infinitepay_webhook(WP_REST_Request $request): WP_REST_Response {
        // InfinitePay webhook is an untrusted notification hint. It can trigger a
        // server-to-server payment_check, but it can never establish payment truth.
        $content_length=(int)($_SERVER['CONTENT_LENGTH']??0);
        if ($content_length>65536) return new WP_REST_Response(['success'=>false,'message'=>'payload_too_large'],413);

        $data=$request->get_json_params();
        if (!is_array($data)) return new WP_REST_Response(['success'=>false,'message'=>'invalid_json'],400);
        $order_nsu=WFCA_Util::short_text((string)($data['order_nsu']??''),191);
        $tx=WFCA_Util::short_text((string)($data['transaction_nsu']??''),191);
        $slug=WFCA_Util::short_text((string)($data['invoice_slug']??''),191);
        if ($order_nsu==='' || $tx==='' || $slug==='') return new WP_REST_Response(['success'=>false,'message'=>'missing_identifiers'],400);
        $o=WFCA_DB::get_order_by_nsu($order_nsu);
        if (!$o) return new WP_REST_Response(['success'=>false,'message'=>'order_not_found'],400);

        // A transaction already VERIFIED on another order is a hard conflict.
        // Unverified webhook candidates are deliberately not trusted/locked.
        $tx_order=WFCA_DB::get_order_by_transaction($tx);
        if ($tx_order && (int)$tx_order['id']!==(int)$o['id']) {
            WFCA_Alerts::raise('PAYMENT_TRANSACTION_REUSE_CONFLICT','CRITICAL',(string)$o['lead_record_id'],(int)$o['conversation_id'],0,'','payment-conflict:'.hash('sha256',$tx));
            return new WP_REST_Response(['success'=>false,'message'=>'transaction_conflict'],400);
        }
        if (($o['state']??'')==='PAID') {
            if ((string)$o['transaction_nsu']!==$tx || (string)$o['invoice_slug']!==$slug) {
                WFCA_Alerts::raise('PAID_ORDER_WEBHOOK_IDENTITY_CONFLICT','CRITICAL',(string)$o['lead_record_id'],(int)$o['conversation_id'],0,'','payment-paid-conflict:'.$order_nsu);
                return new WP_REST_Response(['success'=>false,'message'=>'paid_order_conflict'],400);
            }
            return new WP_REST_Response(['success'=>true,'message'=>null],200);
        }

        $is_new_candidate=(string)($o['pending_transaction_nsu']??'')!==$tx || (string)($o['pending_invoice_slug']??'')!==$slug;
        // Data minimization: persist identifiers + a one-way payload fingerprint,
        // not the full third-party webhook body.
        $audit=[
            'order_nsu'=>$order_nsu,'transaction_nsu'=>$tx,'invoice_slug'=>$slug,
            'received_at'=>WFCA_Util::now_iso(),'payload_hash'=>hash('sha256',WFCA_Util::json($data))
        ];
        $fields=[
            'state'=>'WEBHOOK_RECEIVED','pending_transaction_nsu'=>$tx,'pending_invoice_slug'=>$slug,
            'webhook_payload'=>WFCA_Util::json($audit),'next_verify_at'=>WFCA_Util::now_mysql(),'error'=>null
        ];
        if ($is_new_candidate) $fields['verify_attempts']=0;
        if (!WFCA_DB::update_order((int)$o['id'],$fields)) return new WP_REST_Response(['success'=>false,'message'=>'payment_persistence_failed'],500);
        wp_schedule_single_event(time()+1,'wfca_verify_order',[(int)$o['id']]);
        return new WP_REST_Response(['success'=>true,'message'=>null],200);
    }

    public static function run_permission(WP_REST_Request $request): bool {
        $secret=(string)WFCA_Util::c('WFCA_RUN_SECRET','');
        if ($secret==='') return current_user_can('manage_options');
        $given=(string)$request->get_header('x-wfca-run-secret');
        return $given!=='' && hash_equals($secret,$given);
    }

    public static function run(): WP_REST_Response {
        WFCA_Engine::tick();
        return new WP_REST_Response(['ok'=>true,'stats'=>WFCA_DB::stats(),'last_tick_at'=>get_option('wfca_last_tick_at')],200);
    }
}
